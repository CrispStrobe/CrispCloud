#!/usr/bin/env python3
"""Align a resolved package's generated runtime graph to the app's resolution.

Usage: python3 align_runtime_resolution.py APP PACKAGE_RELATIVE_PATH REPORT_JSON
Requires PyYAML and prior pub get in both APP and the package. Only the generated
package_config.json and requested report are written; manifests stay untouched.
"""
from pathlib import Path
import hashlib
import json
import sys
import urllib.parse

import yaml


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    app = Path(sys.argv[1]).resolve()
    package = app / sys.argv[2]
    report_path = Path(sys.argv[3])
    app_config_path = app / '.dart_tool/package_config.json'
    package_config_path = package / '.dart_tool/package_config.json'
    app_config = json.loads(app_config_path.read_text())
    package_config = json.loads(package_config_path.read_text())
    app_packages = {entry['name']: entry for entry in app_config['packages']}
    pending = list(yaml.safe_load((package / 'pubspec.yaml').read_text()).get('dependencies', {}))
    selected = {}
    report = {'package_config_before_sha256': digest(package_config_path),
              'runtime_dependencies': {}}
    while pending:
        name = pending.pop()
        if name in selected:
            continue
        entry = dict(app_packages[name])
        entry['rootUri'] = urllib.parse.urljoin(app_config_path.as_uri(), entry['rootUri'])
        selected[name] = entry
        root = Path(urllib.parse.unquote(urllib.parse.urlparse(entry['rootUri']).path))
        spec_path = root / 'pubspec.yaml'
        spec = yaml.safe_load(spec_path.read_text())
        pending.extend(spec.get('dependencies', {}))
        report['runtime_dependencies'][name] = {
            'version': str(spec.get('version')),
            'root_uri': entry['rootUri'],
            'pubspec_sha256': digest(spec_path),
        }
    package_config['packages'] = [selected.get(entry['name'], entry)
                                  for entry in package_config['packages']]
    package_config_path.write_text(json.dumps(package_config, indent=2) + '\n')
    report['package_config_after_sha256'] = digest(package_config_path)
    report_path.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
