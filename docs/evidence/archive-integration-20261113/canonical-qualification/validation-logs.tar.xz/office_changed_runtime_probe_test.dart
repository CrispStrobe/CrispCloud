// Qualification-only public API probes for canonical Quds 05a581de.
// Run from the CrispCloud checkout with its pinned Flutter and asset bundle.
import 'package:crisp_cloud/services/document_fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_editor/quds_office_editor.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('app registration keeps its actual Calibri and Roboto paint faces', () async {
    await DocumentFonts.ensureRegistered();
    expect(OfficeHostFonts.registeredFamily('Calibri'), 'Carlito');
    expect(OfficeHostFonts.registeredFamily('Roboto'), 'Roboto');
    for (final family in ['Calibri', 'Carlito', 'Roboto']) {
      expect(PaintRunText.familyFor(text: 'Example', runFamily: family), family);
    }
    expect(
      PaintRunText.familyFor(text: 'Example', runFamily: 'Unavailable face'),
      'Liberation Sans',
    );
    expect(
      PaintRunText.familyFor(text: 'مرحبا', runFamily: 'Unavailable face'),
      'Noto Naskh Arabic',
    );
  });

  for (final direction in [TextDirection.ltr, TextDirection.rtl]) {
    testWidgets('long bilingual shortcut stays usable in a 320px $direction menu', (
      tester,
    ) async {
      tester.view.physicalSize = const Size(320, 480);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.reset);
      const label = 'استعادة المستند ومتابعة التحرير — Restore document';
      const shortcut = 'Control + Shift + Alt + Command + Document action';
      final selected = <String>[];
      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: direction,
            child: Builder(
              builder: (context) => GestureDetector(
                key: const Key('open-menu'),
                behavior: HitTestBehavior.opaque,
                onTap: () => OfficeContextMenu.show(
                  context: context,
                  globalPosition: const Offset(16, 24),
                  actions: const [
                    OfficeContextAction(
                      id: 'restore',
                      label: label,
                      shortcut: shortcut,
                    ),
                  ],
                  onSelect: selected.add,
                ),
                child: const SizedBox.expand(),
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.byKey(const Key('open-menu')));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      expect(find.text(label).hitTestable(), findsOneWidget);
      final menu = tester.getRect(find.byKey(const Key('office-context-menu')));
      expect(menu.left, greaterThanOrEqualTo(0));
      expect(menu.right, lessThanOrEqualTo(320));
      await tester.tap(find.text(label));
      await tester.pumpAndSettle();
      expect(selected, ['restore']);
      expect(find.byKey(const Key('office-context-menu')), findsNothing);
      expect(tester.takeException(), isNull);
    });
  }
}
