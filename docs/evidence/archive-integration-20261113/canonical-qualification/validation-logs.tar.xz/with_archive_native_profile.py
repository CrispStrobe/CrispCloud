#!/usr/bin/env python3
"""Run one validation command with documented local hooks and restore manifests.

This local profile does not qualify native ebook conversion. The production
dependency graph, versions, source and native PTY compilation remain intact.
"""
import ctypes
import fcntl
import hashlib
import json
from pathlib import Path
import re
import signal
import subprocess
import sys

TOOLS = Path(__file__).resolve().parent
SMB = TOOLS / 'native-libs/libsmb2_linux-x86_64.so'
SMB_SHA = '4612ed4499f4c066d0db295679469c62545c6252849bfa61eb5f45ec1bbd3577'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def probe_sqlite():
    sqlite = ctypes.CDLL(str(TOOLS / 'native-libs/libsqlite3.so'))
    sqlite.sqlite3_libversion.restype = ctypes.c_char_p
    sqlite.sqlite3_open.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
    sqlite.sqlite3_close.argtypes = [ctypes.c_void_p]
    sqlite.sqlite3_exec.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p,
                                  ctypes.c_void_p, ctypes.POINTER(ctypes.c_char_p)]
    database = ctypes.c_void_p()
    if sqlite.sqlite3_open(b':memory:', ctypes.byref(database)):
        raise RuntimeError('System SQLite cannot open an in-memory database')
    try:
        status = sqlite.sqlite3_exec(database, b'PRAGMA foreign_keys=ON; CREATE TABLE p(id INTEGER PRIMARY KEY); '
                                    b'CREATE TABLE c(id INTEGER REFERENCES p(id)); BEGIN; '
                                    b'INSERT INTO p VALUES(1); INSERT INTO c VALUES(1); COMMIT;', None, None, None)
        if status:
            raise RuntimeError(f'System SQLite transaction probe failed: {status}')
        status = sqlite.sqlite3_exec(database, b'INSERT INTO c VALUES(99);', None, None, None)
        if status != 19:
            raise RuntimeError('System SQLite foreign-key enforcement probe failed')
        print('Local SQLite: ' + sqlite.sqlite3_libversion().decode() + '; transactions and foreign keys verified', flush=True)
    finally:
        sqlite.sqlite3_close(database)


def main():
    if len(sys.argv) < 3:
        raise SystemExit('Usage: with_archive_native_profile.sh CHECKOUT COMMAND [ARG ...]')
    checkout = Path(sys.argv[1]).resolve()
    command = sys.argv[2:]
    pubspec = checkout / 'pubspec.yaml'
    lock = checkout / 'pubspec.lock'
    if not pubspec.is_file() or not lock.is_file():
        raise RuntimeError('The checkout must contain pubspec.yaml and pubspec.lock')
    if sha(SMB.read_bytes()) != SMB_SHA:
        raise RuntimeError('Local libsmb2 does not match the repository-pinned SHA-256')
    probe_sqlite()
    lock_name = sha(str(checkout).encode())[:20]
    with (TOOLS / 'tmp' / f'profile-{lock_name}.lock').open('w') as profile_lock:
        fcntl.flock(profile_lock, fcntl.LOCK_EX)
        original = pubspec.read_bytes()
        original_lock = lock.read_bytes()
        if re.search(rb'^hooks\s*:', original, re.MULTILINE):
            raise RuntimeError('Existing hooks configuration requires explicit merging')
        hook = ('\nhooks:\n  user_defines:\n'
                '    crisp_ebook_conversion:\n      enabled: false\n'
                '    sqlite3:\n      source: system\n      name_windows: winsqlite3\n'
                f'    dart_smb2:\n      libsmb2: {json.dumps(str(SMB))}\n').encode()
        overlay = original.rstrip(b'\r\n') + b'\n' + hook
        status = 1
        print('Local archive validation profile: optional native ebook hook disabled; verified system SQLite and pinned libsmb2', flush=True)
        print('Original manifest SHA-256: ' + sha(original), flush=True)
        print('Original lockfile SHA-256: ' + sha(original_lock), flush=True)
        signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))
        try:
            pubspec.write_bytes(overlay)
            status = subprocess.run(command, cwd=checkout, check=False).returncode
        finally:
            current = pubspec.read_bytes()
            if current != overlay:
                backup = TOOLS / 'tmp' / f'profile-{lock_name}-original-pubspec.yaml'
                backup.write_bytes(original)
                raise RuntimeError(f'Pubspec changed concurrently; original preserved at {backup}; refusing to overwrite concurrent edits')
            pubspec.write_bytes(original)
            if lock.read_bytes() != original_lock:
                lock.write_bytes(original_lock)
                status = 1
                print('ERROR: validation changed pubspec.lock; restored original bytes; result is invalid', file=sys.stderr)
            print('Manifest and lockfile restored byte-for-byte', flush=True)
        return status


if __name__ == '__main__':
    sys.exit(main())
