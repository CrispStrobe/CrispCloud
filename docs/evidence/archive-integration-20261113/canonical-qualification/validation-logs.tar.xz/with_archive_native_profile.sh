#!/usr/bin/env bash
set -euo pipefail
CRISP_PROFILE_DIR="$(cd "$(dirname "$0")" && pwd)"
source "$CRISP_PROFILE_DIR/validation_env.sh"
exec python3 "$CRISP_PROFILE_DIR/with_archive_native_profile.py" "$@"
