#!/usr/bin/env python3
"""Package immutable official-head Office API, source and artifact observations."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'CrispCloud-final-next/docs/evidence/office-hosted-fb81b2ac-20261113'
OUT.mkdir(parents=True, exist_ok=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
records = {path.relative_to(ROOT / 'app-final-office-hosted').as_posix(): path.read_bytes()
           for path in sorted((ROOT / 'app-final-office-hosted').rglob('*')) if path.is_file()}
records['collection/download_app_ci_artifact.py'] = (ROOT / 'download_app_ci_artifact.py').read_bytes()
records['collection/seal_office_fb81_evidence.py'] = Path(__file__).read_bytes()
with tarfile.open(OUT / 'records.tar.xz', 'w:xz', preset=6) as archive:
    for name, data in sorted(records.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(data), 0o644, 0
        archive.addfile(member, io.BytesIO(data))
manifest = {'schemaVersion': 1, 'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(records.items())}}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
receipt = {
    'schemaVersion': 1, 'phase': 'host-and-external-complete',
    'measuredAppCommit': 'fb81b2ace557964459189afd7c0c7d76b2c9557d',
    'measuredAppTree': 'a14d066f1179ea00e20eaa3431aec0dd4fe05a5f',
    'measuredRuntimeCommit': '86d5a218853d8441afe8bc28f19cfe0adf4cd71e',
    'measuredRuntimeTree': '765bf752b0095233192d38e678941e7ca92a76b8',
    'parserCommit': 'c5ff75e76163d9abbdd44a9f2a7c5ad210929289', 'officeRunId': 43390627156,
    'metadataRecordCount': len(records), 'metadataUncompressedBytes': sum(map(len, records.values())),
    'files': {name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha((OUT / name).read_bytes())}
              for name in ['README.md', 'verify.py', 'test_verifier.py', 'manifest.json', 'records.tar.xz']},
}
for kind, filename in [('host', 'office-host-fb81b2ac.zip'), ('external', 'office-external-fb81b2ac.zip')]:
    raw = (ROOT / 'app-final-ci-downloads' / filename).read_bytes()
    parts = []
    for offset in range(0, len(raw), 3 * 1024 * 1024):
        data = raw[offset:offset + 3 * 1024 * 1024]
        name = f'{kind}-artifact.part{len(parts) + 1:02d}'
        (OUT / name).write_bytes(data)
        parts.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    receipt[kind + 'Parts'] = parts
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'metadataRecords': len(records), 'metadataRawBytes': sum(map(len, records.values())),
                  'metadataArchiveBytes': (OUT / 'records.tar.xz').stat().st_size,
                  'retainedZipBytes': sum(item['bytes'] for kind in ['host', 'external'] for item in receipt[kind + 'Parts'])}, indent=2))
