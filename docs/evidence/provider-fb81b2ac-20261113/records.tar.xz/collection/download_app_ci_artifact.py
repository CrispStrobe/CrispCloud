#!/usr/bin/env python3
"""Download one connector-selected artifact and inventory its exact ZIP bytes.

The temporary reference file contains an authorized signed URL and is never
included in the evidence bundle or printed. Public GitHub artifact metadata
supplies the expected archive size/digest and run identity.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import urllib.request
import zipfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference', type=Path)
    parser.add_argument('archive', type=Path)
    parser.add_argument('receipt', type=Path)
    args = parser.parse_args()
    reference = json.loads(args.reference.read_text())
    metadata = reference['artifact']
    expected_size = metadata['size_in_bytes']
    require(0 < expected_size <= 512 * 1024 * 1024, 'Artifact archive size is outside the collection bound')
    require(metadata['expired'] is False, 'Artifact expired')
    expected_digest = metadata['digest']
    require(expected_digest.startswith('sha256:') and len(expected_digest) == 71, 'Missing artifact digest')
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    digest = hashlib.sha256()
    with urllib.request.urlopen(reference['download_url'], timeout=120) as source, args.archive.open('xb') as target:
        while chunk := source.read(1024 * 1024):
            count += len(chunk)
            require(count <= expected_size, 'Download exceeds advertised artifact size')
            digest.update(chunk)
            target.write(chunk)
    require(count == expected_size, 'Truncated artifact download')
    require('sha256:' + digest.hexdigest() == expected_digest, 'GitHub/download ZIP digest mismatch')
    files = {}
    directories = []
    with zipfile.ZipFile(args.archive) as archive:
        entries = archive.infolist()
        require(len(entries) <= 25000, 'Artifact member bound exceeded')
        require(len({entry.filename for entry in entries}) == len(entries), 'Duplicate artifact member')
        require(sum(entry.file_size for entry in entries) <= 4 * 1024 ** 3, 'Artifact expansion bound exceeded')
        for entry in entries:
            path = PurePosixPath(entry.filename)
            require(not path.is_absolute() and '..' not in path.parts and '\\' not in entry.filename, 'Unsafe artifact path')
            mode = entry.external_attr >> 16
            require((mode & 0o170000) != 0o120000, 'Artifact symlink rejected')
            if entry.is_dir():
                directories.append(entry.filename)
                continue
            measured = hashlib.sha256()
            size = 0
            with archive.open(entry) as source:
                while chunk := source.read(1024 * 1024):
                    measured.update(chunk)
                    size += len(chunk)
            require(size == entry.file_size, 'Artifact member length mismatch')
            files[entry.filename] = {
                'bytes': size, 'sha256': measured.hexdigest(),
                'zipCompressedBytes': entry.compress_size, 'zipCrc32': entry.CRC,
                'zipCompression': entry.compress_type, 'zipExternalAttributes': entry.external_attr,
            }
    receipt = {
        'schemaVersion': 1, 'artifact': metadata, 'archiveFile': args.archive.name,
        'archiveBytes': count, 'archiveSha256': digest.hexdigest(),
        'fileCount': len(files), 'uncompressedBytes': sum(item['bytes'] for item in files.values()),
        'directories': directories, 'files': files,
    }
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: receipt[key] for key in ['archiveFile', 'archiveBytes', 'archiveSha256', 'fileCount', 'uncompressedBytes']}))


if __name__ == '__main__':
    main()
