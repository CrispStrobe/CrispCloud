#!/usr/bin/env python3
"""Seal immutable provider data and an explicitly dated Office queue snapshot."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'CrispCloud-final-next/docs/evidence/provider-fb81b2ac-20261113'
records = {}
for path in sorted((ROOT / 'app-final-official-ci').rglob('*')):
    if path.is_file() and path.name != 'provider-outputs.tar.xz':
        records[path.relative_to(ROOT / 'app-final-official-ci').as_posix()] = path.read_bytes()
for path in sorted((ROOT / 'app-final-queue-diagnosis').iterdir()):
    if path.is_file():
        records['queue/' + path.name] = path.read_bytes()
records['collection/download_app_ci_artifact.py'] = (ROOT / 'download_app_ci_artifact.py').read_bytes()
records['collection/seal_provider_fb81_evidence.py'] = Path(__file__).read_bytes()
archive = OUT / 'records.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as target:
    for name, data in sorted(records.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(data), 0o644, 0
        target.addfile(member, io.BytesIO(data))
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = {'schemaVersion': 1, 'files': {name: {'bytes': len(data), 'sha256': sha(data)}
                                        for name, data in sorted(records.items())}}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
raw = (ROOT / 'app-final-official-ci/provider-outputs.tar.xz').read_bytes()
parts = []
for offset in range(0, len(raw), 3 * 1024 * 1024):
    data = raw[offset:offset + 3 * 1024 * 1024]
    name = f'provider-outputs.part{len(parts) + 1:02d}'
    (OUT / name).write_bytes(data)
    parts.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
receipt = {
    'schemaVersion': 1,
    'measuredAppCommit': 'fb81b2ace557964459189afd7c0c7d76b2c9557d',
    'measuredAppTree': 'a14d066f1179ea00e20eaa3431aec0dd4fe05a5f',
    'parserCommit': 'c5ff75e76163d9abbdd44a9f2a7c5ad210929289',
    'scope': 'Actual provider outputs; ten known gaps and promotion_ready=false. Office was queued in the retained dated snapshot.',
    'providerRunId': 43390627091, 'providerArtifactId': 14020796791,
    'metadataRecordCount': len(records), 'metadataUncompressedBytes': sum(map(len, records.values())),
    'providerParts': parts,
    'files': {name: {'bytes': (OUT / name).stat().st_size, 'sha256': sha((OUT / name).read_bytes())}
              for name in ['README.md', 'verify.py', 'test_verifier.py', 'manifest.json', 'records.tar.xz']},
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'metadataRecords': len(records), 'metadataArchiveBytes': archive.stat().st_size,
                  'providerArchiveBytes': len(raw), 'providerParts': len(parts)}, indent=2))
