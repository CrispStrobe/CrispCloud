(function dartProgram(){function copyProperties(a,b){var s=Object.keys(a)
for(var r=0;r<s.length;r++){var q=s[r]
b[q]=a[q]}}function mixinPropertiesHard(a,b){var s=Object.keys(a)
for(var r=0;r<s.length;r++){var q=s[r]
if(!b.hasOwnProperty(q)){b[q]=a[q]}}}function mixinPropertiesEasy(a,b){Object.assign(b,a)}var z=function(){var s=function(){}
s.prototype={p:{}}
var r=new s()
if(!(Object.getPrototypeOf(r)&&Object.getPrototypeOf(r).p===s.prototype.p))return false
try{if(typeof navigator!="undefined"&&typeof navigator.userAgent=="string"&&navigator.userAgent.indexOf("Chrome/")>=0)return true
if(typeof version=="function"&&version.length==0){var q=version()
if(/^\d+\.\d+\.\d+\.\d+$/.test(q))return true}}catch(p){}return false}()
function inherit(a,b){a.prototype.constructor=a
a.prototype["$i"+a.name]=a
if(b!=null){if(z){Object.setPrototypeOf(a.prototype,b.prototype)
return}var s=Object.create(b.prototype)
copyProperties(a.prototype,s)
a.prototype=s}}function inheritMany(a,b){for(var s=0;s<b.length;s++){inherit(b[s],a)}}function mixinEasy(a,b){mixinPropertiesEasy(b.prototype,a.prototype)
a.prototype.constructor=a}function mixinHard(a,b){mixinPropertiesHard(b.prototype,a.prototype)
a.prototype.constructor=a}function lazy(a,b,c,d){var s=a
a[b]=s
a[c]=function(){if(a[b]===s){a[b]=d()}a[c]=function(){return this[b]}
return a[b]}}function lazyFinal(a,b,c,d){var s=a
a[b]=s
a[c]=function(){if(a[b]===s){var r=d()
if(a[b]!==s){A.m_(b)}a[b]=r}var q=a[b]
a[c]=function(){return q}
return q}}function makeConstList(a,b){if(b!=null)A.h(a,b)
a.$flags=7
return a}function convertToFastObject(a){function t(){}t.prototype=a
new t()
return a}function convertAllToFastObject(a){for(var s=0;s<a.length;++s){convertToFastObject(a[s])}}var y=0
function instanceTearOffGetter(a,b){var s=null
return a?function(c){if(s===null)s=A.i0(b)
return new s(c,this)}:function(){if(s===null)s=A.i0(b)
return new s(this,null)}}function staticTearOffGetter(a){var s=null
return function(){if(s===null)s=A.i0(a).prototype
return s}}var x=0
function tearOffParameters(a,b,c,d,e,f,g,h,i,j){if(typeof h=="number"){h+=x}return{co:a,iS:b,iI:c,rC:d,dV:e,cs:f,fs:g,fT:h,aI:i||0,nDA:j}}function installStaticTearOff(a,b,c,d,e,f,g,h){var s=tearOffParameters(a,true,false,c,d,e,f,g,h,false)
var r=staticTearOffGetter(s)
a[b]=r}function installInstanceTearOff(a,b,c,d,e,f,g,h,i,j){c=!!c
var s=tearOffParameters(a,false,c,d,e,f,g,h,i,!!j)
var r=instanceTearOffGetter(c,s)
a[b]=r}function setOrUpdateInterceptorsByTag(a){var s=v.interceptorsByTag
if(!s){v.interceptorsByTag=a
return}copyProperties(a,s)}function setOrUpdateLeafTags(a){var s=v.leafTags
if(!s){v.leafTags=a
return}copyProperties(a,s)}function updateTypes(a){var s=v.types
var r=s.length
s.push.apply(s,a)
return r}function updateHolder(a,b){copyProperties(b,a)
return a}var hunkHelpers=function(){var s=function(a,b,c,d,e){return function(f,g,h,i){return installInstanceTearOff(f,g,a,b,c,d,[h],i,e,false)}},r=function(a,b,c,d){return function(e,f,g,h){return installStaticTearOff(e,f,a,b,c,[g],h,d)}}
return{inherit:inherit,inheritMany:inheritMany,mixin:mixinEasy,mixinHard:mixinHard,installStaticTearOff:installStaticTearOff,installInstanceTearOff:installInstanceTearOff,_instance_0u:s(0,0,null,["$0"],0),_instance_1u:s(0,1,null,["$1"],0),_instance_2u:s(0,2,null,["$2"],0),_instance_0i:s(1,0,null,["$0"],0),_instance_1i:s(1,1,null,["$1"],0),_instance_2i:s(1,2,null,["$2"],0),_static_0:r(0,null,["$0"],0),_static_1:r(1,null,["$1"],0),_static_2:r(2,null,["$2"],0),makeConstList:makeConstList,lazy:lazy,lazyFinal:lazyFinal,updateHolder:updateHolder,convertToFastObject:convertToFastObject,updateTypes:updateTypes,setOrUpdateInterceptorsByTag:setOrUpdateInterceptorsByTag,setOrUpdateLeafTags:setOrUpdateLeafTags}}()
function initializeDeferredHunk(a){x=v.types.length
a(hunkHelpers,v,w,$)}var J={
i3(a,b,c,d){return{i:a,p:b,e:c,x:d}},
fD(a){var s,r,q,p,o,n="_$dart_js",m=a[v.dispatchPropertyName]
if(m==null)if($.i1==null){A.lR()
m=a[v.dispatchPropertyName]}if(m!=null){s=m.p
if(!1===s)return m.i
if(!0===s)return a
r=Object.getPrototypeOf(a)
if(s===r)return m.i
if(m.e===r)throw A.c(A.iv("Return interceptor for "+A.y(s(a,m))))}q=a.constructor
if(q==null)p=null
else{o=$.eV
if(o==null)o=$.eV=A.fC(n)
p=q[o]}if(p!=null)return p
p=A.lW(a)
if(p!=null)return p
if(typeof a=="function")return B.O
s=Object.getPrototypeOf(a)
if(s==null)return B.x
if(s===Object.prototype)return B.x
if(typeof q=="function"){o=$.eV
if(o==null)o=$.eV=A.fC(n)
Object.defineProperty(q,o,{value:B.o,enumerable:false,writable:true,configurable:true})
return B.o}return B.o},
jT(a,b){if(a<0||a>4294967295)throw A.c(A.bj(a,0,4294967295,"length",null))
return J.jU(new Array(a),b)},
hC(a,b){if(a<0)throw A.c(A.cw("Length must be a non-negative integer: "+a,null))
return A.h(new Array(a),b.h("D<0>"))},
jU(a,b){var s=A.h(a,b.h("D<0>"))
s.$flags=1
return s},
ba(a){if(typeof a=="number"){if(Math.floor(a)==a)return J.bN.prototype
return J.cK.prototype}if(typeof a=="string")return J.be.prototype
if(a==null)return J.bO.prototype
if(typeof a=="boolean")return J.cJ.prototype
if(Array.isArray(a))return J.D.prototype
if(typeof a!="object"){if(typeof a=="function")return J.as.prototype
if(typeof a=="symbol")return J.bg.prototype
if(typeof a=="bigint")return J.bf.prototype
return a}if(a instanceof A.d)return a
return J.fD(a)},
j9(a){if(typeof a=="string")return J.be.prototype
if(a==null)return a
if(Array.isArray(a))return J.D.prototype
if(typeof a!="object"){if(typeof a=="function")return J.as.prototype
if(typeof a=="symbol")return J.bg.prototype
if(typeof a=="bigint")return J.bf.prototype
return a}if(a instanceof A.d)return a
return J.fD(a)},
cu(a){if(a==null)return a
if(Array.isArray(a))return J.D.prototype
if(typeof a!="object"){if(typeof a=="function")return J.as.prototype
if(typeof a=="symbol")return J.bg.prototype
if(typeof a=="bigint")return J.bf.prototype
return a}if(a instanceof A.d)return a
return J.fD(a)},
ja(a){if(a==null)return a
if(typeof a!="object"){if(typeof a=="function")return J.as.prototype
if(typeof a=="symbol")return J.bg.prototype
if(typeof a=="bigint")return J.bf.prototype
return a}if(a instanceof A.d)return a
return J.fD(a)},
aB(a,b){if(a==null)return b==null
if(typeof a!="object")return b!=null&&a===b
return J.ba(a).S(a,b)},
jz(a,b){if(typeof b==="number")if(Array.isArray(a)||A.lU(a,a[v.dispatchPropertyName]))if(b>>>0===b&&b<a.length)return a[b]
return J.cu(a).u(a,b)},
hA(a,b,c){return J.cu(a).v(a,b,c)},
i7(a,b){return J.cu(a).m(a,b)},
jA(a,b,c){return J.ja(a).cj(a,b,c)},
jB(a){return J.ja(a).ck(a)},
i8(a,b){return J.cu(a).U(a,b)},
an(a){return J.ba(a).gC(a)},
jC(a){return J.cu(a).gcv(a)},
df(a){return J.cu(a).gF(a)},
aC(a){return J.j9(a).gk(a)},
jD(a){return J.ba(a).gZ(a)},
cv(a){return J.ba(a).i(a)},
cH:function cH(){},
cJ:function cJ(){},
bO:function bO(){},
bQ:function bQ(){},
aE:function aE(){},
cP:function cP(){},
c2:function c2(){},
as:function as(){},
bf:function bf(){},
bg:function bg(){},
D:function D(a){this.$ti=a},
cI:function cI(){},
dp:function dp(a){this.$ti=a},
bG:function bG(a,b,c){var _=this
_.a=a
_.b=b
_.c=0
_.d=null
_.$ti=c},
bP:function bP(){},
bN:function bN(){},
cK:function cK(){},
be:function be(){}},A={hD:function hD(){},
jW(a){return new A.aS("Field '"+a+"' has not been initialized.")},
jV(a){return new A.aS("Field '"+a+"' has already been initialized.")},
aH(a,b){a=a+b&536870911
a=a+((a&524287)<<10)&536870911
return a^a>>>6},
hL(a){a=a+((a&67108863)<<3)&536870911
a^=a>>>11
return a+((a&16383)<<15)&536870911},
db(a,b,c){return a},
i2(a){var s,r
for(s=$.aa.length,r=0;r<s;++r)if(a===$.aa[r])return!0
return!1},
it(a,b,c,d){A.dG(b,"start")
if(c!=null){A.dG(c,"end")
if(b>c)A.b(A.bj(b,0,c,"start",null))}return new A.c1(a,b,c,d.h("c1<0>"))},
bM(){return new A.Z("No element")},
jR(){return new A.Z("Too many elements")},
jQ(){return new A.Z("Too few elements")},
aS:function aS(a){this.a=a},
hw:function hw(){},
dI:function dI(){},
bJ:function bJ(){},
a3:function a3(){},
c1:function c1(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.$ti=d},
aW:function aW(a,b,c){var _=this
_.a=a
_.b=b
_.c=0
_.d=null
_.$ti=c},
bU:function bU(a,b,c){this.a=a
this.b=b
this.$ti=c},
a6:function a6(a,b,c){this.a=a
this.b=b
this.$ti=c},
c4:function c4(a,b,c){this.a=a
this.b=b
this.$ti=c},
bL:function bL(){},
jL(){throw A.c(A.c3("Cannot modify unmodifiable Map"))},
jj(a){var s=A.ji(a)
if(s!=null)return s
return"minified:"+a},
lU(a,b){var s
if(b!=null){s=b.x
if(s!=null)return s}return t.aU.b(a)},
y(a){var s
if(typeof a=="string")return a
if(typeof a=="number"){if(a!==0)return""+a}else if(!0===a)return"true"
else if(!1===a)return"false"
else if(a==null)return"null"
s=J.cv(a)
return s},
bZ(a){var s,r=$.im
if(r==null)r=$.im=Symbol("identityHashCode")
s=a[r]
if(s==null){s=Math.random()*0x3fffffff|0
a[r]=s}return s},
cQ(a){var s,r,q,p
if(a instanceof A.d)return A.a9(A.bB(a),null)
s=J.ba(a)
if(s===B.N||s===B.P||t.ak.b(a)){r=B.q(a)
if(r!=="Object"&&r!=="")return r
q=a.constructor
if(typeof q=="function"){p=q.name
if(typeof p=="string"&&p!=="Object"&&p!=="")return p}}return A.a9(A.bB(a),null)},
io(a){var s,r,q
if(a==null||typeof a=="number"||A.hV(a))return J.cv(a)
if(typeof a=="string")return JSON.stringify(a)
if(a instanceof A.aD)return a.i(0)
if(a instanceof A.b6)return a.cc(!0)
s=$.jx()
for(r=0;r<1;++r){q=s[r].e6(a)
if(q!=null)return q}return"Instance of '"+A.cQ(a)+"'"},
k_(){return Date.now()},
k1(){var s,r
if($.dE!==0)return
$.dE=1000
if(typeof window=="undefined")return
s=window
if(s==null)return
if(!!s.dartUseDateNowForTicks)return
r=s.performance
if(r==null)return
if(typeof r.now!="function")return
$.dE=1e6
$.hI=new A.dD(r)},
R(a){var s
if(a<=65535)return String.fromCharCode(a)
if(a<=1114111){s=a-65536
return String.fromCharCode((B.e.c8(s,10)|55296)>>>0,s&1023|56320)}throw A.c(A.bj(a,0,1114111,null,null))},
k0(a){var s=a.$thrownJsError
if(s==null)return null
return A.P(s)},
dF(a,b){var s
if(a.$thrownJsError==null){s=new Error()
A.M(a,s)
a.$thrownJsError=s
s.stack=b.i(0)}},
de(a){throw A.c(A.lq(a))},
z(a,b){if(a==null)J.aC(a)
throw A.c(A.fA(a,b))},
fA(a,b){var s,r="index",q=null
if(!A.iV(b))return new A.ab(!0,b,r,q)
s=A.ar(J.aC(a))
if(b<0||b>=s)return A.dm(b,s,a,q,r)
return new A.aG(q,q,!0,b,r,"Value not in range")},
lq(a){return new A.ab(!0,a,null,null)},
c(a){return A.M(a,new Error())},
M(a,b){var s
if(a==null)a=new A.au()
b.dartException=a
s=A.m0
if("defineProperty" in Object){Object.defineProperty(b,"message",{get:s})
b.name=""}else b.toString=s
return b},
m0(){return J.cv(this.dartException)},
b(a,b){throw A.M(a,b==null?new Error():b)},
aP(a,b,c){var s
if(b==null)b=0
if(c==null)c=0
s=Error()
A.b(A.kM(a,b,c),s)},
kM(a,b,c){var s,r,q,p,o,n,m,l,k
if(typeof b=="string")s=b
else{r="[]=;add;removeWhere;retainWhere;removeRange;setRange;setInt8;setInt16;setInt32;setUint8;setUint16;setUint32;setFloat32;setFloat64".split(";")
q=r.length
p=b
if(p>q){c=p/q|0
p%=q}s=r[p]}o=typeof c=="string"?c:"modify;remove from;add to".split(";")[c]
n=t.j.b(a)?"list":"ByteData"
m=a.$flags|0
l="a "
if((m&4)!==0)k="constant "
else if((m&2)!==0){k="unmodifiable "
l="an "}else k=(m&1)!==0?"fixed-length ":""
return new A.aK("'"+s+"': Cannot "+o+" "+l+k+n)},
W(a){throw A.c(A.X(a))},
av(a){var s,r,q,p,o,n
a=A.lZ(a.replace(String({}),"$receiver$"))
s=a.match(/\\\$[a-zA-Z]+\\\$/g)
if(s==null)s=A.h([],t.W)
r=s.indexOf("\\$arguments\\$")
q=s.indexOf("\\$argumentsExpr\\$")
p=s.indexOf("\\$expr\\$")
o=s.indexOf("\\$method\\$")
n=s.indexOf("\\$receiver\\$")
return new A.dW(a.replace(new RegExp("\\\\\\$arguments\\\\\\$","g"),"((?:x|[^x])*)").replace(new RegExp("\\\\\\$argumentsExpr\\\\\\$","g"),"((?:x|[^x])*)").replace(new RegExp("\\\\\\$expr\\\\\\$","g"),"((?:x|[^x])*)").replace(new RegExp("\\\\\\$method\\\\\\$","g"),"((?:x|[^x])*)").replace(new RegExp("\\\\\\$receiver\\\\\\$","g"),"((?:x|[^x])*)"),r,q,p,o,n)},
dX(a){return function($expr$){var $argumentsExpr$="$arguments$"
try{$expr$.$method$($argumentsExpr$)}catch(s){return s.message}}(a)},
iu(a){return function($expr$){try{$expr$.$method$}catch(s){return s.message}}(a)},
hE(a,b){var s=b==null,r=s?null:b.method
return new A.cM(a,r,s?null:b.receiver)},
O(a){var s
if(a==null)return new A.dC(a)
if(a instanceof A.bK){s=a.a
return A.aO(a,s==null?A.G(s):s)}if(typeof a!=="object")return a
if("dartException" in a)return A.aO(a,a.dartException)
return A.lp(a)},
aO(a,b){if(t.C.b(b))if(b.$thrownJsError==null)b.$thrownJsError=a
return b},
lp(a){var s,r,q,p,o,n,m,l,k,j,i,h,g
if(!("message" in a))return a
s=a.message
if("number" in a&&typeof a.number=="number"){r=a.number
q=r&65535
if((B.e.c8(r,16)&8191)===10)switch(q){case 438:return A.aO(a,A.hE(A.y(s)+" (Error "+q+")",null))
case 445:case 5007:A.y(s)
return A.aO(a,new A.bY())}}if(a instanceof TypeError){p=$.jn()
o=$.jo()
n=$.jp()
m=$.jq()
l=$.jt()
k=$.ju()
j=$.js()
$.jr()
i=$.jw()
h=$.jv()
g=p.R(s)
if(g!=null)return A.aO(a,A.hE(A.bx(s),g))
else{g=o.R(s)
if(g!=null){g.method="call"
return A.aO(a,A.hE(A.bx(s),g))}else if(n.R(s)!=null||m.R(s)!=null||l.R(s)!=null||k.R(s)!=null||j.R(s)!=null||m.R(s)!=null||i.R(s)!=null||h.R(s)!=null){A.bx(s)
return A.aO(a,new A.bY())}}return A.aO(a,new A.cV(typeof s=="string"?s:""))}if(a instanceof RangeError){if(typeof s=="string"&&s.indexOf("call stack")!==-1)return new A.c0()
s=function(b){try{return String(b)}catch(f){}return null}(a)
return A.aO(a,new A.ab(!1,null,null,typeof s=="string"?s.replace(/^RangeError:\s*/,""):s))}if(typeof InternalError=="function"&&a instanceof InternalError)if(typeof s=="string"&&s==="too much recursion")return new A.c0()
return a},
P(a){var s
if(a instanceof A.bK)return a.b
if(a==null)return new A.cf(a)
s=a.$cachedTrace
if(s!=null)return s
s=new A.cf(a)
if(typeof a==="object")a.$cachedTrace=s
return s},
jc(a){if(a==null)return J.an(a)
if(typeof a=="object")return A.bZ(a)
return J.an(a)},
lN(a,b){var s,r,q,p=a.length
for(s=0;s<p;s=q){r=s+1
q=r+1
b.v(0,a[s],a[r])}return b},
kU(a,b,c,d,e,f){t.a.a(a)
switch(A.ar(b)){case 0:return a.$0()
case 1:return a.$1(c)
case 2:return a.$2(c,d)
case 3:return a.$3(c,d,e)
case 4:return a.$4(c,d,e,f)}throw A.c(new A.eE("Unsupported number of arguments for wrapped closure"))},
cs(a,b){var s=a.$identity
if(!!s)return s
s=A.lI(a,b)
a.$identity=s
return s},
lI(a,b){var s
switch(b){case 0:s=a.$0
break
case 1:s=a.$1
break
case 2:s=a.$2
break
case 3:s=a.$3
break
case 4:s=a.$4
break
default:s=null}if(s!=null)return s.bind(a)
return function(c,d,e){return function(f,g,h,i){return e(c,d,f,g,h,i)}}(a,b,A.kU)},
jK(a2){var s,r,q,p,o,n,m,l,k,j,i=a2.co,h=a2.iS,g=a2.iI,f=a2.nDA,e=a2.aI,d=a2.fs,c=a2.cs,b=d[0],a=c[0],a0=i[b],a1=a2.fT
a1.toString
s=h?Object.create(new A.cS().constructor.prototype):Object.create(new A.bd(null,null).constructor.prototype)
s.$initialize=s.constructor
r=h?function static_tear_off(){this.$initialize()}:function tear_off(a3,a4){this.$initialize(a3,a4)}
s.constructor=r
r.prototype=s
s.$_name=b
s.$_target=a0
q=!h
if(q)p=A.ie(b,a0,g,f)
else{s.$static_name=b
p=a0}s.$S=A.jG(a1,h,g)
s[a]=p
for(o=p,n=1;n<d.length;++n){m=d[n]
if(typeof m=="string"){l=i[m]
k=m
m=l}else k=""
j=c[n]
if(j!=null){if(q)m=A.ie(k,m,g,f)
s[j]=m}if(n===e)o=m}s.$C=o
s.$R=a2.rC
s.$D=a2.dV
return r},
jG(a,b,c){if(typeof a=="number")return a
if(typeof a=="string"){if(b)throw A.c("Cannot compute signature for static tearoff.")
return function(d,e){return function(){return e(this,d)}}(a,A.jE)}throw A.c("Error in functionType of tearoff")},
jH(a,b,c,d){var s=A.id
switch(b?-1:a){case 0:return function(e,f){return function(){return f(this)[e]()}}(c,s)
case 1:return function(e,f){return function(g){return f(this)[e](g)}}(c,s)
case 2:return function(e,f){return function(g,h){return f(this)[e](g,h)}}(c,s)
case 3:return function(e,f){return function(g,h,i){return f(this)[e](g,h,i)}}(c,s)
case 4:return function(e,f){return function(g,h,i,j){return f(this)[e](g,h,i,j)}}(c,s)
case 5:return function(e,f){return function(g,h,i,j,k){return f(this)[e](g,h,i,j,k)}}(c,s)
default:return function(e,f){return function(){return e.apply(f(this),arguments)}}(d,s)}},
ie(a,b,c,d){if(c)return A.jJ(a,b,d)
return A.jH(b.length,d,a,b)},
jI(a,b,c,d){var s=A.id,r=A.jF
switch(b?-1:a){case 0:throw A.c(new A.cR("Intercepted function with no arguments."))
case 1:return function(e,f,g){return function(){return f(this)[e](g(this))}}(c,r,s)
case 2:return function(e,f,g){return function(h){return f(this)[e](g(this),h)}}(c,r,s)
case 3:return function(e,f,g){return function(h,i){return f(this)[e](g(this),h,i)}}(c,r,s)
case 4:return function(e,f,g){return function(h,i,j){return f(this)[e](g(this),h,i,j)}}(c,r,s)
case 5:return function(e,f,g){return function(h,i,j,k){return f(this)[e](g(this),h,i,j,k)}}(c,r,s)
case 6:return function(e,f,g){return function(h,i,j,k,l){return f(this)[e](g(this),h,i,j,k,l)}}(c,r,s)
default:return function(e,f,g){return function(){var q=[g(this)]
Array.prototype.push.apply(q,arguments)
return e.apply(f(this),q)}}(d,r,s)}},
jJ(a,b,c){var s,r
if($.ib==null)$.ib=A.ia("interceptor")
if($.ic==null)$.ic=A.ia("receiver")
s=b.length
r=A.jI(s,c,a,b)
return r},
i0(a){return A.jK(a)},
jE(a,b){return A.co(v.typeUniverse,A.bB(a.a),b)},
id(a){return a.a},
jF(a){return a.b},
ia(a){var s,r,q,p=new A.bd("receiver","interceptor"),o=Object.getOwnPropertyNames(p)
o.$flags=1
s=o
for(o=s.length,r=0;r<o;++r){q=s[r]
if(p[q]===a)return q}throw A.c(A.cw("Field name "+a+" not found.",null))},
fC(a){return v.getIsolateTag(a)},
mq(a,b,c){Object.defineProperty(a,b,{value:c,enumerable:false,writable:true,configurable:true})},
lW(a){var s,r,q,p,o,n=A.bx($.jb.$1(a)),m=$.fB[n]
if(m!=null){Object.defineProperty(a,v.dispatchPropertyName,{value:m,enumerable:false,writable:true,configurable:true})
return m.i}s=$.fH[n]
if(s!=null)return s
r=v.interceptorsByTag[n]
if(r==null){q=A.iO($.j4.$2(a,n))
if(q!=null){m=$.fB[q]
if(m!=null){Object.defineProperty(a,v.dispatchPropertyName,{value:m,enumerable:false,writable:true,configurable:true})
return m.i}s=$.fH[q]
if(s!=null)return s
r=v.interceptorsByTag[q]
n=q}}if(r==null)return null
s=r.prototype
p=n[0]
if(p==="!"){m=A.hv(s)
$.fB[n]=m
Object.defineProperty(a,v.dispatchPropertyName,{value:m,enumerable:false,writable:true,configurable:true})
return m.i}if(p==="~"){$.fH[n]=s
return s}if(p==="-"){o=A.hv(s)
Object.defineProperty(Object.getPrototypeOf(a),v.dispatchPropertyName,{value:o,enumerable:false,writable:true,configurable:true})
return o.i}if(p==="+")return A.jd(a,s)
if(p==="*")throw A.c(A.iv(n))
if(v.leafTags[n]===true){o=A.hv(s)
Object.defineProperty(Object.getPrototypeOf(a),v.dispatchPropertyName,{value:o,enumerable:false,writable:true,configurable:true})
return o.i}else return A.jd(a,s)},
jd(a,b){var s=Object.getPrototypeOf(a)
Object.defineProperty(s,v.dispatchPropertyName,{value:J.i3(b,s,null,null),enumerable:false,writable:true,configurable:true})
return b},
hv(a){return J.i3(a,!1,null,!!a.$icL)},
lY(a,b,c){var s=b.prototype
if(v.leafTags[a]===true)return A.hv(s)
else return J.i3(s,c,null,null)},
lR(){if(!0===$.i1)return
$.i1=!0
A.lS()},
lS(){var s,r,q,p,o,n,m,l
$.fB=Object.create(null)
$.fH=Object.create(null)
A.lQ()
s=v.interceptorsByTag
r=Object.getOwnPropertyNames(s)
if(typeof window!="undefined"){window
q=function(){}
for(p=0;p<r.length;++p){o=r[p]
n=$.jg.$1(o)
if(n!=null){m=A.lY(o,s[o],n)
if(m!=null){Object.defineProperty(n,v.dispatchPropertyName,{value:m,enumerable:false,writable:true,configurable:true})
q.prototype=n}}}}for(p=0;p<r.length;++p){o=r[p]
if(/^[A-Za-z_]/.test(o)){l=s[o]
s["!"+o]=l
s["~"+o]=l
s["-"+o]=l
s["+"+o]=l
s["*"+o]=l}}},
lQ(){var s,r,q,p,o,n,m=B.y()
m=A.bA(B.z,A.bA(B.A,A.bA(B.r,A.bA(B.r,A.bA(B.B,A.bA(B.C,A.bA(B.D(B.q),m)))))))
if(typeof dartNativeDispatchHooksTransformer!="undefined"){s=dartNativeDispatchHooksTransformer
if(typeof s=="function")s=[s]
if(Array.isArray(s))for(r=0;r<s.length;++r){q=s[r]
if(typeof q=="function")m=q(m)||m}}p=m.getTag
o=m.getUnknownTag
n=m.prototypeForTag
$.jb=new A.fE(p)
$.j4=new A.fF(o)
$.jg=new A.fG(n)},
bA(a,b){return a(b)||b},
lK(a,b){var s=b.length,r=v.rttc[""+s+";"+a]
if(r==null)return null
if(s===0)return r
if(s===r.length)return r.apply(null,b)
return r(b)},
lZ(a){if(/[[\]{}()*+?.\\^$|]/.test(a))return a.replace(/[[\]{}()*+?.\\^$|]/g,"\\$&")
return a},
bt:function bt(a,b){this.a=a
this.b=b},
bH:function bH(){},
bI:function bI(a,b,c){this.a=a
this.b=b
this.$ti=c},
dD:function dD(a){this.a=a},
c_:function c_(){},
dW:function dW(a,b,c,d,e,f){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=e
_.f=f},
bY:function bY(){},
cM:function cM(a,b,c){this.a=a
this.b=b
this.c=c},
cV:function cV(a){this.a=a},
dC:function dC(a){this.a=a},
bK:function bK(a,b){this.a=a
this.b=b},
cf:function cf(a){this.a=a
this.b=null},
aD:function aD(){},
cA:function cA(){},
cB:function cB(){},
cT:function cT(){},
cS:function cS(){},
bd:function bd(a,b){this.a=a
this.b=b},
cR:function cR(a){this.a=a},
aR:function aR(a){var _=this
_.a=0
_.f=_.e=_.d=_.c=_.b=null
_.r=0
_.$ti=a},
ds:function ds(a,b){var _=this
_.a=a
_.b=b
_.d=_.c=null},
aT:function aT(a,b){this.a=a
this.$ti=b},
at:function at(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.d=null
_.$ti=d},
aV:function aV(a,b){this.a=a
this.$ti=b},
aU:function aU(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.d=null
_.$ti=d},
bS:function bS(a,b){this.a=a
this.$ti=b},
bT:function bT(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.d=null
_.$ti=d},
fE:function fE(a){this.a=a},
fF:function fF(a){this.a=a},
fG:function fG(a){this.a=a},
b6:function b6(){},
bs:function bs(){},
m_(a){throw A.M(new A.aS("Field '"+a+"' has been assigned during initialization."),new Error())},
x(){throw A.M(A.jW(""),new Error())},
hy(){throw A.M(A.jV(""),new Error())},
kf(){var s=new A.ez()
return s.b=s},
ez:function ez(){this.b=null},
jZ(a,b,c){var s=new Uint8Array(a,b,c)
return s},
iQ(a,b,c){if(a>>>0!==a||a>=c)throw A.c(A.fA(b,a))},
aZ:function aZ(){},
bW:function bW(){},
fc:function fc(a){this.a=a},
bi:function bi(){},
bV:function bV(){},
bX:function bX(){},
cc:function cc(){},
cd:function cd(){},
hJ(a,b){var s=b.c
return s==null?b.c=A.cm(a,"K",[b.x]):s},
ip(a){var s=a.w
if(s===6||s===7)return A.ip(a.x)
return s===11||s===12},
k2(a){return a.as},
dd(a){return A.fb(v.typeUniverse,a,!1)},
b8(a1,a2,a3,a4){var s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0=a2.w
switch(a0){case 5:case 1:case 2:case 3:case 4:return a2
case 6:s=a2.x
r=A.b8(a1,s,a3,a4)
if(r===s)return a2
return A.iF(a1,r,!0)
case 7:s=a2.x
r=A.b8(a1,s,a3,a4)
if(r===s)return a2
return A.iE(a1,r,!0)
case 8:q=a2.y
p=A.bz(a1,q,a3,a4)
if(p===q)return a2
return A.cm(a1,a2.x,p)
case 9:o=a2.x
n=A.b8(a1,o,a3,a4)
m=a2.y
l=A.bz(a1,m,a3,a4)
if(n===o&&l===m)return a2
return A.hR(a1,n,l)
case 10:k=a2.x
j=a2.y
i=A.bz(a1,j,a3,a4)
if(i===j)return a2
return A.iG(a1,k,i)
case 11:h=a2.x
g=A.b8(a1,h,a3,a4)
f=a2.y
e=A.lm(a1,f,a3,a4)
if(g===h&&e===f)return a2
return A.iD(a1,g,e)
case 12:d=a2.y
a4+=d.length
c=A.bz(a1,d,a3,a4)
o=a2.x
n=A.b8(a1,o,a3,a4)
if(c===d&&n===o)return a2
return A.hS(a1,n,c,!0)
case 13:b=a2.x
if(b<a4)return a2
a=a3[b-a4]
if(a==null)return a2
return a
default:throw A.c(A.cy("Attempted to substitute unexpected RTI kind "+a0))}},
bz(a,b,c,d){var s,r,q,p,o=b.length,n=A.fd(o)
for(s=!1,r=0;r<o;++r){q=b[r]
p=A.b8(a,q,c,d)
if(p!==q)s=!0
n[r]=p}return s?n:b},
ln(a,b,c,d){var s,r,q,p,o,n,m=b.length,l=A.fd(m)
for(s=!1,r=0;r<m;r+=3){q=b[r]
p=b[r+1]
o=b[r+2]
n=A.b8(a,o,c,d)
if(n!==o)s=!0
l.splice(r,3,q,p,n)}return s?l:b},
lm(a,b,c,d){var s,r=b.a,q=A.bz(a,r,c,d),p=b.b,o=A.bz(a,p,c,d),n=b.c,m=A.ln(a,n,c,d)
if(q===r&&o===p&&m===n)return b
s=new A.d3()
s.a=q
s.b=o
s.c=m
return s},
h(a,b){a[v.arrayRti]=b
return a},
j8(a){var s=a.$S
if(s!=null){if(typeof s=="number")return A.lP(s)
return a.$S()}return null},
lT(a,b){var s
if(A.ip(b))if(a instanceof A.aD){s=A.j8(a)
if(s!=null)return s}return A.bB(a)},
bB(a){if(a instanceof A.d)return A.e(a)
if(Array.isArray(a))return A.V(a)
return A.hT(J.ba(a))},
V(a){var s=a[v.arrayRti],r=t.b
if(s==null)return r
if(s.constructor!==r.constructor)return r
return s},
e(a){var s=a.$ti
return s!=null?s:A.hT(a)},
hT(a){var s=a.constructor,r=s.$ccache
if(r!=null)return r
return A.kT(a,s)},
kT(a,b){var s=a instanceof A.aD?Object.getPrototypeOf(Object.getPrototypeOf(a)).constructor:b,r=A.kC(v.typeUniverse,s.name)
b.$ccache=r
return r},
lP(a){var s,r=v.types,q=r[a]
if(typeof q=="string"){s=A.fb(v.typeUniverse,q,!1)
r[a]=s
return s}return q},
lO(a){return A.b9(A.e(a))},
i_(a){var s
if(a instanceof A.b6)return A.lL(a.$r,a.bR())
s=a instanceof A.aD?A.j8(a):null
if(s!=null)return s
if(t.dm.b(a))return J.jD(a).a
if(Array.isArray(a))return A.V(a)
return A.bB(a)},
b9(a){var s=a.r
return s==null?a.r=new A.fa(a):s},
lL(a,b){var s,r,q=b,p=q.length
if(p===0)return t.bQ
if(0>=p)return A.z(q,0)
s=A.co(v.typeUniverse,A.i_(q[0]),"@<0>")
for(r=1;r<p;++r){if(!(r<q.length))return A.z(q,r)
s=A.iI(v.typeUniverse,s,A.i_(q[r]))}return A.co(v.typeUniverse,s,a)},
i4(a){return A.b9(A.fb(v.typeUniverse,a,!1))},
kS(a){var s=this
s.b=A.lk(s)
return s.b(a)},
lk(a){var s,r,q,p,o
if(a===t.K)return A.l_
if(A.bb(a))return A.l3
s=a.w
if(s===6)return A.kQ
if(s===1)return A.iX
if(s===7)return A.kV
r=A.lj(a)
if(r!=null)return r
if(s===8){q=a.x
if(a.y.every(A.bb)){a.f="$i"+q
if(q==="F")return A.kY
if(a===t.m)return A.kX
return A.l2}}else if(s===10){p=A.lK(a.x,a.y)
o=p==null?A.iX:p
return o==null?A.G(o):o}return A.kO},
lj(a){if(a.w===8){if(a===t.S)return A.iV
if(a===t.i||a===t.o)return A.kZ
if(a===t.N)return A.l1
if(a===t.y)return A.hV}return null},
kR(a){var s=this,r=A.kN
if(A.bb(s))r=A.kK
else if(s===t.K)r=A.G
else if(A.bC(s)){r=A.kP
if(s===t.h6)r=A.kH
else if(s===t.dk)r=A.iO
else if(s===t.a6)r=A.kE
else if(s===t.cg)r=A.iN
else if(s===t.cD)r=A.kG
else if(s===t.an)r=A.kJ}else if(s===t.S)r=A.ar
else if(s===t.N)r=A.bx
else if(s===t.y)r=A.iL
else if(s===t.o)r=A.iM
else if(s===t.i)r=A.kF
else if(s===t.m)r=A.kI
s.a=r
return s.a(a)},
kO(a){var s=this
if(a==null)return A.bC(s)
return A.lV(v.typeUniverse,A.lT(a,s),s)},
kQ(a){if(a==null)return!0
return this.x.b(a)},
l2(a){var s,r=this
if(a==null)return A.bC(r)
s=r.f
if(a instanceof A.d)return!!a[s]
return!!J.ba(a)[s]},
kY(a){var s,r=this
if(a==null)return A.bC(r)
if(typeof a!="object")return!1
if(Array.isArray(a))return!0
s=r.f
if(a instanceof A.d)return!!a[s]
return!!J.ba(a)[s]},
kX(a){var s=this
if(a==null)return!1
if(typeof a=="object"){if(a instanceof A.d)return!!a[s.f]
return!0}if(typeof a=="function")return!0
return!1},
iW(a){if(typeof a=="object"){if(a instanceof A.d)return t.m.b(a)
return!0}if(typeof a=="function")return!0
return!1},
kN(a){var s=this
if(a==null){if(A.bC(s))return a}else if(s.b(a))return a
throw A.M(A.iR(a,s),new Error())},
kP(a){var s=this
if(a==null||s.b(a))return a
throw A.M(A.iR(a,s),new Error())},
iR(a,b){return new A.ck("TypeError: "+A.iy(a,A.a9(b,null)))},
iy(a,b){return A.cF(a)+": type '"+A.a9(A.i_(a),null)+"' is not a subtype of type '"+b+"'"},
ai(a,b){return new A.ck("TypeError: "+A.iy(a,b))},
kV(a){var s=this
return s.x.b(a)||A.hJ(v.typeUniverse,s).b(a)},
l_(a){return a!=null},
G(a){if(a!=null)return a
throw A.M(A.ai(a,"Object"),new Error())},
l3(a){return!0},
kK(a){return a},
iX(a){return!1},
hV(a){return!0===a||!1===a},
iL(a){if(!0===a)return!0
if(!1===a)return!1
throw A.M(A.ai(a,"bool"),new Error())},
kE(a){if(!0===a)return!0
if(!1===a)return!1
if(a==null)return a
throw A.M(A.ai(a,"bool?"),new Error())},
kF(a){if(typeof a=="number")return a
throw A.M(A.ai(a,"double"),new Error())},
kG(a){if(typeof a=="number")return a
if(a==null)return a
throw A.M(A.ai(a,"double?"),new Error())},
iV(a){return typeof a=="number"&&Math.floor(a)===a},
ar(a){if(typeof a=="number"&&Math.floor(a)===a)return a
throw A.M(A.ai(a,"int"),new Error())},
kH(a){if(typeof a=="number"&&Math.floor(a)===a)return a
if(a==null)return a
throw A.M(A.ai(a,"int?"),new Error())},
kZ(a){return typeof a=="number"},
iM(a){if(typeof a=="number")return a
throw A.M(A.ai(a,"num"),new Error())},
iN(a){if(typeof a=="number")return a
if(a==null)return a
throw A.M(A.ai(a,"num?"),new Error())},
l1(a){return typeof a=="string"},
bx(a){if(typeof a=="string")return a
throw A.M(A.ai(a,"String"),new Error())},
iO(a){if(typeof a=="string")return a
if(a==null)return a
throw A.M(A.ai(a,"String?"),new Error())},
kI(a){if(A.iW(a))return a
throw A.M(A.ai(a,"JSObject"),new Error())},
kJ(a){if(a==null)return a
if(A.iW(a))return a
throw A.M(A.ai(a,"JSObject?"),new Error())},
j2(a,b){var s,r,q
for(s="",r="",q=0;q<a.length;++q,r=", ")s+=r+A.a9(a[q],b)
return s},
lb(a,b){var s,r,q,p,o,n,m=a.x,l=a.y
if(""===m)return"("+A.j2(l,b)+")"
s=l.length
r=m.split(",")
q=r.length-s
for(p="(",o="",n=0;n<s;++n,o=", "){p+=o
if(q===0)p+="{"
p+=A.a9(l[n],b)
if(q>=0)p+=" "+r[q];++q}return p+"})"},
iS(a3,a4,a5){var s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1=", ",a2=null
if(a5!=null){s=a5.length
if(a4==null)a4=A.h([],t.W)
else a2=a4.length
r=a4.length
for(q=s;q>0;--q)B.b.m(a4,"T"+(r+q))
for(p=t.X,o="<",n="",q=0;q<s;++q,n=a1){m=a4.length
l=m-1-q
if(!(l>=0))return A.z(a4,l)
o=o+n+a4[l]
k=a5[q]
j=k.w
if(!(j===2||j===3||j===4||j===5||k===p))o+=" extends "+A.a9(k,a4)}o+=">"}else o=""
p=a3.x
i=a3.y
h=i.a
g=h.length
f=i.b
e=f.length
d=i.c
c=d.length
b=A.a9(p,a4)
for(a="",a0="",q=0;q<g;++q,a0=a1)a+=a0+A.a9(h[q],a4)
if(e>0){a+=a0+"["
for(a0="",q=0;q<e;++q,a0=a1)a+=a0+A.a9(f[q],a4)
a+="]"}if(c>0){a+=a0+"{"
for(a0="",q=0;q<c;q+=3,a0=a1){a+=a0
if(d[q+1])a+="required "
a+=A.a9(d[q+2],a4)+" "+d[q]}a+="}"}if(a2!=null){a4.toString
a4.length=a2}return o+"("+a+") => "+b},
a9(a,b){var s,r,q,p,o,n,m,l=a.w
if(l===5)return"erased"
if(l===2)return"dynamic"
if(l===3)return"void"
if(l===1)return"Never"
if(l===4)return"any"
if(l===6){s=a.x
r=A.a9(s,b)
q=s.w
return(q===11||q===12?"("+r+")":r)+"?"}if(l===7)return"FutureOr<"+A.a9(a.x,b)+">"
if(l===8){p=A.lo(a.x)
o=a.y
return o.length>0?p+("<"+A.j2(o,b)+">"):p}if(l===10)return A.lb(a,b)
if(l===11)return A.iS(a,b,null)
if(l===12)return A.iS(a.x,b,a.y)
if(l===13){n=a.x
m=b.length
n=m-1-n
if(!(n>=0&&n<m))return A.z(b,n)
return b[n]}return"?"},
lo(a){var s=A.ji(a)
if(s!=null)return s
return"minified:"+a},
kD(a,b){var s=a.tR[b]
while(typeof s=="string")s=a.tR[s]
return s},
kC(a,b){var s,r,q,p,o,n=a.eT,m=n[b]
if(m==null)return A.fb(a,b,!1)
else if(typeof m=="number"){s=m
r=A.cn(a,5,"#")
q=A.fd(s)
for(p=0;p<s;++p)q[p]=r
o=A.cm(a,b,q)
n[b]=o
return o}else return m},
kB(a,b){return A.iJ(a.tR,b)},
kA(a,b){return A.iJ(a.eT,b)},
fb(a,b,c){var s,r=a.eC,q=r.get(b)
if(q!=null)return q
s=A.iH(a,null,b,!1)
r.set(b,s)
return s},
co(a,b,c){var s,r,q=b.z
if(q==null)q=b.z=new Map()
s=q.get(c)
if(s!=null)return s
r=A.iH(a,b,c,!0)
q.set(c,r)
return r},
iI(a,b,c){var s,r,q,p=b.Q
if(p==null)p=b.Q=new Map()
s=c.as
r=p.get(s)
if(r!=null)return r
q=A.hR(a,b,c.w===9?c.y:[c])
p.set(s,q)
return q},
iH(a,b,c,d){return A.kr(A.kl(a,b,c,d))},
aN(a,b){b.a=A.kR
b.b=A.kS
return b},
cn(a,b,c){var s,r,q=a.eC.get(c)
if(q!=null)return q
s=new A.ak(null,null)
s.w=b
s.as=c
r=A.aN(a,s)
a.eC.set(c,r)
return r},
iF(a,b,c){var s,r=b.as+"?",q=a.eC.get(r)
if(q!=null)return q
s=A.ky(a,b,r,c)
a.eC.set(r,s)
return s},
ky(a,b,c,d){var s,r,q
if(d){s=b.w
r=!0
if(!A.bb(b))if(!(b===t.P||b===t.T))if(s!==6)r=s===7&&A.bC(b.x)
if(r)return b
else if(s===1)return t.P}q=new A.ak(null,null)
q.w=6
q.x=b
q.as=c
return A.aN(a,q)},
iE(a,b,c){var s,r=b.as+"/",q=a.eC.get(r)
if(q!=null)return q
s=A.kw(a,b,r,c)
a.eC.set(r,s)
return s},
kw(a,b,c,d){var s,r
if(d){s=b.w
if(A.bb(b)||b===t.K)return b
else if(s===1)return A.cm(a,"K",[b])
else if(b===t.P||b===t.T)return t.eH}r=new A.ak(null,null)
r.w=7
r.x=b
r.as=c
return A.aN(a,r)},
kz(a,b){var s,r,q=""+b+"^",p=a.eC.get(q)
if(p!=null)return p
s=new A.ak(null,null)
s.w=13
s.x=b
s.as=q
r=A.aN(a,s)
a.eC.set(q,r)
return r},
cl(a){var s,r,q,p=a.length
for(s="",r="",q=0;q<p;++q,r=",")s+=r+a[q].as
return s},
kv(a){var s,r,q,p,o,n=a.length
for(s="",r="",q=0;q<n;q+=3,r=","){p=a[q]
o=a[q+1]?"!":":"
s+=r+p+o+a[q+2].as}return s},
cm(a,b,c){var s,r,q,p=b
if(c.length>0)p+="<"+A.cl(c)+">"
s=a.eC.get(p)
if(s!=null)return s
r=new A.ak(null,null)
r.w=8
r.x=b
r.y=c
if(c.length>0)r.c=c[0]
r.as=p
q=A.aN(a,r)
a.eC.set(p,q)
return q},
hR(a,b,c){var s,r,q,p,o,n
if(b.w===9){s=b.x
r=b.y.concat(c)}else{r=c
s=b}q=s.as+(";<"+A.cl(r)+">")
p=a.eC.get(q)
if(p!=null)return p
o=new A.ak(null,null)
o.w=9
o.x=s
o.y=r
o.as=q
n=A.aN(a,o)
a.eC.set(q,n)
return n},
iG(a,b,c){var s,r,q="+"+(b+"("+A.cl(c)+")"),p=a.eC.get(q)
if(p!=null)return p
s=new A.ak(null,null)
s.w=10
s.x=b
s.y=c
s.as=q
r=A.aN(a,s)
a.eC.set(q,r)
return r},
iD(a,b,c){var s,r,q,p,o,n=b.as,m=c.a,l=m.length,k=c.b,j=k.length,i=c.c,h=i.length,g="("+A.cl(m)
if(j>0){s=l>0?",":""
g+=s+"["+A.cl(k)+"]"}if(h>0){s=l>0?",":""
g+=s+"{"+A.kv(i)+"}"}r=n+(g+")")
q=a.eC.get(r)
if(q!=null)return q
p=new A.ak(null,null)
p.w=11
p.x=b
p.y=c
p.as=r
o=A.aN(a,p)
a.eC.set(r,o)
return o},
hS(a,b,c,d){var s,r=b.as+("<"+A.cl(c)+">"),q=a.eC.get(r)
if(q!=null)return q
s=A.kx(a,b,c,r,d)
a.eC.set(r,s)
return s},
kx(a,b,c,d,e){var s,r,q,p,o,n,m,l
if(e){s=c.length
r=A.fd(s)
for(q=0,p=0;p<s;++p){o=c[p]
if(o.w===1){r[p]=o;++q}}if(q>0){n=A.b8(a,b,r,0)
m=A.bz(a,c,r,0)
return A.hS(a,n,m,c!==m)}}l=new A.ak(null,null)
l.w=12
l.x=b
l.y=c
l.as=d
return A.aN(a,l)},
kl(a,b,c,d){return{u:a,e:b,r:c,s:[],p:0,n:d}},
kr(a){var s,r,q,p,o,n,m,l=a.r,k=a.s
for(s=l.length,r=0;r<s;){q=l.charCodeAt(r)
if(q>=48&&q<=57)r=A.kn(r+1,q,l,k)
else if((((q|32)>>>0)-97&65535)<26||q===95||q===36||q===124)r=A.iB(a,r,l,k,!1)
else if(q===46)r=A.iB(a,r,l,k,!0)
else{++r
switch(q){case 44:break
case 58:k.push(!1)
break
case 33:k.push(!0)
break
case 59:k.push(A.b5(a.u,a.e,k.pop()))
break
case 94:k.push(A.kz(a.u,k.pop()))
break
case 35:k.push(A.cn(a.u,5,"#"))
break
case 64:k.push(A.cn(a.u,2,"@"))
break
case 126:k.push(A.cn(a.u,3,"~"))
break
case 60:k.push(a.p)
a.p=k.length
break
case 62:A.kp(a,k)
break
case 38:A.ko(a,k)
break
case 63:p=a.u
k.push(A.iF(p,A.b5(p,a.e,k.pop()),a.n))
break
case 47:p=a.u
k.push(A.iE(p,A.b5(p,a.e,k.pop()),a.n))
break
case 40:k.push(-3)
k.push(a.p)
a.p=k.length
break
case 41:A.km(a,k)
break
case 91:k.push(a.p)
a.p=k.length
break
case 93:o=k.splice(a.p)
A.iC(a.u,a.e,o)
a.p=k.pop()
k.push(o)
k.push(-1)
break
case 123:k.push(a.p)
a.p=k.length
break
case 125:o=k.splice(a.p)
A.ks(a.u,a.e,o)
a.p=k.pop()
k.push(o)
k.push(-2)
break
case 43:n=l.indexOf("(",r)
k.push(l.substring(r,n))
k.push(-4)
k.push(a.p)
a.p=k.length
r=n+1
break
default:throw"Bad character "+q}}}m=k.pop()
return A.b5(a.u,a.e,m)},
kn(a,b,c,d){var s,r,q=b-48
for(s=c.length;a<s;++a){r=c.charCodeAt(a)
if(!(r>=48&&r<=57))break
q=q*10+(r-48)}d.push(q)
return a},
iB(a,b,c,d,e){var s,r,q,p,o,n,m=b+1
for(s=c.length;m<s;++m){r=c.charCodeAt(m)
if(r===46){if(e)break
e=!0}else{if(!((((r|32)>>>0)-97&65535)<26||r===95||r===36||r===124))q=r>=48&&r<=57
else q=!0
if(!q)break}}p=c.substring(b,m)
if(e){s=a.u
o=a.e
if(o.w===9)o=o.x
n=A.kD(s,o.x)[p]
if(n==null)A.b('No "'+p+'" in "'+A.k2(o)+'"')
d.push(A.co(s,o,n))}else d.push(p)
return m},
kp(a,b){var s,r=a.u,q=A.iA(a,b),p=b.pop()
if(typeof p=="string")b.push(A.cm(r,p,q))
else{s=A.b5(r,a.e,p)
switch(s.w){case 11:b.push(A.hS(r,s,q,a.n))
break
default:b.push(A.hR(r,s,q))
break}}},
km(a,b){var s,r,q,p=a.u,o=b.pop(),n=null,m=null
if(typeof o=="number")switch(o){case-1:n=b.pop()
break
case-2:m=b.pop()
break
default:b.push(o)
break}else b.push(o)
s=A.iA(a,b)
o=b.pop()
switch(o){case-3:o=b.pop()
if(n==null)n=p.sEA
if(m==null)m=p.sEA
r=A.b5(p,a.e,o)
q=new A.d3()
q.a=s
q.b=n
q.c=m
b.push(A.iD(p,r,q))
return
case-4:b.push(A.iG(p,b.pop(),s))
return
default:throw A.c(A.cy("Unexpected state under `()`: "+A.y(o)))}},
ko(a,b){var s=b.pop()
if(0===s){b.push(A.cn(a.u,1,"0&"))
return}if(1===s){b.push(A.cn(a.u,4,"1&"))
return}throw A.c(A.cy("Unexpected extended operation "+A.y(s)))},
iA(a,b){var s=b.splice(a.p)
A.iC(a.u,a.e,s)
a.p=b.pop()
return s},
b5(a,b,c){if(typeof c=="string")return A.cm(a,c,a.sEA)
else if(typeof c=="number"){b.toString
return A.kq(a,b,c)}else return c},
iC(a,b,c){var s,r=c.length
for(s=0;s<r;++s)c[s]=A.b5(a,b,c[s])},
ks(a,b,c){var s,r=c.length
for(s=2;s<r;s+=3)c[s]=A.b5(a,b,c[s])},
kq(a,b,c){var s,r,q=b.w
if(q===9){if(c===0)return b.x
s=b.y
r=s.length
if(c<=r)return s[c-1]
c-=r
b=b.x
q=b.w}else if(c===0)return b
if(q!==8)throw A.c(A.cy("Indexed base must be an interface type"))
s=b.y
if(c<=s.length)return s[c-1]
throw A.c(A.cy("Bad index "+c+" for "+b.i(0)))},
lV(a,b,c){var s,r=b.d
if(r==null)r=b.d=new Map()
s=r.get(c)
if(s==null){s=A.N(a,b,null,c,null)
r.set(c,s)}return s},
N(a,b,c,d,e){var s,r,q,p,o,n,m,l,k,j,i
if(b===d)return!0
if(A.bb(d))return!0
s=b.w
if(s===4)return!0
if(A.bb(b))return!1
if(b.w===1)return!0
r=s===13
if(r)if(A.N(a,c[b.x],c,d,e))return!0
q=d.w
p=t.P
if(b===p||b===t.T){if(q===7)return A.N(a,b,c,d.x,e)
return d===p||d===t.T||q===6}if(d===t.K){if(s===7)return A.N(a,b.x,c,d,e)
return s!==6}if(s===7){if(!A.N(a,b.x,c,d,e))return!1
return A.N(a,A.hJ(a,b),c,d,e)}if(s===6)return A.N(a,p,c,d,e)&&A.N(a,b.x,c,d,e)
if(q===7){if(A.N(a,b,c,d.x,e))return!0
return A.N(a,b,c,A.hJ(a,d),e)}if(q===6)return A.N(a,b,c,p,e)||A.N(a,b,c,d.x,e)
if(r)return!1
p=s!==11
if((!p||s===12)&&d===t.a)return!0
o=s===10
if(o&&d===t.gT)return!0
if(q===12){if(b===t.g)return!0
if(s!==12)return!1
n=b.y
m=d.y
l=n.length
if(l!==m.length)return!1
c=c==null?n:n.concat(c)
e=e==null?m:m.concat(e)
for(k=0;k<l;++k){j=n[k]
i=m[k]
if(!A.N(a,j,c,i,e)||!A.N(a,i,e,j,c))return!1}return A.iU(a,b.x,c,d.x,e)}if(q===11){if(b===t.g)return!0
if(p)return!1
return A.iU(a,b,c,d,e)}if(s===8){if(q!==8)return!1
return A.kW(a,b,c,d,e)}if(o&&q===10)return A.l0(a,b,c,d,e)
return!1},
iU(a3,a4,a5,a6,a7){var s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2
if(!A.N(a3,a4.x,a5,a6.x,a7))return!1
s=a4.y
r=a6.y
q=s.a
p=r.a
o=q.length
n=p.length
if(o>n)return!1
m=n-o
l=s.b
k=r.b
j=l.length
i=k.length
if(o+j<n+i)return!1
for(h=0;h<o;++h){g=q[h]
if(!A.N(a3,p[h],a7,g,a5))return!1}for(h=0;h<m;++h){g=l[h]
if(!A.N(a3,p[o+h],a7,g,a5))return!1}for(h=0;h<i;++h){g=l[m+h]
if(!A.N(a3,k[h],a7,g,a5))return!1}f=s.c
e=r.c
d=f.length
c=e.length
for(b=0,a=0;a<c;a+=3){a0=e[a]
for(;;){if(b>=d)return!1
a1=f[b]
b+=3
if(a0<a1)return!1
a2=f[b-2]
if(a1<a0){if(a2)return!1
continue}g=e[a+1]
if(a2&&!g)return!1
g=f[b-1]
if(!A.N(a3,e[a+2],a7,g,a5))return!1
break}}while(b<d){if(f[b+1])return!1
b+=3}return!0},
kW(a,b,c,d,e){var s,r,q,p,o,n=b.x,m=d.x
while(n!==m){s=a.tR[n]
if(s==null)return!1
if(typeof s=="string"){n=s
continue}r=s[m]
if(r==null)return!1
q=r.length
p=q>0?new Array(q):v.typeUniverse.sEA
for(o=0;o<q;++o)p[o]=A.co(a,b,r[o])
return A.iK(a,p,null,c,d.y,e)}return A.iK(a,b.y,null,c,d.y,e)},
iK(a,b,c,d,e,f){var s,r=b.length
for(s=0;s<r;++s)if(!A.N(a,b[s],d,e[s],f))return!1
return!0},
l0(a,b,c,d,e){var s,r=b.y,q=d.y,p=r.length
if(p!==q.length)return!1
if(b.x!==d.x)return!1
for(s=0;s<p;++s)if(!A.N(a,r[s],c,q[s],e))return!1
return!0},
bC(a){var s=a.w,r=!0
if(!(a===t.P||a===t.T))if(!A.bb(a))if(s!==6)r=s===7&&A.bC(a.x)
return r},
bb(a){var s=a.w
return s===2||s===3||s===4||s===5||a===t.X},
iJ(a,b){var s,r,q=Object.keys(b),p=q.length
for(s=0;s<p;++s){r=q[s]
a[r]=b[r]}},
fd(a){return a>0?new Array(a):v.typeUniverse.sEA},
ak:function ak(a,b){var _=this
_.a=a
_.b=b
_.r=_.f=_.d=_.c=null
_.w=0
_.as=_.Q=_.z=_.y=_.x=null},
d3:function d3(){this.c=this.b=this.a=null},
fa:function fa(a){this.a=a},
d2:function d2(){},
ck:function ck(a){this.a=a},
k9(){var s,r,q
if(self.scheduleImmediate!=null)return A.ls()
if(self.MutationObserver!=null&&self.document!=null){s={}
r=self.document.createElement("div")
q=self.document.createElement("span")
s.a=null
new self.MutationObserver(A.cs(new A.e0(s),1)).observe(r,{childList:true})
return new A.e_(s,r,q)}else if(self.setImmediate!=null)return A.lt()
return A.lu()},
ka(a){self.scheduleImmediate(A.cs(new A.e1(t.M.a(a)),0))},
kb(a){self.setImmediate(A.cs(new A.e2(t.M.a(a)),0))},
kc(a){A.hN(B.a,t.M.a(a))},
hN(a,b){var s=B.e.O(a.a,1000)
return A.kt(s<0?0:s,b)},
kt(a,b){var s=new A.cj(!0)
s.cW(a,b)
return s},
ku(a,b){var s=new A.cj(!1)
s.cX(a,b)
return s},
w(a){return new A.c5(new A.j($.i,a.h("j<0>")),a.h("c5<0>"))},
v(a,b){a.$2(0,null)
b.b=!0
return b.a},
a(a,b){A.iP(a,b)},
u(a,b){b.I(a)},
t(a,b){b.bm(A.O(a),A.P(a))},
iP(a,b){var s,r,q=new A.fs(b),p=new A.ft(b)
if(a instanceof A.j)a.cb(q,p,t.z)
else{s=t.z
if(a instanceof A.j)a.ap(q,p,s)
else{r=new A.j($.i,t._)
r.a=8
r.c=a
r.cb(q,p,s)}}},
n(a){var s=function(b,c){return function(d,e){while(true){try{b(d,e)
break}catch(r){e=r
d=c}}}}(a,1)
return $.i.aZ(new A.fz(s),t.H,t.S,t.z)},
az(a,b,c){var s,r,q
if(b===0){s=c.c
if(s!=null)s.a_(null)
else{s=c.a
s===$&&A.x()
s.j()}return}else if(b===1){s=c.c
if(s!=null){r=A.O(a)
q=A.P(a)
s.G(new A.A(r,q))}else{s=A.O(a)
r=A.P(a)
q=c.a
q===$&&A.x()
q.aV(s,r)
c.a.j()}return}t.as.a(b)
if(a instanceof A.cb){if(c.c!=null){b.$2(2,null)
return}s=a.b
if(s===0){s=a.a
r=c.a
r===$&&A.x()
r.m(0,c.$ti.c.a(s))
A.aA(new A.fq(c,b))
return}else if(s===1){s=c.$ti.h("ad<1>").a(t.fN.a(a.a))
r=c.a
r===$&&A.x()
r.dH(s,!1).cD(new A.fr(c,b),t.P)
return}}A.iP(a,b)},
hZ(a){var s=a.a
s===$&&A.x()
return new A.r(s,A.e(s).h("r<1>"))},
kd(a,b){var s=new A.cY(b.h("cY<0>"))
s.cT(a,b)
return s},
hX(a,b){return A.kd(a,b)},
ml(a){return new A.cb(a,1)},
eU(a){return new A.cb(a,0)},
cz(a){var s
if(t.C.b(a)){s=a.gau()
if(s!=null)return s}return B.l},
jO(a,b){var s,r,q,p,o,n,m,l=null
try{l=a.$0()}catch(q){s=A.O(q)
r=A.P(q)
p=new A.j($.i,b.h("j<0>"))
o=s
n=r
m=A.hU(o,n)
if(m==null)o=new A.A(o,n==null?A.cz(o):n)
else o=m
p.a5(o)
return p}if(b.h("K<0>").b(l))p=l
else{p=l
o=new A.j($.i,b.h("j<0>"))
b.a(p)
o.a=8
o.c=p
p=o}return p},
ih(a,b){var s
b.a(a)
s=new A.j($.i,b.h("j<0>"))
s.E(a)
return s},
q(a,b){var s
if(!b.b(null))throw A.c(A.bF(null,"computation","The type parameter is not nullable"))
s=new A.j($.i,b.h("j<0>"))
A.hM(a,new A.dj(null,s,b))
return s},
hB(a,b){var s,r,q,p,o,n,m,l,k,j,i={},h=null,g=!1,f=new A.j($.i,b.h("j<F<0>>"))
i.a=null
i.b=0
i.c=i.d=null
s=new A.dl(i,h,g,f)
try{for(n=J.df(a),m=t.P;n.q();){r=n.gB()
q=i.b
r.ap(new A.dk(i,q,f,b,h,g),s,m);++i.b}n=i.b
if(n===0){n=f
n.a_(A.h([],b.h("D<0>")))
return n}i.a=A.Y(n,null,!1,b.h("0?"))}catch(l){p=A.O(l)
o=A.P(l)
if(i.b===0||g){n=f
m=p
k=o
j=A.hU(m,k)
if(j==null)m=new A.A(m,k==null?A.cz(m):k)
else m=j
n.a5(m)
return n}else{i.d=p
i.c=o}}return f},
hU(a,b){var s,r,q,p=$.i
if(p===B.c)return null
s=p.cr(a,b)
if(s==null)return null
r=s.a
q=s.b
if(t.C.b(r))A.dF(r,q)
return s},
iT(a,b){var s
if($.i!==B.c){s=A.hU(a,b)
if(s!=null)return s}if(b==null)if(t.C.b(a)){b=a.gau()
if(b==null){A.dF(a,B.l)
b=B.l}}else b=B.l
else if(t.C.b(a))A.dF(a,b)
return new A.A(a,b)},
kh(a,b,c){var s=new A.j(b,c.h("j<0>"))
c.a(a)
s.a=8
s.c=a
return s},
eI(a,b,c){var s,r,q,p,o={},n=o.a=a
for(s=t._;r=n.a,(r&4)!==0;n=a){a=s.a(n.c)
o.a=a}if(n===b){s=A.iq()
b.a5(new A.A(new A.ab(!0,n,null,"Cannot complete a future with itself"),s))
return}q=b.a&1
s=n.a=r|q
if((s&24)===0){p=t.F.a(b.c)
b.a=b.a&1|4
b.c=n
n.bW(p)
return}if(!c)if(b.c==null)n=(s&16)===0||q!==0
else n=!1
else n=!0
if(n){p=b.aB()
b.aQ(o.a)
A.b2(b,p)
return}b.a^=2
b.b.a2(new A.eJ(o,b))},
b2(a,b){var s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d={},c=d.a=a
for(s=t.n,r=t.F;;){q={}
p=c.a
o=(p&16)===0
n=!o
if(b==null){if(n&&(p&1)===0){m=s.a(c.c)
c.b.aE(m.a,m.b)}return}q.a=b
l=b.a
for(c=b;l!=null;c=l,l=k){c.a=null
A.b2(d.a,c)
q.a=l
k=l.a}p=d.a
j=p.c
q.b=n
q.c=j
if(o){i=c.c
i=(i&1)!==0||(i&15)===8}else i=!0
if(i){h=c.b.b
if(n){c=p.b
c=!(c===h||c.gV()===h.gV())}else c=!1
if(c){c=d.a
m=s.a(c.c)
c.b.aE(m.a,m.b)
return}g=$.i
if(g!==h)$.i=h
else g=null
c=q.a.c
if((c&15)===8)new A.eN(q,d,n).$0()
else if(o){if((c&1)!==0)new A.eM(q,j).$0()}else if((c&2)!==0)new A.eL(d,q).$0()
if(g!=null)$.i=g
c=q.c
if(c instanceof A.j){p=q.a.$ti
p=p.h("K<2>").b(c)||!p.y[1].b(c)}else p=!1
if(p){f=q.a.b
if((c.a&24)!==0){e=r.a(f.c)
f.c=null
b=f.aU(e)
f.a=c.a&30|f.a&1
f.c=c.c
d.a=c
continue}else A.eI(c,f,!0)
return}}f=q.a.b
e=r.a(f.c)
f.c=null
b=f.aU(e)
c=q.b
p=q.c
if(!c){f.$ti.c.a(p)
f.a=8
f.c=p}else{s.a(p)
f.a=f.a&1|16
f.c=p}d.a=f
c=f}},
iY(a,b){if(t.Q.b(a))return b.aZ(a,t.z,t.K,t.l)
if(t.w.b(a))return b.an(a,t.z,t.K)
throw A.c(A.bF(a,"onError",u.c))},
l6(){var s,r
for(s=$.by;s!=null;s=$.by){$.cq=null
r=s.b
$.by=r
if(r==null)$.cp=null
s.a.$0()}},
ll(){$.hW=!0
try{A.l6()}finally{$.cq=null
$.hW=!1
if($.by!=null)$.i6().$1(A.j7())}},
j3(a){var s=new A.cX(a),r=$.cp
if(r==null){$.by=$.cp=s
if(!$.hW)$.i6().$1(A.j7())}else $.cp=r.b=s},
li(a){var s,r,q,p=$.by
if(p==null){A.j3(a)
$.cq=$.cp
return}s=new A.cX(a)
r=$.cq
if(r==null){s.b=p
$.by=$.cq=s}else{q=r.b
s.b=q
$.cq=r.b=s
if(q==null)$.cp=s}},
aA(a){var s,r=null,q=$.i
if(B.c===q){A.fy(r,r,B.c,a)
return}if(B.c===q.gbj().a)s=B.c.gV()===q.gV()
else s=!1
if(s){A.fy(r,r,q,q.X(a,t.H))
return}s=$.i
s.a2(s.aW(a))},
I(a,b){var s=null,r=b.h("af<0>"),q=new A.af(s,s,s,s,r)
q.a4(a)
q.az()
return new A.r(q,r.h("r<1>"))},
m9(a,b){return new A.aM(A.db(a,"stream",t.K),b.h("aM<0>"))},
bl(a,b,c,d,e,f){return e?new A.bu(b,c,d,a,f.h("bu<0>")):new A.af(b,c,d,a,f.h("af<0>"))},
da(a){var s,r,q
if(a==null)return
try{a.$0()}catch(q){s=A.O(q)
r=A.P(q)
$.i.aE(s,r)}},
kg(a,b,c,d,e,f){var s,r=$.i,q=e?1:0,p=c!=null?32:0,o=b==null?A.j5():b,n=t.H
o=r.an(o,n,f)
s=A.ix(r,c)
return new A.aw(a,o,s,r.X(d==null?A.j6():d,n),r,q|p,f.h("aw<0>"))},
k8(a){return new A.dZ(a)},
ix(a,b){if(b==null)b=A.lv()
if(t.da.b(b))return a.aZ(b,t.z,t.K,t.l)
if(t.u.b(b))return a.an(b,t.z,t.K)
throw A.c(A.cw("handleError callback must take either an Object (the error), or both an Object (the error) and a StackTrace.",null))},
l7(a){},
l9(a,b){A.G(a)
t.l.a(b)
$.i.aE(a,b)},
l8(){},
hM(a,b){var s=$.i
if(s===B.c)return s.bn(a,b)
return s.bn(a,s.aW(b))},
k4(a,b){return A.hM(a,t.M.a(b))},
jh(a,b,c){return A.lh(a,b,null,c)},
lh(a,b,c,d){return $.i.cu(c,b).M(a,d)},
lf(a,b,c,d,e){A.cr(d,e)},
cr(a,b){A.li(new A.fv(a,b))},
fw(a,b,c,d,e){var s,r
t.p.a(a)
t.q.a(b)
t.x.a(c)
e.h("0()").a(d)
r=$.i
if(r===c)return d.$0()
$.i=c
s=r
try{r=d.$0()
return r}finally{$.i=s}},
fx(a,b,c,d,e,f,g){var s,r
t.p.a(a)
t.q.a(b)
t.x.a(c)
f.h("@<0>").p(g).h("1(2)").a(d)
g.a(e)
r=$.i
if(r===c)return d.$1(e)
$.i=c
s=r
try{r=d.$1(e)
return r}finally{$.i=s}},
hY(a,b,c,d,e,f,g,h,i){var s,r
t.p.a(a)
t.q.a(b)
t.x.a(c)
g.h("@<0>").p(h).p(i).h("1(2,3)").a(d)
h.a(e)
i.a(f)
r=$.i
if(r===c)return d.$2(e,f)
$.i=c
s=r
try{r=d.$2(e,f)
return r}finally{$.i=s}},
j0(a,b,c,d,e){var s=t.x
s.a(a)
t.Y.a(b)
s.a(c)
return e.h("0()").a(d)},
j1(a,b,c,d,e,f){var s=t.x
s.a(a)
t.Y.a(b)
s.a(c)
return e.h("@<0>").p(f).h("1(2)").a(d)},
j_(a,b,c,d,e,f,g){var s=t.x
s.a(a)
t.Y.a(b)
s.a(c)
return e.h("@<0>").p(f).p(g).h("1(2,3)").a(d)},
le(a,b,c,d,e){var s=t.x
s.a(a)
t.Y.a(b)
s.a(c)
A.G(d)
t.gO.a(e)
return null},
fy(a,b,c,d){var s,r
t.M.a(d)
if(B.c!==c){s=B.c.gV()
r=c.gV()
d=s!==r?c.aW(d):c.bl(d,t.H)}A.j3(d)},
ld(a,b,c,d,e){var s=t.x
s.a(a)
t.Y.a(b)
s.a(c)
t.A.a(d)
t.M.a(e)
return A.hN(d,B.c!==c?c.bl(e,t.H):e)},
lc(a,b,c,d,e){var s
e=c.eb(t.cB.a(e),t.H,t.aF)
s=d.gec()
return A.ku(s.b0(0,0)?0:s,e)},
lg(a,b,c,d){A.jf(d)},
iZ(a,b,c,d,e){var s=t.X,r=A.jP(s,s)
r.ai(0,e)
s=new A.d0(c.gc5(),c.gc7(),c.gc6(),c.gc2(),c.gc3(),c.gc1(),c.gbO(),c.gbj(),c.gbL(),c.gbK(),c.gbX(),c.gbP(),c.gbb(),c.gbk(),c)
if(d!=null)s.as=new A.d8(s,d.a)
s.at=new A.d9(s,r)
return s},
e0:function e0(a){this.a=a},
e_:function e_(a,b,c){this.a=a
this.b=b
this.c=c},
e1:function e1(a){this.a=a},
e2:function e2(a){this.a=a},
cj:function cj(a){this.a=a
this.b=null
this.c=0},
f9:function f9(a,b){this.a=a
this.b=b},
f8:function f8(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.d=d},
c5:function c5(a,b){this.a=a
this.b=!1
this.$ti=b},
fs:function fs(a){this.a=a},
ft:function ft(a){this.a=a},
fz:function fz(a){this.a=a},
fq:function fq(a,b){this.a=a
this.b=b},
fr:function fr(a,b){this.a=a
this.b=b},
cY:function cY(a){var _=this
_.a=$
_.b=!1
_.c=null
_.$ti=a},
e4:function e4(a){this.a=a},
e5:function e5(a){this.a=a},
e7:function e7(a){this.a=a},
e8:function e8(a,b){this.a=a
this.b=b},
e6:function e6(a,b){this.a=a
this.b=b},
e3:function e3(a){this.a=a},
cb:function cb(a,b){this.a=a
this.b=b},
A:function A(a,b){this.a=a
this.b=b},
aq:function aq(a,b,c,d,e,f,g){var _=this
_.ay=0
_.CW=_.ch=null
_.w=a
_.a=b
_.b=c
_.c=d
_.d=e
_.e=f
_.r=_.f=null
_.$ti=g},
b1:function b1(){},
ci:function ci(a,b,c){var _=this
_.a=a
_.b=b
_.c=0
_.r=_.f=_.e=_.d=null
_.$ti=c},
f5:function f5(a,b){this.a=a
this.b=b},
f7:function f7(a,b,c){this.a=a
this.b=b
this.c=c},
f6:function f6(a){this.a=a},
dj:function dj(a,b,c){this.a=a
this.b=b
this.c=c},
dl:function dl(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.d=d},
dk:function dk(a,b,c,d,e,f){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=e
_.f=f},
dM:function dM(a,b){this.a=a
this.b=b},
c7:function c7(){},
a_:function a_(a,b){this.a=a
this.$ti=b},
am:function am(a,b,c,d,e){var _=this
_.a=null
_.b=a
_.c=b
_.d=c
_.e=d
_.$ti=e},
j:function j(a,b){var _=this
_.a=0
_.b=a
_.c=null
_.$ti=b},
eF:function eF(a,b){this.a=a
this.b=b},
eK:function eK(a,b){this.a=a
this.b=b},
eJ:function eJ(a,b){this.a=a
this.b=b},
eH:function eH(a,b){this.a=a
this.b=b},
eG:function eG(a,b){this.a=a
this.b=b},
eN:function eN(a,b,c){this.a=a
this.b=b
this.c=c},
eO:function eO(a,b){this.a=a
this.b=b},
eP:function eP(a){this.a=a},
eM:function eM(a,b){this.a=a
this.b=b},
eL:function eL(a,b){this.a=a
this.b=b},
eQ:function eQ(a,b){this.a=a
this.b=b},
eR:function eR(a,b,c){this.a=a
this.b=b
this.c=c},
eS:function eS(a,b){this.a=a
this.b=b},
cX:function cX(a){this.a=a
this.b=null},
ad:function ad(){},
dK:function dK(a,b){this.a=a
this.b=b},
dL:function dL(a,b){this.a=a
this.b=b},
b7:function b7(){},
f4:function f4(a){this.a=a},
f3:function f3(a){this.a=a},
d7:function d7(){},
cZ:function cZ(){},
af:function af(a,b,c,d,e){var _=this
_.a=null
_.b=0
_.c=null
_.d=a
_.e=b
_.f=c
_.r=d
_.$ti=e},
bu:function bu(a,b,c,d,e){var _=this
_.a=null
_.b=0
_.c=null
_.d=a
_.e=b
_.f=c
_.r=d
_.$ti=e},
r:function r(a,b){this.a=a
this.$ti=b},
aw:function aw(a,b,c,d,e,f,g){var _=this
_.w=a
_.a=b
_.b=c
_.c=d
_.d=e
_.e=f
_.r=_.f=null
_.$ti=g},
cW:function cW(){},
dZ:function dZ(a){this.a=a},
dY:function dY(a){this.a=a},
a8:function a8(a,b,c,d){var _=this
_.c=a
_.a=b
_.b=c
_.$ti=d},
a0:function a0(){},
ex:function ex(a,b){this.a=a
this.b=b},
ey:function ey(a,b){this.a=a
this.b=b},
ew:function ew(a,b,c){this.a=a
this.b=b
this.c=c},
ev:function ev(a,b,c){this.a=a
this.b=b
this.c=c},
eu:function eu(a){this.a=a},
ch:function ch(){},
ax:function ax(){},
S:function S(a,b){this.b=a
this.a=null
this.$ti=b},
bq:function bq(a,b){this.b=a
this.c=b
this.a=null},
d1:function d1(){},
a7:function a7(a){var _=this
_.a=0
_.c=_.b=null
_.$ti=a},
eZ:function eZ(a,b){this.a=a
this.b=b},
br:function br(a,b){var _=this
_.a=1
_.b=a
_.c=null
_.$ti=b},
eC:function eC(a,b){this.a=a
this.b=b},
aM:function aM(a,b){var _=this
_.a=null
_.b=a
_.c=!1
_.$ti=b},
fm:function fm(a,b){this.a=a
this.b=b},
fo:function fo(a,b){this.a=a
this.b=b},
fn:function fn(a,b){this.a=a
this.b=b},
fk:function fk(a,b){this.a=a
this.b=b},
fl:function fl(a,b){this.a=a
this.b=b},
fj:function fj(a,b){this.a=a
this.b=b},
fg:function fg(a,b){this.a=a
this.b=b},
fp:function fp(a,b){this.a=a
this.b=b},
ff:function ff(a,b){this.a=a
this.b=b},
fe:function fe(){},
fi:function fi(a,b){this.a=a
this.b=b},
fh:function fh(a,b){this.a=a
this.b=b},
d8:function d8(a,b){this.a=a
this.b=b},
d9:function d9(a,b){this.a=a
this.b=b},
bv:function bv(){},
d0:function d0(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=e
_.f=f
_.r=g
_.w=h
_.x=i
_.y=j
_.z=k
_.Q=l
_.as=m
_.at=n
_.ax=null
_.ay=o},
eB:function eB(a,b,c){this.a=a
this.b=b
this.c=c},
eA:function eA(a,b){this.a=a
this.b=b},
d5:function d5(){},
f2:function f2(a,b,c){this.a=a
this.b=b
this.c=c},
f1:function f1(a,b){this.a=a
this.b=b},
bw:function bw(a){this.a=a},
fv:function fv(a,b){this.a=a
this.b=b},
jP(a,b){return new A.c8(a.h("@<0>").p(b).h("c8<1,2>"))},
iz(a,b){var s=a[b]
return s===a?null:s},
hP(a,b,c){if(c==null)a[b]=a
else a[b]=c},
hO(){var s=Object.create(null)
A.hP(s,"<non-identifier-key>",s)
delete s["<non-identifier-key>"]
return s},
dt(a,b,c){return b.h("@<0>").p(c).h("ij<1,2>").a(A.lN(a,new A.aR(b.h("@<0>").p(c).h("aR<1,2>"))))},
hF(a,b){return new A.aR(a.h("@<0>").p(b).h("aR<1,2>"))},
jX(a){return new A.b3(a.h("b3<0>"))},
du(a){return new A.b3(a.h("b3<0>"))},
hQ(){var s=Object.create(null)
s["<non-identifier-key>"]=s
delete s["<non-identifier-key>"]
return s},
kk(a,b,c){var s=new A.b4(a,b,c.h("b4<0>"))
s.c=a.e
return s},
hH(a){var s,r
if(A.i2(a))return"{...}"
s=new A.bm("")
try{r={}
B.b.m($.aa,a)
s.a+="{"
r.a=!0
a.ak(0,new A.dB(r,s))
s.a+="}"}finally{if(0>=$.aa.length)return A.z($.aa,-1)
$.aa.pop()}r=s.a
return r.charCodeAt(0)==0?r:r},
hG(a){return new A.aX(A.Y(A.ik(null),null,!1,a.h("0?")),a.h("aX<0>"))},
ik(a){return 8},
c8:function c8(a){var _=this
_.a=0
_.e=_.d=_.c=_.b=null
_.$ti=a},
eT:function eT(a){this.a=a},
c9:function c9(a,b){this.a=a
this.$ti=b},
ca:function ca(a,b,c){var _=this
_.a=a
_.b=b
_.c=0
_.d=null
_.$ti=c},
b3:function b3(a){var _=this
_.a=0
_.f=_.e=_.d=_.c=_.b=null
_.r=0
_.$ti=a},
d4:function d4(a){this.a=a
this.c=this.b=null},
b4:function b4(a,b,c){var _=this
_.a=a
_.b=b
_.d=_.c=null
_.$ti=c},
aF:function aF(){},
bh:function bh(){},
dB:function dB(a,b){this.a=a
this.b=b},
aX:function aX(a,b){var _=this
_.a=a
_.d=_.c=_.b=0
_.$ti=b},
ay:function ay(a,b,c,d,e){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=null
_.$ti=e},
bk:function bk(){},
ce:function ce(){},
ii(a,b,c){return new A.bR(a,b)},
kL(a){return a.ed()},
ki(a,b){return new A.eW(a,[],A.lJ())},
kj(a,b,c){var s,r=new A.bm(""),q=A.ki(r,b)
q.b_(a)
s=r.a
return s.charCodeAt(0)==0?s:s},
cC:function cC(){},
cE:function cE(){},
bR:function bR(a,b){this.a=a
this.b=b},
cN:function cN(a,b){this.a=a
this.b=b},
dq:function dq(){},
dr:function dr(a){this.b=a},
eX:function eX(){},
eY:function eY(a,b){this.a=a
this.b=b},
eW:function eW(a,b,c){this.c=a
this.a=b
this.b=c},
jM(a,b){a=A.M(a,new Error())
if(a==null)a=A.G(a)
a.stack=b.i(0)
throw a},
Y(a,b,c,d){var s,r=J.jT(a,d)
if(a!==0&&b!=null)for(s=0;s<a;++s)r[s]=b
return r},
jY(a,b,c){var s,r,q=A.h([],c.h("D<0>"))
for(s=a.length,r=0;r<a.length;a.length===s||(0,A.W)(a),++r)B.b.m(q,c.a(a[r]))
q.$flags=1
return q},
ac(a,b){var s,r
if(Array.isArray(a))return A.h(a.slice(0),b.h("D<0>"))
s=A.h([],b.h("D<0>"))
for(r=J.df(a);r.q();)B.b.m(s,r.gB())
return s},
is(a,b,c){var s=J.df(b)
if(!s.q())return a
if(c.length===0){do a+=A.y(s.gB())
while(s.q())}else{a+=A.y(s.gB())
while(s.q())a=a+c+A.y(s.gB())}return a},
iq(){return A.P(new Error())},
ig(a){return new A.E(a)},
cF(a){if(typeof a=="number"||A.hV(a)||a==null)return J.cv(a)
if(typeof a=="string")return JSON.stringify(a)
return A.io(a)},
jN(a,b){A.db(a,"error",t.K)
A.db(b,"stackTrace",t.l)
A.jM(a,b)},
cy(a){return new A.cx(a)},
cw(a,b){return new A.ab(!1,null,b,a)},
bF(a,b,c){return new A.ab(!0,a,b,c)},
i9(a){return new A.ab(!1,null,a,"Must not be null")},
bj(a,b,c,d,e){return new A.aG(b,c,!0,a,d,"Invalid value")},
dH(a,b,c){if(0>a||a>c)throw A.c(A.bj(a,0,c,"start",null))
if(b!=null){if(a>b||b>c)throw A.c(A.bj(b,a,c,"end",null))
return b}return c},
dG(a,b){if(a<0)throw A.c(A.bj(a,0,null,b,null))
return a},
dm(a,b,c,d,e){return new A.cG(b,!0,a,e,"Index out of range")},
c3(a){return new A.aK(a)},
iv(a){return new A.cU(a)},
f(a){return new A.Z(a)},
X(a){return new A.cD(a)},
jS(a,b,c){var s,r
if(A.i2(a)){if(b==="("&&c===")")return"(...)"
return b+"..."+c}s=A.h([],t.W)
B.b.m($.aa,a)
try{A.l4(a,s)}finally{if(0>=$.aa.length)return A.z($.aa,-1)
$.aa.pop()}r=A.is(b,t.hf.a(s),", ")+c
return r.charCodeAt(0)==0?r:r},
dn(a,b,c){var s,r
if(A.i2(a))return b+"..."+c
s=new A.bm(b)
B.b.m($.aa,a)
try{r=s
r.a=A.is(r.a,a,", ")}finally{if(0>=$.aa.length)return A.z($.aa,-1)
$.aa.pop()}s.a+=c
r=s.a
return r.charCodeAt(0)==0?r:r},
l4(a,b){var s,r,q,p,o,n,m,l=a.gF(a),k=0,j=0
for(;;){if(!(k<80||j<3))break
if(!l.q())return
s=A.y(l.gB())
B.b.m(b,s)
k+=s.length+2;++j}if(!l.q()){if(j<=5)return
if(0>=b.length)return A.z(b,-1)
r=b.pop()
if(0>=b.length)return A.z(b,-1)
q=b.pop()}else{p=l.gB();++j
if(!l.q()){if(j<=4){B.b.m(b,A.y(p))
return}r=A.y(p)
if(0>=b.length)return A.z(b,-1)
q=b.pop()
k+=r.length+2}else{o=l.gB();++j
for(;l.q();p=o,o=n){n=l.gB();++j
if(j>100){for(;;){if(!(k>75&&j>3))break
if(0>=b.length)return A.z(b,-1)
k-=b.pop().length+2;--j}B.b.m(b,"...")
return}}q=A.y(p)
r=A.y(o)
k+=r.length+q.length+4}}if(j>b.length+2){k+=5
m="..."}else m=null
for(;;){if(!(k>80&&b.length>3))break
if(0>=b.length)return A.z(b,-1)
k-=b.pop().length+2
if(m==null){k+=5
m="..."}}if(m!=null)B.b.m(b,m)
B.b.m(b,q)
B.b.m(b,r)},
il(a,b,c,d){var s
if(B.j===c){s=B.e.gC(a)
b=J.an(b)
return A.hL(A.aH(A.aH($.hz(),s),b))}if(B.j===d){s=B.e.gC(a)
b=J.an(b)
c=J.an(c)
return A.hL(A.aH(A.aH(A.aH($.hz(),s),b),c))}s=B.e.gC(a)
b=J.an(b)
c=J.an(c)
d=J.an(d)
d=A.hL(A.aH(A.aH(A.aH(A.aH($.hz(),s),b),c),d))
return d},
je(a){var s=$.la
if(s==null)A.jf(a)
else s.$1(a)},
E:function E(a){this.a=a},
eD:function eD(){},
B:function B(){},
cx:function cx(a){this.a=a},
au:function au(){},
ab:function ab(a,b,c,d){var _=this
_.a=a
_.b=b
_.c=c
_.d=d},
aG:function aG(a,b,c,d,e,f){var _=this
_.e=a
_.f=b
_.a=c
_.b=d
_.c=e
_.d=f},
cG:function cG(a,b,c,d,e){var _=this
_.f=a
_.a=b
_.b=c
_.c=d
_.d=e},
aK:function aK(a){this.a=a},
cU:function cU(a){this.a=a},
Z:function Z(a){this.a=a},
cD:function cD(a){this.a=a},
cO:function cO(){},
c0:function c0(){},
eE:function eE(a){this.a=a},
m:function m(){},
aY:function aY(a,b,c){this.a=a
this.b=b
this.$ti=c},
J:function J(){},
d:function d(){},
d6:function d6(){},
dJ:function dJ(){this.b=this.a=0},
bm:function bm(a){this.a=a},
bn(a,b,c){var s=a==null?A.k5():a,r=b==null?A.lr():b
r=new A.dN(c,s,r,A.hF(t.N,t.s),new A.ci(null,null,t.dn))
c.bx()
r.f=A.iw(r,B.d)
r.r=A.iw(r,B.h)
return r},
k5(){var s,r=new A.dJ()
$.i5()
s=$.hI.$0()
r.a=s
r.b=null
return new A.dO(r)},
iw(a,b){var s=t.s
return new A.eo(a,b,A.hF(s,t.G),A.hF(s,t.S),new A.er(A.hG(t.R)))},
e9(a,b,c,d){var s=new A.c6(a,b,c,d,A.du(t.M))
s.cU(a,b,c,d)
return s},
ke(a){var s=new A.d_()
s.cV(a)
return s},
b0:function b0(a,b){this.a=a
this.b=b},
ap:function ap(a,b){this.a=a
this.b=b},
dV:function dV(a,b,c,d,e,f,g,h){var _=this
_.b=a
_.c=b
_.d=c
_.f=d
_.r=e
_.w=f
_.x=g
_.y=h},
aI:function aI(){},
dN:function dN(a,b,c,d,e){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=e
_.r=_.f=$
_.x=_.w=!1},
dO:function dO(a){this.a=a},
dR:function dR(){},
dS:function dS(a){this.a=a},
dU:function dU(a){this.a=a},
dT:function dT(a){this.a=a},
dQ:function dQ(a){this.a=a},
dP:function dP(a){this.a=a},
aJ:function aJ(a,b,c,d,e){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=e
_.f=!1},
aL:function aL(a,b){var _=this
_.a=a
_.b=b
_.d=_.c=!1},
bo:function bo(a,b,c){this.a=a
this.b=b
this.c=c},
bp:function bp(a,b){this.a=a
this.b=b},
et:function et(a,b){this.a=a
this.b=b
this.c=null},
eo:function eo(a,b,c,d,e){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=e
_.f=null
_.r=!1
_.y=_.x=_.w=0},
eq:function eq(a){this.a=a},
ep:function ep(a,b){this.a=a
this.b=b},
c6:function c6(a,b,c,d,e){var _=this
_.a=a
_.b=b
_.c=c
_.d=d
_.e=$
_.f=e
_.r=!1
_.x=_.w=null
_.Q=_.z=_.y=!1
_.as=0},
ef:function ef(a){this.a=a},
ea:function ea(a){this.a=a},
eg:function eg(a){this.a=a},
eh:function eh(a){this.a=a},
ee:function ee(a){this.a=a},
eb:function eb(a){this.a=a},
ec:function ec(a){this.a=a},
ed:function ed(a){this.a=a},
d_:function d_(){var _=this
_.b=_.a=$
_.c=null
_.r=_.f=_.e=_.d=!1},
el:function el(a,b){this.a=a
this.b=b},
ej:function ej(a){this.a=a},
em:function em(a){this.a=a},
en:function en(a){this.a=a},
ei:function ei(){},
ek:function ek(){},
er:function er(a){this.a=a},
es:function es(){},
T(a,b,c){return A.bn(new A.fu(a),a.gbw(),new A.ap(c,b))},
o(a,b){var s=new A.a2(A.h([],t.t),A.h([],t.gL),new A.a_(new A.j($.i,t.U),t.h))
s.cS(a,b)
return s},
a1(a,b){var s=0,r=A.w(t.H),q,p,o
var $async$a1=A.n(function(c,d){if(c===1)return A.t(d,r)
for(;;)switch(s){case 0:p=t.H,o=0
case 3:if(!(o<1e4)){s=5
break}s=6
return A.a(A.q(B.a,p),$async$a1)
case 6:if(B.b.aj(b,new A.hx())){s=1
break}s=a.gK()>0?7:8
break
case 7:s=9
return A.a(a.J(),$async$a1)
case 9:case 8:case 4:++o
s=3
break
case 5:throw A.c(A.f("streams did not settle within the deterministic work bound"))
case 1:return A.u(q,r)}})
return A.v($async$a1,r)},
dc(a,b){return A.lM(a,b)},
lM(a,b){var s=0,r=A.w(t.H),q,p=2,o=[],n,m,l,k,j
var $async$dc=A.n(function(c,d){if(c===1){o.push(d)
s=p}for(;;)switch(s){case 0:p=4
s=7
return A.a(a.$0(),$async$dc)
case 7:p=2
s=6
break
case 4:p=3
j=o.pop()
n=A.O(j)
l=b.$1(n)
k=A.y(n)
if(!l)A.b(A.f("unexpected failure: "+k))
s=1
break
s=6
break
case 3:s=2
break
case 6:throw A.c(A.f("expected failure"))
case 1:return A.u(q,r)
case 2:return A.t(o.at(-1),r)}})
return A.v($async$dc,r)},
H(){return A.lX()},
lX(){var s=0,r=A.w(t.H),q,p
var $async$H=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:p={}
p.a=0
q=new A.hu(p)
s=2
return A.a(q.$2("limits reject invalid values without changing runtime state",new A.h2()),$async$H)
case 2:s=3
return A.a(q.$2("independent directions pace before handoff and count actual payload",new A.h3()),$async$H)
case 3:s=4
return A.a(q.$2("many sibling contexts share one fair operation allocation",new A.h4()),$async$H)
case 4:s=5
return A.a(q.$2("byte fairness does not depend on request chunk sizes",new A.hf()),$async$H)
case 5:s=6
return A.a(q.$2("late joiners start at current service without historical catch-up",new A.hj()),$async$H)
case 6:s=7
return A.a(q.$2("idle rejoiners receive no credit for time spent without ready data",new A.hk()),$async$H)
case 7:s=8
return A.a(q.$2("a waiting source does not reserve another ready jobs capacity",new A.hl()),$async$H)
case 8:s=9
return A.a(q.$2("pause withdraws pending work and no paused time becomes burst credit",new A.hm()),$async$H)
case 9:s=10
return A.a(q.$2("downstream pause releases pending quota for another job",new A.hn()),$async$H)
case 10:s=11
return A.a(q.$2("limit changes wake pending work and zero is unlimited",new A.ho()),$async$H)
case 11:s=12
return A.a(q.$2("changing upload limits leaves download pacing untouched",new A.hp()),$async$H)
case 12:s=13
return A.a(q.$2("lowering a limit invalidates already waiting higher-rate slices",new A.h5()),$async$H)
case 13:s=14
return A.a(q.$2("one-byte and maximum allowed rates retain safe timing arithmetic",new A.h6()),$async$H)
case 14:s=15
return A.a(q.$2("cancel affects sibling contexts while close releases only its own demand",new A.h7()),$async$H)
case 15:s=16
return A.a(q.$2("allocator disposal wakes sources, paused consumers and quotas",new A.h8()),$async$H)
case 16:s=17
return A.a(q.$2("captured binding remains owned by A when subscribed inside B",new A.h9()),$async$H)
case 17:s=18
return A.a(q.$2("a closed captured context cannot reopen under a reused job ID",new A.ha()),$async$H)
case 18:s=19
return A.a(q.$2("unsupported paths preserve bytes and controls without false upload accounting",new A.hb()),$async$H)
case 19:s=20
return A.a(q.$2("reused 100KiB input is copied under pull backpressure into immutable slices",new A.hc()),$async$H)
case 20:s=21
return A.a(q.$2("original read error is delivered before stalled upstream cancellation completes",new A.hd()),$async$H)
case 21:s=22
return A.a(q.$2("downstream cancellation detaches stalled provider cleanup promptly",new A.he()),$async$H)
case 22:s=23
return A.a(q.$2("submitted payload is not refunded when a later source error occurs",new A.hg()),$async$H)
case 23:s=24
return A.a(q.$2("observed direction rates decay without idle timers",new A.hh()),$async$H)
case 24:s=25
return A.a(q.$2("invalid input bytes fail before handoff and release quota",new A.hi()),$async$H)
case 25:A.je(B.t.cq(A.dt(["suite","shared-transfer-bandwidth","passed",p.a,"failed",0],t.N,t.K),null))
return A.u(null,r)}})
return A.v($async$H,r)},
fu:function fu(a){this.a=a},
a2:function a2(a,b,c){var _=this
_.a=a
_.b=b
_.c=c
_.d=null
_.e=$},
dg:function dg(a,b){this.a=a
this.b=b},
dh:function dh(a){this.a=a},
hx:function hx(){},
hu:function hu(a){this.a=a},
h2:function h2(){},
fT:function fT(a,b){this.a=a
this.b=b},
fU:function fU(){},
h3:function h3(){},
h4:function h4(){},
fR:function fR(a){this.a=a},
fS:function fS(a){this.a=a},
hf:function hf(){},
ht:function ht(a){this.a=a},
fP:function fP(a,b){this.a=a
this.b=b},
fQ:function fQ(a,b){this.a=a
this.b=b},
hj:function hj(){},
hk:function hk(){},
hl:function hl(){},
hm:function hm(){},
fO:function fO(a){this.a=a},
hn:function hn(){},
ho:function ho(){},
hp:function hp(){},
h5:function h5(){},
h6:function h6(){},
h7:function h7(){},
h8:function h8(){},
fM:function fM(){},
fN:function fN(){},
h9:function h9(){},
hs:function hs(a){this.a=a},
h0:function h0(a,b){this.a=a
this.b=b},
h1:function h1(a,b){this.a=a
this.b=b},
ha:function ha(){},
h_:function h_(a){this.a=a},
hb:function hb(){},
hc:function hc(){},
hr:function hr(a){this.a=a},
fV:function fV(){},
fW:function fW(){},
fX:function fX(){},
fY:function fY(a){this.a=a},
fZ:function fZ(){},
hd:function hd(){},
fL:function fL(a,b){this.a=a
this.b=b},
fI:function fI(a,b){this.a=a
this.b=b},
fK:function fK(a,b){this.a=a
this.b=b},
he:function he(){},
fJ:function fJ(a){this.a=a},
hg:function hg(){},
hq:function hq(){},
hh:function hh(){},
hi:function hi(){},
L:function L(a,b){this.a=a
this.b=b},
dv:function dv(){},
dy:function dy(a){this.a=a},
dz:function dz(){},
dA:function dA(){},
dw:function dw(){},
dx:function dx(){},
ah:function ah(a,b){var _=this
_.a=a
_.b=b
_.c=!0
_.d=0},
ji(a){return v.mangledGlobalNames[a]},
jf(a){if(typeof dartPrint=="function"){dartPrint(a)
return}if(typeof console=="object"&&typeof console.log!="undefined"){console.log(a)
return}if(typeof print=="function"){print(a)
return}throw"Unable to print message: "+String(a)}},B={}
var w=[A,J,B]
var $={}
A.hD.prototype={}
J.cH.prototype={
S(a,b){return a===b},
gC(a){return A.bZ(a)},
i(a){return"Instance of '"+A.cQ(a)+"'"},
gZ(a){return A.b9(A.hT(this))}}
J.cJ.prototype={
i(a){return String(a)},
gC(a){return a?519018:218159},
gZ(a){return A.b9(t.y)},
$ia5:1,
$ip:1}
J.bO.prototype={
S(a,b){return null==b},
i(a){return"null"},
gC(a){return 0},
$ia5:1,
$iJ:1}
J.bQ.prototype={$iaj:1}
J.aE.prototype={
gC(a){return 0},
i(a){return String(a)}}
J.cP.prototype={}
J.c2.prototype={}
J.as.prototype={
i(a){var s=a[$.jl()]
if(s==null)s=a[$.jk()]
if(s==null)return this.cQ(a)
return"JavaScript function for "+J.cv(s)},
$iaQ:1}
J.bf.prototype={
gC(a){return 0},
i(a){return String(a)}}
J.bg.prototype={
gC(a){return 0},
i(a){return String(a)}}
J.D.prototype={
m(a,b){A.V(a).c.a(b)
a.$flags&1&&A.aP(a,29)
a.push(b)},
dv(a,b,c){var s,r,q,p,o
A.V(a).h("p(1)").a(b)
s=[]
r=a.length
for(q=0;q<r;++q){p=a[q]
if(!b.$1(p))s.push(p)
if(a.length!==r)throw A.c(A.X(a))}o=s.length
if(o===r)return
this.sk(a,o)
for(q=0;q<s.length;++q)a[q]=s[q]},
ai(a,b){var s,r
A.V(a).h("m<1>").a(b)
a.$flags&1&&A.aP(a,"addAll",2)
if(Array.isArray(b)){this.cY(a,b)
return}for(s=b.length,r=0;r<b.length;b.length===s||(0,A.W)(b),++r)a.push(b[r])},
cY(a,b){var s,r
t.b.a(b)
s=b.length
if(s===0)return
if(a===b)throw A.c(A.X(a))
for(r=0;r<s;++r)a.push(b[r])},
dX(a,b){var s,r=A.Y(a.length,"",!1,t.N)
for(s=0;s<a.length;++s)this.v(r,s,A.y(a[s]))
return r.join(b)},
U(a,b){if(!(b>=0&&b<a.length))return A.z(a,b)
return a[b]},
gct(a){if(a.length>0)return a[0]
throw A.c(A.bM())},
gcP(a){var s=a.length
if(s===1){if(0>=s)return A.z(a,0)
return a[0]}if(s===0)throw A.c(A.bM())
throw A.c(A.jR())},
by(a,b,c,d,e){var s,r,q,p
A.V(a).h("m<1>").a(d)
a.$flags&2&&A.aP(a,5)
A.dH(b,c,a.length)
s=c-b
if(s===0)return
A.dG(e,"skipCount")
r=d
if(e+s>r.length)throw A.c(A.jQ())
if(e<b)for(q=s-1;q>=0;--q){p=e+q
if(!(p<r.length))return A.z(r,p)
a[b+q]=r[p]}else for(q=0;q<s;++q){p=e+q
if(!(p<r.length))return A.z(r,p)
a[b+q]=r[p]}},
aj(a,b){var s,r
A.V(a).h("p(1)").a(b)
s=a.length
for(r=0;r<s;++r){if(!b.$1(a[r]))return!1
if(a.length!==s)throw A.c(A.X(a))}return!0},
bz(a,b){var s,r,q,p,o,n=A.V(a)
n.h("l(1,1)?").a(b)
a.$flags&2&&A.aP(a,"sort")
s=a.length
if(s<2)return
if(s===2){r=a[0]
q=a[1]
n=b.$2(r,q)
if(typeof n!=="number")return n.cN()
if(n>0){a[0]=q
a[1]=r}return}p=0
if(n.c.b(null))for(o=0;o<a.length;++o)if(a[o]===void 0){a[o]=null;++p}a.sort(A.cs(b,2))
if(p>0)this.dw(a,p)},
dw(a,b){var s,r=a.length
for(;s=r-1,r>0;r=s)if(a[s]===null){a[s]=void 0;--b
if(b===0)break}},
gcv(a){return a.length!==0},
i(a){return A.dn(a,"[","]")},
gF(a){return new J.bG(a,a.length,A.V(a).h("bG<1>"))},
gC(a){return A.bZ(a)},
gk(a){return a.length},
sk(a,b){a.$flags&1&&A.aP(a,"set length","change the length of")
if(b>a.length)A.V(a).c.a(null)
a.length=b},
u(a,b){if(!(b>=0&&b<a.length))throw A.c(A.fA(a,b))
return a[b]},
v(a,b,c){A.V(a).c.a(c)
a.$flags&2&&A.aP(a)
if(!(b>=0&&b<a.length))throw A.c(A.fA(a,b))
a[b]=c},
$im:1,
$iF:1}
J.cI.prototype={
e6(a){var s,r,q
if(!Array.isArray(a))return null
s=a.$flags|0
if((s&4)!==0)r="const, "
else if((s&2)!==0)r="unmodifiable, "
else r=(s&1)!==0?"fixed, ":""
q="Instance of '"+A.cQ(a)+"'"
if(r==="")return q
return q+" ("+r+"length: "+a.length+")"}}
J.dp.prototype={}
J.bG.prototype={
gB(){var s=this.d
return s==null?this.$ti.c.a(s):s},
q(){var s,r=this,q=r.a,p=q.length
if(r.b!==p){q=A.W(q)
throw A.c(q)}s=r.c
if(s>=p){r.d=null
return!1}r.d=q[s]
r.c=s+1
return!0},
$iU:1}
J.bP.prototype={
cp(a,b){var s
A.iM(b)
if(a<b)return-1
else if(a>b)return 1
else if(a===b){if(a===0){s=this.gbr(b)
if(this.gbr(a)===s)return 0
if(this.gbr(a))return-1
return 1}return 0}else if(isNaN(a)){if(isNaN(b))return 0
return 1}else return-1},
gbr(a){return a===0?1/a<0:a<0},
dQ(a){var s,r
if(a>=0){if(a<=2147483647)return a|0}else if(a>=-2147483648){s=a|0
return a===s?s:s-1}r=Math.floor(a)
if(isFinite(r))return r
throw A.c(A.c3(""+a+".floor()"))},
i(a){if(a===0&&1/a<0)return"-0.0"
else return""+a},
gC(a){var s,r,q,p,o=a|0
if(a===o)return o&536870911
s=Math.abs(a)
r=Math.log(s)/0.6931471805599453|0
q=Math.pow(2,r)
p=s<1?s/q:q/s
return((p*9007199254740992|0)+(p*3542243181176521|0))*599197+r*1259&536870911},
b1(a,b){if((a|0)===a)if(b>=1||b<-1)return a/b|0
return this.ca(a,b)},
O(a,b){return(a|0)===a?a/b|0:this.ca(a,b)},
ca(a,b){var s=a/b
if(s>=-2147483648&&s<=2147483647)return s|0
if(s>0){if(s!==1/0)return Math.floor(s)}else if(s>-1/0)return Math.ceil(s)
throw A.c(A.c3("Result of truncating division is "+A.y(s)+": "+A.y(a)+" ~/ "+b))},
c8(a,b){var s
if(a>0)s=this.dC(a,b)
else{s=b>31?31:b
s=a>>s>>>0}return s},
dC(a,b){return b>31?0:a>>>b},
gZ(a){return A.b9(t.o)},
$ict:1,
$ibD:1}
J.bN.prototype={
gZ(a){return A.b9(t.S)},
$ia5:1,
$il:1}
J.cK.prototype={
gZ(a){return A.b9(t.i)},
$ia5:1}
J.be.prototype={
aM(a,b,c){return a.substring(b,A.dH(b,c,a.length))},
cO(a,b){var s,r
if(0>=b)return""
if(b===1||a.length===0)return a
if(b!==b>>>0)throw A.c(B.E)
for(s=a,r="";;){if((b&1)===1)r=s+r
b=b>>>1
if(b===0)break
s+=s}return r},
e0(a,b,c){var s=b-a.length
if(s<=0)return a
return this.cO(c,s)+a},
i(a){return a},
gC(a){var s,r,q
for(s=a.length,r=0,q=0;q<s;++q){r=r+a.charCodeAt(q)&536870911
r=r+((r&524287)<<10)&536870911
r^=r>>6}r=r+((r&67108863)<<3)&536870911
r^=r>>11
return r+((r&16383)<<15)&536870911},
gZ(a){return A.b9(t.N)},
gk(a){return a.length},
$ia5:1,
$iae:1}
A.aS.prototype={
i(a){return"LateInitializationError: "+this.a}}
A.hw.prototype={
$0(){return A.ih(null,t.H)},
$S:1}
A.dI.prototype={}
A.bJ.prototype={}
A.a3.prototype={
gF(a){var s=this
return new A.aW(s,s.gk(s),A.e(s).h("aW<a3.E>"))},
aj(a,b){var s,r,q=this
A.e(q).h("p(a3.E)").a(b)
s=q.gk(q)
for(r=0;r<s;++r){if(!b.$1(q.U(0,r)))return!1
if(s!==q.gk(q))throw A.c(A.X(q))}return!0},
dR(a,b,c,d){var s,r,q,p=this
d.a(b)
A.e(p).p(d).h("1(1,a3.E)").a(c)
s=p.gk(p)
for(r=b,q=0;q<s;++q){r=c.$2(r,p.U(0,q))
if(s!==p.gk(p))throw A.c(A.X(p))}return r}}
A.c1.prototype={
gda(){var s=J.aC(this.a),r=this.c
if(r==null||r>s)return s
return r},
gdE(){var s=J.aC(this.a),r=this.b
if(r>s)return s
return r},
gk(a){var s,r=J.aC(this.a),q=this.b
if(q>=r)return 0
s=this.c
if(s==null||s>=r)return r-q
return s-q},
U(a,b){var s=this,r=s.gdE()+b
if(b<0||r>=s.gda())throw A.c(A.dm(b,s.gk(0),s,null,"index"))
return J.i8(s.a,r)}}
A.aW.prototype={
gB(){var s=this.d
return s==null?this.$ti.c.a(s):s},
q(){var s,r=this,q=r.a,p=J.j9(q),o=p.gk(q)
if(r.b!==o)throw A.c(A.X(q))
s=r.c
if(s>=o){r.d=null
return!1}r.d=p.U(q,s);++r.c
return!0},
$iU:1}
A.bU.prototype={
gk(a){return J.aC(this.a)},
U(a,b){return this.b.$1(J.i8(this.a,b))}}
A.a6.prototype={
gF(a){return new A.c4(J.df(this.a),this.b,this.$ti.h("c4<1>"))}}
A.c4.prototype={
q(){var s,r
for(s=this.a,r=this.b;s.q();)if(r.$1(s.gB()))return!0
return!1},
gB(){return this.a.gB()},
$iU:1}
A.bL.prototype={}
A.bt.prototype={$r:"+(1,2)",$s:1}
A.bH.prototype={
gP(a){return this.gk(this)===0},
i(a){return A.hH(this)},
v(a,b,c){var s=A.e(this)
s.c.a(b)
s.y[1].a(c)
A.jL()},
$iao:1}
A.bI.prototype={
gk(a){return this.b.length},
gdg(){var s=this.$keys
if(s==null){s=Object.keys(this.a)
this.$keys=s}return s},
aa(a){if(typeof a!="string")return!1
if("__proto__"===a)return!1
return this.a.hasOwnProperty(a)},
u(a,b){if(!this.aa(b))return null
return this.b[this.a[b]]},
ak(a,b){var s,r,q,p
this.$ti.h("~(1,2)").a(b)
s=this.gdg()
r=this.b
for(q=s.length,p=0;p<q;++p)b.$2(s[p],r[p])}}
A.dD.prototype={
$0(){return B.w.dQ(1000*this.a.now())},
$S:13}
A.c_.prototype={}
A.dW.prototype={
R(a){var s,r,q=this,p=new RegExp(q.a).exec(a)
if(p==null)return null
s=Object.create(null)
r=q.b
if(r!==-1)s.arguments=p[r+1]
r=q.c
if(r!==-1)s.argumentsExpr=p[r+1]
r=q.d
if(r!==-1)s.expr=p[r+1]
r=q.e
if(r!==-1)s.method=p[r+1]
r=q.f
if(r!==-1)s.receiver=p[r+1]
return s}}
A.bY.prototype={
i(a){return"Null check operator used on a null value"}}
A.cM.prototype={
i(a){var s,r=this,q="NoSuchMethodError: method not found: '",p=r.b
if(p==null)return"NoSuchMethodError: "+r.a
s=r.c
if(s==null)return q+p+"' ("+r.a+")"
return q+p+"' on '"+s+"' ("+r.a+")"}}
A.cV.prototype={
i(a){var s=this.a
return s.length===0?"Error":"Error: "+s}}
A.dC.prototype={
i(a){return"Throw of null ('"+(this.a===null?"null":"undefined")+"' from JavaScript)"}}
A.bK.prototype={}
A.cf.prototype={
i(a){var s,r=this.b
if(r!=null)return r
r=this.a
s=r!==null&&typeof r==="object"?r.stack:null
return this.b=s==null?"":s},
$iQ:1}
A.aD.prototype={
i(a){var s=this.constructor,r=s==null?null:s.name
return"Closure '"+A.jj(r==null?"unknown":r)+"'"},
$iaQ:1,
ge9(){return this},
$C:"$1",
$R:1,
$D:null}
A.cA.prototype={$C:"$0",$R:0}
A.cB.prototype={$C:"$2",$R:2}
A.cT.prototype={}
A.cS.prototype={
i(a){var s=this.$static_name
if(s==null)return"Closure of unknown static method"
return"Closure '"+A.jj(s)+"'"}}
A.bd.prototype={
S(a,b){if(b==null)return!1
if(this===b)return!0
if(!(b instanceof A.bd))return!1
return this.$_target===b.$_target&&this.a===b.a},
gC(a){return(A.jc(this.a)^A.bZ(this.$_target))>>>0},
i(a){return"Closure '"+this.$_name+"' of "+("Instance of '"+A.cQ(this.a)+"'")}}
A.cR.prototype={
i(a){return"RuntimeError: "+this.a}}
A.aR.prototype={
gk(a){return this.a},
gP(a){return this.a===0},
gaY(){return new A.aT(this,A.e(this).h("aT<1>"))},
aa(a){var s,r
if(typeof a=="string"){s=this.b
if(s==null)return!1
return s[a]!=null}else if(typeof a=="number"&&(a&0x3fffffff)===a){r=this.c
if(r==null)return!1
return r[a]!=null}else return this.dU(a)},
dU(a){var s=this.d
if(s==null)return!1
return this.aX(this.bQ(s,a),a)>=0},
u(a,b){var s,r,q,p,o=null
if(typeof b=="string"){s=this.b
if(s==null)return o
r=s[b]
q=r==null?o:r.b
return q}else if(typeof b=="number"&&(b&0x3fffffff)===b){p=this.c
if(p==null)return o
r=p[b]
q=r==null?o:r.b
return q}else return this.dV(b)},
dV(a){var s,r,q=this.d
if(q==null)return null
s=this.bQ(q,a)
r=this.aX(s,a)
if(r<0)return null
return s[r].b},
v(a,b,c){var s,r,q,p,o,n,m=this,l=A.e(m)
l.c.a(b)
l.y[1].a(c)
if(typeof b=="string"){s=m.b
m.bA(s==null?m.b=m.bd():s,b,c)}else if(typeof b=="number"&&(b&0x3fffffff)===b){r=m.c
m.bA(r==null?m.c=m.bd():r,b,c)}else{q=m.d
if(q==null)q=m.d=m.bd()
p=m.bo(b)
o=q[p]
if(o==null)q[p]=[m.be(b,c)]
else{n=m.aX(o,b)
if(n>=0)o[n].b=c
else o.push(m.be(b,c))}}},
e1(a,b){var s,r,q=this,p=A.e(q)
p.c.a(a)
p.h("2()").a(b)
if(q.aa(a)){s=q.u(0,a)
return s==null?p.y[1].a(s):s}r=b.$0()
q.v(0,a,r)
return r},
Y(a,b){var s
if(typeof b=="string")return this.du(this.b,b)
else{s=this.dW(b)
return s}},
dW(a){var s,r,q,p,o=this,n=o.d
if(n==null)return null
s=o.bo(a)
r=n[s]
q=o.aX(r,a)
if(q<0)return null
p=r.splice(q,1)[0]
o.cd(p)
if(r.length===0)delete n[s]
return p.b},
co(a){var s=this
if(s.a>0){s.b=s.c=s.d=s.e=s.f=null
s.a=0
s.bc()}},
ak(a,b){var s,r,q=this
A.e(q).h("~(1,2)").a(b)
s=q.e
r=q.r
while(s!=null){b.$2(s.a,s.b)
if(r!==q.r)throw A.c(A.X(q))
s=s.c}},
bA(a,b,c){var s,r=A.e(this)
r.c.a(b)
r.y[1].a(c)
s=a[b]
if(s==null)a[b]=this.be(b,c)
else s.b=c},
du(a,b){var s
if(a==null)return null
s=a[b]
if(s==null)return null
this.cd(s)
delete a[b]
return s.b},
bc(){this.r=this.r+1&1073741823},
be(a,b){var s=this,r=A.e(s),q=new A.ds(r.c.a(a),r.y[1].a(b))
if(s.e==null)s.e=s.f=q
else{r=s.f
r.toString
q.d=r
s.f=r.c=q}++s.a
s.bc()
return q},
cd(a){var s=this,r=a.d,q=a.c
if(r==null)s.e=q
else r.c=q
if(q==null)s.f=r
else q.d=r;--s.a
s.bc()},
bo(a){return J.an(a)&1073741823},
bQ(a,b){return a[this.bo(b)]},
aX(a,b){var s,r
if(a==null)return-1
s=a.length
for(r=0;r<s;++r)if(J.aB(a[r].a,b))return r
return-1},
i(a){return A.hH(this)},
bd(){var s=Object.create(null)
s["<non-identifier-key>"]=s
delete s["<non-identifier-key>"]
return s},
$iij:1}
A.ds.prototype={}
A.aT.prototype={
gk(a){return this.a.a},
gP(a){return this.a.a===0},
gF(a){var s=this.a
return new A.at(s,s.r,s.e,this.$ti.h("at<1>"))}}
A.at.prototype={
gB(){return this.d},
q(){var s,r=this,q=r.a
if(r.b!==q.r)throw A.c(A.X(q))
s=r.c
if(s==null){r.d=null
return!1}else{r.d=s.a
r.c=s.c
return!0}},
$iU:1}
A.aV.prototype={
gk(a){return this.a.a},
gF(a){var s=this.a
return new A.aU(s,s.r,s.e,this.$ti.h("aU<1>"))}}
A.aU.prototype={
gB(){return this.d},
q(){var s,r=this,q=r.a
if(r.b!==q.r)throw A.c(A.X(q))
s=r.c
if(s==null){r.d=null
return!1}else{r.d=s.b
r.c=s.c
return!0}},
$iU:1}
A.bS.prototype={
gk(a){return this.a.a},
gF(a){var s=this.a
return new A.bT(s,s.r,s.e,this.$ti.h("bT<1,2>"))}}
A.bT.prototype={
gB(){var s=this.d
s.toString
return s},
q(){var s,r=this,q=r.a
if(r.b!==q.r)throw A.c(A.X(q))
s=r.c
if(s==null){r.d=null
return!1}else{r.d=new A.aY(s.a,s.b,r.$ti.h("aY<1,2>"))
r.c=s.c
return!0}},
$iU:1}
A.fE.prototype={
$1(a){return this.a(a)},
$S:14}
A.fF.prototype={
$2(a,b){return this.a(a,b)},
$S:26}
A.fG.prototype={
$1(a){return this.a(A.bx(a))},
$S:33}
A.b6.prototype={
i(a){return this.cc(!1)},
cc(a){var s,r,q,p,o,n=this.dd(),m=this.bR(),l=(a?"Record ":"")+"("
for(s=n.length,r="",q=0;q<s;++q,r=", "){l+=r
p=n[q]
if(typeof p=="string")l=l+p+": "
if(!(q<m.length))return A.z(m,q)
o=m[q]
l=a?l+A.io(o):l+A.y(o)}l+=")"
return l.charCodeAt(0)==0?l:l},
dd(){var s,r=this.$s
while($.f_.length<=r)B.b.m($.f_,null)
s=$.f_[r]
if(s==null){s=this.d6()
B.b.v($.f_,r,s)}return s},
d6(){var s,r,q,p=this.$r,o=p.indexOf("("),n=p.substring(1,o),m=p.substring(o),l=m==="()"?0:m.replace(/[^,]/g,"").length+1,k=t.K,j=J.hC(l,k)
for(s=0;s<l;++s)j[s]=s
if(n!==""){r=n.split(",")
s=r.length
for(q=l;s>0;){--q;--s
B.b.v(j,q,r[s])}}j=A.jY(j,!1,k)
j.$flags=3
return j}}
A.bs.prototype={
bR(){return[this.a,this.b]},
S(a,b){if(b==null)return!1
return b instanceof A.bs&&this.$s===b.$s&&J.aB(this.a,b.a)&&J.aB(this.b,b.b)},
gC(a){return A.il(this.$s,this.a,this.b,B.j)}}
A.ez.prototype={
bi(){var s=this.b
if(s===this)throw A.c(new A.aS("Local '' has not been initialized."))
return s}}
A.aZ.prototype={
gZ(a){return B.X},
cj(a,b,c){var s=new Uint8Array(a,b,c)
return s},
$ia5:1,
$iaZ:1}
A.bW.prototype={
gdK(a){if(((a.$flags|0)&2)!==0)return new A.fc(a.buffer)
else return a.buffer}}
A.fc.prototype={
cj(a,b,c){var s=A.jZ(this.a,b,c)
s.$flags=3
return s}}
A.bi.prototype={
gk(a){return a.length},
$icL:1}
A.bV.prototype={
v(a,b,c){A.ar(c)
a.$flags&2&&A.aP(a)
A.iQ(b,a,a.length)
a[b]=c},
$im:1,
$iF:1}
A.bX.prototype={
gZ(a){return B.Z},
gk(a){return a.length},
u(a,b){A.iQ(b,a,a.length)
return a[b]},
ck(a){var s
if(((a.$flags|0)&2)!==0)return a
s=new Uint8Array(a.buffer,a.byteOffset,a.length)
s.$flags=3
return s},
$ia5:1}
A.cc.prototype={}
A.cd.prototype={}
A.ak.prototype={
h(a){return A.co(v.typeUniverse,this,a)},
p(a){return A.iI(v.typeUniverse,this,a)}}
A.d3.prototype={}
A.fa.prototype={
i(a){return A.a9(this.a,null)}}
A.d2.prototype={
i(a){return this.a}}
A.ck.prototype={$iau:1}
A.e0.prototype={
$1(a){var s=this.a,r=s.a
s.a=null
r.$0()},
$S:9}
A.e_.prototype={
$1(a){var s,r
this.a.a=t.M.a(a)
s=this.b
r=this.c
s.firstChild?s.removeChild(r):s.appendChild(r)},
$S:34}
A.e1.prototype={
$0(){this.a.$0()},
$S:2}
A.e2.prototype={
$0(){this.a.$0()},
$S:2}
A.cj.prototype={
cW(a,b){if(self.setTimeout!=null)this.b=self.setTimeout(A.cs(new A.f9(this,b),0),a)
else throw A.c(A.c3("`setTimeout()` not found."))},
cX(a,b){if(self.setTimeout!=null)this.b=self.setInterval(A.cs(new A.f8(this,a,Date.now(),b),0),a)
else throw A.c(A.c3("Periodic timer."))},
gbq(){return this.b!=null},
A(){if(self.setTimeout!=null){var s=this.b
if(s==null)return
if(this.a)self.clearTimeout(s)
else self.clearInterval(s)
this.b=null}else throw A.c(A.c3("Canceling a timer."))},
$ia4:1}
A.f9.prototype={
$0(){var s=this.a
s.b=null
s.c=1
this.b.$0()},
$S:0}
A.f8.prototype={
$0(){var s,r=this,q=r.a,p=q.c+1,o=r.b
if(o>0){s=Date.now()-r.c
if(s>(p+1)*o)p=B.e.b1(s,o)}q.c=p
r.d.$1(q)},
$S:2}
A.c5.prototype={
I(a){var s,r=this,q=r.$ti
q.h("1/?").a(a)
if(a==null)a=q.c.a(a)
if(!r.b)r.a.E(a)
else{s=r.a
if(q.h("K<1>").b(a))s.bD(a)
else s.a_(a)}},
bm(a,b){var s=this.a
if(this.b)s.G(new A.A(a,b))
else s.a5(new A.A(a,b))},
$idi:1}
A.fs.prototype={
$1(a){return this.a.$2(0,a)},
$S:19}
A.ft.prototype={
$2(a,b){this.a.$2(1,new A.bK(a,t.l.a(b)))},
$S:53}
A.fz.prototype={
$2(a,b){this.a(A.ar(a),b)},
$S:41}
A.fq.prototype={
$0(){var s,r=this.a,q=r.a
q===$&&A.x()
s=q.b
if((s&1)!==0?(q.ga1().e&4)!==0:(s&2)===0){r.b=!0
return}r=r.c!=null?2:0
this.b.$2(r,null)},
$S:0}
A.fr.prototype={
$1(a){var s=this.a.c!=null?2:0
this.b.$2(s,null)},
$S:9}
A.cY.prototype={
cT(a,b){var s=this,r=new A.e4(a)
s.a=s.$ti.h("b_<1>").a(A.bl(new A.e6(s,a),new A.e7(r),null,new A.e8(s,r),!1,b))}}
A.e4.prototype={
$0(){A.aA(new A.e5(this.a))},
$S:2}
A.e5.prototype={
$0(){this.a.$2(0,null)},
$S:0}
A.e7.prototype={
$0(){this.a.$0()},
$S:0}
A.e8.prototype={
$0(){var s=this.a
if(s.b){s.b=!1
this.b.$0()}},
$S:0}
A.e6.prototype={
$0(){var s=this.a,r=s.a
r===$&&A.x()
if((r.b&4)===0){s.c=new A.j($.i,t._)
if(s.b){s.b=!1
A.aA(new A.e3(this.b))}return s.c}},
$S:25}
A.e3.prototype={
$0(){this.a.$2(2,null)},
$S:0}
A.cb.prototype={
i(a){return"IterationMarker("+this.b+", "+A.y(this.a)+")"}}
A.A.prototype={
i(a){return A.y(this.a)},
$iB:1,
gau(){return this.b}}
A.aq.prototype={
ag(){},
ah(){},
saS(a){this.ch=this.$ti.h("aq<1>?").a(a)},
sbh(a){this.CW=this.$ti.h("aq<1>?").a(a)}}
A.b1.prototype={
gaR(){return this.c<4},
c4(a){var s,r
A.e(this).h("aq<1>").a(a)
s=a.CW
r=a.ch
if(s==null)this.d=r
else s.saS(r)
if(r==null)this.e=s
else r.sbh(s)
a.sbh(a)
a.saS(a)},
c9(a,b,c,d){var s,r,q,p,o,n,m,l,k=this,j=A.e(k)
j.h("~(1)?").a(a)
t.Z.a(c)
if((k.c&4)!==0){s=$.i
j=new A.br(s,j.h("br<1>"))
A.aA(j.gbU())
if(c!=null)j.c=s.X(c,t.H)
return j}s=$.i
r=d?1:0
q=b!=null?32:0
p=a==null?A.j5():a
o=t.H
p=s.an(p,o,j.c)
n=A.ix(s,b)
j=j.h("aq<1>")
m=new A.aq(k,p,n,s.X(c==null?A.j6():c,o),s,r|q,j)
m.CW=m
m.ch=m
j.a(m)
m.ay=k.c&1
l=k.e
k.e=m
m.saS(null)
m.sbh(l)
if(l==null)k.d=m
else l.saS(m)
if(k.d==k.e)A.da(k.a)
return m},
bZ(a){var s=this,r=A.e(s)
a=r.h("aq<1>").a(r.h("al<1>").a(a))
if(a.ch===a)return null
r=a.ay
if((r&2)!==0)a.ay=r|4
else{s.c4(a)
if((s.c&2)===0&&s.d==null)s.b2()}return null},
c_(a){A.e(this).h("al<1>").a(a)},
c0(a){A.e(this).h("al<1>").a(a)},
aN(){if((this.c&4)!==0)return new A.Z("Cannot add new events after calling close")
return new A.Z("Cannot add new events while doing an addStream")},
j(){var s,r,q=this
if((q.c&4)!==0){s=q.r
s.toString
return s}if(!q.gaR())throw A.c(q.aN())
q.c|=4
r=q.r
if(r==null)r=q.r=new A.j($.i,t.U)
q.a8()
return r},
a3(a,b){this.a9(A.G(a),t.l.a(b))},
ae(){var s=this.f
s.toString
this.f=null
this.c&=4294967287
s.a.E(null)},
b9(a){var s,r,q,p,o=this
A.e(o).h("~(a0<1>)").a(a)
s=o.c
if((s&2)!==0)throw A.c(A.f(u.g))
r=o.d
if(r==null)return
q=s&1
o.c=s^3
while(r!=null){s=r.ay
if((s&1)===q){r.ay=s|2
a.$1(r)
s=r.ay^=1
p=r.ch
if((s&4)!==0)o.c4(r)
r.ay&=4294967293
r=p}else r=r.ch}o.c&=4294967293
if(o.d==null)o.b2()},
b2(){if((this.c&4)!==0){var s=this.r
if((s.a&30)===0)s.E(null)}A.da(this.b)},
$ib_:1,
$icg:1,
$iag:1}
A.ci.prototype={
gaR(){return A.b1.prototype.gaR.call(this)&&(this.c&2)===0},
aN(){if((this.c&2)!==0)return new A.Z(u.g)
return this.cR()},
a0(a){var s,r=this
r.$ti.c.a(a)
s=r.d
if(s==null)return
if(s===r.e){r.c|=2
s.a4(a)
r.c&=4294967293
if(r.d==null)r.b2()
return}r.b9(new A.f5(r,a))},
a9(a,b){if(this.d==null)return
this.b9(new A.f7(this,a,b))},
a8(){var s=this
if(s.d!=null)s.b9(new A.f6(s))
else s.r.E(null)}}
A.f5.prototype={
$1(a){this.a.$ti.h("a0<1>").a(a).a4(this.b)},
$S(){return this.a.$ti.h("~(a0<1>)")}}
A.f7.prototype={
$1(a){this.a.$ti.h("a0<1>").a(a).a3(this.b,this.c)},
$S(){return this.a.$ti.h("~(a0<1>)")}}
A.f6.prototype={
$1(a){this.a.$ti.h("a0<1>").a(a).ae()},
$S(){return this.a.$ti.h("~(a0<1>)")}}
A.dj.prototype={
$0(){this.c.a(null)
this.b.aP(null)},
$S:0}
A.dl.prototype={
$2(a,b){var s,r,q=this
A.G(a)
t.l.a(b)
s=q.a
r=--s.b
if(s.a!=null){s.a=null
s.d=a
s.c=b
if(r===0||q.c)q.d.G(new A.A(a,b))}else if(r===0&&!q.c){r=s.d
r.toString
s=s.c
s.toString
q.d.G(new A.A(r,s))}},
$S:4}
A.dk.prototype={
$1(a){var s,r,q,p,o,n,m,l,k=this,j=k.d
j.a(a)
o=k.a
s=--o.b
r=o.a
if(r!=null){J.hA(r,k.b,a)
if(J.aB(s,0)){q=A.h([],j.h("D<0>"))
for(o=r,n=o.length,m=0;m<o.length;o.length===n||(0,A.W)(o),++m){p=o[m]
l=p
if(l==null)l=j.a(l)
J.i7(q,l)}k.c.a_(q)}}else if(J.aB(s,0)&&!k.f){q=o.d
q.toString
o=o.c
o.toString
k.c.G(new A.A(q,o))}},
$S(){return this.d.h("J(0)")}}
A.dM.prototype={
i(a){var s=this.b.i(0)
return"TimeoutException after "+s+": "+this.a}}
A.c7.prototype={
bm(a,b){var s=this.a
if((s.a&30)!==0)throw A.c(A.f("Future already completed"))
s.a5(A.iT(a,b))},
$idi:1}
A.a_.prototype={
I(a){var s,r=this.$ti
r.h("1/?").a(a)
s=this.a
if((s.a&30)!==0)throw A.c(A.f("Future already completed"))
s.E(r.h("1/").a(a))},
aD(){return this.I(null)}}
A.am.prototype={
e_(a){if((this.c&15)!==6)return!0
return this.b.b.aI(t.al.a(this.d),a.a,t.y,t.K)},
dT(a){var s,r=this,q=r.e,p=null,o=t.z,n=t.K,m=a.a,l=r.b.b
if(t.Q.b(q))p=l.bu(q,m,a.b,o,n,t.l)
else p=l.aI(t.w.a(q),m,o,n)
try{o=r.$ti.h("2/").a(p)
return o}catch(s){if(t.eK.b(A.O(s))){if((r.c&1)!==0)throw A.c(A.cw("The error handler of Future.then must return a value of the returned future's type","onError"))
throw A.c(A.cw("The error handler of Future.catchError must return a value of the future's type","onError"))}else throw s}}}
A.j.prototype={
ap(a,b,c){var s,r,q,p=this.$ti
p.p(c).h("1/(2)").a(a)
s=$.i
if(s===B.c){if(b!=null&&!t.Q.b(b)&&!t.w.b(b))throw A.c(A.bF(b,"onError",u.c))}else{a=s.an(a,c.h("0/"),p.c)
if(b!=null)b=A.iY(b,s)}r=new A.j($.i,c.h("j<0>"))
q=b==null?1:3
this.av(new A.am(r,q,a,b,p.h("@<1>").p(c).h("am<1,2>")))
return r},
cD(a,b){return this.ap(a,null,b)},
cb(a,b,c){var s,r=this.$ti
r.p(c).h("1/(2)").a(a)
s=new A.j($.i,c.h("j<0>"))
this.av(new A.am(s,19,a,b,r.h("@<1>").p(c).h("am<1,2>")))
return s},
cn(a){var s=this.$ti,r=$.i,q=new A.j(r,s)
if(r!==B.c)a=A.iY(a,r)
this.av(new A.am(q,2,null,a,s.h("am<1,1>")))
return q},
aq(a){var s,r,q
t.J.a(a)
s=this.$ti
r=$.i
q=new A.j(r,s)
if(r!==B.c)a=r.X(a,t.z)
this.av(new A.am(q,8,a,null,s.h("am<1,1>")))
return q},
dA(a){this.a=this.a&1|16
this.c=a},
aQ(a){this.a=a.a&30|this.a&1
this.c=a.c},
av(a){var s,r=this,q=r.a
if(q<=3){a.a=t.F.a(r.c)
r.c=a}else{if((q&4)!==0){s=t._.a(r.c)
if((s.a&24)===0){s.av(a)
return}r.aQ(s)}r.b.a2(new A.eF(r,a))}},
bW(a){var s,r,q,p,o,n,m=this,l={}
l.a=a
if(a==null)return
s=m.a
if(s<=3){r=t.F.a(m.c)
m.c=a
if(r!=null){q=a.a
for(p=a;q!=null;p=q,q=o)o=q.a
p.a=r}}else{if((s&4)!==0){n=t._.a(m.c)
if((n.a&24)===0){n.bW(a)
return}m.aQ(n)}l.a=m.aU(a)
m.b.a2(new A.eK(l,m))}},
aB(){var s=t.F.a(this.c)
this.c=null
return this.aU(s)},
aU(a){var s,r,q
for(s=a,r=null;s!=null;r=s,s=q){q=s.a
s.a=r}return r},
aP(a){var s,r=this,q=r.$ti
q.h("1/").a(a)
if(q.h("K<1>").b(a))A.eI(a,r,!0)
else{s=r.aB()
q.c.a(a)
r.a=8
r.c=a
A.b2(r,s)}},
a_(a){var s,r=this
r.$ti.c.a(a)
s=r.aB()
r.a=8
r.c=a
A.b2(r,s)},
d5(a){var s,r,q,p=this
if((a.a&16)!==0){s=p.b
r=a.b
s=!(s===r||s.gV()===r.gV())}else s=!1
if(s)return
q=p.aB()
p.aQ(a)
A.b2(p,q)},
G(a){var s=this.aB()
this.dA(a)
A.b2(this,s)},
d4(a,b){A.G(a)
t.l.a(b)
this.G(new A.A(a,b))},
E(a){var s=this.$ti
s.h("1/").a(a)
if(s.h("K<1>").b(a)){this.bD(a)
return}this.bB(a)},
bB(a){var s=this
s.$ti.c.a(a)
s.a^=2
s.b.a2(new A.eH(s,a))},
bD(a){A.eI(this.$ti.h("K<1>").a(a),this,!1)
return},
a5(a){this.a^=2
this.b.a2(new A.eG(this,a))},
e4(a){var s,r=this,q={}
if((r.a&24)!==0){q=new A.j($.i,r.$ti)
q.E(r)
return q}s=new A.j($.i,r.$ti)
q.a=null
q.a=A.hM(a,new A.eQ(s,a))
r.ap(new A.eR(q,r,s),new A.eS(q,s),t.P)
return s},
$iK:1}
A.eF.prototype={
$0(){A.b2(this.a,this.b)},
$S:0}
A.eK.prototype={
$0(){A.b2(this.b,this.a.a)},
$S:0}
A.eJ.prototype={
$0(){A.eI(this.a.a,this.b,!0)},
$S:0}
A.eH.prototype={
$0(){this.a.a_(this.b)},
$S:0}
A.eG.prototype={
$0(){this.a.G(this.b)},
$S:0}
A.eN.prototype={
$0(){var s,r,q,p,o,n,m,l,k=this,j=null
try{q=k.a.a
j=q.b.b.M(t.J.a(q.d),t.z)}catch(p){s=A.O(p)
r=A.P(p)
if(k.c&&t.n.a(k.b.a.c).a===s){q=k.a
q.c=t.n.a(k.b.a.c)}else{q=s
o=r
if(o==null)o=A.cz(q)
n=k.a
n.c=new A.A(q,o)
q=n}q.b=!0
return}if(j instanceof A.j&&(j.a&24)!==0){if((j.a&16)!==0){q=k.a
q.c=t.n.a(j.c)
q.b=!0}return}if(j instanceof A.j){m=k.b.a
l=new A.j(m.b,m.$ti)
j.ap(new A.eO(l,m),new A.eP(l),t.H)
q=k.a
q.c=l
q.b=!1}},
$S:0}
A.eO.prototype={
$1(a){this.a.d5(this.b)},
$S:9}
A.eP.prototype={
$2(a,b){A.G(a)
t.l.a(b)
this.a.G(new A.A(a,b))},
$S:3}
A.eM.prototype={
$0(){var s,r,q,p,o,n,m,l
try{q=this.a
p=q.a
o=p.$ti
n=o.c
m=n.a(this.b)
q.c=p.b.b.aI(o.h("2/(1)").a(p.d),m,o.h("2/"),n)}catch(l){s=A.O(l)
r=A.P(l)
q=s
p=r
if(p==null)p=A.cz(q)
o=this.a
o.c=new A.A(q,p)
o.b=!0}},
$S:0}
A.eL.prototype={
$0(){var s,r,q,p,o,n,m,l=this
try{s=t.n.a(l.a.a.c)
p=l.b
if(p.a.e_(s)&&p.a.e!=null){p.c=p.a.dT(s)
p.b=!1}}catch(o){r=A.O(o)
q=A.P(o)
p=t.n.a(l.a.a.c)
if(p.a===r){n=l.b
n.c=p
p=n}else{p=r
n=q
if(n==null)n=A.cz(p)
m=l.b
m.c=new A.A(p,n)
p=m}p.b=!0}},
$S:0}
A.eQ.prototype={
$0(){var s=A.iq()
this.a.G(new A.A(new A.dM("Future not completed",this.b),s))},
$S:0}
A.eR.prototype={
$1(a){var s
this.b.$ti.c.a(a)
s=this.a
if(s.a.gbq()){s.a.A()
this.c.a_(a)}},
$S(){return this.b.$ti.h("J(1)")}}
A.eS.prototype={
$2(a,b){var s
A.G(a)
t.l.a(b)
s=this.a
if(s.a.gbq()){s.a.A()
this.b.G(new A.A(a,b))}},
$S:3}
A.cX.prototype={}
A.ad.prototype={
gk(a){var s={},r=new A.j($.i,t.fJ)
s.a=0
this.al(new A.dK(s,this),!0,new A.dL(s,r),r.gd3())
return r}}
A.dK.prototype={
$1(a){A.e(this.b).c.a(a);++this.a.a},
$S(){return A.e(this.b).h("~(1)")}}
A.dL.prototype={
$0(){this.b.aP(this.a.a)},
$S:0}
A.b7.prototype={
gdq(){var s,r=this
if((r.b&8)===0)return A.e(r).h("a7<1>?").a(r.a)
s=A.e(r)
return s.h("a7<1>?").a(s.h("a8<1>").a(r.a).c)},
a6(){var s,r,q,p=this
if((p.b&8)===0){s=p.a
if(s==null)s=p.a=new A.a7(A.e(p).h("a7<1>"))
return A.e(p).h("a7<1>").a(s)}r=A.e(p)
q=r.h("a8<1>").a(p.a)
s=q.c
if(s==null)s=q.c=new A.a7(r.h("a7<1>"))
return r.h("a7<1>").a(s)},
ga1(){var s=this.a
if((this.b&8)!==0)s=t.fv.a(s).c
return A.e(this).h("aw<1>").a(s)},
aw(){if((this.b&4)!==0)return new A.Z("Cannot add event after closing")
return new A.Z("Cannot add event while adding a stream")},
dH(a,b){var s,r,q,p,o,n=this,m=A.e(n)
m.h("ad<1>").a(a)
s=n.b
if(s>=4)throw A.c(n.aw())
if((s&2)!==0){m=new A.j($.i,t._)
m.E(null)
return m}s=n.a
r=b===!0
q=new A.j($.i,t._)
p=m.h("~(1)").a(n.gd_())
o=r?A.k8(n):n.gcZ()
o=a.al(p,r,n.gd1(),o)
r=n.b
if((r&1)!==0?(n.ga1().e&4)!==0:(r&2)===0)o.am()
n.a=new A.a8(s,q,o,m.h("a8<1>"))
n.b|=8
return q},
bN(){var s=this.c
if(s==null)s=this.c=(this.b&2)!==0?$.bc():new A.j($.i,t.U)
return s},
m(a,b){var s=this
A.e(s).c.a(b)
if(s.b>=4)throw A.c(s.aw())
s.a4(b)},
aV(a,b){var s
A.G(a)
t.gO.a(b)
if(this.b>=4)throw A.c(this.aw())
s=A.iT(a,b)
this.a3(s.a,s.b)},
cg(a){return this.aV(a,null)},
j(){var s=this,r=s.b
if((r&4)!==0)return s.bN()
if(r>=4)throw A.c(s.aw())
s.az()
return s.bN()},
az(){var s=this.b|=4
if((s&1)!==0)this.a8()
else if((s&3)===0)this.a6().m(0,B.n)},
a4(a){var s,r=this,q=A.e(r)
q.c.a(a)
s=r.b
if((s&1)!==0)r.a0(a)
else if((s&3)===0)r.a6().m(0,new A.S(a,q.h("S<1>")))},
a3(a,b){var s
A.G(a)
t.l.a(b)
s=this.b
if((s&1)!==0)this.a9(a,b)
else if((s&3)===0)this.a6().m(0,new A.bq(a,b))},
ae(){var s=this,r=A.e(s).h("a8<1>").a(s.a)
s.a=r.c
s.b&=4294967287
r.a.E(null)},
c9(a,b,c,d){var s,r,q,p=this,o=A.e(p)
o.h("~(1)?").a(a)
t.Z.a(c)
if((p.b&3)!==0)throw A.c(A.f("Stream has already been listened to."))
s=A.kg(p,a,b,c,d,o.c)
r=p.gdq()
if(((p.b|=1)&8)!==0){q=o.h("a8<1>").a(p.a)
q.c=s
q.b.ao()}else p.a=s
s.dB(r)
s.ba(new A.f4(p))
return s},
bZ(a){var s,r,q,p,o,n,m,l,k=this,j=A.e(k)
j.h("al<1>").a(a)
s=null
if((k.b&8)!==0)s=j.h("a8<1>").a(k.a).A()
k.a=null
k.b=k.b&4294967286|2
r=k.r
if(r!=null)if(s==null)try{q=r.$0()
if(q instanceof A.j)s=q}catch(n){p=A.O(n)
o=A.P(n)
m=new A.j($.i,t.U)
j=A.G(p)
l=t.l.a(o)
m.a5(new A.A(j,l))
s=m}else s=s.aq(r)
j=new A.f3(k)
if(s!=null)s=s.aq(j)
else j.$0()
return s},
c_(a){var s=this,r=A.e(s)
r.h("al<1>").a(a)
if((s.b&8)!==0)r.h("a8<1>").a(s.a).b.am()
A.da(s.e)},
c0(a){var s=this,r=A.e(s)
r.h("al<1>").a(a)
if((s.b&8)!==0)r.h("a8<1>").a(s.a).b.ao()
A.da(s.f)},
$ib_:1,
$icg:1,
$iag:1}
A.f4.prototype={
$0(){A.da(this.a.d)},
$S:0}
A.f3.prototype={
$0(){var s=this.a.c
if(s!=null&&(s.a&30)===0)s.E(null)},
$S:0}
A.d7.prototype={
a0(a){this.$ti.c.a(a)
this.ga1().a4(a)},
a9(a,b){this.ga1().a3(a,b)},
a8(){this.ga1().ae()}}
A.cZ.prototype={
a0(a){var s=this.$ti
s.c.a(a)
this.ga1().ad(new A.S(a,s.h("S<1>")))},
a9(a,b){this.ga1().ad(new A.bq(a,b))},
a8(){this.ga1().ad(B.n)}}
A.af.prototype={}
A.bu.prototype={}
A.r.prototype={
gC(a){return(A.bZ(this.a)^892482866)>>>0},
S(a,b){if(b==null)return!1
if(this===b)return!0
return b instanceof A.r&&b.a===this.a}}
A.aw.prototype={
bT(){return this.w.bZ(this)},
ag(){this.w.c_(this)},
ah(){this.w.c0(this)}}
A.cW.prototype={
A(){var s=this.b.A()
return s.aq(new A.dY(this))}}
A.dZ.prototype={
$2(a,b){var s=this.a
s.a3(A.G(a),t.l.a(b))
s.ae()},
$S:3}
A.dY.prototype={
$0(){this.a.a.E(null)},
$S:2}
A.a8.prototype={}
A.a0.prototype={
dB(a){var s=this
A.e(s).h("a7<1>?").a(a)
if(a==null)return
s.r=a
if(a.c!=null){s.e=(s.e|128)>>>0
a.aL(s)}},
am(){var s,r,q=this,p=q.e
if((p&8)!==0)return
s=(p+256|4)>>>0
q.e=s
if(p<256){r=q.r
if(r!=null)if(r.a===1)r.a=3}if((p&4)===0&&(s&64)===0)q.ba(q.gbf())},
ao(){var s=this,r=s.e
if((r&8)!==0)return
if(r>=256){r=s.e=r-256
if(r<256)if((r&128)!==0&&s.r.c!=null)s.r.aL(s)
else{r=(r&4294967291)>>>0
s.e=r
if((r&64)===0)s.ba(s.gbg())}}},
A(){var s=this,r=(s.e&4294967279)>>>0
s.e=r
if((r&8)===0)s.b3()
r=s.f
return r==null?$.bc():r},
ci(a,b){var s,r=this,q={}
q.a=null
if(!b.b(null))throw A.c(A.i9("futureValue"))
b.a(a)
q.a=a
s=new A.j($.i,b.h("j<0>"))
r.c=new A.ex(q,s)
r.e=(r.e|32)>>>0
r.b=new A.ey(r,s)
return s},
b3(){var s,r=this,q=r.e=(r.e|8)>>>0
if((q&128)!==0){s=r.r
if(s.a===1)s.a=3}if((q&64)===0)r.r=null
r.f=r.bT()},
a4(a){var s,r=this,q=A.e(r)
q.c.a(a)
s=r.e
if((s&8)!==0)return
if(s<64)r.a0(a)
else r.ad(new A.S(a,q.h("S<1>")))},
a3(a,b){var s
if(t.C.b(a))A.dF(a,b)
s=this.e
if((s&8)!==0)return
if(s<64)this.a9(a,b)
else this.ad(new A.bq(a,b))},
ae(){var s=this,r=s.e
if((r&8)!==0)return
r=(r|2)>>>0
s.e=r
if(r<64)s.a8()
else s.ad(B.n)},
ag(){},
ah(){},
bT(){return null},
ad(a){var s,r=this,q=r.r
if(q==null)q=r.r=new A.a7(A.e(r).h("a7<1>"))
q.m(0,a)
s=r.e
if((s&128)===0){s=(s|128)>>>0
r.e=s
if(s<256)q.aL(r)}},
a0(a){var s,r=this,q=A.e(r).c
q.a(a)
s=r.e
r.e=(s|64)>>>0
r.d.bv(r.a,a,q)
r.e=(r.e&4294967231)>>>0
r.b5((s&4)!==0)},
a9(a,b){var s,r=this,q=r.e,p=new A.ev(r,a,b)
if((q&1)!==0){r.e=(q|16)>>>0
r.b3()
s=r.f
if(s!=null&&s!==$.bc())s.aq(p)
else p.$0()}else{p.$0()
r.b5((q&4)!==0)}},
a8(){var s,r=this,q=new A.eu(r)
r.b3()
r.e=(r.e|16)>>>0
s=r.f
if(s!=null&&s!==$.bc())s.aq(q)
else q.$0()},
ba(a){var s,r=this
t.M.a(a)
s=r.e
r.e=(s|64)>>>0
a.$0()
r.e=(r.e&4294967231)>>>0
r.b5((s&4)!==0)},
b5(a){var s,r,q=this,p=q.e
if((p&128)!==0&&q.r.c==null){p=q.e=(p&4294967167)>>>0
s=!1
if((p&4)!==0)if(p<256){s=q.r
s=s==null?null:s.c==null
s=s!==!1}if(s){p=(p&4294967291)>>>0
q.e=p}}for(;;a=r){if((p&8)!==0){q.r=null
return}r=(p&4)!==0
if(a===r)break
q.e=(p^64)>>>0
if(r)q.ag()
else q.ah()
p=(q.e&4294967231)>>>0
q.e=p}if((p&128)!==0&&p<256)q.r.aL(q)},
$ial:1,
$iag:1}
A.ex.prototype={
$0(){this.b.aP(this.a.a)},
$S:0}
A.ey.prototype={
$2(a,b){var s,r
A.G(a)
t.l.a(b)
s=this.a.A()
r=this.b
if(s!==$.bc())s.aq(new A.ew(r,a,b))
else r.G(new A.A(a,b))},
$S:3}
A.ew.prototype={
$0(){this.a.G(new A.A(this.b,this.c))},
$S:2}
A.ev.prototype={
$0(){var s,r,q,p=this.a,o=p.e
if((o&8)!==0&&(o&16)===0)return
p.e=(o|64)>>>0
s=p.b
o=this.b
r=t.K
q=p.d
if(t.da.b(s))q.cC(s,o,this.c,r,t.l)
else q.bv(t.u.a(s),o,r)
p.e=(p.e&4294967231)>>>0},
$S:0}
A.eu.prototype={
$0(){var s=this.a,r=s.e
if((r&16)===0)return
s.e=(r|74)>>>0
s.d.aH(s.c)
s.e=(s.e&4294967231)>>>0},
$S:0}
A.ch.prototype={
al(a,b,c,d){var s=A.e(this)
s.h("~(1)?").a(a)
t.Z.a(c)
return this.a.c9(s.h("~(1)?").a(a),d,c,b===!0)},
dZ(a,b,c){return this.al(a,null,b,c)},
dY(a,b){return this.al(a,b,null,null)}}
A.ax.prototype={
sW(a){this.a=t.ev.a(a)},
gW(){return this.a}}
A.S.prototype={
bt(a){this.$ti.h("ag<1>").a(a).a0(this.b)}}
A.bq.prototype={
bt(a){a.a9(this.b,this.c)}}
A.d1.prototype={
bt(a){a.a8()},
gW(){return null},
sW(a){throw A.c(A.f("No events after a done."))},
$iax:1}
A.a7.prototype={
aL(a){var s,r=this
r.$ti.h("ag<1>").a(a)
s=r.a
if(s===1)return
if(s>=1){r.a=1
return}A.aA(new A.eZ(r,a))
r.a=1},
m(a,b){var s=this,r=s.c
if(r==null)s.b=s.c=b
else{r.sW(b)
s.c=b}}}
A.eZ.prototype={
$0(){var s,r,q,p=this.a,o=p.a
p.a=0
if(o===3)return
s=p.$ti.h("ag<1>").a(this.b)
r=p.b
q=r.gW()
p.b=q
if(q==null)p.c=null
r.bt(s)},
$S:0}
A.br.prototype={
am(){var s=this.a
if(s>=0)this.a=s+2},
ao(){var s=this,r=s.a-2
if(r<0)return
if(r===0){s.a=1
A.aA(s.gbU())}else s.a=r},
A(){this.a=-1
this.c=null
return $.bc()},
ci(a,b){var s,r={}
r.a=null
if(!b.b(null))throw A.c(A.i9("futureValue"))
b.a(a)
r.a=a
s=new A.j($.i,b.h("j<0>"))
if(this.a>=0)this.c=this.b.X(new A.eC(r,s),t.H)
return s},
dn(){var s,r=this,q=r.a-1
if(q===0){r.a=-1
s=r.c
if(s!=null){r.c=null
r.b.aH(s)}}else r.a=q},
$ial:1}
A.eC.prototype={
$0(){this.b.a_(this.a.a)},
$S:0}
A.aM.prototype={
gB(){var s=this
if(s.c)return s.$ti.c.a(s.b)
return s.$ti.c.a(null)},
q(){var s,r=this,q=r.a
if(q!=null){if(r.c){s=new A.j($.i,t.k)
r.b=s
r.c=!1
q.ao()
return s}throw A.c(A.f("Already waiting for next."))}return r.df()},
df(){var s,r,q=this,p=q.b
if(p!=null){q.$ti.h("ad<1>").a(p)
s=new A.j($.i,t.k)
q.b=s
r=p.al(q.gdh(),!0,q.gdj(),q.gdl())
if(q.b!=null)q.a=r
return s}return $.jm()},
A(){var s=this,r=s.a,q=s.b
s.b=null
if(r!=null){s.a=null
if(!s.c)t.k.a(q).E(!1)
else s.c=!1
return r.A()}return $.bc()},
di(a){var s,r,q=this
q.$ti.c.a(a)
if(q.a==null)return
s=t.k.a(q.b)
q.b=a
q.c=!0
s.aP(!0)
if(q.c){r=q.a
if(r!=null)r.am()}},
dm(a,b){var s,r,q=this
A.G(a)
t.l.a(b)
s=q.a
r=t.k.a(q.b)
q.b=q.a=null
if(s!=null)r.G(new A.A(a,b))
else r.a5(new A.A(a,b))},
dk(){var s=this,r=s.a,q=t.k.a(s.b)
s.b=s.a=null
if(r!=null)q.a_(!1)
else q.bB(!1)},
$iir:1}
A.fm.prototype={}
A.fo.prototype={}
A.fn.prototype={}
A.fk.prototype={}
A.fl.prototype={}
A.fj.prototype={}
A.fg.prototype={}
A.fp.prototype={}
A.ff.prototype={}
A.fe.prototype={}
A.fi.prototype={}
A.fh.prototype={}
A.d8.prototype={
dS(a,b,c,d,e){return this.b.$5(a,b,c,d,e)}}
A.d9.prototype={}
A.bv.prototype={
aA(a,b,c){var s,r,q,p,o,n,m,l
t.l.a(c)
s=this.gbb()
r=s.a
if(r===B.c){A.cr(b,c)
return}m=r.gbs()
m.toString
q=m
p=$.i
try{$.i=q
s.dS(r,r.gH(),a,b,c)
$.i=p}catch(l){o=A.O(l)
n=A.P(l)
$.i=p
m=b===o?c:n
q.aA(r,o,m)}},
$ik:1}
A.d0.prototype={
gbM(){var s=this.ax
return s==null?this.ax=new A.bw(this):s},
gH(){return this.ay.gbM()},
gV(){return this.as.a},
aH(a){var s,r,q
t.M.a(a)
try{this.M(a,t.H)}catch(q){s=A.O(q)
r=A.P(q)
this.aA(this,A.G(s),t.l.a(r))}},
bv(a,b,c){var s,r,q
c.h("~(0)").a(a)
c.a(b)
try{this.aI(a,b,t.H,c)}catch(q){s=A.O(q)
r=A.P(q)
this.aA(this,A.G(s),t.l.a(r))}},
cC(a,b,c,d,e){var s,r,q
d.h("@<0>").p(e).h("~(1,2)").a(a)
d.a(b)
e.a(c)
try{this.bu(a,b,c,t.H,d,e)}catch(q){s=A.O(q)
r=A.P(q)
this.aA(this,A.G(s),t.l.a(r))}},
bl(a,b){return new A.eB(this,this.X(b.h("0()").a(a),b),b)},
aW(a){return new A.eA(this,this.X(t.M.a(a),t.H))},
u(a,b){var s,r,q=this.at
if(q===B.p)return null
s=q.b
r=s.u(0,b)
return r!=null||s.aa(b)?r:this.ds(q,b)},
ds(a,b){var s,r,q
for(s=a,r=null;;){s=s.a.gbs().gbk()
if(s===B.p)break
q=s.b
r=q.u(0,b)
if(r!=null||q.aa(b)){a.b.v(0,b,r)
break}}return r},
aE(a,b){this.aA(this,a,t.l.a(b))},
cu(a,b){var s=this.Q,r=s.a
return s.b.$5(r,r.gH(),this,a,b)},
M(a,b){var s,r
b.h("0()").a(a)
s=this.a
r=s.a
return s.b.$1$4(r,r.gH(),this,a,b)},
aI(a,b,c,d){var s,r
c.h("@<0>").p(d).h("1(2)").a(a)
d.a(b)
s=this.b
r=s.a
return s.b.$2$5(r,r.gH(),this,a,b,c,d)},
bu(a,b,c,d,e,f){var s,r
d.h("@<0>").p(e).p(f).h("1(2,3)").a(a)
e.a(b)
f.a(c)
s=this.c
r=s.a
return s.b.$3$6(r,r.gH(),this,a,b,c,d,e,f)},
X(a,b){var s,r
b.h("0()").a(a)
s=this.d
r=s.a
return s.b.$1$4(r,r.gH(),this,a,b)},
an(a,b,c){var s,r
b.h("@<0>").p(c).h("1(2)").a(a)
s=this.e
r=s.a
return s.b.$2$4(r,r.gH(),this,a,b,c)},
aZ(a,b,c,d){var s,r
b.h("@<0>").p(c).p(d).h("1(2,3)").a(a)
s=this.f
r=s.a
return s.b.$3$4(r,r.gH(),this,a,b,c,d)},
cr(a,b){var s=this.r,r=s.a
if(r===B.c)return null
return s.b.$5(r,r.gH(),this,a,b)},
a2(a){var s,r
t.M.a(a)
s=this.w
r=s.a
return s.b.$4(r,r.gH(),this,a)},
bn(a,b){var s,r
t.M.a(b)
s=this.x
r=s.a
return s.b.$5(r,r.gH(),this,a,b)},
gc5(){return this.a},
gc7(){return this.b},
gc6(){return this.c},
gc2(){return this.d},
gc3(){return this.e},
gc1(){return this.f},
gbO(){return this.r},
gbj(){return this.w},
gbL(){return this.x},
gbK(){return this.y},
gbX(){return this.z},
gbP(){return this.Q},
gbb(){return this.as},
gbk(){return this.at},
gbs(){return this.ay}}
A.eB.prototype={
$0(){return this.a.M(this.b,this.c)},
$S(){return this.c.h("0()")}}
A.eA.prototype={
$0(){return this.a.aH(this.b)},
$S:0}
A.d5.prototype={
gc5(){return B.a9},
gc7(){return B.a8},
gc6(){return B.a7},
gc2(){return B.a5},
gc3(){return B.a6},
gc1(){return B.a4},
gbO(){return B.a0},
gbj(){return B.aa},
gbL(){return B.a_},
gbK(){return B.F},
gbX(){return B.a3},
gbP(){return B.a1},
gbb(){return B.a2},
gbk(){return B.p},
gbs(){return null},
gbM(){var s=$.f0
return s==null?$.f0=new A.bw(this):s},
gH(){var s=$.f0
return s==null?$.f0=new A.bw(this):s},
gV(){return this},
aH(a){var s,r,q
t.M.a(a)
try{if(B.c===$.i){a.$0()
return}A.fw(null,null,this,a,t.H)}catch(q){s=A.O(q)
r=A.P(q)
A.cr(A.G(s),t.l.a(r))}},
bv(a,b,c){var s,r,q
c.h("~(0)").a(a)
c.a(b)
try{if(B.c===$.i){a.$1(b)
return}A.fx(null,null,this,a,b,t.H,c)}catch(q){s=A.O(q)
r=A.P(q)
A.cr(A.G(s),t.l.a(r))}},
cC(a,b,c,d,e){var s,r,q
d.h("@<0>").p(e).h("~(1,2)").a(a)
d.a(b)
e.a(c)
try{if(B.c===$.i){a.$2(b,c)
return}A.hY(null,null,this,a,b,c,t.H,d,e)}catch(q){s=A.O(q)
r=A.P(q)
A.cr(A.G(s),t.l.a(r))}},
bl(a,b){return new A.f2(this,b.h("0()").a(a),b)},
aW(a){return new A.f1(this,t.M.a(a))},
u(a,b){return null},
aE(a,b){A.cr(a,t.l.a(b))},
cu(a,b){return A.iZ(null,null,this,a,b)},
M(a,b){b.h("0()").a(a)
if($.i===B.c)return a.$0()
return A.fw(null,null,this,a,b)},
aI(a,b,c,d){c.h("@<0>").p(d).h("1(2)").a(a)
d.a(b)
if($.i===B.c)return a.$1(b)
return A.fx(null,null,this,a,b,c,d)},
bu(a,b,c,d,e,f){d.h("@<0>").p(e).p(f).h("1(2,3)").a(a)
e.a(b)
f.a(c)
if($.i===B.c)return a.$2(b,c)
return A.hY(null,null,this,a,b,c,d,e,f)},
X(a,b){return b.h("0()").a(a)},
an(a,b,c){return b.h("@<0>").p(c).h("1(2)").a(a)},
aZ(a,b,c,d){return b.h("@<0>").p(c).p(d).h("1(2,3)").a(a)},
cr(a,b){return null},
a2(a){A.fy(null,null,this,t.M.a(a))},
bn(a,b){return A.hN(a,t.M.a(b))}}
A.f2.prototype={
$0(){return this.a.M(this.b,this.c)},
$S(){return this.c.h("0()")}}
A.f1.prototype={
$0(){return this.a.aH(this.b)},
$S:0}
A.bw.prototype={$iC:1}
A.fv.prototype={
$0(){A.jN(this.a,this.b)},
$S:0}
A.c8.prototype={
gk(a){return this.a},
gP(a){return this.a===0},
gaY(){return new A.c9(this,A.e(this).h("c9<1>"))},
aa(a){var s=this.d8(a)
return s},
d8(a){var s=this.d
if(s==null)return!1
return this.a7(this.bG(s,a),a)>=0},
ai(a,b){A.e(this).h("ao<1,2>").a(b).ak(0,new A.eT(this))},
u(a,b){var s,r,q
if(typeof b=="string"&&b!=="__proto__"){s=this.b
r=s==null?null:A.iz(s,b)
return r}else if(typeof b=="number"&&(b&1073741823)===b){q=this.c
r=q==null?null:A.iz(q,b)
return r}else return this.de(b)},
de(a){var s,r,q=this.d
if(q==null)return null
s=this.bG(q,a)
r=this.a7(s,a)
return r<0?null:s[r+1]},
v(a,b,c){var s,r,q=this,p=A.e(q)
p.c.a(b)
p.y[1].a(c)
if(typeof b=="string"&&b!=="__proto__"){s=q.b
q.bF(s==null?q.b=A.hO():s,b,c)}else if(typeof b=="number"&&(b&1073741823)===b){r=q.c
q.bF(r==null?q.c=A.hO():r,b,c)}else q.dz(b,c)},
dz(a,b){var s,r,q,p,o=this,n=A.e(o)
n.c.a(a)
n.y[1].a(b)
s=o.d
if(s==null)s=o.d=A.hO()
r=o.af(a)
q=s[r]
if(q==null){A.hP(s,r,[a,b]);++o.a
o.e=null}else{p=o.a7(q,a)
if(p>=0)q[p+1]=b
else{q.push(a,b);++o.a
o.e=null}}},
ak(a,b){var s,r,q,p,o,n,m=this,l=A.e(m)
l.h("~(1,2)").a(b)
s=m.bJ()
for(r=s.length,q=l.c,l=l.y[1],p=0;p<r;++p){o=s[p]
q.a(o)
n=m.u(0,o)
b.$2(o,n==null?l.a(n):n)
if(s!==m.e)throw A.c(A.X(m))}},
bJ(){var s,r,q,p,o,n,m,l,k,j,i=this,h=i.e
if(h!=null)return h
h=A.Y(i.a,null,!1,t.z)
s=i.b
r=0
if(s!=null){q=Object.getOwnPropertyNames(s)
p=q.length
for(o=0;o<p;++o){h[r]=q[o];++r}}n=i.c
if(n!=null){q=Object.getOwnPropertyNames(n)
p=q.length
for(o=0;o<p;++o){h[r]=+q[o];++r}}m=i.d
if(m!=null){q=Object.getOwnPropertyNames(m)
p=q.length
for(o=0;o<p;++o){l=m[q[o]]
k=l.length
for(j=0;j<k;j+=2){h[r]=l[j];++r}}}return i.e=h},
bF(a,b,c){var s=A.e(this)
s.c.a(b)
s.y[1].a(c)
if(a[b]==null){++this.a
this.e=null}A.hP(a,b,c)},
af(a){return J.an(a)&1073741823},
bG(a,b){return a[this.af(b)]},
a7(a,b){var s,r
if(a==null)return-1
s=a.length
for(r=0;r<s;r+=2)if(J.aB(a[r],b))return r
return-1}}
A.eT.prototype={
$2(a,b){var s=this.a,r=A.e(s)
s.v(0,r.c.a(a),r.y[1].a(b))},
$S(){return A.e(this.a).h("~(1,2)")}}
A.c9.prototype={
gk(a){return this.a.a},
gP(a){return this.a.a===0},
gF(a){var s=this.a
return new A.ca(s,s.bJ(),this.$ti.h("ca<1>"))}}
A.ca.prototype={
gB(){var s=this.d
return s==null?this.$ti.c.a(s):s},
q(){var s=this,r=s.b,q=s.c,p=s.a
if(r!==p.e)throw A.c(A.X(p))
else if(q>=r.length){s.d=null
return!1}else{s.d=r[q]
s.c=q+1
return!0}},
$iU:1}
A.b3.prototype={
gF(a){var s=this,r=new A.b4(s,s.r,A.e(s).h("b4<1>"))
r.c=s.e
return r},
gk(a){return this.a},
dM(a,b){var s=this.d7(b)
return s},
d7(a){var s=this.d
if(s==null)return!1
return this.a7(s[this.af(a)],a)>=0},
m(a,b){var s,r,q=this
A.e(q).c.a(b)
if(typeof b=="string"&&b!=="__proto__"){s=q.b
return q.bE(s==null?q.b=A.hQ():s,b)}else if(typeof b=="number"&&(b&1073741823)===b){r=q.c
return q.bE(r==null?q.c=A.hQ():r,b)}else return q.ac(b)},
ac(a){var s,r,q,p=this
A.e(p).c.a(a)
s=p.d
if(s==null)s=p.d=A.hQ()
r=p.af(a)
q=s[r]
if(q==null)s[r]=[p.b6(a)]
else{if(p.a7(q,a)>=0)return!1
q.push(p.b6(a))}return!0},
Y(a,b){var s=this.dt(b)
return s},
dt(a){var s,r,q,p,o=this,n=o.d
if(n==null)return!1
s=o.af(a)
r=n[s]
q=o.a7(r,a)
if(q<0)return!1
p=r.splice(q,1)[0]
if(0===r.length)delete n[s]
o.d2(p)
return!0},
bE(a,b){A.e(this).c.a(b)
if(t.br.a(a[b])!=null)return!1
a[b]=this.b6(b)
return!0},
bH(){this.r=this.r+1&1073741823},
b6(a){var s,r=this,q=new A.d4(A.e(r).c.a(a))
if(r.e==null)r.e=r.f=q
else{s=r.f
s.toString
q.c=s
r.f=s.b=q}++r.a
r.bH()
return q},
d2(a){var s=this,r=a.c,q=a.b
if(r==null)s.e=q
else r.b=q
if(q==null)s.f=r
else q.c=r;--s.a
s.bH()},
af(a){return J.an(a)&1073741823},
a7(a,b){var s,r
if(a==null)return-1
s=a.length
for(r=0;r<s;++r)if(J.aB(a[r].a,b))return r
return-1}}
A.d4.prototype={}
A.b4.prototype={
gB(){var s=this.d
return s==null?this.$ti.c.a(s):s},
q(){var s=this,r=s.c,q=s.a
if(s.b!==q.r)throw A.c(A.X(q))
else if(r==null){s.d=null
return!1}else{s.d=s.$ti.h("1?").a(r.a)
s.c=r.b
return!0}},
$iU:1}
A.aF.prototype={
gF(a){return new A.aW(a,a.length,A.bB(a).h("aW<aF.E>"))},
U(a,b){if(!(b>=0&&b<a.length))return A.z(a,b)
return a[b]},
gcv(a){return a.length!==0},
cs(a,b,c,d){var s,r,q
A.bB(a).h("aF.E?").a(d)
s=a.length
A.dH(b,c,s)
for(r=a.$flags|0,q=b;q<c;++q){r&2&&A.aP(a)
if(!(q<s))return A.z(a,q)
a[q]=d}},
i(a){return A.dn(a,"[","]")}}
A.bh.prototype={
ak(a,b){var s,r,q,p=A.e(this)
p.h("~(1,2)").a(b)
for(s=this.gaY(),s=s.gF(s),p=p.y[1];s.q();){r=s.gB()
q=this.u(0,r)
b.$2(r,q==null?p.a(q):q)}},
gk(a){var s=this.gaY()
return s.gk(s)},
gP(a){var s=this.gaY()
return s.gP(s)},
i(a){return A.hH(this)},
$iao:1}
A.dB.prototype={
$2(a,b){var s,r=this.a
if(!r.a)this.b.a+=", "
r.a=!1
r=this.b
s=A.y(a)
r.a=(r.a+=s)+": "
s=A.y(b)
r.a+=s},
$S:11}
A.aX.prototype={
gF(a){var s=this
return new A.ay(s,s.c,s.d,s.b,s.$ti.h("ay<1>"))},
gP(a){return this.b===this.c},
gk(a){return(this.c-this.b&this.a.length-1)>>>0},
U(a,b){var s,r,q=this,p=q.gk(0)
if(0>b||b>=p)A.b(A.dm(b,p,q,null,"index"))
p=q.a
s=p.length
r=(q.b+b&s-1)>>>0
if(!(r>=0&&r<s))return A.z(p,r)
r=p[r]
return r==null?q.$ti.c.a(r):r},
i(a){return A.dn(this,"{","}")},
cB(){var s,r,q=this,p=q.b
if(p===q.c)throw A.c(A.bM());++q.d
s=q.a
if(!(p<s.length))return A.z(s,p)
r=s[p]
if(r==null)r=q.$ti.c.a(r)
B.b.v(s,p,null)
q.b=(q.b+1&q.a.length-1)>>>0
return r},
ac(a){var s,r=this
r.$ti.c.a(a)
B.b.v(r.a,r.c,a)
s=(r.c+1&r.a.length-1)>>>0
r.c=s
if(r.b===s)r.bS();++r.d},
bS(){var s=this,r=A.Y(s.a.length*2,null,!1,s.$ti.h("1?")),q=s.a,p=s.b,o=q.length-p
B.b.by(r,0,o,q,p)
B.b.by(r,o,o+s.b,s.a,0)
s.b=0
s.c=s.a.length
s.a=r}}
A.ay.prototype={
gB(){var s=this.e
return s==null?this.$ti.c.a(s):s},
q(){var s,r,q=this,p=q.a
if(q.c!==p.d)A.b(A.X(p))
s=q.d
if(s===q.b){q.e=null
return!1}p=p.a
r=p.length
if(!(s<r))return A.z(p,s)
q.e=p[s]
q.d=(s+1&r-1)>>>0
return!0},
$iU:1}
A.bk.prototype={
ai(a,b){var s
A.e(this).h("m<1>").a(b)
for(s=b.a,s=new A.at(s,s.r,s.e,b.$ti.h("at<1>"));s.q();)this.m(0,s.d)},
i(a){return A.dn(this,"{","}")},
dJ(a,b){var s,r,q=A.e(this)
q.h("p(1)").a(b)
for(q=A.kk(this,this.r,q.c),s=q.$ti.c;q.q();){r=q.d
if(b.$1(r==null?s.a(r):r))return!0}return!1},
$im:1,
$ihK:1}
A.ce.prototype={}
A.cC.prototype={}
A.cE.prototype={}
A.bR.prototype={
i(a){var s=A.cF(this.a)
return(this.b!=null?"Converting object to an encodable object failed:":"Converting object did not return an encodable object:")+" "+s}}
A.cN.prototype={
i(a){return"Cyclic error in JSON stringify"}}
A.dq.prototype={
cq(a,b){var s=A.kj(a,this.gdO().b,null)
return s},
gdO(){return B.Q}}
A.dr.prototype={}
A.eX.prototype={
cG(a){var s,r,q,p,o,n,m=a.length
for(s=this.c,r=0,q=0;q<m;++q){p=a.charCodeAt(q)
if(p>92){if(p>=55296){o=p&64512
if(o===55296){n=q+1
n=!(n<m&&(a.charCodeAt(n)&64512)===56320)}else n=!1
if(!n)if(o===56320){o=q-1
o=!(o>=0&&(a.charCodeAt(o)&64512)===55296)}else o=!1
else o=!0
if(o){if(q>r)s.a+=B.k.aM(a,r,q)
r=q+1
o=A.R(92)
s.a+=o
o=A.R(117)
s.a+=o
o=A.R(100)
s.a+=o
o=p>>>8&15
o=A.R(o<10?48+o:87+o)
s.a+=o
o=p>>>4&15
o=A.R(o<10?48+o:87+o)
s.a+=o
o=p&15
o=A.R(o<10?48+o:87+o)
s.a+=o}}continue}if(p<32){if(q>r)s.a+=B.k.aM(a,r,q)
r=q+1
o=A.R(92)
s.a+=o
switch(p){case 8:o=A.R(98)
s.a+=o
break
case 9:o=A.R(116)
s.a+=o
break
case 10:o=A.R(110)
s.a+=o
break
case 12:o=A.R(102)
s.a+=o
break
case 13:o=A.R(114)
s.a+=o
break
default:o=A.R(117)
s.a+=o
o=A.R(48)
s.a=(s.a+=o)+o
o=p>>>4&15
o=A.R(o<10?48+o:87+o)
s.a+=o
o=p&15
o=A.R(o<10?48+o:87+o)
s.a+=o
break}}else if(p===34||p===92){if(q>r)s.a+=B.k.aM(a,r,q)
r=q+1
o=A.R(92)
s.a+=o
o=A.R(p)
s.a+=o}}if(r===0)s.a+=a
else if(r<m)s.a+=B.k.aM(a,r,m)},
b4(a){var s,r,q,p
for(s=this.a,r=s.length,q=0;q<r;++q){p=s[q]
if(a==null?p==null:a===p)throw A.c(new A.cN(a,null))}B.b.m(s,a)},
b_(a){var s,r,q,p,o=this
if(o.cF(a))return
o.b4(a)
try{s=o.b.$1(a)
if(!o.cF(s)){q=A.ii(a,null,o.gbV())
throw A.c(q)}q=o.a
if(0>=q.length)return A.z(q,-1)
q.pop()}catch(p){r=A.O(p)
q=A.ii(a,r,o.gbV())
throw A.c(q)}},
cF(a){var s,r,q=this
if(typeof a=="number"){if(!isFinite(a))return!1
q.c.a+=B.w.i(a)
return!0}else if(a===!0){q.c.a+="true"
return!0}else if(a===!1){q.c.a+="false"
return!0}else if(a==null){q.c.a+="null"
return!0}else if(typeof a=="string"){s=q.c
s.a+='"'
q.cG(a)
s.a+='"'
return!0}else if(t.j.b(a)){q.b4(a)
q.e7(a)
s=q.a
if(0>=s.length)return A.z(s,-1)
s.pop()
return!0}else if(t.eO.b(a)){q.b4(a)
r=q.e8(a)
s=q.a
if(0>=s.length)return A.z(s,-1)
s.pop()
return r}else return!1},
e7(a){var s,r=this.c
r.a+="["
if(J.jC(a)){if(0>=a.length)return A.z(a,0)
this.b_(a[0])
for(s=1;s<a.length;++s){r.a+=","
this.b_(a[s])}}r.a+="]"},
e8(a){var s,r,q,p,o,n,m=this,l={}
if(a.gP(a)){m.c.a+="{}"
return!0}s=a.gk(a)*2
r=A.Y(s,null,!1,t.X)
q=l.a=0
l.b=!0
a.ak(0,new A.eY(l,r))
if(!l.b)return!1
p=m.c
p.a+="{"
for(o='"';q<s;q+=2,o=',"'){p.a+=o
m.cG(A.bx(r[q]))
p.a+='":'
n=q+1
if(!(n<s))return A.z(r,n)
m.b_(r[n])}p.a+="}"
return!0}}
A.eY.prototype={
$2(a,b){var s,r
if(typeof a!="string")this.a.b=!1
s=this.b
r=this.a
B.b.v(s,r.a++,a)
B.b.v(s,r.a++,b)},
$S:11}
A.eW.prototype={
gbV(){var s=this.c.a
return s.charCodeAt(0)==0?s:s}}
A.E.prototype={
S(a,b){if(b==null)return!1
return b instanceof A.E&&this.a===b.a},
gC(a){return B.e.gC(this.a)},
i(a){var s,r,q,p,o,n=this.a,m=B.e.O(n,36e8),l=n%36e8
if(n<0){m=0-m
n=0-l
s="-"}else{n=l
s=""}r=B.e.O(n,6e7)
n%=6e7
q=r<10?"0":""
p=B.e.O(n,1e6)
o=p<10?"0":""
return s+m+":"+q+r+":"+o+p+"."+B.k.e0(B.e.i(n%1e6),6,"0")}}
A.eD.prototype={
i(a){return this.dc()}}
A.B.prototype={
gau(){return A.k0(this)}}
A.cx.prototype={
i(a){var s=this.a
if(s!=null)return"Assertion failed: "+A.cF(s)
return"Assertion failed"}}
A.au.prototype={}
A.ab.prototype={
gb8(){return"Invalid argument"+(!this.a?"(s)":"")},
gb7(){return""},
i(a){var s=this,r=s.c,q=r==null?"":" ("+r+")",p=s.d,o=p==null?"":": "+A.y(p),n=s.gb8()+q+o
if(!s.a)return n
return n+s.gb7()+": "+A.cF(s.gbp())},
gbp(){return this.b}}
A.aG.prototype={
gbp(){return A.iN(this.b)},
gb8(){return"RangeError"},
gb7(){var s,r=this.e,q=this.f
if(r==null)s=q!=null?": Not less than or equal to "+A.y(q):""
else if(q==null)s=": Not greater than or equal to "+A.y(r)
else if(q>r)s=": Not in inclusive range "+A.y(r)+".."+A.y(q)
else s=q<r?": Valid value range is empty":": Only valid value is "+A.y(r)
return s}}
A.cG.prototype={
gbp(){return A.ar(this.b)},
gb8(){return"RangeError"},
gb7(){if(A.ar(this.b)<0)return": index must not be negative"
var s=this.f
if(s===0)return": no indices are valid"
return": index should be less than "+s},
$iaG:1,
gk(a){return this.f}}
A.aK.prototype={
i(a){return"Unsupported operation: "+this.a}}
A.cU.prototype={
i(a){return"UnimplementedError: "+this.a},
$iaK:1}
A.Z.prototype={
i(a){return"Bad state: "+this.a}}
A.cD.prototype={
i(a){var s=this.a
if(s==null)return"Concurrent modification during iteration."
return"Concurrent modification during iteration: "+A.cF(s)+"."}}
A.cO.prototype={
i(a){return"Out of Memory"},
gau(){return null},
$iB:1}
A.c0.prototype={
i(a){return"Stack Overflow"},
gau(){return null},
$iB:1}
A.eE.prototype={
i(a){return"Exception: "+this.a}}
A.m.prototype={
gk(a){var s,r=this.gF(this)
for(s=0;r.q();)++s
return s},
U(a,b){var s,r
A.dG(b,"index")
s=this.gF(this)
for(r=b;s.q();){if(r===0)return s.gB();--r}throw A.c(A.dm(b,b-r,this,null,"index"))},
i(a){return A.jS(this,"(",")")}}
A.aY.prototype={
i(a){return"MapEntry("+A.y(this.a)+": "+A.y(this.b)+")"}}
A.J.prototype={
gC(a){return A.d.prototype.gC.call(this,0)},
i(a){return"null"}}
A.d.prototype={$id:1,
S(a,b){return this===b},
gC(a){return A.bZ(this)},
i(a){return"Instance of '"+A.cQ(this)+"'"},
gZ(a){return A.lO(this)},
toString(){return this.i(this)}}
A.d6.prototype={
i(a){return""},
$iQ:1}
A.dJ.prototype={
gdN(){var s,r=this.b
if(r==null)r=$.hI.$0()
s=r-this.a
if($.i5()===1e6)return s
return s*1000}}
A.bm.prototype={
gk(a){return this.a.length},
i(a){var s=this.a
return s.charCodeAt(0)==0?s:s},
$ik3:1}
A.b0.prototype={
dc(){return"TransferBandwidthDirection."+this.b}}
A.ap.prototype={
bx(){var s,r,q
for(s=[this.a,this.b],r=0;r<2;++r){q=s[r]
if(q<0||q>1099511627776)throw A.c(A.bF(q,"bytesPerSecond",null))}},
S(a,b){if(b==null)return!1
return b instanceof A.ap&&this.a===b.a&&this.b===b.b},
gC(a){return A.il(this.a,this.b,B.j,B.j)}}
A.dV.prototype={}
A.aI.prototype={
i(a){return"Transfer bandwidth operation cancelled"}}
A.dN.prototype={
gD(){var s,r,q,p=this,o=p.d,n=A.e(o).h("aV<2>"),m=n.h("a6<m.E>"),l=A.ac(new A.a6(new A.aV(o,n),n.h("p(m.E)").a(new A.dR()),m),m.h("m.E")),k=p.b.$0()
o=new A.dS(l)
n=p.f
n===$&&A.x()
m=n.y
s=p.r
s===$&&A.x()
r=s.y
q=n.e.cl(k)
s.e.cl(k)
return new A.dV(m,r,q,l.length,n.gcz(),s.gcz(),o.$1(B.d),o.$1(B.h))},
aJ(a){var s,r,q=this
if(q.w)throw A.c(A.f("The bandwidth allocator is closed."))
a.bx()
s=q.a
if(a.S(0,s))return
q.a=a
if(s.a!==a.a){r=q.f
r===$&&A.x()
r.cA()}if(s.b!==a.b){s=q.r
s===$&&A.x()
s.cA()}q.N()},
l(a){var s,r,q=this
if(q.w)throw A.c(A.f("The bandwidth allocator is closed."))
if(a.length===0)throw A.c(A.bF(a,"operationId",null))
s=q.d.e1(a,new A.dQ(a))
if(s.d)throw A.c(B.f)
r=new A.aJ(q,s,A.du(t.fT),A.du(t.fQ),new A.a_(new A.j($.i,t.U),t.h))
s.b.m(0,r)
q.N()
return r},
N(){var s=this
if(s.w||s.x)return
s.x=!0
A.aA(new A.dP(s))},
cf(a){var s=this.f
s===$&&A.x()
s.cE(a)
s=this.r
s===$&&A.x()
s.cE(a)},
t(){var s,r,q,p,o,n,m=this
if(m.w)return
m.w=!0
s=m.d
r=A.e(s).h("aV<2>")
s=A.ac(new A.aV(s,r),r.h("m.E"))
r=s.length
q=0
for(;q<s.length;s.length===r||(0,A.W)(s),++q){p=s[q].b
p=A.ac(p,A.e(p).c)
o=p.length
n=0
for(;n<p.length;p.length===o||(0,A.W)(p),++n)p[n].j()}s=m.f
s===$&&A.x()
s.t()
s=m.r
s===$&&A.x()
s.t()
m.e.j()}}
A.dO.prototype={
$0(){return A.ig(this.a.gdN())},
$S:15}
A.dR.prototype={
$1(a){return!t.s.a(a).d},
$S:16}
A.dS.prototype={
$1(a){var s=this.a,r=A.V(s)
return new A.a6(s,r.h("p(1)").a(new A.dU(a)),r.h("a6<1>")).gk(0)},
$S:35}
A.dU.prototype={
$1(a){return t.s.a(a).b.dJ(0,new A.dT(this.a))},
$S:16}
A.dT.prototype={
$1(a){return t.E.a(a).d.dM(0,this.a)},
$S:38}
A.dQ.prototype={
$0(){return new A.aL(this.a,A.du(t.E))},
$S:40}
A.dP.prototype={
$0(){var s=this.a
s.x=!1
if(!s.w){s=s.e
A.e(s).c.a(null)
if(!s.gaR())A.b(s.aN())
s.a0(null)}},
$S:0}
A.aJ.prototype={
cw(a){var s=this
if(s.b.d||s.f||s.a.w)A.b(B.f)
if(s.d.m(0,a))s.a.N()},
M(a,b){var s,r=this
b.h("0()").a(a)
if(r.b.d||r.f||r.a.w)A.b(B.f)
s=t.X
return A.jh(a,A.dt([$.bE(),r],s,s),b)},
cm(a,b,c){var s,r=this
t.v.a(a)
if(r.b.d||r.f||r.a.w)A.b(B.f)
s=A.e9(r,a,b,c).e
s===$&&A.x()
return new A.r(s,A.e(s).h("r<1>"))},
n(a,b){return this.cm(a,b,!0)},
ar(a){var s,r,q,p,o,n,m=this
if(!(m.f||m.a.w)){s=m.b
s=s.d||s.c===a}else s=!0
if(s)return
s=m.b
s.c=a
s=s.b
s=A.ac(s,A.e(s).c)
r=s.length
q=0
for(;q<s.length;s.length===r||(0,A.W)(s),++q){p=s[q].c
p=A.ac(p,A.e(p).c)
o=p.length
n=0
for(;n<p.length;p.length===o||(0,A.W)(p),++n)p[n].ab()}m.a.N()},
A(){var s,r,q,p,o,n,m,l=this
if(l.f||l.a.w||l.b.d)return
s=l.b
s.d=!0
s=s.b
s=A.ac(s,A.e(s).c)
r=s.length
q=0
for(;q<s.length;s.length===r||(0,A.W)(s),++q){p=s[q]
o=p.e
n=o.a
if((n.a&30)===0)n.E(o.$ti.h("1/").a(null))
o=p.c
o=A.ac(o,A.e(o).c)
n=o.length
m=0
for(;m<o.length;o.length===n||(0,A.W)(o),++m)o[m].ab()}l.a.N()},
j(){var s,r,q,p,o,n=this
if(n.f)return
n.f=!0
s=n.e
if((s.a.a&30)===0)s.aD()
s=n.c
s=A.ac(s,A.e(s).c)
r=s.length
q=0
for(;q<s.length;s.length===r||(0,A.W)(s),++q)s[q].ab()
s=n.a
p=n.b
r=p.b
r.Y(0,n)
if(r.a===0){r=s.d
o=p.a
if(r.u(0,o)===p)r.Y(0,o)
r=s.f
r===$&&A.x()
r.d.Y(0,p)
r=s.r
r===$&&A.x()
r.d.Y(0,p)}s.N()}}
A.aL.prototype={}
A.bo.prototype={}
A.bp.prototype={}
A.et.prototype={
sbw(a){this.c=t.av.a(a)}}
A.eo.prototype={
gaF(){var s=this.a.a
return this.b===B.d?s.a:s.b},
ge2(){return this.gaF()===0?65536:Math.max(1,Math.min(65536,B.e.O(this.gaF(),10)))},
gcz(){var s=this.c,r=A.jX(t.s)
r.ai(0,new A.aT(s,A.e(s).h("aT<1>")))
s=this.f
if(s!=null)r.m(0,s.a.a.a.b)
return r.a},
e3(a,b){var s,r,q,p=this,o=new A.j($.i,t.eo),n=a.a.b
if(!a.gaG())return A.ih(null,t.h0)
s=p.c
if(!s.aa(n)){r=p.f
r=(r==null?null:r.a.a.a.b)!==n}else r=!1
if(r){r=p.d
q=r.u(0,n)
if(q==null)q=0
r.v(0,n,Math.max(q,p.w))}r=s.u(0,n)
if(r==null){r=A.hG(t.f)
s.v(0,n,r)
s=r}else s=r
s.ac(s.$ti.c.a(new A.bo(a,b,new A.a_(o,t.dM))))
p.aC()
p.a.N()
return o},
aC(){var s=this
if(s.r||s.a.w)return
s.r=!0
A.aA(new A.eq(s))},
d9(){var s,r,q,p,o,n,m,l,k,j,i=this,h=i.a
if(h.w||i.f!=null||i.c.a===0)return
for(s=i.c,r=new A.at(s,s.r,s.e,A.e(s).h("at<1>")),q=i.d,p=null;r.q();){o=r.d
if(p!=null){n=q.u(0,o)
n.toString
m=q.u(0,p)
m.toString
m=n<m
n=m}else n=!0
if(n)p=o}l=s.u(0,p)
k=l.cB()
if(l.b===l.c)s.Y(0,p)
if(!k.a.gaG()){k.c.I(null)
i.aC()
return}s=Math.min(k.b,i.ge2())
j=i.f=new A.et(k,s)
if(i.gaF()===0)i.bI(j)
else j.sbw(h.c.$2(A.ig(B.e.b1(s*1e6+i.gaF()-1,i.gaF())),new A.ep(i,j)))},
bI(a){var s,r,q,p,o,n,m=this
if(m.f!==a)return
m.f=null
s=a.a
r=s.a
if(r.gaG()){q=m.d
r=r.a.b
p=q.u(0,r)
if(p==null)p=m.w
o=a.b
n=p+o
q.v(0,r,n)
m.w=Math.max(m.w,n)
s.c.I(new A.bp(o,m.x))}else s.c.I(null)
m.aC()
m.a.N()},
cE(a){var s,r,q,p,o,n,m,l,k,j,i,h,g=this,f=g.f
if(f!=null&&f.a.a===a){s=f.c
if(s!=null)s.A()
g.f=null
f.a.c.I(null)}s=g.c
r=A.e(s).h("bS<1,2>")
r=A.ac(new A.bS(s,r),r.h("m.E"))
q=r.length
p=t.gX
o=t.G
n=0
for(;n<r.length;r.length===q||(0,A.W)(r),++n){m=r[n]
l=new A.aX(A.Y(A.ik(null),null,!1,p),o)
for(k=m.b,j=k.$ti,k=new A.ay(k,k.c,k.d,k.b,j.h("ay<1>")),j=j.c;k.q();){i=k.e
if(i==null)i=j.a(i)
if(i.a===a){i=i.c
h=i.a
if((h.a&30)!==0)A.b(A.f("Future already completed"))
h.E(i.$ti.h("1/").a(null))}else l.ac(i)}k=m.a
if(l.b===l.c)s.Y(0,k)
else s.v(0,k,l)}g.aC()
g.a.N()},
cA(){var s,r,q,p,o,n=this;++n.x
s=n.f
if(s!=null){r=s.c
if(r!=null)r.A()
n.f=null
r=s.a
q=r.a
if(q.gaG()){p=n.c
q=q.a.b
o=p.u(0,q)
if(o==null){o=A.hG(t.f)
p.v(0,q,o)
q=o}else q=o
q.$ti.c.a(r)
p=q.b
o=q.a
p=(p-1&o.length-1)>>>0
q.b=p
B.b.v(o,p,r)
if(q.b===q.c)q.bS();++q.d}else r.c.I(null)}n.aC()},
t(){var s,r,q,p,o,n,m=this,l=m.f
if(l!=null){l=l.c
if(l!=null)l.A()}s=m.f
m.f=null
if(s!=null)s.a.c.I(null)
for(l=m.c,r=new A.aU(l,l.r,l.e,A.e(l).h("aU<2>"));r.q();){q=r.d
for(p=q.$ti,q=new A.ay(q,q.c,q.d,q.b,p.h("ay<1>")),p=p.c;q.q();){o=q.e
o=(o==null?p.a(o):o).c
n=o.a
if((n.a&30)!==0)A.b(A.f("Future already completed"))
n.E(o.$ti.h("1/").a(null))}}l.co(0)
m.d.co(0)}}
A.eq.prototype={
$0(){var s=this.a
s.r=!1
s.d9()},
$S:0}
A.ep.prototype={
$0(){return this.a.bI(this.b)},
$S:0}
A.c6.prototype={
cU(a,b,c,d){var s=this,r=t.I.a(A.bl(new A.ee(s),new A.ef(s),new A.eg(s),new A.eh(s),!0,t.L))
s.e!==$&&A.hy()
s.e=r},
gaG(){var s,r=this,q=!1
if(!r.Q)if(!r.z){q=r.a
s=q.b
q=!(s.d||q.f||q.a.w)&&!r.y&&!s.c}return q},
ab(){var s,r,q,p,o=this;++o.as
s=o.w
if(s!=null){s.e=o.y||o.a.b.c
s.aO()}if(!o.gaG())o.a.a.cf(o)
if(!o.z){s=o.a
s=s.b.d||s.f||s.a.w}else s=!0
if(s){o.r=!0
s=o.f
s=A.ac(s,A.e(s).c)
r=s.length
q=0
for(;q<s.length;s.length===r||(0,A.W)(s),++q)s[q].$0()
s=o.w
if(s!=null)s.A()}s=!0
if(!(!o.y&&!o.a.b.c))if(!o.z){s=o.a
s=s.b.d||s.f||s.a.w}if(s){p=o.x
o.x=null
if(p!=null)p.aD()}},
ce(){var s=this,r=s.a,q=r.b
if(q.d||r.f||r.a.w)A.b(B.f)
if(s.z)A.b(B.f)
if(!s.y&&!q.c)return null
r=s.x
return(r==null?s.x=new A.a_(new A.j($.i,t.U),t.h):r).a},
aT(a){return this.dr(a)},
dr(a){var s=0,r=A.w(t.y),q,p=2,o=[],n=[],m=this,l,k,j,i
var $async$aT=A.n(function(b,c){if(b===1){o.push(c)
s=p}for(;;)switch(s){case 0:k=new A.a_(new A.j($.i,t.k),t.co)
j=new A.eb(k)
i=m.f
i.m(0,j)
p=3
if(m.r)j.$0()
else{l=a.b
l===$&&A.x()
l.q().ap(new A.ec(k),new A.ed(k),t.H)}s=6
return A.a(k.a,$async$aT)
case 6:l=c
q=l
n=[1]
s=4
break
n.push(5)
s=4
break
case 3:n=[2]
case 4:p=2
i.Y(0,j)
s=n.pop()
break
case 5:case 1:return A.u(q,r)
case 2:return A.t(o.at(-1),r)}})
return A.v($async$aT,r)},
T(){var s=0,r=A.w(t.H),q,p=2,o=[],n=[],m=this,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,d0,d1
var $async$T=A.n(function(d2,d3){if(d2===1){o.push(d3)
s=p}for(;;)A:switch(s){case 0:c9=m.a
d0=c9.c
d0.m(0,m)
a7=c9.a
a8=m.c
if(a8===B.d){a9=a7.f
a9===$&&A.x()
b0=a9}else{a9=a7.r
a9===$&&A.x()
b0=a9}l=b0
k=0
j=0
p=4
a9=c9.b
if(a9.d||c9.f||a7.w)A.b(B.f)
if(m.z)A.b(B.f)
b1=m.d
if(!b1)c9.cw(a8)
a8=t.A,b2=t.H,b3=m.b
case 7:i=m.ce()
s=i!=null?9:10
break
case 9:s=11
return A.a(i,$async$T)
case 11:s=7
break
case 10:b4=m.w
h=b4==null?m.w=A.ke(b3):b4
s=12
return A.a(m.aT(h),$async$T)
case 12:g=d3
if(a9.d||c9.f||a7.w)A.b(B.f)
if(m.z)A.b(B.f)
if(!g){s=8
break}b5=h.b
b5===$&&A.x()
f=b5.gB()
e=0
case 13:b5=e
b6=J.aC(f)
if(typeof b5!=="number"){q=b5.b0()
n=[1]
s=5
break}if(!(b5<b6)){s=14
break}d=m.ce()
s=d!=null?16:17
break
case 16:s=18
return A.a(d,$async$T)
case 18:s=15
break
case 17:b5=65536
if(b1){b6=l
b7=b6.b===B.d
b6=b6.a.a
if(!((b7?b6.a:b6.b)===0))b5=Math.max(1,Math.min(65536,B.e.O(b7?b6.a:b6.b,10)))}b6=J.aC(f)
b7=e
if(typeof b7!=="number"){q=A.de(b7)
n=[1]
s=5
break}c=Math.min(b5,b6-b7)
b=new Uint8Array(c)
a=0
for(;;){b5=a
b6=c
if(typeof b5!=="number"){q=b5.b0()
n=[1]
s=5
break A}if(typeof b6!=="number"){q=A.de(b6)
n=[1]
s=5
break A}if(!(b5<b6))break
b5=e
b6=a
if(typeof b5!=="number"){q=b5.aK()
n=[1]
s=5
break A}if(typeof b6!=="number"){q=A.de(b6)
n=[1]
s=5
break A}a0=J.jz(f,b5+b6)
b5=a0
if(typeof b5!=="number"){q=b5.b0()
n=[1]
s=5
break A}if(!(b5<0)){b5=a0
if(typeof b5!=="number"){q=b5.cN()
n=[1]
s=5
break A}b5=b5>255}else b5=!0
if(b5){c9=A.bj(a0,0,255,"byte",null)
throw A.c(c9)}J.hA(b,a,a0)
b5=a
if(typeof b5!=="number"){q=b5.aK()
n=[1]
s=5
break A}a=b5+1}a1=m.as
s=b1?19:21
break
case 19:s=22
return A.a(l.e3(m,c),$async$T)
case 22:s=20
break
case 21:d3=null
case 20:a2=d3
b5=!a9.d
if(!b5||c9.f||a7.w)A.b(B.f)
if(m.z)A.b(B.f)
b6=!1
if(!m.Q)b5=!(!b5||c9.f||a7.w)&&!m.y&&!a9.c
else b5=b6
b6=!0
if(b5)if(J.aB(a1,m.as))if(b1)b5=a2==null||a2.b!==l.x
else b5=!1
else b5=b6
else b5=b6
if(b5){s=15
break}a3=b1?a2.a:c
if(J.aB(a3,J.aC(b)))b8=J.jB(b)
else{b5=b
b9=b5.BYTES_PER_ELEMENT
c0=A.dH(0,a3,B.e.b1(b5.byteLength,b9))
b8=B.m.ck(J.jA(B.m.gdK(b5),b5.byteOffset+0*b9,c0*b9))}a4=b8
if(b1){b5=l
b6=A.ar(a3)
b5.y+=b6
b7=b5.e
b5=b5.a
c1=B.e.O(a8.a(b5.b.$0()).a,1e5)
b7.bY(c1)
b7=b7.a
if(!b7.gP(0)){c2=b7.b
c3=b7.c
if(c2===c3)A.b(A.bM())
c2=b7.a
c4=c2.length
c3=(c3-1&c4-1)>>>0
if(!(c3>=0&&c3<c4)){q=A.z(c2,c3)
n=[1]
s=5
break}c3=c2[c3]
c2=(c3==null?b7.$ti.c.a(c3):c3).a===c1}else c2=!1
if(c2){c2=b7.b
c3=b7.c
if(c2===c3)A.b(A.bM());++b7.d
c2=b7.a
c4=c2.length
c3=(c3-1&c4-1)>>>0
b7.c=c3
if(!(c3>=0&&c3<c4)){q=A.z(c2,c3)
n=[1]
s=5
break}c5=c2[c3]
if(c5==null)c5=b7.$ti.c.a(c5)
B.b.v(c2,c3,null)
b7.ac(b7.$ti.c.a(new A.bt(c1,c5.b+b6)))}else b7.ac(b7.$ti.c.a(new A.bt(c1,b6)))
b5.N()}b5=m.e
b5===$&&A.x()
b6=A.e(b5)
b7=b6.c.a(a4)
c2=b5.b
if(c2>=4)A.b(b5.aw())
if((c2&1)!==0)b5.a0(b7)
else if((c2&3)===0){b5=b5.a6()
b6=new A.S(b7,b6.h("S<1>"))
c6=b5.c
if(c6==null)b5.b=b5.c=b6
else{c6.sW(b6)
b5.c=b6}}b5=e
b6=a3
if(typeof b5!=="number"){q=b5.aK()
n=[1]
s=5
break}if(typeof b6!=="number"){q=A.de(b6)
n=[1]
s=5
break}e=b5+b6
b6=j
b5=a3
if(typeof b6!=="number"){q=b6.aK()
n=[1]
s=5
break}if(typeof b5!=="number"){q=A.de(b5)
n=[1]
s=5
break}j=b6+b5
b5=j
if(typeof b5!=="number"){q=b5.ea()
n=[1]
s=5
break}s=b5>=1048576?23:24
break
case 23:j=0
s=25
return A.a(A.q(B.a,b2),$async$T)
case 25:case 24:case 15:s=13
break
case 14:b5=k
if(typeof b5!=="number"){q=b5.aK()
n=[1]
s=5
break}c7=b5+1
k=c7
s=c7>=64?26:27
break
case 26:k=0
s=28
return A.a(A.q(B.a,b2),$async$T)
case 28:case 27:s=7
break
case 8:n.push(6)
s=5
break
case 4:p=3
d1=o.pop()
a5=A.O(d1)
a6=A.P(d1)
if(!m.z){c9=m.e
c9===$&&A.x()
c9.aV(a5,a6)}n.push(6)
s=5
break
case 3:n=[2]
case 5:p=2
m.Q=!0
a7.cf(m)
c9=m.w
if(c9!=null)c9.A()
d0.Y(0,m)
c9=m.e
c9===$&&A.x()
c9.j()
s=n.pop()
break
case 6:case 1:return A.u(q,r)
case 2:return A.t(o.at(-1),r)}})
return A.v($async$T,r)}}
A.ef.prototype={
$0(){return A.aA(new A.ea(this.a))},
$S:0}
A.ea.prototype={
$0(){var s=this.a,r=t.X
A.jh(s.gdD(),A.dt([$.bE(),s.a],r,r),t.B)},
$S:0}
A.eg.prototype={
$0(){var s=this.a
s.y=!0
s.ab()},
$S:0}
A.eh.prototype={
$0(){var s=this.a
s.y=!1
s.ab()},
$S:0}
A.ee.prototype={
$0(){var s=this.a
s.z=!0
s.ab()},
$S:2}
A.eb.prototype={
$0(){var s=this.a
if((s.a.a&30)===0)s.I(!1)},
$S:0}
A.ec.prototype={
$1(a){var s
A.iL(a)
s=this.a
if((s.a.a&30)===0)s.I(a)},
$S:24}
A.ed.prototype={
$2(a,b){var s
A.G(a)
t.l.a(b)
s=this.a
if((s.a.a&30)===0)s.bm(a,b)},
$S:3}
A.d_.prototype={
cV(a){var s=this,r=t.I.a(A.bl(s.gd0(),new A.el(s,a),new A.em(s),new A.en(s),!0,t.L))
s.a!==$&&A.hy()
s.a=r
r=t.b9.a(new A.aM(A.db(new A.r(r,A.e(r).h("r<1>")),"stream",t.K),t.dd))
s.b!==$&&A.hy()
s.b=r},
aO(){var s,r=this,q=r.c
if(q==null||r.r)return
s=r.d||r.e
if(s===r.f)return
r.f=s
if(s)q.am()
else q.ao()},
bC(){var s,r=this
if(r.r)return
r.r=!0
s=r.c
r.c=null
if(s!=null)s.A().cn(new A.ei())},
A(){this.bC()
var s=this.b
s===$&&A.x()
s.A().cn(new A.ek())}}
A.el.prototype={
$0(){var s=this.a,r=s.a
r===$&&A.x()
s.c=this.b.al(t.f8.a(r.gdF(r)),!1,new A.ej(s),r.gdG())
s.aO()},
$S:0}
A.ej.prototype={
$0(){var s=this.a.a
s===$&&A.x()
s.j()
return null},
$S:0}
A.em.prototype={
$0(){var s=this.a
s.d=!0
s.aO()},
$S:0}
A.en.prototype={
$0(){var s=this.a
s.d=!1
s.aO()},
$S:0}
A.ei.prototype={
$2(a,b){A.G(a)
t.l.a(b)},
$S:3}
A.ek.prototype={
$2(a,b){A.G(a)
t.l.a(b)},
$S:3}
A.er.prototype={
bY(a){var s,r,q=this.a,p=a-10,o=q.$ti.c
for(;;){if(!q.gP(0)){s=q.b
if(s===q.c)A.b(A.bM())
r=q.a
if(!(s<r.length))return A.z(r,s)
s=r[s]
s=(s==null?o.a(s):s).a<=p}else s=!1
if(!s)break
q.cB()}},
cl(a){this.bY(B.e.O(a.a,1e5))
return this.a.dR(0,0,new A.es(),t.S)}}
A.es.prototype={
$2(a,b){return A.ar(a)+t.R.a(b).b},
$S:23}
A.fu.prototype={
$0(){return this.a.a},
$S:15}
A.a2.prototype={
cS(a,b){var s=this,r=t.cf.a(a.dZ(new A.dg(s,b),t.du.a(s.c.gdL()),new A.dh(s)))
s.e!==$&&A.hy()
s.e=r}}
A.dg.prototype={
$1(a){var s
t.L.a(a)
s=this.a
B.b.ai(s.a,a)
B.b.m(s.b,a)
s=this.b
if(s!=null)s.$1(a)},
$S:5}
A.dh.prototype={
$1(a){this.a.d=A.G(a)},
$S:27}
A.hx.prototype={
$1(a){return(t.c.a(a).c.a.a&30)!==0},
$S:17}
A.hu.prototype={
cM(a,b){var s=0,r=A.w(t.H),q=this,p
var $async$$2=A.n(function(c,d){if(c===1)return A.t(d,r)
for(;;)switch(s){case 0:s=2
return A.a(A.jO(b,t.H).e4(B.L),$async$$2)
case 2:++q.a.a
p=t.N
A.je(B.t.cq(A.dt(["test",a,"result","passed"],p,p),null))
return A.u(null,r)}})
return A.v($async$$2,r)},
$2(a,b){return this.cM(a,t.M.a(b))},
$S:29}
A.h2.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:n=A.bn(null,null,B.i)
q=[-1,1099511627777],p=0
case 2:if(!(p<2)){s=4
break}s=5
return A.a(A.dc(new A.fT(n,q[p]),new A.fU()),$async$$0)
case 5:o=n.a
if(!(o.a===0&&o.b===0))A.b(A.f("invalid limit became active"))
case 3:++p
s=2
break
case 4:B.T.bx()
n.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.fT.prototype={
$0(){var s=0,r=A.w(t.H),q,p=this
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=p.a.aJ(new A.ap(p.b,0))
s=1
break
case 1:return A.u(q,r)}})
return A.v($async$$0,r)},
$S:1}
A.fU.prototype={
$1(a){return a instanceof A.ab},
$S:18}
A.h3.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,2,4)
o=p.l("both")
n=t.t
m=t.L
l=A.o(o.n(A.I(A.h([1,2],n),m),B.d),null)
k=A.o(o.n(A.I(A.h([3],n),m),B.h),null)
m=t.H
s=2
return A.a(A.q(B.a,m),$async$$0)
case 2:if(q.gK()!==2)A.b(A.f("directions did not get independent timers"))
q.L(B.H)
s=3
return A.a(A.q(B.a,m),$async$$0)
case 3:n=l.a
if(!(n.length===0&&k.a.length===0))A.b(A.f("unpaid data escaped"))
q.L(B.u)
s=4
return A.a(A.q(B.a,m),$async$$0)
case 4:if(!(n.length===1&&k.a.length===0))A.b(A.f("upload quantum timing wrong"))
q.L(B.I)
s=5
return A.a(A.q(B.a,m),$async$$0)
case 5:s=6
return A.a(A.hB(A.h([l.c.a,k.c.a],t.e),m),$async$$0)
case 6:if(!(p.gD().b===2&&p.gD().c===1))A.b(A.f("direction accounting wrong"))
if(q.gK()!==0)A.b(A.f("settled directions retained timers"))
o.j()
p.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.h4.prototype={
$0(){return this.cL()},
cL(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
var $async$$0=A.n(function(a4,a5){if(a4===1)return A.t(a5,r)
for(;;)switch(s){case 0:a={}
a0=new A.L(B.a,A.h([],t.V))
a1=A.T(a0,0,10)
a2=t.E
a3=J.hC(4,a2)
for(q=0;q<4;++q)a3[q]=a1.l("a")
p=a1.l("b")
a.a=a.b=0
o=A.h([],t.D)
for(n=t.v,m=t.t,l=t.O,k=l.c,j=l.h("S<1>"),i=l.h("r<1>"),h=0;h<4;++h){g=a3[h]
f=new A.af(null,null,null,null,l)
e=k.a(A.h([1,1,1],m))
d=f.a6()
e=new A.S(e,j)
c=d.c
if(c==null)d.b=d.c=e
else{c.sW(e)
d.c=e}f.az()
f=n.a(new A.r(f,i))
if(g.b.d||g.f||g.a.w)A.b(B.f)
f=A.e9(g,f,B.d,!0).e
f===$&&A.x()
o.push(A.o(new A.r(f,A.e(f).h("r<1>")),new A.fR(a)))}o.push(A.o(p.n(A.I(A.Y(12,2,!1,t.S),t.L),B.d),new A.fS(a)))
s=2
return A.a(A.q(B.a,t.H),$async$$0)
case 2:b=0
case 3:if(!(b<24)){s=5
break}s=6
return A.a(a0.J(),$async$$0)
case 6:n=a.b
m=a.a
if(Math.abs(n-m)>1)A.b(A.f("task splitting gained a bandwidth share: "+n+"/"+m))
if(n+m>B.e.O(B.e.O(a0.a.a,1000),100))A.b(A.f("aggregate rate exceeded"))
case 4:++b
s=3
break
case 5:s=7
return A.a(A.a1(a0,o),$async$$0)
case 7:if(!(a.b===12&&a.a===12))A.b(A.f("payload was lost"))
if(a1.gD().f!==2)A.b(A.f("context count was mistaken for job count"))
a2=A.ac(a3,a2)
a2.push(p)
o=a2.length
h=0
for(;h<a2.length;a2.length===o||(0,A.W)(a2),++h)a2[h].j()
if(a1.gD().f!==0)A.b(A.f("closed groups retained participation"))
a1.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.fR.prototype={
$1(a){var s
t.L.a(a)
s=this.a
return s.b=s.b+a.length},
$S:5}
A.fS.prototype={
$1(a){var s
t.L.a(a)
s=this.a
return s.a=s.a+a.length},
$S:5}
A.hf.prototype={
$0(){return this.cK()},
cK(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2
var $async$$0=A.n(function(a3,a4){if(a3===1)return A.t(a4,r)
for(;;)switch(s){case 0:b={}
a=new A.L(B.a,A.h([],t.V))
a0=A.T(a,0,100)
a1=a0.l("large-parts")
a2=J.hC(40,t.E)
for(q=0;q<40;++q)a2[q]=a0.l("tiny-parts")
b.a=b.b=0
p=new A.ht(b)
o=A.h([A.o(a1.n(A.I(A.Y(40,1,!1,t.S),t.L),B.d),new A.fP(b,p))],t.D)
for(n=t.v,m=t.t,l=t.O,k=l.c,j=l.h("S<1>"),i=l.h("r<1>"),h=0;h<40;++h){g=a2[h]
f=new A.af(null,null,null,null,l)
e=k.a(A.h([2],m))
d=f.a6()
e=new A.S(e,j)
c=d.c
if(c==null)d.b=d.c=e
else{c.sW(e)
d.c=e}f.az()
f=n.a(new A.r(f,i))
if(g.b.d||g.f||g.a.w)A.b(B.f)
f=A.e9(g,f,B.d,!0).e
f===$&&A.x()
o.push(A.o(new A.r(f,A.e(f).h("r<1>")),new A.fQ(b,p)))}s=2
return A.a(A.a1(a,o),$async$$0)
case 2:o=!1
if(b.b===40)if(b.a===40)o=a.a.a===8e5
if(!o)A.b(A.f("unequal chunk accounting failed"))
for(o=A.h([a1],t.gk),B.b.ai(o,a2),n=o.length,h=0;h<o.length;o.length===n||(0,A.W)(o),++h)o[h].j()
a0.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.ht.prototype={
$0(){var s=this.a
if(Math.abs(s.b-s.a)>10)A.b(A.f("fairness used request count instead of byte service"))
return null},
$S:0}
A.fP.prototype={
$1(a){var s
t.L.a(a)
s=this.a
s.b=s.b+a.length
this.b.$0()},
$S:5}
A.fQ.prototype={
$1(a){var s
t.L.a(a)
s=this.a
s.a=s.a+a.length
this.b.$0()},
$S:5}
A.hj.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:m=new A.L(B.a,A.h([],t.V))
l=A.T(m,0,10)
k=l.l("old")
j=t.S
i=t.L
h=A.o(k.n(A.I(A.Y(30,1,!1,j),i),B.d),null)
q=0
case 2:if(!(q<10)){s=4
break}s=5
return A.a(m.J(),$async$$0)
case 5:case 3:++q
s=2
break
case 4:p=h.a
if(p.length!==10)A.b(A.f("old job setup failed"))
o=l.l("late")
n=A.o(o.n(A.I(A.Y(10,2,!1,j),i),B.d),null)
s=6
return A.a(A.q(B.a,t.H),$async$$0)
case 6:j=n.a,q=0
case 7:if(!(q<10)){s=9
break}s=10
return A.a(m.J(),$async$$0)
case 10:if(Math.abs(p.length-10-j.length)>1)A.b(A.f("late job received catch-up credit"))
case 8:++q
s=7
break
case 9:s=11
return A.a(A.a1(m,A.h([h,n],t.D)),$async$$0)
case 11:k.j()
o.j()
l.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hk.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h,g,f
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:k=new A.L(B.a,A.h([],t.V))
j=A.T(k,0,10)
i=j.l("busy")
h=j.l("returning")
g=t.L
f=A.o(h.n(A.I(A.h([2],t.t),g),B.d),null)
s=2
return A.a(k.J(),$async$$0)
case 2:s=3
return A.a(f.c.a,$async$$0)
case 3:q=t.S
p=A.o(i.n(A.I(A.Y(30,1,!1,q),g),B.d),null)
o=0
case 4:if(!(o<10)){s=6
break}s=7
return A.a(k.J(),$async$$0)
case 7:case 5:++o
s=4
break
case 6:n=p.a
m=n.length
l=A.o(h.n(A.I(A.Y(8,2,!1,q),g),B.d),null)
s=8
return A.a(A.q(B.a,t.H),$async$$0)
case 8:g=l.a,o=0
case 9:if(!(o<8)){s=11
break}s=12
return A.a(k.J(),$async$$0)
case 12:if(Math.abs(n.length-m-g.length)>1)A.b(A.f("returning job accrued idle credit"))
case 10:++o
s=9
break
case 11:s=13
return A.a(A.a1(k,A.h([p,l],t.D)),$async$$0)
case 13:i.j()
h.j()
j.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hl.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,10,0)
o=p.l("slow")
n=p.l("fast")
m=t.L
l=A.bl(null,null,null,null,!1,m)
k=A.o(o.n(new A.r(l,A.e(l).h("r<1>")),B.h),null)
j=A.o(n.n(A.I(A.h([1,2,3],t.t),m),B.h),null)
s=2
return A.a(A.q(B.a,t.H),$async$$0)
case 2:if(p.gD().w!==1)A.b(A.f("waiting source occupied quota"))
s=3
return A.a(A.a1(q,A.h([j],t.D)),$async$$0)
case 3:m=q.a
if(m.a!==3e5)A.b(A.f("slow source reduced ready throughput"))
o.A()
s=4
return A.a(k.c.a,$async$$0)
case 4:if(!(k.d instanceof A.aI))A.b(A.f("waiting source did not observe cancellation"))
s=5
return A.a(l.j(),$async$$0)
case 5:o.j()
n.j()
p.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hm.prototype={
$0(){return this.cJ()},
cJ(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:n={}
m=new A.L(B.a,A.h([],t.V))
l=A.T(m,0,4)
k=l.l("paused")
n.a=!1
k.e.a.cD(new A.fO(n),t.y)
q=A.o(k.n(A.I(A.h([1,2],t.t),t.L),B.d),null)
p=t.H
s=2
return A.a(A.q(B.a,p),$async$$0)
case 2:m.L(B.v)
k.ar(!0)
s=3
return A.a(A.q(B.a,p),$async$$0)
case 3:if(!(m.gK()===0&&l.gD().r===0))A.b(A.f("paused job held quota"))
m.L(B.J)
s=4
return A.a(A.q(B.a,p),$async$$0)
case 4:o=q.a
if(!(o.length===0&&!n.a))A.b(A.f("pause emitted bytes or cancelled context"))
k.ar(!1)
s=5
return A.a(A.q(B.a,p),$async$$0)
case 5:if(o.length!==0)A.b(A.f("paused time became burst credit"))
s=6
return A.a(A.a1(m,A.h([q],t.D)),$async$$0)
case 6:if(o.length!==2)A.b(A.f("resume lost payload"))
k.j()
s=7
return A.a(A.q(B.a,p),$async$$0)
case 7:if(!n.a)A.b(A.f("close did not settle cancellation signal"))
l.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.fO.prototype={
$1(a){return this.a.a=!0},
$S:31}
A.hn.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:o=new A.L(B.a,A.h([],t.V))
n=A.T(o,0,10)
m=n.l("paused-consumer")
l=n.l("ready-consumer")
k=t.t
j=t.L
i=A.o(m.n(A.I(A.h([1,2],k),j),B.d),null)
h=t.H
s=2
return A.a(A.q(B.a,h),$async$$0)
case 2:q=i.e
q===$&&A.x()
q.am()
s=3
return A.a(A.q(B.a,h),$async$$0)
case 3:if(o.gK()!==0)A.b(A.f("consumer pause kept pacing timer"))
p=A.o(l.n(A.I(A.h([3,4],k),j),B.d),null)
k=t.D
s=4
return A.a(A.a1(o,A.h([p],k)),$async$$0)
case 4:if(!(i.a.length===0&&p.a.length===2))A.b(A.f("paused consumer retained share"))
q.ao()
s=5
return A.a(A.a1(o,A.h([i],k)),$async$$0)
case 5:m.j()
l.j()
n.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.ho.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:p=new A.L(B.a,A.h([],t.V))
o=A.T(p,0,1)
n=o.l("changing")
m=A.o(n.n(A.I(A.h([1,2,3],t.t),t.L),B.d),null)
s=2
return A.a(A.q(B.a,t.H),$async$$0)
case 2:o.aJ(B.U)
s=3
return A.a(p.J(),$async$$0)
case 3:q=p.a
if(!(q.a===1e5&&m.a.length===1))A.b(A.f("new rate did not replace pending wait"))
o.aJ(B.i)
s=4
return A.a(m.c.a,$async$$0)
case 4:if(!(m.a.length===3&&p.gK()===0))A.b(A.f("zero did not wake unlimited path"))
if(o.gD().b!==3)A.b(A.f("unlimited supported payload not counted"))
n.j()
o.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hp.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,2,1)
o=p.l("independent-change")
n=A.o(o.n(A.I(A.h([1],t.t),t.L),B.h),null)
m=t.H
s=2
return A.a(A.q(B.a,m),$async$$0)
case 2:q.L(B.v)
p.aJ(B.V)
s=3
return A.a(A.q(B.a,m),$async$$0)
case 3:q.L(B.K)
s=4
return A.a(A.q(B.a,m),$async$$0)
case 4:if(n.a.length!==1)A.b(A.f("an upload-only change restarted the download wait"))
s=5
return A.a(n.c.a,$async$$0)
case 5:o.j()
p.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.h5.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:p=new A.L(B.a,A.h([],t.V))
o=A.T(p,0,100)
n=o.l("lowered")
m=A.o(n.n(A.I(A.h([1,2],t.t),t.L),B.d),null)
l=t.H
s=2
return A.a(A.q(B.a,l),$async$$0)
case 2:o.aJ(B.W)
s=3
return A.a(A.q(B.a,l),$async$$0)
case 3:p.L(B.M)
s=4
return A.a(A.q(B.a,l),$async$$0)
case 4:q=m.a
if(q.length!==0)A.b(A.f("old rate escaped after lowering"))
p.L(B.u)
s=5
return A.a(A.q(B.a,l),$async$$0)
case 5:if(q.length!==1)A.b(A.f("lowered rate did not deliver one paid byte"))
s=6
return A.a(A.a1(p,A.h([m],t.D)),$async$$0)
case 6:n.j()
o.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.h6.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
var $async$$0=A.n(function(a4,a5){if(a4===1)return A.t(a5,r)
for(;;)switch(s){case 0:q=[1,1099511627776],p=t.D,o=t.v,n=t.S,m=t.O,l=m.c,k=t.V,j=m.h("S<1>"),i=m.h("r<1>"),h=0
case 2:if(!(h<2)){s=4
break}g=q[h]
f=new A.L(B.a,A.h([],k))
e=A.T(f,0,g)
d=e.l("rate-"+g)
c=g===1
b=c?1:65536
a=new A.af(null,null,null,null,m)
a0=l.a(A.Y(b,7,!1,n))
a1=a.a6()
a0=new A.S(a0,j)
a2=a1.c
if(a2==null)a1.b=a1.c=a0
else{a2.sW(a0)
a1.c=a0}a.az()
a=o.a(new A.r(a,i))
if(d.b.d||d.f||d.a.w)A.b(B.f)
a=A.e9(d,a,B.d,!0).e
a===$&&A.x()
a3=A.o(new A.r(a,A.e(a).h("r<1>")),null)
s=5
return A.a(A.a1(f,A.h([a3],p)),$async$$0)
case 5:if(a3.a.length!==b)A.b(A.f("rate arithmetic lost bytes"))
a=f.a
c=c?1e6:1
if(a.a!==c)A.b(A.f("rate arithmetic overflowed"))
d.j()
e.t()
case 3:++h
s=2
break
case 4:return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.h7.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i,h,g,f
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:n=new A.L(B.a,A.h([],t.V))
m=A.T(n,0,1)
l=m.l("shared")
k=m.l("shared")
j=t.t
i=t.L
h=A.o(l.n(A.I(A.h([1],j),i),B.d),null)
g=A.o(k.n(A.I(A.h([2],j),i),B.d),null)
f=t.H
s=2
return A.a(A.q(B.a,f),$async$$0)
case 2:l.j()
s=3
return A.a(h.c.a,$async$$0)
case 3:if(h.d instanceof A.aI)q=!(k.b.d||k.f||k.a.w)
else q=!1
if(!q)A.b(A.f("close cancelled siblings"))
s=4
return A.a(A.a1(n,A.h([g],t.D)),$async$$0)
case 4:if(B.b.gcP(g.a)!==2)A.b(A.f("sibling lost its demand"))
p=m.l("shared")
o=A.o(p.n(A.I(A.h([3],j),i),B.d),null)
s=5
return A.a(A.q(B.a,f),$async$$0)
case 5:k.A()
s=6
return A.a(A.hB(A.h([k.e.a,p.e.a,o.c.a],t.e),f),$async$$0)
case 6:if(!(o.d instanceof A.aI&&m.gD().r===0))A.b(A.f("group cancellation left demand"))
k.j()
p.j()
m.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.h8.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k,j,i
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,0,1)
o=t.L
n=A.bl(null,null,null,null,!1,o)
m=p.l("source")
l=p.l("quota")
k=p.l("paused")
j=t.t
i=A.h([A.o(m.n(new A.r(n,A.e(n).h("r<1>")),B.d),null),A.o(l.n(A.I(A.h([1],j),o),B.d),null),A.o(k.n(A.I(A.h([2],j),o),B.d),null)],t.D)
k.ar(!0)
o=t.H
s=2
return A.a(A.q(B.a,o),$async$$0)
case 2:p.t()
s=3
return A.a(A.hB(new A.bU(i,t.eP.a(new A.fM()),t.eM),o),$async$$0)
case 3:if(!B.b.aj(i,new A.fN()))A.b(A.f("dispose did not settle all waits"))
if(!(q.gK()===0&&p.gD().f===0))A.b(A.f("dispose retained work"))
s=4
return A.a(n.j(),$async$$0)
case 4:return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.fM.prototype={
$1(a){return t.c.a(a).c.a},
$S:32}
A.fN.prototype={
$1(a){return t.c.a(a).d instanceof A.aI},
$S:17}
A.h9.prototype={
$0(){return this.cI()},
cI(){var s=0,r=A.w(t.H),q,p,o,n,m,l,k
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:n={}
m=A.bn(null,null,B.i)
l=m.l("a")
k=m.l("b")
n.a=null
q=l.M(new A.h0(l,new A.hs(n)),t.v)
l.ar(!0)
p=k.M(new A.h1(k,q),t.c)
s=2
return A.a(A.q(B.a,t.H),$async$$0)
case 2:o=p.a
if(o.length!==0)A.b(A.f("subscription adopted B instead of paused A"))
l.ar(!1)
s=3
return A.a(p.c.a,$async$$0)
case 3:if(!(o.length===2&&t.d.a($.i.u(0,$.bE()))==null))A.b(A.f("zone leaked or payload lost"))
if(n.a!==l)A.b(A.f("a lazy source or nested transport adopted subscriber B"))
l.j()
k.j()
m.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hs.prototype={
$0(){var $async$$0=A.n(function(a,b){switch(a){case 2:n=q
s=n.pop()
break
case 1:o.push(b)
s=p}for(;;)switch(s){case 0:m.a.a=t.d.a($.i.u(0,$.bE()))
s=3
q=[1]
return A.az(A.eU(A.h([1,2],t.t)),$async$$0,r)
case 3:case 1:return A.az(null,0,r)
case 2:return A.az(o.at(-1),1,r)}})
var s=0,r=A.hX($async$$0,t.L),q,p=2,o=[],n=[],m=this
return A.hZ(r)},
$S:6}
A.h0.prototype={
$0(){var s=$.i,r=$.bE(),q=t.d
if(q.a(s.u(0,r))!==this.a)A.b(A.f("zone did not capture A"))
s=q.a($.i.u(0,r))
s.toString
return s.n(this.b.$0(),B.d)},
$S:6}
A.h1.prototype={
$0(){if(t.d.a($.i.u(0,$.bE()))!==this.a)A.b(A.f("zone did not capture B"))
return A.o(this.b,null)},
$S:20}
A.ha.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:o=A.bn(null,null,B.i)
n=o.l("same-id")
m=n.n(A.I(A.h([1],t.t),t.L),B.d)
n.j()
q=o.l("same-id")
p=q.M(new A.h_(m),t.c)
s=2
return A.a(p.c.a,$async$$0)
case 2:if(!(p.d instanceof A.aI&&p.a.length===0))A.b(A.f("closed identity adopted replacement"))
q.j()
o.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.h_.prototype={
$0(){return A.o(this.a,null)},
$S:20}
A.hb.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,0,1)
o=p.l("browser")
n=A.o(o.cm(A.I(A.h([1,2,3],t.t),t.L),B.d,!1),null)
s=2
return A.a(n.c.a,$async$$0)
case 2:if(!(B.b.dX(n.a,",")==="1,2,3"&&q.gK()===0))A.b(A.f("unsupported path was throttled or changed"))
if(!(p.gD().b===0&&p.gD().x===1))A.b(A.f("preparation counted as transport"))
o.cw(B.h)
if(p.gD().y!==1)A.b(A.f("streamless unsupported hook absent"))
o.j()
if(p.gD().x!==0)A.b(A.f("closed job retained live coverage"))
p.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hc.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n,m,l
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:n=A.bn(null,null,B.i)
m=n.l("reused")
l=new Uint8Array(102400)
B.m.cs(l,0,102400,1)
q=A.o(m.n(new A.hr(l).$0(),B.h),null)
s=2
return A.a(q.c.a,$async$$0)
case 2:if(!(q.d==null&&q.a.length===204800))A.b(A.f("reused payload length wrong"))
p=q.a
o=A.V(p).c
if(!A.it(p,0,A.db(102400,"count",t.S),o).aj(0,new A.fV()))A.b(A.f("first buffer was reused too soon"))
if(!A.it(p,102400,null,o).aj(0,new A.fW()))A.b(A.f("second buffer wrong"))
if(!B.b.aj(q.b,new A.fX()))A.b(A.f("unbounded handoff slice"))
s=3
return A.a(A.dc(new A.fY(q),new A.fZ()),$async$$0)
case 3:m.j()
n.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hr.prototype={
$0(){var $async$$0=A.n(function(a,b){switch(a){case 2:n=q
s=n.pop()
break
case 1:o.push(b)
s=p}for(;;)switch(s){case 0:l=m.a
s=3
q=[1]
return A.az(A.eU(l),$async$$0,r)
case 3:B.m.cs(l,0,102400,2)
s=4
q=[1]
return A.az(A.eU(l),$async$$0,r)
case 4:case 1:return A.az(null,0,r)
case 2:return A.az(o.at(-1),1,r)}})
var s=0,r=A.hX($async$$0,t.L),q,p=2,o=[],n=[],m=this,l
return A.hZ(r)},
$S:6}
A.fV.prototype={
$1(a){return A.ar(a)===1},
$S:21}
A.fW.prototype={
$1(a){return A.ar(a)===2},
$S:21}
A.fX.prototype={
$1(a){return t.L.a(a).length<=65536},
$S:54}
A.fY.prototype={
$0(){var s=0,r=A.w(t.S),q,p=this
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:J.hA(B.b.gct(p.a.b),0,9)
q=9
s=1
break
case 1:return A.u(q,r)}})
return A.v($async$$0,r)},
$S:37}
A.fZ.prototype={
$1(a){return t.d0.b(a)},
$S:18}
A.hd.prototype={
$0(){return this.cH()},
cH(){var s=0,r=A.w(t.H),q=1,p=[],o=[],n,m,l,k,j,i,h,g,f
var $async$$0=A.n(function(a,b){if(a===1){p.push(b)
s=q}for(;;)switch(s){case 0:j={}
i=A.bn(null,null,B.i)
h=i.l("error")
g=new A.a_(new A.j($.i,t.U),t.h)
f=new A.Z("original transport read error")
j.a=!1
n=A.kf()
n.b=A.bl(new A.fK(j,g),new A.fL(n,f),null,null,!1,t.L)
l=n.bi()
m=A.o(h.n(new A.r(l,A.e(l).h("r<1>")),B.h),null)
q=2
s=5
return A.a(m.c.a,$async$$0)
case 5:l=m.d
k=f
if(!((l==null?k==null:l===k)&&j.a&&(g.a.a&30)===0))A.b(A.f("read error waited for or was replaced by cleanup"))
if(i.gD().w!==0)A.b(A.f("failed reader held quota"))
o.push(4)
s=3
break
case 2:o=[1]
case 3:q=1
g.aD()
s=6
return A.a(n.bi().j(),$async$$0)
case 6:h.j()
i.t()
s=o.pop()
break
case 4:return A.u(null,r)
case 1:return A.t(p.at(-1),r)}})
return A.v($async$$0,r)},
$S:1}
A.fL.prototype={
$0(){return A.aA(new A.fI(this.a,this.b))},
$S:0}
A.fI.prototype={
$0(){return this.a.bi().cg(this.b)},
$S:0}
A.fK.prototype={
$0(){this.a.a=!0
return this.b.a},
$S:1}
A.he.prototype={
$0(){var s=0,r=A.w(t.H),q=1,p=[],o=[],n,m,l,k,j,i,h
var $async$$0=A.n(function(a,b){if(a===1){p.push(b)
s=q}for(;;)switch(s){case 0:n=new A.L(B.a,A.h([],t.V))
m=A.T(n,0,1)
l=m.l("consumer-cancel")
k=new A.a_(new A.j($.i,t.U),t.h)
j=A.bl(new A.fJ(k),null,null,null,!1,t.L)
i=j
h=A.o(l.n(new A.r(i,A.e(i).h("r<1>")),B.d),null)
J.i7(j,A.h([1],t.t))
s=2
return A.a(A.q(B.a,t.H),$async$$0)
case 2:q=3
i=h.e
i===$&&A.x()
s=6
return A.a(i.A(),$async$$0)
case 6:if(!((k.a.a&30)===0&&n.gK()===0))A.b(A.f("consumer cancel awaited provider cleanup"))
if(m.gD().b!==0)A.b(A.f("cancelled unsubmitted byte was counted"))
o.push(5)
s=4
break
case 3:o=[1]
case 4:q=1
k.aD()
s=7
return A.a(j.j(),$async$$0)
case 7:l.j()
m.t()
s=o.pop()
break
case 5:return A.u(null,r)
case 1:return A.t(p.at(-1),r)}})
return A.v($async$$0,r)},
$S:1}
A.fJ.prototype={
$0(){return this.a.a},
$S:1}
A.hg.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=A.bn(null,null,B.i)
p=q.l("partial")
o=A.o(p.n(new A.hq().$0(),B.d),null)
s=2
return A.a(o.c.a,$async$$0)
case 2:if(!(o.d instanceof A.Z&&q.gD().b===3))A.b(A.f("failure refunded submitted bytes"))
p.j()
q.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hq.prototype={
$0(){var $async$$0=A.n(function(a,b){switch(a){case 2:n=q
s=n.pop()
break
case 1:o.push(b)
s=p}for(;;)switch(s){case 0:s=3
q=[1]
return A.az(A.eU(A.h([1,2,3],t.t)),$async$$0,r)
case 3:throw A.c(A.f("after handoff"))
case 1:return A.az(null,0,r)
case 2:return A.az(o.at(-1),1,r)}})
var s=0,r=A.hX($async$$0,t.L),q,p=2,o=[],n=[]
return A.hZ(r)},
$S:6}
A.hh.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,0,0)
o=p.l("observed")
n=o.n(A.I(A.Y(1024,1,!1,t.S),t.L),B.d)
s=2
return A.a(n.dY(null,!0).ci(null,t.H),$async$$0)
case 2:if(p.gD().d!==1024)A.b(A.f("recent handoff rate absent"))
q.L(B.G)
if(!(p.gD().d===0&&p.gD().b===1024))A.b(A.f("idle rate did not decay"))
if(q.gK()!==0)A.b(A.f("rate observation retained an idle timer"))
o.j()
p.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.hi.prototype={
$0(){var s=0,r=A.w(t.H),q,p,o,n
var $async$$0=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:q=new A.L(B.a,A.h([],t.V))
p=A.T(q,0,1)
o=p.l("invalid")
n=A.o(o.n(A.I(A.h([256],t.t),t.L),B.d),null)
s=2
return A.a(n.c.a,$async$$0)
case 2:if(!(t.b8.b(n.d)&&p.gD().b===0))A.b(A.f("invalid byte was normalized or delivered"))
if(q.gK()!==0)A.b(A.f("invalid bytes retained pacing work"))
o.j()
p.t()
return A.u(null,r)}})
return A.v($async$$0,r)},
$S:1}
A.L.prototype={
gK(){var s=this.b,r=A.V(s)
return new A.a6(s,r.h("p(1)").a(new A.dv()),r.h("a6<1>")).gk(0)},
e5(a,b){var s,r
t.M.a(b)
s=a.a
if(s<=0)throw A.c(A.f("A pacing timer must have a positive duration."))
r=new A.ah(new A.E(this.a.a+s),b)
B.b.m(this.b,r)
return r},
L(a){var s,r,q,p,o,n,m=this,l=a.a
if(l<0)throw A.c(A.bF(a,"duration",null))
s=new A.E(m.a.a+l)
l=m.b
r=A.V(l)
q=r.h("p(1)")
r=r.h("a6<1>")
p=A.ac(new A.a6(l,q.a(new A.dy(s)),r),r.h("m.E"))
B.b.bz(p,new A.dz())
for(r=p.length,o=0;o<p.length;p.length===r||(0,A.W)(p),++o){n=p[o]
m.a=n.a
n.dP()}m.a=s
r=q.a(new A.dA())
l.$flags&1&&A.aP(l,16)
B.b.dv(l,r,!0)},
dI(){var s=this.b,r=A.V(s),q=r.h("a6<1>"),p=A.ac(new A.a6(s,r.h("p(1)").a(new A.dw()),q),q.h("m.E"))
B.b.bz(p,new A.dx())
if(p.length===0)throw A.c(A.f("Expected a pacing timer."))
this.L(new A.E(B.b.gct(p).a.a-this.a.a))},
J(){var s=0,r=A.w(t.H),q=this,p
var $async$J=A.n(function(a,b){if(a===1)return A.t(b,r)
for(;;)switch(s){case 0:p=t.H
s=2
return A.a(A.q(B.a,p),$async$J)
case 2:q.dI()
s=3
return A.a(A.q(B.a,p),$async$J)
case 3:return A.u(null,r)}})
return A.v($async$J,r)}}
A.dv.prototype={
$1(a){return t.r.a(a).c},
$S:7}
A.dy.prototype={
$1(a){t.r.a(a)
return a.c&&a.a.a<=this.a.a},
$S:7}
A.dz.prototype={
$2(a,b){var s=t.r
return B.e.cp(s.a(a).a.a,s.a(b).a.a)},
$S:12}
A.dA.prototype={
$1(a){return!t.r.a(a).c},
$S:7}
A.dw.prototype={
$1(a){return t.r.a(a).c},
$S:7}
A.dx.prototype={
$2(a,b){var s=t.r
return B.e.cp(s.a(a).a.a,s.a(b).a.a)},
$S:12}
A.ah.prototype={
A(){return this.c=!1},
dP(){var s=this
if(!s.c)return
s.c=!1;++s.d
s.b.$0()},
$ia4:1,
gbq(){return this.c}};(function aliases(){var s=J.aE.prototype
s.cQ=s.i
s=A.b1.prototype
s.cR=s.aN})();(function installTearOffs(){var s=hunkHelpers._static_0,r=hunkHelpers._static_1,q=hunkHelpers._static_2,p=hunkHelpers.installStaticTearOff,o=hunkHelpers._instance_0u,n=hunkHelpers.installInstanceTearOff,m=hunkHelpers._instance_2u,l=hunkHelpers._instance_1i,k=hunkHelpers._instance_1u
s(A,"l5","k_",13)
r(A,"ls","ka",8)
r(A,"lt","kb",8)
r(A,"lu","kc",8)
s(A,"j7","ll",0)
r(A,"j5","l7",19)
q(A,"lv","l9",4)
s(A,"j6","l8",0)
q(A,"lr","k4",22)
p(A,"lz",5,null,["$5"],["lf"],42,0)
p(A,"lE",4,null,["$1$4","$4"],["fw",function(a,b,c,d){return A.fw(a,b,c,d,t.z)}],43,0)
p(A,"lG",5,null,["$2$5","$5"],["fx",function(a,b,c,d,e){var i=t.z
return A.fx(a,b,c,d,e,i,i)}],44,0)
p(A,"lF",6,null,["$3$6"],["hY"],45,0)
p(A,"lC",4,null,["$1$4","$4"],["j0",function(a,b,c,d){return A.j0(a,b,c,d,t.z)}],46,0)
p(A,"lD",4,null,["$2$4","$4"],["j1",function(a,b,c,d){var i=t.z
return A.j1(a,b,c,d,i,i)}],47,0)
p(A,"lB",4,null,["$3$4","$4"],["j_",function(a,b,c,d){var i=t.z
return A.j_(a,b,c,d,i,i,i)}],48,0)
p(A,"lx",5,null,["$5"],["le"],49,0)
p(A,"lH",4,null,["$4"],["fy"],50,0)
p(A,"lw",5,null,["$5"],["ld"],51,0)
p(A,"mp",5,null,["$5"],["lc"],52,0)
p(A,"lA",4,null,["$4"],["lg"],39,0)
p(A,"ly",5,null,["$5"],["iZ"],36,0)
var j
o(j=A.aq.prototype,"gbf","ag",0)
o(j,"gbg","ah",0)
n(A.a_.prototype,"gdL",0,0,null,["$1","$0"],["I","aD"],30,0,0)
m(A.j.prototype,"gd3","d4",4)
l(j=A.b7.prototype,"gdF","m",10)
n(j,"gdG",0,1,null,["$2","$1"],["aV","cg"],28,0,0)
k(j,"gd_","a4",10)
m(j,"gcZ","a3",4)
o(j,"gd1","ae",0)
o(j=A.aw.prototype,"gbf","ag",0)
o(j,"gbg","ah",0)
o(j=A.a0.prototype,"gbf","ag",0)
o(j,"gbg","ah",0)
o(A.br.prototype,"gbU","dn",0)
k(j=A.aM.prototype,"gdh","di",10)
m(j,"gdl","dm",4)
o(j,"gdj","dk",0)
r(A,"lJ","kL",14)
o(A.c6.prototype,"gdD","T",1)
o(A.d_.prototype,"gd0","bC",0)
m(A.L.prototype,"gbw","e5",22)})();(function inheritance(){var s=hunkHelpers.mixin,r=hunkHelpers.inherit,q=hunkHelpers.inheritMany
r(A.d,null)
q(A.d,[A.hD,J.cH,A.c_,J.bG,A.B,A.aD,A.dI,A.m,A.aW,A.c4,A.bL,A.b6,A.bH,A.dW,A.dC,A.bK,A.cf,A.bh,A.ds,A.at,A.aU,A.bT,A.ez,A.fc,A.ak,A.d3,A.fa,A.cj,A.c5,A.cY,A.cb,A.A,A.a0,A.b1,A.dM,A.c7,A.am,A.j,A.cX,A.ad,A.b7,A.d7,A.cZ,A.cW,A.ax,A.d1,A.a7,A.br,A.aM,A.fm,A.fo,A.fn,A.fk,A.fl,A.fj,A.fg,A.fp,A.ff,A.fe,A.fi,A.fh,A.d8,A.d9,A.bv,A.bw,A.ca,A.bk,A.d4,A.b4,A.aF,A.ay,A.cC,A.cE,A.eX,A.E,A.eD,A.cO,A.c0,A.eE,A.aY,A.J,A.d6,A.dJ,A.bm,A.ap,A.dV,A.aI,A.dN,A.aJ,A.aL,A.bo,A.bp,A.et,A.eo,A.c6,A.d_,A.er,A.a2,A.L,A.ah])
q(J.cH,[J.cJ,J.bO,J.bQ,J.bf,J.bg,J.bP,J.be])
q(J.bQ,[J.aE,J.D,A.aZ,A.bW])
q(J.aE,[J.cP,J.c2,J.as])
r(J.cI,A.c_)
r(J.dp,J.D)
q(J.bP,[J.bN,J.cK])
q(A.B,[A.aS,A.au,A.cM,A.cV,A.cR,A.d2,A.bR,A.cx,A.ab,A.aK,A.cU,A.Z,A.cD])
q(A.aD,[A.cA,A.cB,A.cT,A.fE,A.fG,A.e0,A.e_,A.fs,A.fr,A.f5,A.f7,A.f6,A.dk,A.eO,A.eR,A.dK,A.dR,A.dS,A.dU,A.dT,A.ec,A.dg,A.dh,A.hx,A.fU,A.fR,A.fS,A.fP,A.fQ,A.fO,A.fM,A.fN,A.fV,A.fW,A.fX,A.fZ,A.dv,A.dy,A.dA,A.dw])
q(A.cA,[A.hw,A.dD,A.e1,A.e2,A.f9,A.f8,A.fq,A.e4,A.e5,A.e7,A.e8,A.e6,A.e3,A.dj,A.eF,A.eK,A.eJ,A.eH,A.eG,A.eN,A.eM,A.eL,A.eQ,A.dL,A.f4,A.f3,A.dY,A.ex,A.ew,A.ev,A.eu,A.eZ,A.eC,A.eB,A.eA,A.f2,A.f1,A.fv,A.dO,A.dQ,A.dP,A.eq,A.ep,A.ef,A.ea,A.eg,A.eh,A.ee,A.eb,A.el,A.ej,A.em,A.en,A.fu,A.h2,A.fT,A.h3,A.h4,A.hf,A.ht,A.hj,A.hk,A.hl,A.hm,A.hn,A.ho,A.hp,A.h5,A.h6,A.h7,A.h8,A.h9,A.hs,A.h0,A.h1,A.ha,A.h_,A.hb,A.hc,A.hr,A.fY,A.hd,A.fL,A.fI,A.fK,A.he,A.fJ,A.hg,A.hq,A.hh,A.hi])
q(A.m,[A.bJ,A.a6])
q(A.bJ,[A.a3,A.aT,A.aV,A.bS,A.c9])
q(A.a3,[A.c1,A.bU,A.aX])
r(A.bs,A.b6)
r(A.bt,A.bs)
r(A.bI,A.bH)
r(A.bY,A.au)
q(A.cT,[A.cS,A.bd])
q(A.bh,[A.aR,A.c8])
q(A.cB,[A.fF,A.ft,A.fz,A.dl,A.eP,A.eS,A.dZ,A.ey,A.eT,A.dB,A.eY,A.ed,A.ei,A.ek,A.es,A.hu,A.dz,A.dx])
r(A.bi,A.bW)
r(A.cc,A.bi)
r(A.cd,A.cc)
r(A.bV,A.cd)
r(A.bX,A.bV)
r(A.ck,A.d2)
r(A.aw,A.a0)
r(A.aq,A.aw)
r(A.ci,A.b1)
r(A.a_,A.c7)
q(A.b7,[A.af,A.bu])
r(A.ch,A.ad)
r(A.r,A.ch)
r(A.a8,A.cW)
q(A.ax,[A.S,A.bq])
q(A.bv,[A.d0,A.d5])
r(A.ce,A.bk)
r(A.b3,A.ce)
r(A.cN,A.bR)
r(A.dq,A.cC)
r(A.dr,A.cE)
r(A.eW,A.eX)
q(A.ab,[A.aG,A.cG])
r(A.b0,A.eD)
s(A.cc,A.aF)
s(A.cd,A.bL)
s(A.af,A.cZ)
s(A.bu,A.d7)})()
var v={G:typeof self!="undefined"?self:globalThis,typeUniverse:{eC:new Map(),tR:{},eT:{},tPV:{},sEA:[]},mangledGlobalNames:{l:"int",ct:"double",bD:"num",ae:"String",p:"bool",J:"Null",F:"List",d:"Object",ao:"Map",aj:"JSObject"},mangledNames:{},types:["~()","K<~>()","J()","J(d,Q)","~(d,Q)","~(F<l>)","ad<F<l>>()","p(ah)","~(~())","J(@)","~(d?)","~(d?,d?)","l(ah,ah)","l()","@(@)","E()","p(aL)","p(a2)","p(d)","~(@)","a2()","p(l)","a4(E,~())","l(l,+(l,l))","J(p)","j<@>?()","@(@,ae)","J(d)","~(d[Q?])","K<~>(ae,~())","~([d?])","p(~)","K<~>(a2)","@(ae)","J(~())","l(b0)","k(k?,C?,k,k7?,ao<d?,d?>?)","K<l>()","p(aJ)","~(k,C,k,ae)","aL()","~(l,@)","~(k?,C?,k,d,Q)","0^(k?,C?,k,0^())<d?>","0^(k?,C?,k,0^(1^),1^)<d?,d?>","0^(k?,C?,k,0^(1^,2^),1^,2^)<d?,d?,d?>","0^()(k,C,k,0^())<d?>","0^(1^)(k,C,k,0^(1^))<d?,d?>","0^(1^,2^)(k,C,k,0^(1^,2^))<d?,d?,d?>","A?(k,C,k,d,Q?)","~(k?,C?,k,~())","a4(k,C,k,E,~())","a4(k,C,k,E,~(a4))","J(@,Q)","p(F<l>)"],interceptorsByTag:null,leafTags:null,arrayRti:Symbol("$ti"),rttc:{"2;":(a,b)=>c=>c instanceof A.bt&&a.b(c.a)&&b.b(c.b)}}
A.kB(v.typeUniverse,JSON.parse('{"cP":"aE","c2":"aE","as":"aE","m6":"aZ","cJ":{"p":[],"a5":[]},"bO":{"J":[],"a5":[]},"bQ":{"aj":[]},"aE":{"aj":[]},"D":{"F":["1"],"aj":[],"m":["1"]},"cI":{"c_":[]},"dp":{"D":["1"],"F":["1"],"aj":[],"m":["1"]},"bG":{"U":["1"]},"bP":{"ct":[],"bD":[]},"bN":{"ct":[],"l":[],"bD":[],"a5":[]},"cK":{"ct":[],"bD":[],"a5":[]},"be":{"ae":[],"a5":[]},"aS":{"B":[]},"bJ":{"m":["1"]},"a3":{"m":["1"]},"c1":{"a3":["1"],"m":["1"],"m.E":"1","a3.E":"1"},"aW":{"U":["1"]},"bU":{"a3":["2"],"m":["2"],"m.E":"2","a3.E":"2"},"a6":{"m":["1"],"m.E":"1"},"c4":{"U":["1"]},"bt":{"bs":[],"b6":[]},"bH":{"ao":["1","2"]},"bI":{"bH":["1","2"],"ao":["1","2"]},"bY":{"au":[],"B":[]},"cM":{"B":[]},"cV":{"B":[]},"cf":{"Q":[]},"aD":{"aQ":[]},"cA":{"aQ":[]},"cB":{"aQ":[]},"cT":{"aQ":[]},"cS":{"aQ":[]},"bd":{"aQ":[]},"cR":{"B":[]},"aR":{"bh":["1","2"],"ij":["1","2"],"ao":["1","2"]},"aT":{"m":["1"],"m.E":"1"},"at":{"U":["1"]},"aV":{"m":["1"],"m.E":"1"},"aU":{"U":["1"]},"bS":{"m":["aY<1,2>"],"m.E":"aY<1,2>"},"bT":{"U":["aY<1,2>"]},"bs":{"b6":[]},"aZ":{"aj":[],"a5":[]},"bW":{"aj":[]},"bi":{"cL":["1"],"aj":[]},"bV":{"aF":["l"],"F":["l"],"cL":["l"],"aj":[],"m":["l"],"bL":["l"]},"bX":{"aF":["l"],"F":["l"],"cL":["l"],"aj":[],"m":["l"],"bL":["l"],"a5":[],"aF.E":"l"},"d2":{"B":[]},"ck":{"au":[],"B":[]},"A":{"B":[]},"j":{"K":["1"]},"a0":{"al":["1"],"ag":["1"]},"cj":{"a4":[]},"c5":{"di":["1"]},"aq":{"aw":["1"],"a0":["1"],"al":["1"],"ag":["1"]},"b1":{"b_":["1"],"cg":["1"],"ag":["1"]},"ci":{"b1":["1"],"b_":["1"],"cg":["1"],"ag":["1"]},"c7":{"di":["1"]},"a_":{"c7":["1"],"di":["1"]},"b7":{"b_":["1"],"cg":["1"],"ag":["1"]},"af":{"cZ":["1"],"b7":["1"],"b_":["1"],"cg":["1"],"ag":["1"]},"bu":{"d7":["1"],"b7":["1"],"b_":["1"],"cg":["1"],"ag":["1"]},"r":{"ch":["1"],"ad":["1"]},"aw":{"a0":["1"],"al":["1"],"ag":["1"]},"a8":{"cW":["1"]},"ch":{"ad":["1"]},"S":{"ax":["1"]},"bq":{"ax":["@"]},"d1":{"ax":["@"]},"br":{"al":["1"]},"aM":{"ir":["1"]},"bv":{"k":[]},"d0":{"bv":[],"k":[]},"d5":{"bv":[],"k":[]},"bw":{"C":[]},"aX":{"a3":["1"],"m":["1"],"m.E":"1","a3.E":"1"},"c8":{"bh":["1","2"],"ao":["1","2"]},"c9":{"m":["1"],"m.E":"1"},"ca":{"U":["1"]},"b3":{"bk":["1"],"hK":["1"],"m":["1"]},"b4":{"U":["1"]},"bh":{"ao":["1","2"]},"ay":{"U":["1"]},"bk":{"hK":["1"],"m":["1"]},"ce":{"bk":["1"],"hK":["1"],"m":["1"]},"bR":{"B":[]},"cN":{"B":[]},"l":{"bD":[]},"F":{"m":["1"]},"cx":{"B":[]},"au":{"B":[]},"ab":{"B":[]},"aG":{"B":[]},"cG":{"aG":[],"B":[]},"aK":{"B":[]},"cU":{"aK":[],"B":[]},"Z":{"B":[]},"cD":{"B":[]},"cO":{"B":[]},"c0":{"B":[]},"d6":{"Q":[]},"bm":{"k3":[]},"ah":{"a4":[]},"k6":{"F":["l"],"m":["l"]}}'))
A.kA(v.typeUniverse,JSON.parse('{"bJ":1,"bi":1,"ax":1,"ce":1,"cC":2,"cE":2}'))
var u={g:"Cannot fire new event. Controller is already firing an event",c:"Error handler must accept one Object or one Object and a StackTrace as arguments, and return a value of the returned future's type"}
var t=(function rtii(){var s=A.dd
return{n:s("A"),c:s("a2"),A:s("E"),C:s("B"),a:s("aQ"),B:s("K<~>"),eP:s("K<~>(a2)"),hf:s("m<@>"),D:s("D<a2>"),e:s("D<K<~>>"),gL:s("D<F<l>>"),W:s("D<ae>"),gk:s("D<aJ>"),V:s("D<ah>"),b:s("D<@>"),t:s("D<l>"),T:s("bO"),m:s("aj"),g:s("as"),aU:s("cL<@>"),G:s("aX<bo>"),j:s("F<@>"),L:s("F<l>"),eO:s("ao<@,@>"),eM:s("bU<a2,K<~>>"),P:s("J"),K:s("d"),b8:s("aG"),gT:s("m7"),bQ:s("+()"),R:s("+(l,l)"),l:s("Q"),I:s("b_<F<l>>"),b9:s("ir<F<l>>"),cf:s("al<F<l>>"),v:s("ad<F<l>>"),fN:s("ad<@>"),N:s("ae"),aF:s("a4"),E:s("aJ"),fQ:s("b0"),dm:s("a5"),eK:s("au"),ak:s("c2"),d0:s("aK"),x:s("k"),Y:s("C"),co:s("a_<p>"),dM:s("a_<bp?>"),h:s("a_<~>"),O:s("af<F<l>>"),fT:s("c6"),f:s("bo"),s:s("aL"),k:s("j<p>"),_:s("j<@>"),fJ:s("j<l>"),eo:s("j<bp?>"),U:s("j<~>"),r:s("ah"),fv:s("a8<d?>"),dd:s("aM<F<l>>"),dn:s("ci<~>"),y:s("p"),al:s("p(d)"),i:s("ct"),z:s("@"),J:s("@()"),w:s("@(d)"),Q:s("@(d,Q)"),S:s("l"),eH:s("K<J>?"),an:s("aj?"),X:s("d?"),gO:s("Q?"),dk:s("ae?"),av:s("a4?"),d:s("aJ?"),p:s("k?"),q:s("C?"),gX:s("bo?"),h0:s("bp?"),ev:s("ax<@>?"),F:s("am<@,@>?"),br:s("d4?"),a6:s("p?"),cD:s("ct?"),h6:s("l?"),cg:s("bD?"),Z:s("~()?"),o:s("bD"),H:s("~"),M:s("~()"),du:s("~([~])"),f8:s("~(F<l>)"),u:s("~(d)"),da:s("~(d,Q)"),cB:s("~(a4)"),as:s("~(l,@)")}})();(function constants(){B.N=J.cH.prototype
B.b=J.D.prototype
B.e=J.bN.prototype
B.w=J.bP.prototype
B.k=J.be.prototype
B.O=J.as.prototype
B.P=J.bQ.prototype
B.m=A.bX.prototype
B.x=J.cP.prototype
B.o=J.c2.prototype
B.q=function getTagFallback(o) {
  var s = Object.prototype.toString.call(o);
  return s.substring(8, s.length - 1);
}
B.y=function() {
  var toStringFunction = Object.prototype.toString;
  function getTag(o) {
    var s = toStringFunction.call(o);
    return s.substring(8, s.length - 1);
  }
  function getUnknownTag(object, tag) {
    if (/^HTML[A-Z].*Element$/.test(tag)) {
      var name = toStringFunction.call(object);
      if (name == "[object Object]") return null;
      return "HTMLElement";
    }
  }
  function getUnknownTagGenericBrowser(object, tag) {
    if (object instanceof HTMLElement) return "HTMLElement";
    return getUnknownTag(object, tag);
  }
  function prototypeForTag(tag) {
    if (typeof window == "undefined") return null;
    if (typeof window[tag] == "undefined") return null;
    var constructor = window[tag];
    if (typeof constructor != "function") return null;
    return constructor.prototype;
  }
  function discriminator(tag) { return null; }
  var isBrowser = typeof HTMLElement == "function";
  return {
    getTag: getTag,
    getUnknownTag: isBrowser ? getUnknownTagGenericBrowser : getUnknownTag,
    prototypeForTag: prototypeForTag,
    discriminator: discriminator };
}
B.D=function(getTagFallback) {
  return function(hooks) {
    if (typeof navigator != "object") return hooks;
    var userAgent = navigator.userAgent;
    if (typeof userAgent != "string") return hooks;
    if (userAgent.indexOf("DumpRenderTree") >= 0) return hooks;
    if (userAgent.indexOf("Chrome") >= 0) {
      function confirm(p) {
        return typeof window == "object" && window[p] && window[p].name == p;
      }
      if (confirm("Window") && confirm("HTMLElement")) return hooks;
    }
    hooks.getTag = getTagFallback;
  };
}
B.z=function(hooks) {
  if (typeof dartExperimentalFixupGetTag != "function") return hooks;
  hooks.getTag = dartExperimentalFixupGetTag(hooks.getTag);
}
B.C=function(hooks) {
  if (typeof navigator != "object") return hooks;
  var userAgent = navigator.userAgent;
  if (typeof userAgent != "string") return hooks;
  if (userAgent.indexOf("Firefox") == -1) return hooks;
  var getTag = hooks.getTag;
  var quickMap = {
    "BeforeUnloadEvent": "Event",
    "DataTransfer": "Clipboard",
    "GeoGeolocation": "Geolocation",
    "Location": "!Location",
    "WorkerMessageEvent": "MessageEvent",
    "XMLDocument": "!Document"};
  function getTagFirefox(o) {
    var tag = getTag(o);
    return quickMap[tag] || tag;
  }
  hooks.getTag = getTagFirefox;
}
B.B=function(hooks) {
  if (typeof navigator != "object") return hooks;
  var userAgent = navigator.userAgent;
  if (typeof userAgent != "string") return hooks;
  if (userAgent.indexOf("Trident/") == -1) return hooks;
  var getTag = hooks.getTag;
  var quickMap = {
    "BeforeUnloadEvent": "Event",
    "DataTransfer": "Clipboard",
    "HTMLDDElement": "HTMLElement",
    "HTMLDTElement": "HTMLElement",
    "HTMLPhraseElement": "HTMLElement",
    "Position": "Geoposition"
  };
  function getTagIE(o) {
    var tag = getTag(o);
    var newTag = quickMap[tag];
    if (newTag) return newTag;
    if (tag == "Object") {
      if (window.DataView && (o instanceof window.DataView)) return "DataView";
    }
    return tag;
  }
  function prototypeForTagIE(tag) {
    var constructor = window[tag];
    if (constructor == null) return null;
    return constructor.prototype;
  }
  hooks.getTag = getTagIE;
  hooks.prototypeForTag = prototypeForTagIE;
}
B.A=function(hooks) {
  var getTag = hooks.getTag;
  var prototypeForTag = hooks.prototypeForTag;
  function getTagFixed(o) {
    var tag = getTag(o);
    if (tag == "Document") {
      if (!!o.xmlVersion) return "!Document";
      return "!HTMLDocument";
    }
    return tag;
  }
  function prototypeForTagFixed(tag) {
    if (tag == "Document") return null;
    return prototypeForTag(tag);
  }
  hooks.getTag = getTagFixed;
  hooks.prototypeForTag = prototypeForTagFixed;
}
B.r=function(hooks) { return hooks; }

B.t=new A.dq()
B.E=new A.cO()
B.j=new A.dI()
B.f=new A.aI()
B.n=new A.d1()
B.c=new A.d5()
B.l=new A.d6()
B.F=new A.fe()
B.a=new A.E(0)
B.u=new A.E(1000)
B.v=new A.E(1e5)
B.G=new A.E(2e6)
B.H=new A.E(249e3)
B.I=new A.E(25e4)
B.J=new A.E(36e8)
B.K=new A.E(4e5)
B.L=new A.E(8e6)
B.M=new A.E(999e3)
B.Q=new A.dr(null)
B.d=new A.b0(0,"upload")
B.h=new A.b0(1,"download")
B.i=new A.ap(0,0)
B.T=new A.ap(1099511627776,0)
B.U=new A.ap(10,0)
B.V=new A.ap(10,2)
B.W=new A.ap(1,0)
B.X=A.i4("m1")
B.Y=A.i4("d")
B.Z=A.i4("k6")
B.a_=new A.ff(B.c,A.lw())
B.a0=new A.fg(B.c,A.lx())
B.a1=new A.fh(B.c,A.ly())
B.a2=new A.d8(B.c,A.lz())
B.a3=new A.fi(B.c,A.lA())
B.a4=new A.fj(B.c,A.lB())
B.a5=new A.fk(B.c,A.lC())
B.a6=new A.fl(B.c,A.lD())
B.a7=new A.fn(B.c,A.lF())
B.a8=new A.fo(B.c,A.lG())
B.a9=new A.fm(B.c,A.lE())
B.aa=new A.fp(B.c,A.lH())
B.S={}
B.R=new A.bI(B.S,[],A.dd("bI<d?,d?>"))
B.p=new A.d9(B.c,B.R)})();(function staticFields(){$.eV=null
$.aa=A.h([],A.dd("D<d>"))
$.la=null
$.im=null
$.dE=0
$.hI=A.l5()
$.ic=null
$.ib=null
$.jb=null
$.j4=null
$.jg=null
$.fB=null
$.fH=null
$.i1=null
$.f_=A.h([],A.dd("D<F<d>?>"))
$.by=null
$.cp=null
$.cq=null
$.hW=!1
$.i=B.c
$.f0=null})();(function lazyInitializers(){var s=hunkHelpers.lazyFinal
s($,"m3","jl",()=>A.fC("_$dart_dartClosure"))
s($,"m2","jk",()=>A.fC("_$dart_dartClosure_dartJSInterop"))
s($,"mr","jy",()=>B.c.M(new A.hw(),t.B))
s($,"mo","jx",()=>A.h([new J.cI()],A.dd("D<c_>")))
s($,"ma","jn",()=>A.av(A.dX({
toString:function(){return"$receiver$"}})))
s($,"mb","jo",()=>A.av(A.dX({$method$:null,
toString:function(){return"$receiver$"}})))
s($,"mc","jp",()=>A.av(A.dX(null)))
s($,"md","jq",()=>A.av(function(){var $argumentsExpr$="$arguments$"
try{null.$method$($argumentsExpr$)}catch(r){return r.message}}()))
s($,"mg","jt",()=>A.av(A.dX(void 0)))
s($,"mh","ju",()=>A.av(function(){var $argumentsExpr$="$arguments$"
try{(void 0).$method$($argumentsExpr$)}catch(r){return r.message}}()))
s($,"mf","js",()=>A.av(A.iu(null)))
s($,"me","jr",()=>A.av(function(){try{null.$method$}catch(r){return r.message}}()))
s($,"mj","jw",()=>A.av(A.iu(void 0)))
s($,"mi","jv",()=>A.av(function(){try{(void 0).$method$}catch(r){return r.message}}()))
s($,"mk","i6",()=>A.k9())
s($,"m5","bc",()=>$.jy())
s($,"m4","jm",()=>A.kh(!1,B.c,t.y))
s($,"mn","hz",()=>A.jc(B.Y))
s($,"m8","i5",()=>{A.k1()
return $.dE})
s($,"mm","bE",()=>new A.d())})();(function nativeSupport(){!function(){var s=function(a){var m={}
m[a]=1
return Object.keys(hunkHelpers.convertToFastObject(m))[0]}
v.getIsolateTag=function(a){return s("___dart_"+a+v.isolateTag)}
var r="___dart_isolate_tags_"
var q=Object[r]||(Object[r]=Object.create(null))
var p="_ZxYxX"
for(var o=0;;o++){var n=s(p+"_"+o+"_")
if(!(n in q)){q[n]=1
v.isolateTag=n
break}}v.dispatchPropertyName=v.getIsolateTag("dispatch_record")}()
hunkHelpers.setOrUpdateInterceptorsByTag({ArrayBuffer:A.aZ,SharedArrayBuffer:A.aZ,ArrayBufferView:A.bW,Uint8Array:A.bX})
hunkHelpers.setOrUpdateLeafTags({ArrayBuffer:true,SharedArrayBuffer:true,ArrayBufferView:false,Uint8Array:false})
A.bi.$nativeSuperclassTag="ArrayBufferView"
A.cc.$nativeSuperclassTag="ArrayBufferView"
A.cd.$nativeSuperclassTag="ArrayBufferView"
A.bV.$nativeSuperclassTag="ArrayBufferView"})()
Function.prototype.$2=function(a,b){return this(a,b)}
Function.prototype.$0=function(){return this()}
Function.prototype.$1=function(a){return this(a)}
Function.prototype.$3$1=function(a){return this(a)}
Function.prototype.$2$1=function(a){return this(a)}
Function.prototype.$1$1=function(a){return this(a)}
Function.prototype.$3=function(a,b,c){return this(a,b,c)}
Function.prototype.$4=function(a,b,c,d){return this(a,b,c,d)}
Function.prototype.$3$3=function(a,b,c){return this(a,b,c)}
Function.prototype.$2$2=function(a,b){return this(a,b)}
Function.prototype.$1$2=function(a,b){return this(a,b)}
Function.prototype.$2$3=function(a,b,c){return this(a,b,c)}
Function.prototype.$5=function(a,b,c,d,e){return this(a,b,c,d,e)}
Function.prototype.$3$4=function(a,b,c,d){return this(a,b,c,d)}
Function.prototype.$2$4=function(a,b,c,d){return this(a,b,c,d)}
Function.prototype.$1$4=function(a,b,c,d){return this(a,b,c,d)}
Function.prototype.$3$6=function(a,b,c,d,e,f){return this(a,b,c,d,e,f)}
Function.prototype.$2$5=function(a,b,c,d,e){return this(a,b,c,d,e)}
convertAllToFastObject(w)
convertToFastObject($);(function(a){if(typeof document==="undefined"){a(null)
return}if(typeof document.currentScript!="undefined"){a(document.currentScript)
return}var s=document.scripts
function onLoad(b){for(var q=0;q<s.length;++q){s[q].removeEventListener("load",onLoad,false)}a(b.target)}for(var r=0;r<s.length;++r){s[r].addEventListener("load",onLoad,false)}})(function(a){v.currentScript=a
var s=A.H
if(typeof dartMainRunner==="function"){dartMainRunner(s,[])}else{s([])}})})()
//# sourceMappingURL=allocator.js.map
