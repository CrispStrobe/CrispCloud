from pathlib import Path
import json,hashlib,shutil,gzip
r=Path(__file__).resolve().parent
summary=json.loads((r/'receipts/resolution-summary.json').read_text())
assert len(summary['steps'])==5 and all(s['returncode']==0 and s['receipt']['resolution_success'] for s in summary['steps'])
for s in summary['steps']:
 d=s['receipt'];assert d['pubspec_unchanged']
 if d['lock_enforcement']:assert d['lock_unchanged']
 else:assert d['before_inputs']['pubspec.lock'].get('missing',False)
out=r.parent/'qualification-setup/dependencies';out.mkdir(exist_ok=False)
shutil.copytree(r/'receipts/resolution',out/'resolution')
for f in ['resolution-summary.json','archive-cleanup.json']:shutil.copyfile(r/'receipts'/f,out/f)
for d in ['cargo-prefetch','ebook-cargo-prefetch']:shutil.copytree(r/'receipts'/d,out/d)
for f in ['resolution-runner.py','resolve_dependencies.py','prefetch_cargo.py','prefetch_ebook_cargo.py','collect_resolution.py']:shutil.copyfile(r/f,out/f)
lines=['# Local dependency setup receipts','', 'All five app graphs resolved with their existing dependency declarations unchanged. App and CLI use `--enforce-lockfile` and retain committed lockfiles byte-for-byte. The engine, editor and parser had no package-local development locks; normal resolution created them and recorded exact before/after lock/config/graph inputs.','', '| Graph | Elapsed seconds | Pubspec unchanged | Existing lock preserved |','| --- | ---: | --- | --- |']
for s in summary['steps']:
 d=s['receipt'];lines.append('| '+s['name']+' | '+str(round(d['elapsed_seconds'],2))+' | Yes | '+('Yes' if d['lock_enforcement'] else 'New development lock')+' |')
lines += ['', 'The app source and Git head changed concurrently during this explicitly setup-only stage. These receipts do not qualify those source edits. Each receipt retains source heads at start and finish; final acceptance must run after source and all resolution inputs are settled.', '', 'Locked Cargo prefetch also succeeded for the catalog crate and the exact pinned crisperbooks ebook-conversion crate. Their Cargo manifests and locks stayed unchanged; no native build or runtime acceptance is claimed by prefetch.', '', 'The official toolchain archives were removed only after verification, installation, Linux precache and native probes succeeded. This reclaimed about 1.80 GB while retaining installed tools, exact download identities and all setup receipts.', '', 'No native hooks were disabled, no app dependency declaration was changed, and no GitHub Actions run was awaited or restarted.']
(out/'README.md').write_text('\n'.join(lines)+'\n')
(out/'artifacts-sha256.json').write_text(json.dumps({str(p.relative_to(out)):{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file() and p!=out/'artifacts-sha256.json'},indent=2)+'\n')
print(out)
print(json.dumps({s['name']:{'seconds':round(s['receipt']['elapsed_seconds'],1),'success':True} for s in summary['steps']},indent=2))
