from pathlib import Path
import subprocess,json,hashlib,gzip,time,datetime
r=Path(__file__).resolve().parent;repo=r.parent/'CrispCloud'
p=repo/'packages/crisp_catalog/native'
out=r/'receipts/cargo-prefetch';out.mkdir(exist_ok=False)
def snapshot(phase):
 d={}
 for f in ['Cargo.toml','Cargo.lock','vendor/crispcat-format/Cargo.toml']:
  b=(p/f).read_bytes();d[f]={'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}
  dst=out/phase/(f+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(b,mtime=0))
 return d
before=snapshot('before');cmd=['cargo','fetch','--locked','--manifest-path',str(p/'Cargo.toml')];start=time.time()
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 result=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=600)
after=snapshot('after')
receipt={'scope':'Setup-only Cargo dependency prefetch, not native build or app qualification.','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'returncode':result.returncode,'elapsed_seconds':time.time()-start,'before':before,'after':after,'inputs_unchanged':before==after}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
assert result.returncode==0 and before==after
