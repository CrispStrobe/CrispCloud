# Local qualification toolchain — 2026-11-15

Source `/workspace/scratch/0b93849cdeb9/toolchains/env.sh` before running local gates. It sets workspace-only caches, temporary files, native loader paths and genuine native compiler launchers. The launchers restore these settings when a native hook launches a compiler with only PATH inherited.

Pinned Flutter 3.47.8 / Dart 3.13.7 matches `.fvmrc` and prior qualification. The official Flutter archive SHA-256 and each downloaded Debian package SHA-256 were verified. Rust 1.100.0 was installed through official rustup with its component verification; official channel metadata and package hashes are recorded separately.

Flutter bundled preload-cache initialization and Linux precache completed. The Flutter test runner resolves its dynamic libraries. Real C++ and Rust compile/link/run probes passed with the full environment and with PATH alone. No native hook was disabled. These are setup receipts, not project acceptance receipts.

The verified large download payloads were removed after successful installation and probes. Exact public download identities remain in `flutter-release.json`, `native-packages.json`, and `rust-packages.json`. Installed toolchains remain available.
