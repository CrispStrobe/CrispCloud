#!/usr/bin/env python3
"""Fetch exact native hook dependencies into Cargo's cache; do not build."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

base = Path('/workspace/scratch/0b93849cdeb9')
out = base / 'setup-notes/native-dependencies'
out.mkdir(exist_ok=True)
manifests = {
    'catalogue': base / 'CrispCloud/packages/crisp_catalog/native/Cargo.toml',
    'ebook': base / 'toolchains/pub-cache/git/crisperbooks-505d3d7bfb922e5f0d77b7230cd38b0e266d0606/packages/crisp_ebook_conversion/native/Cargo.toml',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

for name, manifest in manifests.items():
    lock = manifest.with_name('Cargo.lock')
    before = {str(p): digest(p) for p in (manifest, lock)}
    command = ['cargo', 'fetch', '--locked', '--target', 'x86_64-unknown-linux-gnu', '--manifest-path', str(manifest)]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    with (out / (name + '.stdout.log')).open('w') as stdout, (out / (name + '.stderr.log')).open('w') as stderr:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=900)
    after = {str(p): digest(p) for p in (manifest, lock)}
    receipt = {'scope': 'Native dependency prefetch only; no build or runtime acceptance.', 'started_at': started, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - tick, 'command': command, 'returncode': result.returncode, 'before': before, 'after': after, 'inputs_unchanged': before == after}
    (out / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'name': name, 'returncode': result.returncode, 'inputs_unchanged': before == after}), flush=True)
    if result.returncode or before != after:
        raise SystemExit(1)
