#!/usr/bin/env python3
"""Summarize recorded dependency setup without treating it as test evidence."""
import datetime
import json
from pathlib import Path

root = Path(__file__).resolve().parent
rows = []
for path in sorted((root / 'dependencies').glob('*/receipt.json')):
    data = json.loads(path.read_text())
    rows.append({
        'attempt': path.parent.name,
        'receipt': str(path.relative_to(root)),
        'cwd': data['cwd'],
        'status': data['status'],
        'returncode': data.get('returncode'),
        'resolution_success': data.get('resolution_success'),
        'pubspec_unchanged': data.get('pubspec_unchanged'),
        'lock_unchanged': data.get('lock_unchanged'),
        'lock_enforcement': data['lock_enforcement'],
        'source_head_at_start': data['source_head_at_start'],
        'source_head_at_end': data.get('source_head_at_end'),
    })
summary = {
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Dependency setup only; not runtime qualification.',
    'attempts': rows,
}
(root / 'dependency-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
