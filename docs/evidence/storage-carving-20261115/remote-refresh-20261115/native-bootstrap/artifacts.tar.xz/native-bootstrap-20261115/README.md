# Native bootstrap — 2026-11-15

The source-bound recorder ran `test/native_file_primitives_test.dart` with the genuine default native hooks enabled on saved CrispCloud commit `41885d7d1d67348f5abe3579b99d9d2951fc909f`. The requested single suite passed all 3 tests, with no skips, failures or errors. Command exit was zero, and all recorded source, resolution inputs and tool identities were unchanged.

This qualifies the recorded native bootstrap command only. It is not the full Office/application regression gate. Before the command there were no native shared-library assets in the checkout. `assets/native-assets.json` records the resulting ELF asset identities, hook input/output receipts, and readelf inspections. These supplementary receipts have their own `assets/artifacts-sha256.json` manifest.

An earlier launcher-path typo prevented execution entirely (exit 127, zero tests); that unchanged-source launch failure is preserved separately in `native-bootstrap-20261115-launch-failure`. The successful gate uses the corrected absolute launcher path.
