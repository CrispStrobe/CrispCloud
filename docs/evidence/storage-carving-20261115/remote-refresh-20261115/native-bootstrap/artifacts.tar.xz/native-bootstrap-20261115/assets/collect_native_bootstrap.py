#!/usr/bin/env python3
"""Inspect native assets after a completed source-bound bootstrap gate."""
import datetime
import hashlib
import json
import shutil
import struct
import subprocess
from pathlib import Path

base = Path('/workspace/scratch/0b93849cdeb9')
repo = base / 'CrispCloud'
gate = base / 'native-bootstrap-20261115'
metadata = json.loads((gate / 'metadata.json').read_text())
if 'finished_at' not in metadata:
    raise SystemExit('Recorder is still running')
out = gate / 'assets'
out.mkdir(exist_ok=False)

def digest(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()

def identity(path):
    data = path.read_bytes()[:64]
    row = {'path': str(path.relative_to(repo)), 'size': path.stat().st_size,
           'sha256': digest(path), 'elf': data[:4] == b'\x7fELF'}
    if row['elf']:
        order = '<' if data[5] == 1 else '>'
        row.update({'elf_class_bits': {1: 32, 2: 64}.get(data[4]),
                    'elf_byte_order': 'little' if data[5] == 1 else 'big',
                    'elf_type': struct.unpack_from(order + 'H', data, 16)[0],
                    'elf_machine': struct.unpack_from(order + 'H', data, 18)[0]})
    return row

runtime = []
hooks = []
for output in sorted((repo / '.dart_tool/hooks_runner').glob('*/*/output.json')):
    value = json.loads(output.read_text())
    parts = output.relative_to(repo / '.dart_tool/hooks_runner').parts
    hook = {'package': parts[0], 'configuration': parts[1],
            'status': value.get('status'), 'asset_count': len(value.get('assets', []))}
    target = out / 'hooks' / parts[0] / parts[1]
    target.mkdir(parents=True)
    for name in ('input.json', 'output.json', 'stdout.txt', 'stderr.txt'):
        source = output.with_name(name)
        if source.exists():
            shutil.copyfile(source, target / name)
    hooks.append(hook)
    for asset in value.get('assets', []):
        encoding = asset.get('encoding', {})
        path = Path(encoding.get('file', ''))
        if path.is_file():
            row = identity(path)
            row.update({'id': encoding.get('id'), 'asset_type': asset.get('type'),
                        'link_mode': encoding.get('link_mode'), 'hook': hook})
            if row['elf']:
                result = subprocess.run(['readelf', '-h', '-n', str(path)],
                                        capture_output=True, text=True)
                name = parts[0] + '-' + path.name + '.readelf.txt'
                (out / name).write_text(result.stdout + result.stderr)
                row['readelf_exit_code'] = result.returncode
                row['readelf_receipt'] = name
            runtime.append(row)

native_files = []
for prefix in ('.dart_tool', 'build'):
    root = repo / prefix
    if not root.exists():
        continue
    for path in sorted(root.rglob('*')):
        if path.is_file() and path.suffix in ('.so', '.dylib', '.dll'):
            native_files.append(identity(path))

before_path = base / 'setup-notes/native-bootstrap-before-assets.json'
before = json.loads(before_path.read_text())
shutil.copyfile(before_path, out / 'native-assets-before.json')
receipt = {
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Native hook output inspection after the recorded bootstrap command; not additional runtime tests.',
    'source_head': metadata['after_git']['head'],
    'gate_qualification_success': metadata['qualification_success'],
    'gate_inputs_and_commit_stable': metadata['inputs_and_commit_stable'],
    'native_files_before': len(before),
    'native_files_after': len(native_files),
    'hooks': hooks,
    'runtime_assets': runtime,
    'all_generated_shared_libraries': native_files,
}
(out / 'native-assets.json').write_text(json.dumps(receipt, indent=2) + '\n')
shutil.copyfile(Path(__file__), out / 'collect_native_bootstrap.py')
manifest = {str(p.relative_to(out)): {'size': p.stat().st_size, 'sha256': digest(p)}
            for p in sorted(out.rglob('*')) if p.is_file()}
(out / 'artifacts-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'gate_success': receipt['gate_qualification_success'],
                  'source_stable': receipt['gate_inputs_and_commit_stable'],
                  'native_files_before': len(before), 'native_files_after': len(native_files),
                  'runtime_assets': [{'id': row['id'], 'size': row['size'],
                                      'sha256': row['sha256'], 'elf': row['elf']}
                                     for row in runtime]}, indent=2))
