#!/usr/bin/env python3
"""Snapshot source, tools, fixtures and resolved config around final acceptance."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
app = root.parents[1]
audit = json.loads((app / 'docs/evidence/word-continuation-0c3e596/source-audit.json').read_text())
paths = {
    'pubspec.yaml', 'pubspec.lock', 'docs/crypto-inventory.json',
    'docs/apple-export-policy.json', 'ios/Runner/Info.plist',
    'macos/Runner/Info.plist', 'packages/legacy_doc_parser/UPSTREAM.json',
    'tool/office_fidelity_manifest.json', 'tool/sync_legacy_doc_parser.py',
    'tool/sync_office_fidelity.py', 'tool/verify_office_fidelity.py',
    'tool/verify_ebook_sources.py', 'tool/crypto_release_evidence.py',
    'tool/apple_export_preflight.py', 'tool/verify_legacy_word_structured.dart',
    'tool/verify_portable_office_web.py',
    'test/fixtures/word_native/formatting.doc',
    'test/fixtures/legacy_powerpoint/current-slides.ppt.gz',
    'docs/evidence/word-continuation-7308125/run_word_cohort.py',
    'docs/evidence/word-continuation-0c3e596/source-audit.json',
}
paths.update(item['path'] for item in audit['reviewedSourceChanges'])
paths.update(str(p.relative_to(app)) for p in (app / 'tool').glob('test_sync_*.py'))
paths.update('tool/' + n for n in ('test_verify_ebook_sources.py',
                                  'test_crypto_release_evidence.py',
                                  'test_apple_export_preflight.py'))
def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=app, text=True).strip()
snapshot = {'commit': git('rev-parse', 'HEAD'),
            'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain'),
            'files': {p: identity(app / p) for p in sorted(paths)},
            'productionPackageConfiguration': identity(app / '.dart_tool/package_config.json')}
(root / ('acceptance-inputs-' + sys.argv[1] + '.json')).write_text(
    json.dumps(snapshot, indent=2, sort_keys=True) + '\n')
print(json.dumps({'commit': snapshot['commit'], 'tree': snapshot['tree'],
                  'status': snapshot['status'], 'capturedSourceInputs': len(paths)}))
