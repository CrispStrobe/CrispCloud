#!/usr/bin/env python3
"""Capture one exact-remote acceptance command without changing its assertions."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
app = root.parents[1]
name, *command = sys.argv[1:]
started = datetime.now(timezone.utc).isoformat()
environment = dict(os.environ)
environment.update({
    'TMPDIR': '/workspace/scratch/b8f8221a5e6e/tmp',
    'PUB_CACHE': '/home/agent/.codex/skills/remote-skills/office-recovery-0905ba96fd2d/pub-cache',
    'FLUTTER_ROOT': '/home/agent/.codex/skills/remote-skills/office-recovery-0905ba96fd2d/flutter-3.47.8',
    'DART_SUPPRESS_ANALYTICS': 'true',
})
stdout_path = root / ('native.json' if name == 'native' else name + '.log')
with stdout_path.open('wb') as output:
    if name == 'native':
        with (root / 'native.stderr.log').open('wb') as errors:
            result = subprocess.run(command, cwd=app, env=environment,
                                    stdout=output, stderr=errors)
    else:
        result = subprocess.run(command, cwd=app, env=environment,
                                stdout=output, stderr=subprocess.STDOUT)
record = {'name': name, 'command': command, 'cwd': str(app),
          'startedUtc': started,
          'finishedUtc': datetime.now(timezone.utc).isoformat(),
          'exitCode': result.returncode,
          'appCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                                              cwd=app, text=True).strip()}
(root / (name + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(result.returncode)
