#!/usr/bin/env python3
"""Package exact-remote acceptance records without relabeling earlier runs."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

run = Path(__file__).resolve().parent
app = run.parents[1]
destination = app / 'docs/evidence/word-continuation-0c3e596'
cohort = app.parent / 'app-word-cohort-0c3e596'
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def load(path):
    return json.loads(path.read_text())

before = load(run / 'acceptance-inputs-before.json')
after = load(run / 'acceptance-inputs-after.json')
assert before == after and before['status'] == ''
summary = load(cohort / 'results/summary.json')
inputs = load(cohort / 'results/inputs-before.json')
assert summary['success'] and summary['testCount'] == 107
assert inputs['appCommit'] == before['commit']
audit = load(destination / 'source-audit.json')
commands = sorted((load(p) for p in run.glob('*.command.json')),
                  key=lambda item: (item['startedUtc'], item['name']))
assert commands and all(item['exitCode'] == 0 and item['appCommit'] == before['commit']
                        for item in commands)
(run / 'acceptance-commands.json').write_text(json.dumps(commands, indent=2) + '\n')

records = {f'cohort-{p.name}': p for p in (cohort / 'results').iterdir() if p.is_file()}
for name in ('pubspec.yaml', 'pubspec.lock', 'pub-get.log', 'word_cohort.py'):
    records['cohort-' + name] = cohort / name
records['cohort-package_config.json'] = cohort / '.dart_tool/package_config.json'
records['production-package_config.json'] = app / '.dart_tool/package_config.json'
for name in (
        'sync-plan.json', 'sync-applied.json', 'cohort-console.log',
        'native.json', 'native.stderr.log', 'portable-web.log',
        'portable-web-initial-attempt.json', 'portable-web-initial-attempt.log',
        'app-pub-get.log', 'source-verification-exact.log',
        'sync-controls-exact.log', 'crypto-evidence-controls-exact.log',
        'apple-preflight-controls-exact.log', 'ebook-source-controls-exact.log',
        'release-input-check-exact.log', 'ebook-source-verification-exact.log',
        'acceptance-inputs-before.json', 'acceptance-inputs-after.json',
        'acceptance-commands.json', 'policy-before.json', 'policy-after.json',
        'inventory-before.json', 'inventory-after.json'):
    records[name] = run / name
records['acceptance-runner.py'] = run / 'run_gate.py'
records['acceptance-input-capture.py'] = run / 'capture_inputs.py'
records['receipt-builder.py'] = Path(__file__)
artifacts = {}
for name, path in sorted(records.items()):
    raw = path.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    (destination / (name + '.gz')).write_bytes(packed)
    artifacts[name + '.gz'] = {'originalName': name, 'bytes': len(raw),
                              'sha256': digest(raw), 'compressedBytes': len(packed),
                              'compressedSha256': digest(packed)}
shutil.copyfile(run / 'verify_evidence.py', destination / 'verify_evidence.py')
cohort_fields = ('testCount', 'success', 'suites', 'executedSuiteCount',
                 'cohortCompleteWithoutSkips', 'sourceAndDependenciesUnchanged',
                 'excludedSuites', 'startedUtc', 'finishedUtc')
receipt = {
    'version': 2,
    'recordedUtc': datetime.now(timezone.utc).isoformat(),
    'measuredRemoteAppCommit': before['commit'],
    'measuredAppTree': before['tree'],
    'measuredWorktreeStatus': '',
    'sourcePublication': {
        'localCommit': '1f8ae72b8a6537d7634cf06d26d363a92c74e828',
        'remoteCommit': before['commit'],
        'tree': before['tree'],
        'note': 'Source was published through GitHub Git Data API, then the clean checkout was aligned to the exact remote commit before these acceptance commands.'},
    'parser': {'repository': 'CrispStrobe/legacy-doc-parser',
               'commit': audit['parserCommit'], 'tree': audit['parserTree']},
    'qudsCommit': audit['qudsCommit'],
    'officeFileCount': audit['officeFileCount'],
    'parserFileCount': audit['parserFileCount'],
    'unchangedNonParserFileCount': audit['unchangedNonParserOfficeFileCount'],
    'sourceAuditSha256': digest((destination / 'source-audit.json').read_bytes()),
    'dartVersion': inputs['dartVersion'],
    'dartExecutableSha256': inputs['dartExecutableSha256'],
    'capturedInputCount': inputs['fileCount'],
    'cohort': {key: summary[key] for key in cohort_fields},
    'nativeChecks': load(run / 'native.json'),
    'productionPackageCount': len(load(app / '.dart_tool/package_config.json')['packages']),
    'productionDependencyResolution': {
        'offline': True, 'enforcedLockfile': True,
        'lockfileSha256': audit['after']['pubspecLockSha256'],
        'note': 'Existing direct Dart binary with the installed FLUTTER_ROOT; no Flutter shell launcher, native hooks, manifest override or lockfile change.'},
    'portableSmoke': {
        'passed': True, 'formats': ['DOC', 'RTF', 'PPT', 'MSG'],
        'tool': 'tool/verify_portable_office_web.py',
        'packageConfiguration': 'production-package_config.json.gz',
        'note': 'Ran the unchanged production command with the genuine app package configuration and real fixtures; generated temporary Dart and JavaScript are deleted by the existing tool. The Unicode assertion covers logical text, not native glyph rendering.',
        'environmentCorrection': 'An initial command specified an absent /usr/bin/node path. Compilation completed, then process creation failed. The retained retry uses the tool\'s own discovered Node executable without changing source or assertions.'},
    'initialAttempts': [load(run / 'portable-web-initial-attempt.json')],
    'sourceControls': {
        'guardedSync': {'passed': 24, 'skipped': 0},
        'appleExportPreflight': {'passed': 38, 'skipped': 0},
        'cryptoReleaseEvidence': {'passed': 40, 'skipped': 2,
                                  'skipReason': "Requires Apple's actual /usr/bin/plutil on macOS."},
        'ebookSources': {'passed': 22, 'skipped': 0}},
    'releaseInputCheck': {'passed': True, 'scope': 'Source/input consistency, not a release build or distribution decision.'},
    'ebookSourceCheck': {'passed': True, 'fileCount': 279,
                         'commit': '32b00f43b6e5112f0b4168a09ff2dcba4c4e0a52'},
    'extraInputHashes': before['files'],
    'acceptanceCommands': commands,
    'artifacts': artifacts,
    'verificationHelperSha256': digest((destination / 'verify_evidence.py').read_bytes()),
    'limitations': [
        'Data-only adapter replaces the flutter_test import in copied suites; Flutter widgets, full application builds and native ebook hooks were not executed.',
        'An earlier routine Flutter version probe was rejected by automatic review because it unexpectedly targeted 169.254.169.254. That launcher was not retried; final checks use the existing direct Dart binary.',
        'Native acceptance checks one authored fixture with LibreOffice/Poppler, retains partialFormatting, does not establish Microsoft Word or exact pagination, and deletes its temporary PDF by existing tool design.',
        'The 13 fake-process installed-converter tests in the cohort are separate from the 13 actual native checks.',
        'The portable Unicode assertion verifies logical text only; the app native check does not assert glyph counts, exact page rasters or arbitrary font fallback.',
        'The source audit refreshes only reviewed runtime membership and two technical fingerprints. Classification/distribution decisions, dates, references, source plist declarations and lockfile identity remain unchanged.',
        'These development checkpoints do not qualify release evidence or claim universal editing or layout fidelity.'
    ]}
(destination / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'commit': before['commit'], 'recordCount': len(artifacts),
                  'inputCount': inputs['fileCount'], 'commands': len(commands)}, indent=2))
