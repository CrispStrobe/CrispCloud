#!/usr/bin/env python3
"""Capture scoped acceptance on the exact published app runtime."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'CrispCloud-final-next'
OUT = ROOT / 'app-acceptance-86d5a218'
DART = ROOT / 'toolchains/dart-3.13.7/dart-sdk/bin/dart'
COHORT = ROOT / 'app-word-cohort-86d5a218'
EXPECTED = '86d5a218853d8441afe8bc28f19cfe0adf4cd71e'
ENV = dict(os.environ, DART_SUPPRESS_ANALYTICS='true',
           PUB_CACHE=str(ROOT / 'toolchains/pub-cache'),
           FLUTTER_ROOT=str(ROOT / 'toolchains/flutter'),
           TMPDIR=str(ROOT / 'tmp'))


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(*args):
    return subprocess.check_output(['git', '-C', str(APP), *args], text=True).strip()


def run(name, argv, timeout=600):
    record = {'name': name, 'argv': [str(x) for x in argv], 'cwd': str(APP),
              'sourceCommit': git('rev-parse', 'HEAD'),
              'startedUtc': datetime.now(timezone.utc).isoformat()}
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(record['argv'], cwd=APP, env=ENV,
                                stdout=stdout, stderr=stderr, timeout=timeout)
    record.update(finishedUtc=datetime.now(timezone.utc).isoformat(), exitCode=result.returncode)
    write(name + '.command.json', record)
    print(name, result.returncode, flush=True)
    return record


def snapshot():
    names = subprocess.check_output(['git', '-C', str(APP), 'ls-files', '-z']).decode().split('\0')
    paths = [name for name in names if name]
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain'),
            'files': {name: {'sha256': sha(APP / name), 'bytes': (APP / name).stat().st_size}
                      for name in sorted(paths)},
            'productionPackageConfigSha256': sha(APP / '.dart_tool/package_config.json')}


assert git('rev-parse', 'HEAD') == EXPECTED
assert git('status', '--porcelain') == ''
OUT.mkdir(exist_ok=False)
shutil.copy2(__file__, OUT / 'run_app_final_acceptance.py')
inputs = ['pubspec.yaml', 'pubspec.lock', '.fvmrc']
before_resolution = {name: sha(APP / name) for name in inputs}
resolved = run('production-offline-resolution', [DART, 'pub', 'get', '--offline', '--enforce-lockfile'])
assert resolved['exitCode'] == 0
assert before_resolution == {name: sha(APP / name) for name in inputs}
write('resolution-inputs.json', before_resolution)
before = snapshot()
assert before['status'] == ''
write('source-before.json', before)
for name in ('pubspec.yaml', 'pubspec.lock', '.dart_tool/package_config.json'):
    shutil.copy2(APP / name, OUT / ('production-' + Path(name).name))

jobs = [
    ('cohort', ['python', 'docs/evidence/word-continuation-7308125/run_word_cohort.py',
                '--app', APP, '--workspace', COHORT, '--dart', DART,
                '--pub-cache', ROOT / 'toolchains/pub-cache']),
    ('portable-web', ['python', 'tool/verify_portable_office_web.py', '--dart', DART]),
    ('native', [DART, '--packages=' + str(APP / '.dart_tool/package_config.json'),
                'tool/verify_legacy_word_structured.dart', shutil.which('soffice')]),
    ('sync-controls', ['python', '-m', 'unittest', 'discover', '-s', 'tool', '-p', 'test_sync_*.py', '-v']),
    ('apple-preflight-controls', ['python', '-m', 'unittest', 'discover', '-s', 'tool', '-p', 'test_apple_export_preflight.py', '-v']),
    ('crypto-evidence-controls', ['python', '-m', 'unittest', 'discover', '-s', 'tool', '-p', 'test_crypto_release_evidence.py', '-v']),
    ('ebook-source-controls', ['python', '-m', 'unittest', 'discover', '-s', 'tool', '-p', 'test_verify_ebook_sources.py', '-v']),
    ('office-source-verification', ['python', 'tool/verify_office_fidelity.py', '--legacy-source', ROOT / 'legacy-doc-parser', '--require-tracked']),
    ('ebook-source-verification', ['python', 'tool/verify_ebook_sources.py']),
    ('release-input-check', ['python', 'tool/crypto_release_evidence.py', '--check']),
]
with ThreadPoolExecutor(max_workers=4) as pool:
    records = list(pool.map(lambda job: run(*job), jobs))
after = snapshot()
write('source-after.json', after)
success = all(record['exitCode'] == 0 for record in records) and before == after
write('summary.json', {'sourceCommit': EXPECTED, 'sourceTree': before['tree'],
                      'sourceFileCount': len(before['files']), 'trackedInputsUnchanged': before == after,
                      'commands': records, 'success': success})
print(json.dumps({'success': success, 'sourceCommit': EXPECTED,
                  'sourceFileCount': len(before['files']), 'trackedInputsUnchanged': before == after}), flush=True)
raise SystemExit(0 if success else 1)
