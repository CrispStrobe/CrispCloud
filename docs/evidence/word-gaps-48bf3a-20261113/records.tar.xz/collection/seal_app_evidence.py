#!/usr/bin/env python3
"""Seal the recorded app execution; do not rerun or relabel earlier probes."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'CrispCloud'
OUT = APP / 'docs/evidence/word-gaps-48bf3a-20261113'
RUNTIME = '0233ed8e9501538a9e68051b58a048407b2e29d0'
PARSER = '48bf3a84e822b960e369f0134d597e025c775a41'
MAIN = '3d9a8823e9e9d0830af433241dcc09bdc73a3901'
records = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def add(source, name):
    assert name not in records, name
    records[name] = source.read_bytes()


def add_tree(source, prefix):
    for path in sorted(source.rglob('*')):
        if path.is_file():
            add(path, prefix + '/' + path.relative_to(source).as_posix())


def git(*args, repository=APP):
    return subprocess.check_output(['git', '-C', str(repository), *args])


assert git('rev-parse', 'HEAD').decode().strip() == RUNTIME
add_tree(ROOT / 'app-acceptance-0233ed8e', 'final')
for directory, prefix in [('app-word-cohort-0233ed8e', 'cohort'),
                          ('app-word-cohort-3c9f9ab2', 'baseline/cohort')]:
    workspace = ROOT / directory
    add_tree(workspace / 'results', prefix + '/results')
    for name in ('pubspec.yaml', 'pubspec.lock', 'word_cohort.py', 'prepared-adapters.json', 'pub-get.log'):
        add(workspace / name, prefix + '/' + name)
    add(workspace / '.dart_tool/package_config.json', prefix + '/package_config.json')
add_tree(ROOT / 'app-acceptance-3c9f9ab2', 'baseline/controls')
for name in ('app-mirror-repair.json', 'app-mirror-repair-source-audit.json',
             'app-final-source-audit.json', 'app-sync-controls-baseline.log',
             'app-sync-controls-repair.log', 'app-sync-controls-final-candidate.log',
             'app-sync-plan-48bf3a.json', 'app-sync-applied-48bf3a.json',
             'app-remote-source-verification.log', 'app-final-remote-checkout.log'):
    add(ROOT / name, 'development/' + name)
for name in ('dart-recovery.json', 'flutter-minimal-recovery.json',
             'production-pub-get-initial.log', 'cohort-cache-warm.log'):
    add(ROOT / 'toolchains/recovery-20261113' / name, 'recovery/' + name)
add(ROOT / 'app-final-remote-source-verification.log', 'remote/source-verification.log')
remote = ROOT / 'CrispCloud-remote-check'
records['remote/verification.json'] = json_bytes({
    'commit': git('rev-parse', 'HEAD', repository=remote).decode().strip(),
    'tree': git('rev-parse', 'HEAD^{tree}', repository=remote).decode().strip(),
    'status': git('status', '--porcelain', repository=remote).decode().strip(),
    'origin': git('remote', 'get-url', 'origin', repository=remote).decode().strip(),
    'branch': 'feature/office-fidelity-gaps-20261113',
    'scope': 'Separate detached checkout of the fetched published commit; full source and Git-index verification passed.'})
records['remote/publication.json'] = json_bytes({
    'checkpoints': [MAIN, '25900447bb184392cd5a992d703342339cc27c3a',
                    '3c9f9ab2ef4a195e538390a56c0265196f33730f', RUNTIME],
    'method': 'GitHub Git Data API with expected-SHA leases, non-forced branch updates and exact staged-tree comparison',
    'ordinaryPushObservedError': "fatal: could not read Username for 'https://github.com': No such device or address",
    'errorProvenance': 'Observed terminal response during the initial fast-forward push; preserved as a narrated tool observation, not an original captured process log.'})
for source, name in [('docs/apple-export-policy.json', 'main-policy.json'),
                     ('pubspec.lock', 'main-lockfile'),
                     ('tool/office_fidelity_manifest.json', 'main-office-manifest.json'),
                     ('docs/crypto-inventory.json', 'main-inventory.json')]:
    records['source-review/' + name] = git('show', MAIN + ':' + source)
for source, name in [('docs/apple-export-policy.json', 'final-policy.json'),
                     ('tool/office_fidelity_manifest.json', 'final-office-manifest.json'),
                     ('docs/crypto-inventory.json', 'final-inventory.json')]:
    records['source-review/' + name] = git('show', RUNTIME + ':' + source)

environment = {}
for name, args in [('soffice', ['--version']), ('pdfinfo', ['-v']),
                   ('pdftoppm', ['-v']), ('pdftotext', ['-v']),
                   ('pdfimages', ['-v']), ('node', ['--version']), ('python', ['--version'])]:
    path = Path(shutil.which(name))
    command = subprocess.run([str(path), *args], capture_output=True, text=True,
                             env=dict(os.environ, TMPDIR=str(ROOT / 'tmp')), timeout=30)
    environment[name] = {'path': str(path), 'sha256': sha(path.read_bytes()),
                         'versionStdout': command.stdout, 'versionStderr': command.stderr,
                         'exitCode': command.returncode}
records['environment.json'] = json_bytes(environment)
add(Path(__file__), 'collection/seal_app_evidence.py')
manifest = {'schemaVersion': 1, 'files': {name: {'bytes': len(data), 'sha256': sha(data)}
                                        for name, data in sorted(records.items())}}
archive = OUT / 'records.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as bundle:
    for name, data in sorted(records.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        item.mtime = 0
        bundle.addfile(item, io.BytesIO(data))
(OUT / 'manifest.json').write_bytes(json_bytes(manifest))
summary = json.loads(records['final/summary.json'])
cohort_before = json.loads(records['cohort/results/inputs-before.json'])
office = json.loads(records['source-review/final-office-manifest.json'])
receipt = {
    'schemaVersion': 1,
    'recordedUtc': datetime.now(timezone.utc).isoformat(),
    'branch': 'feature/office-fidelity-gaps-20261113',
    'measuredAppCommit': RUNTIME,
    'measuredAppTree': summary['sourceTree'],
    'parserCommit': PARSER,
    'qudsCommit': office['source_commit'],
    'managedOfficeFiles': len(office['files']),
    'parserSourceFiles': sum(name.startswith('packages/legacy_doc_parser/') for name in office['files']),
    'trackedSourceFileCount': summary['sourceFileCount'],
    'cohortTests': 107,
    'cohortInputCount': len(cohort_before['files']),
    'nativeAssertions': 13,
    'controlCounts': {'sync-controls': [27, 0], 'apple-preflight-controls': [38, 0],
                      'crypto-evidence-controls': [42, 2], 'ebook-source-controls': [22, 0]},
    'archiveSha256': sha(archive.read_bytes()),
    'archiveBytes': archive.stat().st_size,
    'recordCount': len(records),
    'uncompressedRecordBytes': sum(len(data) for data in records.values()),
    'manifestSha256': sha((OUT / 'manifest.json').read_bytes()),
    'verifierSha256': sha((OUT / 'verify.py').read_bytes()),
    'readmeSha256': sha((OUT / 'README.md').read_bytes()),
    'scope': ['Exact published runtime accepted before the later evidence commit.',
              '107 import-only data tests; no Flutter widget or full app build execution.',
              '13 actual native assertions are distinct from the cohort fake-process tests.',
              'Native tool retains partialFormatting and deletes its temporary PDF.',
              'Native glyph/page exactness, Microsoft Word execution and release readiness are not established.',
              'Initial online dependency setup ran during branch reconciliation; final offline locked resolution and acceptance use the clean measured app commit.',
              'Intermediate baseline/probe records retain their original source identities.'],
}
(OUT / 'receipt.json').write_bytes(json_bytes(receipt))
print(json.dumps({key: receipt[key] for key in ('measuredAppCommit', 'recordCount',
                  'archiveBytes', 'uncompressedRecordBytes', 'cohortInputCount')}))
