#!/usr/bin/env python3
"""Capture baseline acceptance using genuine production dependency resolution."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
app = root.parents[1]
toolchains = app.parent / 'toolchains'
name, *command = sys.argv[1:]
environment = dict(os.environ, TMPDIR=str(toolchains / 'tmp'),
                   PUB_CACHE=str(toolchains / 'pub-cache'),
                   FLUTTER_ROOT=str(toolchains / 'flutter-3.47.8'),
                   DART_SUPPRESS_ANALYTICS='true', CI='true')
started = datetime.now(timezone.utc).isoformat()
with (root / ('native.json' if name == 'native' else name + '.log')).open('wb') as output:
    if name == 'native':
        with (root / 'native.stderr.log').open('wb') as errors:
            result = subprocess.run(command, cwd=app, env=environment,
                                    stdout=output, stderr=errors, timeout=180)
    else:
        result = subprocess.run(command, cwd=app, env=environment,
                                stdout=output, stderr=subprocess.STDOUT, timeout=180)
receipt = {'name': name, 'command': command, 'cwd': str(app),
           'startedUtc': started, 'finishedUtc': datetime.now(timezone.utc).isoformat(),
           'exitCode': result.returncode,
           'appCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                                               cwd=app, text=True).strip()}
(root / (name + '.command.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
