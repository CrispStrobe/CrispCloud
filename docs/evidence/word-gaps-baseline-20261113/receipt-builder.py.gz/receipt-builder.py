#!/usr/bin/env python3
"""Retain bounded baseline records; never bundle SDK or dependency binaries."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

run = Path(__file__).resolve().parent
app = run.parents[1]
workspace = app.parent
destination = app / 'docs/evidence/word-gaps-baseline-20261113'
destination.mkdir(exist_ok=True)
cohort = workspace / 'app-word-cohort-baseline-20261113'
recovery = workspace / 'toolchains/recovery-20261113'
load = lambda path: json.loads(path.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
before = load(run / 'baseline-source-before.json')
assert before == load(run / 'baseline-source-after.json') and before['status'] == ''
summary = load(cohort / 'results/summary.json')
inputs = load(cohort / 'results/inputs-before.json')
assert summary['success'] and summary['testCount'] == 107
records = {'cohort-' + p.name: p for p in (cohort / 'results').iterdir() if p.is_file()}
for name in ('pubspec.yaml', 'pubspec.lock', 'pub-get.log', 'word_cohort.py'):
    records['cohort-' + name] = cohort / name
records['cohort-package_config.json'] = cohort / '.dart_tool/package_config.json'
records['production-package_config.json'] = app / '.dart_tool/package_config.json'
records['production-pubspec.lock'] = app / 'pubspec.lock'
records['production-pubspec.yaml'] = app / 'pubspec.yaml'
for name in (
    'baseline-source-before.json', 'baseline-source-after.json', 'inventory-before.json',
    'policy-before.json', 'reviewed-source-before.json', 'source-verification.log',
    'sync-controls.log', 'apple-preflight-controls.log', 'crypto-evidence-controls.log',
    'ebook-source-controls.log', 'cohort-console.log', 'production-pub-get.log',
    'production-pub-get.json', 'production-dependencies-verified.json',
    'production-offline-pub-get.log', 'production-offline-pub-get.command.json',
    'native.json', 'native.stderr.log', 'native.command.json', 'portable-web.log',
    'portable-web.command.json', 'release-input-check.log', 'release-input-check.command.json',
    'release-input-check-preresolution.log', 'ebook-source-verification.log',
    'ebook-source-verification.command.json', 'environment.json'):
    records[name] = run / name
records['acceptance-runner.py'] = run / 'run_gate.py'
records['receipt-builder.py'] = Path(__file__)
for name in ('flutter-source-recovery.json', 'dart-recovery.json'):
    records[name] = recovery / name
records['flutter-release-index.json'] = workspace / 'toolchains/downloads/flutter-releases-linux.json'
for name in ('flutter-source-clone.log', 'flutter-release-metadata.json',
             'flutter-sdk-archive.json', 'flutter-release-metadata-corrected.json',
             'flutter-sdk-archive-corrected.json'):
    records['setup-' + name] = recovery / 'logs' / name
packed_records = {}
for name, path in sorted(records.items()):
    raw = path.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    (destination / (name + '.gz')).write_bytes(compressed)
    packed_records[name + '.gz'] = {'originalName': name, 'bytes': len(raw),
        'sha256': sha(raw), 'compressedBytes': len(compressed),
        'compressedSha256': sha(compressed)}
shutil.copyfile(run / 'verify_evidence.py', destination / 'verify_evidence.py')
ebook = load(run / 'ebook-source-verification.log')
manifest = load(app / 'tool/office_fidelity_manifest.json')
dependencies = load(run / 'production-dependencies-verified.json')
receipt = {
    'version': 1, 'recordedUtc': datetime.now(timezone.utc).isoformat(),
    'measuredAppCommit': before['appCommit'], 'measuredAppTree': before['appTree'],
    'measuredWorktreeStatus': '',
    'branch': 'feature/office-fidelity-gaps-20261113',
    'parserCommit': before['parserUpstream']['commit'], 'qudsCommit': manifest['source_commit'],
    'officeFileCount': len(manifest['files']),
    'parserFileCount': sum(p.startswith('packages/legacy_doc_parser/') for p in manifest['files']),
    'cohortTestCount': summary['testCount'], 'cohortInputCount': inputs['fileCount'],
    'cohortSuites': summary['suites'], 'excludedSuites': summary['excludedSuites'],
    'cohortCommand': {'argv': ['python3', 'docs/evidence/word-continuation-7308125/run_word_cohort.py',
        '--app', str(app), '--workspace', str(cohort),
        '--dart', str(workspace / 'toolchains/dart-3.13.7/dart-sdk/bin/dart'),
        '--pub-cache', str(workspace / 'toolchains/pub-cache')],
        'startedUtc': summary['startedUtc'], 'finishedUtc': summary['finishedUtc'],
        'scope': 'Retained import-only data test adapter with its own captured dependency configuration.'},
    'controls': {
        'sync-controls.log': {'passed': 24, 'skipped': 0},
        'apple-preflight-controls.log': {'passed': 38, 'skipped': 0},
        'crypto-evidence-controls.log': {'passed': 40, 'skipped': 2},
        'ebook-source-controls.log': {'passed': 22, 'skipped': 0}},
    'controlCommands': [
        ['python3', '-m', 'unittest', 'discover', '-s', 'tool', '-p', pattern, '-v']
        for pattern in ('test_sync_*.py', 'test_apple_export_preflight.py',
                        'test_crypto_release_evidence.py', 'test_verify_ebook_sources.py')],
    'sourceVerificationCommand': ['python3', 'tool/verify_office_fidelity.py', '--legacy-source', '../legacy-doc-parser'],
    'productionPackageCount': dependencies['productionPackageConfigCount'],
    'productionLockedPackageCount': dependencies['lockedPackageCount'],
    'productionHostedPackagesVerified': len(dependencies['hostedHashesVerified']),
    'reviewedSourceBinding': {'fileCount': 413,
        'sha256': load(run / 'reviewed-source-before.json')['reviewedSourceSha256'],
        'scope': 'Reproduces current main\'s existing reviewed binding; no new source audit or fingerprint refresh.'},
    'native': load(run / 'native.json'),
    'ebookSource': {'fileCount': ebook['files_verified'], 'commit': ebook['revision']},
    'recordedAcceptanceCommands': sorted(p.name for p in run.glob('*.command.json')),
    'records': packed_records,
    'verifierSha256': sha((destination / 'verify_evidence.py').read_bytes()),
    'limitations': [
        'This is the current-main baseline; no new parser runtime has been adopted by this checkpoint.',
        'The 107 tests use the retained import-only data adapter; Flutter widgets, native ebook hooks and full application builds were not executed.',
        'Native acceptance checks 13 existing assertions on one authored fixture, retains partialFormatting and deletes its temporary PDF by existing tool design; no pixel, glyph or arbitrary pagination claim.',
        'The 13 fake-process converter tests in the cohort are separate from the 13 actual native assertions.',
        'The first release input check correctly failed before package_config existed; it passed after genuine production resolution. The initial log is retained.',
        'Two Flutter setup requests used an extra URL path segment and returned HTTP 404; corrected official release URLs succeeded and the published checksum matched.',
        'The Flutter launcher and cloud metadata endpoint were not used; version metadata and sky_engine bytes came unchanged from the official release archive.',
        'All current main archive/release work, version, policy decisions, fingerprint values, lockfile and source plists remain unchanged.'
    ]}
(destination / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({'records': len(packed_records), 'measuredAppCommit': before['appCommit'],
                  'cohortInputs': inputs['fileCount'], 'officeFiles': len(manifest['files'])}))
