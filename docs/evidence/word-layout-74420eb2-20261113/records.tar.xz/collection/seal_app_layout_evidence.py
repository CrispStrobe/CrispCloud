#!/usr/bin/env python3
"""Seal the first combined layout integration's exact completed app records."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'CrispCloud-layout-next'
OUT = APP / 'docs/evidence/word-layout-74420eb2-20261113'
records = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(name, path):
    if name in records:
        raise ValueError('Duplicate record: ' + name)
    records[name] = path.read_bytes()


for path in sorted((ROOT / 'app-acceptance-e3eaaa32').iterdir()):
    if path.is_file():
        add('final/' + path.name, path)
cohort = ROOT / 'app-word-cohort-e3eaaa32'
for name in ['word_cohort.py', 'pubspec.yaml', 'pubspec.lock', 'pub-get.log',
             'prepared-adapters.json', '.dart_tool/package_config.json']:
    add('cohort/' + name, cohort / name)
for path in sorted((cohort / 'results').iterdir()):
    if path.is_file():
        add('cohort/results/' + path.name, path)
for path in sorted((cohort / 'test').glob('*.dart')):
    add('cohort/test/' + path.name, path)
for path in sorted((ROOT / 'app-layout-next-integration').iterdir()):
    if path.is_file():
        add('integration/' + path.name, path)
for name in ['dart-recovery.json', 'flutter-minimal-recovery.json']:
    add('recovery/' + name, ROOT / 'toolchains/recovery-20261113' / name)
add('collection/seal_app_layout_evidence.py', Path(__file__))
archive = OUT / 'records.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as packed:
    for name, data in sorted(records.items()):
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(data), 0o644, 0
        packed.addfile(item, io.BytesIO(data))
manifest = {'schemaVersion': 1, 'files': {name: {'sha256': sha(data), 'bytes': len(data)}
                                      for name, data in sorted(records.items())}}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'manifest.json').write_bytes(manifest_bytes)
receipt = {
    'schemaVersion': 1,
    'measuredAppCommit': 'e3eaaa32bafa869548b30c0938aec776e99ea44e',
    'measuredAppTree': 'f7a9943e1790de253930fec3e12375277132fa3a',
    'parserCommit': '74420eb2e0ec14401a0db5bcbb30ab6d202a2340',
    'parserTree': 'ac78b144d90bca0f44993d94ae0fd1c8115ce072',
    'branch': 'checkpoint/app-layout-next-20261113',
    'qudsCommit': '6d6e77d14ead33de90c57ec5feb2ab3cc44f6501',
    'managedOfficeFiles': 1369, 'parserSourceFiles': 948,
    'trackedSourceFileCount': 7257, 'cohortInputCount': 1180, 'cohortTests': 107,
    'nativeAssertions': 13,
    'controlCounts': {'sync-controls': [27, 0], 'apple-preflight-controls': [38, 0],
                      'crypto-evidence-controls': [42, 2], 'ebook-source-controls': [22, 0]},
    'scope': 'Existing data-only app, actual installed Office and source-retention acceptance; '
             'no Flutter widgets, complete build, hosted CI, exact pagination or release claim.',
    'recordCount': len(records), 'uncompressedRecordBytes': sum(map(len, records.values())),
    'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive.read_bytes()),
    'manifestSha256': sha(manifest_bytes), 'verifierSha256': sha((OUT / 'verify.py').read_bytes()),
    'selfTestSha256': sha((OUT / 'test_verifier.py').read_bytes()),
    'readmeSha256': sha((OUT / 'README.md').read_bytes()),
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['recordCount', 'uncompressedRecordBytes',
                                             'archiveBytes', 'archiveSha256']}))
