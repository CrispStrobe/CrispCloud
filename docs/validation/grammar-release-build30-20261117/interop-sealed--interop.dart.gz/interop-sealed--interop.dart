import 'dart:convert';
import 'dart:io';
import 'package:quds_office_engine/quds_office_engine.dart';

void require(bool condition, String message) { if (!condition) throw StateError(message); }
WmlParagraph p(String text) => WmlParagraph(inlines: [WmlRun(text: text)]);
void main(List<String> args) {
  final root=Directory(args[1]);
  if(args[0]=='generate') {
    root.createSync(recursive:true);
    final doc=WmlDocument(sections:[WmlSection(
      header:[p('VISIBLE HEADER')], footer:[p('VISIBLE FOOTER')],
      blocks:[WmlParagraph(inlines:[
        WmlBookmarkBoundary(id:'1',isStart:true,name:'BodyRange'),
        WmlRun(text:'VISIBLE BODY',commentIds:[3]),
        WmlBookmarkBoundary(id:'1',isStart:false),
      ]),WmlTable(grid:[120],rows:[WmlTableRow(cells:[WmlTableCell(blocks:[p('VISIBLE TABLE')])])])],
    )], comments:[WmlComment(id:3,author:'Synthetic reviewer',text:'PRIVATE REVIEW NOTE')]);
    File('${root.path}/stories.odt').writeAsBytesSync(OdtDocumentWriter.writeBytes(doc));
    File('${root.path}/stories.docx').writeAsBytesSync(WordSerializer().write(doc).save());
    final sheet=SmlWorksheet(name:'Data',sheetId:1);
    sheet.cellA1('A1')..value='Item'..type=SmlCellType.string..fontBold=true;
    sheet.cellA1('B1').value='Value';
    sheet.cellA1('A2').value='Äpfel';sheet.cellA1('B2').value=2;
    sheet.cellA1('A3').value='Größe';sheet.cellA1('B3').value=3;
    sheet.cellA1('C2')..formula='=SUM(B2:B3)'..value=5..type=SmlCellType.formula;
    sheet.cellA1('A5').value='  authored  spaces\nsecond line';
    sheet.cellA1('B5')..value=true..type=SmlCellType.boolean;
    sheet.cellA1('C5')..value=45293..styleIndex=1;
    sheet.cellA1('D1').value='Merged';sheet.merges.add(SmlMerge.parse('D1:E2'));
    sheet.comments.add(SmlComment(ref:SmlCellRef.parse('A1'),text:'SHEET REVIEW NOTE',author:'Synthetic reviewer'));
    sheet.cellA1('A7')..value='link'..hyperlink='https://example.test';
    final hidden=SmlWorksheet(name:'Hidden',sheetId:2,hidden:true);hidden.cellA1('A1').value='HIDDEN SHEET VALUE';
    final book=SmlWorkbook(sheets:[sheet,hidden])..styles=SmlStyleSheet(numFmts:{0:'General',164:'DD.MM.YYYY'},cellXfsNumFmt:[0,164]);
    File('${root.path}/values.ods').writeAsBytesSync(OdsSheetWriter.writeBytes(book));
    print('Generated authored Word/ODF fixtures');
  } else {
    final book=OdsSheetReader.readBytes(File('${root.path}/values.ods').readAsBytesSync());
    final sheet=book.sheets.firstWhere((s)=>s.name=='Data');
    require(sheet.cellA1('A2').value=='Äpfel','Unicode cell changed');
    require(sheet.cellA1('B2').value==2 && sheet.cellA1('B3').value==3,'Numbers changed');
    require(sheet.cellA1('C2').value==5,'Formula cache changed');
    require((sheet.cellA1('C2').formula??'').contains('SUM'),'Formula lost');
    require(sheet.cellA1('A5').value=='  authored  spaces\nsecond line','Whitespace changed');
    require(sheet.cellA1('B5').value==true,'Boolean changed');
    require(sheet.cellA1('C5').value==45293,'Date serial changed');
    require(sheet.cellA1('A1').fontBold,'Bold heading changed');
    require(sheet.merges.any((m)=>m.a1=='D1:E2'),'Merge lost');
    require(sheet.comments.any((c)=>c.text.contains('SHEET REVIEW NOTE')),'Comment lost');
    require(book.sheets.firstWhere((s)=>s.name=='Hidden').hidden,'Hidden sheet state lost');
    require(const {'https://example.test','https://example.test/'}.contains(sheet.cellA1('A7').hyperlink),'Hyperlink target changed');
    print(jsonEncode({'status':'passed','file':'${root.path}/values.ods','sheets':book.sheets.length,'formula':sheet.cellA1('C2').formula,'date_serial':sheet.cellA1('C5').value}));
  }
}
