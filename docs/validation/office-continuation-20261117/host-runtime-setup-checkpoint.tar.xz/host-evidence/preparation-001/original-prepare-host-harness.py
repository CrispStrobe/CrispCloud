#!/usr/bin/env python3
"""Rebase the committed locked service harness and link genuine host source.

This setup creates only an isolated wrapper. Production manifests and tests
are not edited. Dependency versions and archive hashes retain the recorded
107-package service graph.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone
import yaml

ROOT = Path(__file__).resolve().parent
OLD = '/workspace/scratch/5ce2ad01fc79/validation-runtime/runtime/service-setup/service-harness'
PREFIX = 'service-setup/service-harness/'
PACKAGES = ('legacy_doc_parser', 'quds_office_engine', 'quds_office_editor', 'quds_reports')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=ROOT.parent / 'crispcloud')
    parser.add_argument('--harness', type=Path, default=ROOT / 'service-harness')
    args = parser.parse_args()
    repo, harness = args.repo.resolve(), args.harness.resolve()
    assert not harness.exists(), 'Use a fresh harness path'
    source = ROOT / 'prior-setup/continuation-setup/harness-inputs-current.json.gz'
    inputs = json.loads(gzip.decompress(source.read_bytes()))
    receipt = {'created_utc': datetime.now(timezone.utc).isoformat(),
               'source_archive': str(source), 'source_archive_sha256': sha(source),
               'repo': str(repo), 'harness': str(harness),
               'source_commit': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
               'production_lock_sha256': sha(repo / 'pubspec.lock'),
               'production_manifests_modified': False, 'application_tests_run': False,
               'inputs': {}, 'source_links': {}}
    for name, value in inputs.items():
        if not name.startswith(PREFIX) or not name.endswith(('pubspec.yaml', 'pubspec.lock')):
            continue
        assert hashlib.sha256(value['text'].encode()).hexdigest() == value['sha256'], name
        relative = name[len(PREFIX):]
        target = harness / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = value['text'].replace(OLD, str(harness))
        assert '/workspace/scratch/5ce2ad01fc79' not in payload, name
        target.write_text(payload)
        receipt['inputs'][relative] = {'recorded_sha256': value['sha256'], 'rebased_sha256': sha(target)}
    def link(target, actual):
        assert actual.exists(), actual
        target.parent.mkdir(parents=True, exist_ok=True)
        target.symlink_to(actual, target_is_directory=actual.is_dir())
        receipt['source_links'][str(target.relative_to(harness))] = str(actual)
    for name in ('lib', 'test', 'analysis_options.yaml'):
        link(harness / name, repo / name)
    for name in PACKAGES:
        for item in (repo / 'packages' / name).iterdir():
            if item.name not in {'pubspec.yaml', 'pubspec.lock', '.dart_tool', 'build', 'example'}:
                link(harness / 'packages' / name / item.name, item)
    lock = yaml.safe_load((harness / 'pubspec.lock').read_text())
    production = yaml.safe_load((repo / 'pubspec.lock').read_text())
    hosted = {name: value for name, value in lock['packages'].items() if value['source'] == 'hosted'}
    deviations = []
    for name, value in hosted.items():
        prod = production['packages'].get(name)
        if prod is None or prod['version'] != value['version'] or prod['description']['sha256'] != value['description']['sha256']:
            deviations.append({'package': name, 'harness': value, 'production': prod})
    receipt['hosted_dependency_count'] = len(hosted)
    receipt['hosted_production_lock_deviations'] = deviations
    receipt['seed_lock_sha256'] = sha(harness / 'pubspec.lock')
    receipt['status'] = 'prepared; dependency resolution still required'
    (ROOT / 'harness-preparation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'harness': str(harness), 'hosted_packages': len(hosted), 'production_lock_deviations': len(deviations)}))

if __name__ == '__main__':
    main()
