#!/usr/bin/env python3
"""Resolve the preserved host service graph with its exact lockfile."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import yaml

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def now():
    return datetime.now(timezone.utc).isoformat()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=ROOT.parent / 'crispcloud')
    parser.add_argument('--harness', type=Path, default=ROOT / 'service-harness')
    parser.add_argument('--flutter', type=Path, default=ROOT.parent / 'runtime/flutter-sdk')
    parser.add_argument('--pub-cache', type=Path, default=ROOT.parent / 'runtime/pub-cache')
    parser.add_argument('--output', type=Path, default=ROOT / 'setup')
    args = parser.parse_args()
    repo, harness, sdk, cache, out = [p.resolve() for p in (args.repo,args.harness,args.flutter,args.pub_cache,args.output)]
    out.mkdir(parents=True, exist_ok=True)
    assert not (out / 'receipt.json').exists(), 'Do not overwrite setup evidence'
    for directory in ('logs', 'config', 'tmp'):
        (out / directory).mkdir(exist_ok=True)
    env = dict(os.environ, FLUTTER_ROOT=str(sdk), PUB_CACHE=str(cache),
               TMPDIR=str(out / 'tmp'), XDG_CONFIG_HOME=str(out / 'config'),
               CI='true', FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true')
    env['PATH'] = str(sdk / 'bin') + os.pathsep + env.get('PATH', '')
    dart = sdk / 'bin/cache/dart-sdk/bin/dart'
    toolkit = sdk / 'bin/cache/flutter_tools.snapshot'
    assert dart.is_file() and toolkit.is_file(), 'SDK must be initialized first'
    runtime_names = ('bin/cache/dart-sdk/bin/dart','bin/cache/flutter_tools.snapshot',
                     'bin/cache/artifacts/engine/linux-x64/flutter_tester')
    runtime_before = {name: sha(sdk / name) for name in runtime_names}
    receipt = {'status': 'running', 'started_utc': now(), 'harness': str(harness), 'pub_cache': str(cache),
               'production_lock_sha256': sha(repo / 'pubspec.lock'),
               'seed_lock_sha256': sha(harness / 'pubspec.lock'),
               'runtime_before': runtime_before, 'commands': [],
               'application_tests_run': False, 'production_files_modified': False,
               'setup_script_sha256': sha(Path(__file__))}
    def save():
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    save()
    for name, options in [('locked-resolution', ['--enforce-lockfile']),
                           ('locked-offline-repeat', ['--offline', '--enforce-lockfile'])]:
        command = [str(dart), str(toolkit), 'pub', 'get', *options]
        log = out / 'logs' / (name + '.log')
        start = time.monotonic()
        row = {'name': name, 'command': command, 'cwd': str(harness), 'log': str(log), 'started_utc': now()}
        receipt['commands'].append(row)
        save()
        with log.open('w') as stream:
            process = subprocess.Popen(command, cwd=harness, env=env, stdout=stream, stderr=subprocess.STDOUT)
            while True:
                try:
                    process.wait(timeout=15)
                    break
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - start
                    print(json.dumps({'active': name, 'seconds': round(elapsed), 'log_bytes': log.stat().st_size}), flush=True)
                    if elapsed > 600:
                        process.terminate()
                        process.wait(timeout=10)
                        raise RuntimeError(name + ' timed out')
        row.update(exit_code=process.returncode, duration_seconds=round(time.monotonic()-start,3),
                   finished_utc=now(), log_sha256=sha(log))
        save()
        if process.returncode:
            receipt.update(status='failed', error=name, finished_utc=now())
            save()
            print(log.read_text()[-7000:], flush=True)
            raise SystemExit(1)
    receipt['final_lock_sha256'] = sha(harness / 'pubspec.lock')
    receipt['locked_inputs_unchanged'] = receipt['final_lock_sha256'] == receipt['seed_lock_sha256']
    production = yaml.safe_load((repo / 'pubspec.lock').read_text())['packages']
    lock = yaml.safe_load((harness / 'pubspec.lock').read_text())['packages']
    mismatches = []
    for name, value in lock.items():
        if value['source'] != 'hosted':
            continue
        prod = production.get(name)
        if not prod or (prod['version'], prod['description']['sha256']) != (value['version'], value['description']['sha256']):
            mismatches.append(name)
    receipt['production_lock_deviations'] = mismatches
    receipt['final_package_count'] = len(json.loads((harness / '.dart_tool/package_config.json').read_text())['packages'])
    receipt['package_config_sha256'] = sha(harness / '.dart_tool/package_config.json')
    receipt['package_graph_sha256'] = sha(harness / '.dart_tool/package_graph.json')
    receipt['runtime_after'] = {name: sha(sdk / name) for name in runtime_names}
    receipt['runtime_unchanged'] = runtime_before == receipt['runtime_after']
    receipt['finished_utc'] = now()
    receipt['status'] = 'passed' if receipt['locked_inputs_unchanged'] and not mismatches and receipt['runtime_unchanged'] else 'failed'
    save()
    print(json.dumps({k: receipt[k] for k in ('status','final_package_count','locked_inputs_unchanged','production_lock_deviations','runtime_unchanged')}), flush=True)
    return int(receipt['status'] != 'passed')

if __name__ == '__main__':
    raise SystemExit(main())
