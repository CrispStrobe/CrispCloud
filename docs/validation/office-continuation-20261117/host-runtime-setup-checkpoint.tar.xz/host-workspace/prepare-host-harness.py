#!/usr/bin/env python3
"""Prepare a genuine-source, production-locked focused host harness.

No production source, manifest, lockfile, or test is edited. The historical
harness supplies its dependency constraints and lock; current production
declarations supply the seven Office notice assets. SDK execution is separate.
"""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import yaml

SEED_MEMBER = 'host-audit/prior-setup/continuation-setup/harness-inputs-current.json.gz'
SEED_PREFIX = 'service-setup/service-harness/'
OLD_ROOT = '/workspace/scratch/5ce2ad01fc79/validation-runtime/runtime/service-setup/service-harness'
PACKAGES = ('legacy_doc_parser', 'quds_office_engine', 'quds_office_editor', 'quds_reports')
NEW_NOTICE = 'packages/quds_office_engine/third_party/proofing/UNICODE_INFLECTION_NOTICE'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--harness', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo, harness, out = (p.resolve() for p in (args.repo, args.harness, args.output))
    if harness.exists() or out.exists():
        raise ValueError('Use fresh harness and preparation output paths')
    archive = repo / 'docs/validation/zotero-landing-20261117/host-evidence.tar.xz'
    production_manifest_before = sha(repo / 'pubspec.yaml')
    production_lock_before = sha(repo / 'pubspec.lock')
    with tarfile.open(archive) as bundle:
        seed_bytes = bundle.extractfile(SEED_MEMBER).read()
        original_preparer = bundle.extractfile('host-audit/prepare-host-harness.py').read()
        original_resolver = bundle.extractfile('host-audit/resolve-host-harness.py').read()
    inputs = json.loads(gzip.decompress(seed_bytes))
    out.mkdir(parents=True)
    (out / 'original-prepare-host-harness.py').write_bytes(original_preparer)
    (out / 'original-resolve-host-harness.py').write_bytes(original_resolver)
    (out / 'harness-inputs-current.json.gz').write_bytes(seed_bytes)
    receipt = {
        'schema_version': 1, 'status': 'preparing',
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit_at_preparation': subprocess.check_output(
            ['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
        'preparation_does_not_qualify_source': True,
        'repo': str(repo), 'harness': str(harness),
        'source_archive': str(archive), 'source_archive_sha256': sha(archive),
        'seed_member': SEED_MEMBER, 'seed_sha256': digest(seed_bytes),
        'original_preparation_script_sha256': digest(original_preparer),
        'original_resolution_script_sha256': digest(original_resolver),
        'preparation_script_sha256': sha(Path(__file__)),
        'production_lock_sha256': production_lock_before,
        'production_manifest_sha256': production_manifest_before,
        'inputs': {}, 'source_links': {}, 'runtime_executed': False,
    }
    for name, value in inputs.items():
        if not name.startswith(SEED_PREFIX) or not name.endswith(('pubspec.yaml', 'pubspec.lock')):
            continue
        if digest(value['text'].encode()) != value['sha256']:
            raise ValueError('Invalid seed entry: ' + name)
        relative = name[len(SEED_PREFIX):]
        if Path(relative).is_absolute() or '..' in Path(relative).parts:
            raise ValueError('Unsafe seed path: ' + relative)
        target = harness / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = value['text'].replace(OLD_ROOT, str(harness))
        if '/workspace/scratch/5ce2ad01fc79' in payload:
            raise ValueError('Unrebased seed path: ' + name)
        target.write_text(payload)
        receipt['inputs'][relative] = {
            'recorded_sha256': value['sha256'], 'rebased_sha256': sha(target)}

    # Update the wrapper's assets from the production declaration before freezing
    # its manifest inputs. This changes no dependency constraint or lock entry.
    manifest_path = harness / 'pubspec.yaml'
    wrapper = yaml.safe_load(manifest_path.read_text())
    production = yaml.safe_load((repo / 'pubspec.yaml').read_text())
    original_assets = wrapper['flutter']['assets']
    requested = set(original_assets) | {NEW_NOTICE}
    declared = production['flutter']['assets']
    assets = [x for x in declared if isinstance(x, str) and x in requested]
    if set(assets) != requested or len(assets) != 7:
        raise ValueError('Seven exact Office notice declarations are required')
    for asset in assets:
        if not (repo / asset).is_file():
            raise ValueError('Declared production notice missing: ' + asset)
    if NEW_NOTICE not in original_assets:
        manifest_path.write_text(manifest_path.read_text().rstrip() + '\n  - ' + NEW_NOTICE + '\n')
    effective = yaml.safe_load(manifest_path.read_text())
    if set(effective['flutter']['assets']) != requested:
        raise ValueError('Wrapper notice declarations differ from production')
    receipt['assets'] = {
        'source': 'current production pubspec.yaml declarations',
        'original_count': len(original_assets), 'final_count': 7,
        'added': [NEW_NOTICE], 'paths': assets,
        'notice_sha256': {x: sha(repo / x) for x in assets},
    }
    receipt['inputs']['pubspec.yaml']['asset_amended_sha256'] = sha(manifest_path)

    def link(target, source):
        if not source.exists():
            raise ValueError('Missing production source: ' + str(source))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.symlink_to(source, target_is_directory=source.is_dir())
        receipt['source_links'][str(target.relative_to(harness))] = str(source)

    for name in ('lib', 'test', 'analysis_options.yaml'):
        link(harness / name, repo / name)
    for name in PACKAGES:
        for item in (repo / 'packages' / name).iterdir():
            if item.name not in {'pubspec.yaml', 'pubspec.lock', '.dart_tool', 'build', 'example'}:
                link(harness / 'packages' / name / item.name, item)
    seed_lock = yaml.safe_load((harness / 'pubspec.lock').read_text())['packages']
    production_lock = yaml.safe_load((repo / 'pubspec.lock').read_text())['packages']
    hosted = {n: v for n, v in seed_lock.items() if v['source'] == 'hosted'}
    deviations = []
    for name, value in hosted.items():
        prod = production_lock.get(name)
        if (prod is None or prod['version'] != value['version']
                or prod['description']['sha256'] != value['description']['sha256']):
            deviations.append(name)
    receipt.update({
        'hosted_dependency_count': len(hosted),
        'hosted_production_lock_deviations': deviations,
        'seed_lock_sha256': sha(harness / 'pubspec.lock'),
        'production_inputs_unchanged': production_manifest_before == sha(repo / 'pubspec.yaml')
            and production_lock_before == sha(repo / 'pubspec.lock'),
        'finished_utc': datetime.now(timezone.utc).isoformat(),
    })
    receipt['status'] = 'prepared; locked dependency resolution and source qualification pending'
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if deviations or not receipt['production_inputs_unchanged']:
        raise ValueError('Production lock or input preservation failure')
    print(json.dumps({k: receipt[k] for k in (
        'status', 'harness', 'hosted_dependency_count',
        'hosted_production_lock_deviations', 'production_inputs_unchanged')}))


if __name__ == '__main__':
    main()
