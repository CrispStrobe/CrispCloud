#!/usr/bin/env python3
"""Run the new annotation cases with only the host reader reverted in isolation.

This is a one-file inverse control, not a qualification of the whole historical
checkout. Final tests, canonical packages, and locked dependencies stay fixed.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('focused_host', HERE / 'run-focused-host.py')
focused = importlib.util.module_from_spec(spec)
spec.loader.exec_module(focused)
audit = focused.audit
SERVICE = 'lib/services/office_document_service.dart'
TEST = 'test/office_annotation_preview_test.dart'


def lib_snapshot(root):
    return {str(p.relative_to(root)): audit.digest(p.read_bytes())
            for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'harness', 'negative-harness', 'flutter', 'shared-runtime', 'positive-receipt', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--service-before', default='fad903782ee45031e26c57cc8a65ccf476b1724d')
    args = parser.parse_args()
    repo, harness, negative, sdk, shared, positive_path, out = (
        getattr(args, k).resolve() for k in ('repo', 'harness', 'negative_harness', 'flutter',
                                            'shared_runtime', 'positive_receipt', 'output'))
    if out.exists() or negative.exists():
        raise ValueError('Use fresh negative harness and output paths')
    if audit.git(repo, 'rev-parse', 'HEAD') != args.source_commit:
        raise ValueError('Final source checkout differs from requested source')
    positive = json.loads(positive_path.read_text())
    if positive['status'] != 'passed' or positive['source_commit'] != args.source_commit:
        raise ValueError('A successful same-source positive run is required first')
    subprocess.run(['git', 'diff', '--exit-code', args.source_commit, '--', 'lib', 'packages',
                    'test', 'tool', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'],
                   cwd=repo, check=True)
    positive_source = json.loads((positive_path.parent / 'source-after.json').read_text())
    if audit.aggregate(positive_source) != positive['source_after_aggregate_sha256']:
        raise ValueError('Positive source fingerprint artifact differs from its receipt')
    for path in (SERVICE, TEST):
        published = subprocess.check_output(['git', 'show', args.source_commit + ':' + path], cwd=repo)
        if (positive_source[path] != audit.digest(published)
                or positive_source[path] != audit.digest((repo / path).read_bytes())):
            raise ValueError('Positive reader/test identity differs from final source: ' + path)
    current_dependencies = audit.dependency_snapshot(harness, sdk, repo)
    if audit.aggregate(current_dependencies) != positive['dependencies_after_aggregate_sha256']:
        raise ValueError('Positive dependency graph changed before the inverse control')
    out.mkdir(parents=True)
    negative.mkdir(parents=True)
    for name in ('pubspec.yaml', 'pubspec.lock'):
        (negative / name).write_bytes((harness / name).read_bytes())
    for name in ('test', 'packages', 'analysis_options.yaml'):
        (negative / name).symlink_to(harness / name, target_is_directory=(harness / name).is_dir())
    before_bytes = subprocess.check_output(['git', 'show', args.service_before + ':' + SERVICE], cwd=repo)
    for source in sorted((repo / 'lib').rglob('*')):
        target = negative / source.relative_to(repo)
        if source.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif source.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            if str(source.relative_to(repo)) == SERVICE:
                target.write_bytes(before_bytes)
            else:
                target.symlink_to(source)
    original_graph_path = harness / '.dart_tool/package_config.json'
    graph = json.loads(original_graph_path.read_text())
    for entry in graph['packages']:
        root = negative if entry['name'] == 'crisp_cloud' else audit.resolve(original_graph_path, entry['rootUri'])
        entry['rootUri'] = root.as_uri() + '/'
    audit.save(negative / '.dart_tool/package_config.json', graph)
    (negative / '.dart_tool/package_graph.json').write_bytes((harness / '.dart_tool/package_graph.json').read_bytes())
    final_lib = lib_snapshot(repo / 'lib')
    negative_lib_before = lib_snapshot(negative / 'lib')
    differences = [p for p in set(final_lib) | set(negative_lib_before)
                   if final_lib.get(p) != negative_lib_before.get(p)]
    if differences != ['services/office_document_service.dart']:
        raise ValueError('Inverse control must differ in exactly the reader source')
    source_before = audit.source_snapshot(repo)
    deps_before = audit.dependency_snapshot(negative, sdk, negative)
    audit.save(out / 'source-before.json', source_before)
    audit.save(out / 'dependencies-before.json', deps_before)
    audit.save(out / 'negative-library-before.json', negative_lib_before)
    (out / 'reader-before.dart').write_bytes(before_bytes)
    env = dict(os.environ, FLUTTER_ROOT=str(sdk), PUB_CACHE=str(shared / 'pub-cache'),
               XDG_CONFIG_HOME=str(shared / 'config'), TMPDIR=str(shared / 'tmp'),
               FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true', CI='true')
    env['PATH'] = str(sdk / 'bin') + os.pathsep + env.get('PATH', '')
    command = [str(sdk / 'bin/cache/dart-sdk/bin/dart'), str(sdk / 'bin/cache/flutter_tools.snapshot'),
               'test', '--no-pub', '--concurrency=1', '--reporter=json', TEST]
    receipt = {
        'schema_version': 1, 'kind': 'one-file inverse annotation control', 'status': 'running',
        'started_utc': audit.now(), 'source_commit': args.source_commit,
        'reader_before_commit': args.service_before,
        'reader_before_blob': audit.git(repo, 'rev-parse', args.service_before + ':' + SERVICE),
        'reader_final_blob': audit.git(repo, 'rev-parse', args.source_commit + ':' + SERVICE),
        'reader_before_sha256': audit.digest(before_bytes),
        'test_blob': audit.git(repo, 'rev-parse', args.source_commit + ':' + TEST),
        'test_sha256': audit.digest((repo / TEST).read_bytes()),
        'positive_reader_sha256': positive_source[SERVICE],
        'positive_test_sha256': positive_source[TEST],
        'positive_reader_test_and_dependencies_reverified': True,
        'positive_receipt_sha256': audit.digest(positive_path.read_bytes()),
        'runner_sha256': audit.digest(Path(__file__).read_bytes()),
        'exactly_one_library_source_difference': differences,
        'all_other_library_files_match_final_source': True,
        'command': command, 'cwd': str(negative), 'runtime_tests_are_expected_to_fail': True,
        'github_actions_or_status_queried': False, 'github_actions_awaited': False,
    }
    save = lambda: audit.save(out / 'receipt.json', receipt)
    save()
    started = time.monotonic()
    log = out / 'annotation-negative.log'
    with log.open('w') as stream:
        process = subprocess.Popen(command, cwd=negative, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            while process.poll() is None:
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - started
                    print(json.dumps({'active': 'annotation-negative', 'seconds': round(elapsed), 'log_bytes': log.stat().st_size}), flush=True)
                    if elapsed > 600:
                        receipt['timed_out'] = True
                        audit.stop_owned_process_group(process)
                        break
        finally:
            if process.poll() is None:
                audit.stop_owned_process_group(process)
    terminal = focused.json_test_results(log)
    audit.save(out / 'test-terminal-events.json', terminal)
    source_after = audit.source_snapshot(repo)
    deps_after = audit.dependency_snapshot(negative, sdk, negative)
    negative_lib_after = lib_snapshot(negative / 'lib')
    audit.save(out / 'source-after.json', source_after)
    audit.save(out / 'dependencies-after.json', deps_after)
    audit.save(out / 'negative-library-after.json', negative_lib_after)
    errors = []
    for line in log.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('type') == 'error':
            errors.append(event)
    assertion_failures = bool(errors) and all(x.get('isFailure') is True for x in errors)
    receipt.update(exit_code=process.returncode, duration_seconds=round(time.monotonic() - started, 3),
        finished_utc=audit.now(), log_sha256=audit.digest(log.read_bytes()),
        test_counts={k: v for k, v in terminal.items() if k != 'records'},
        all_errors_are_test_assertion_failures=assertion_failures,
        source_unchanged=source_before == source_after, dependencies_unchanged=deps_before == deps_after,
        inverse_library_unchanged=negative_lib_before == negative_lib_after,
        head_at_completion=audit.git(repo, 'rev-parse', 'HEAD'))
    receipt['expected_failure_observed'] = (process.returncode == 1 and terminal['failed'] > 0
        and terminal['passed'] + terminal['failed'] == 8 and terminal['skipped'] == 0
        and len(terminal['completion_events']) == 1 and terminal['completion_events'][0].get('success') is False
        and terminal['all_terminal_tests_had_start'] and terminal['all_started_tests_terminated']
        and not terminal['duplicate_start_ids'] and not terminal['duplicate_terminal_ids']
        and assertion_failures and not receipt.get('timed_out', False))
    receipt['status'] = 'expected failure verified' if all(receipt[k] for k in (
        'expected_failure_observed', 'source_unchanged', 'dependencies_unchanged', 'inverse_library_unchanged')) else 'control unsuccessful'
    save()
    print(json.dumps({'status': receipt['status'], 'test_counts': receipt['test_counts']}), flush=True)
    return 0 if receipt['status'] == 'expected failure verified' else 1


if __name__ == '__main__':
    raise SystemExit(main())
