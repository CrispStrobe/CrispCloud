#!/usr/bin/env python3
"""Qualify an immutable host source through the production-bound locked wrapper.

The previous reviewed runner supplies input-fingerprint helpers. This runner
adds current annotation coverage, retains the small Zotero cohort, and records
JSON terminal events without inheriting any previous test totals.
"""
import argparse
from collections import Counter
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('prior_host', HERE / 'prior_host_qualification.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
TESTS = (
    'test/office_annotation_preview_test.dart',
    'test/office_document_service_test.dart',
    'test/office_proofing_licenses_test.dart',
    'test/office_zotero_test.dart',
    'test/office_zotero_citing_transport_test.dart',
    'test/office_zotero_ribbon_test.dart',
)
TARGETS = (
    'lib/services/office_document_service.dart',
    'lib/services/office_proofing_licenses.dart',
    'test/office_annotation_preview_test.dart',
    'test/office_proofing_licenses_test.dart',
)
audit.TESTS = TESTS


def json_test_results(log):
    starts, start_ids, suites, ends, completions, ignored = {}, [], {}, [], [], 0
    for line in log.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            ignored += 1
            continue
        kind = event.get('type')
        if kind == 'testStart':
            start_ids.append(event['test']['id'])
            starts[event['test']['id']] = event['test']
        elif kind == 'suite':
            suites[event['suite']['id']] = event['suite']
        elif kind == 'testDone':
            ends.append(event)
        elif kind == 'done':
            completions.append(event)
    records = []
    for event in ends:
        test = starts.get(event['testID'], {})
        name = test.get('name', '')
        administrative = (event.get('hidden', False) or name.startswith('loading ')
                          or name.endswith('(setUpAll)') or name.endswith('(tearDownAll)'))
        records.append({
            'id': event['testID'], 'name': name,
            'suite': suites.get(test.get('suiteID'), {}).get('path'),
            'result': event.get('result'), 'skipped': event.get('skipped', False),
            'hidden': event.get('hidden', False), 'administrative': administrative,
        })
    substantive = [x for x in records if not x['administrative']]
    terminal_ids = [x['testID'] for x in ends]
    return {
        'passed': sum(x['result'] == 'success' and not x['skipped'] for x in substantive),
        'failed': sum(x['result'] != 'success' and not x['skipped'] for x in substantive),
        'skipped': sum(x['skipped'] for x in substantive),
        'terminal_events': len(records), 'substantive_events': len(substantive),
        'administrative_events': len(records) - len(substantive),
        'unparsed_log_lines': ignored, 'completion_events': completions,
        'all_terminal_tests_had_start': all(x['testID'] in starts for x in ends),
        'all_started_tests_terminated': set(start_ids) == set(terminal_ids),
        'duplicate_start_ids': [k for k, n in Counter(start_ids).items() if n > 1],
        'duplicate_terminal_ids': [k for k, n in Counter(terminal_ids).items() if n > 1],
        'records': records,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'harness', 'quds-source', 'parser-source', 'flutter', 'shared-runtime', 'setup-receipt', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--quds-commit', required=True)
    parser.add_argument('--baseline', default='fad903782ee45031e26c57cc8a65ccf476b1724d')
    args = parser.parse_args()
    repo, harness, quds, legacy, sdk, shared, setup_path, out = (
        getattr(args, x).resolve() for x in ('repo', 'harness', 'quds_source', 'parser_source',
                                            'flutter', 'shared_runtime', 'setup_receipt', 'output'))
    if out.exists():
        raise ValueError('Use a fresh qualification output directory')
    out.mkdir(parents=True)
    receipt = {
        'schema_version': 1, 'status': 'initializing', 'started_utc': audit.now(),
        'repository': 'CrispStrobe/CrispCloud', 'source_commit': args.source_commit,
        'canonical_source_commit': args.quds_commit, 'source_repo': str(repo),
        'harness': str(harness), 'setup_receipt_sha256': audit.digest(setup_path.read_bytes()),
        'runner_sha256': audit.digest(Path(__file__).read_bytes()),
        'prior_fingerprint_helper_sha256': audit.digest((HERE / 'prior_host_qualification.py').read_bytes()),
        'tests': list(TESTS), 'analysis_and_format_targets': list(TARGETS), 'commands': [],
        'historical_counts_reused': False, 'github_actions_or_status_queried': False,
        'github_actions_awaited': False,
        'limitations': ['Focused genuine-source locked dependency graph, not a full application dependency resolution or build.',
                       'No live Zotero account, Word/LibreOffice, native/Wasm Harper, or full viewer/export-dialog acceptance.'],
    }
    save = lambda: audit.save(out / 'receipt.json', receipt)
    save()
    target = repo / '.dart_tool/package_config.json'
    previous = None
    previous_mode = None
    installed_graph = False
    source_before = deps_before = None
    process = None
    env = dict(os.environ, FLUTTER_ROOT=str(sdk), PUB_CACHE=str(shared / 'pub-cache'),
               XDG_CONFIG_HOME=str(shared / 'config'), TMPDIR=str(shared / 'tmp'),
               FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true', CI='true')
    env['PATH'] = str(sdk / 'bin') + os.pathsep + env.get('PATH', '')
    dart = str(sdk / 'bin/cache/dart-sdk/bin/dart')
    flutter = [dart, str(sdk / 'bin/cache/flutter_tools.snapshot')]

    def interrupted(signum, frame):
        raise InterruptedError(f'Received signal {signum}')

    signal.signal(signal.SIGTERM, interrupted)

    def run(name, command, cwd):
        nonlocal process
        log = out / (name + '.log')
        row = {'name': name, 'command': command, 'cwd': str(cwd),
               'started_utc': audit.now(), 'log': log.name, 'status': 'running'}
        receipt['commands'].append(row)
        receipt.update(status='running', active_command=name)
        save()
        started = time.monotonic()
        with log.open('w') as stream:
            process = subprocess.Popen(command, cwd=cwd, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            row['pid'] = process.pid
            save()
            while process.poll() is None:
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - started
                    print(json.dumps({'active': name, 'seconds': round(elapsed), 'log_bytes': log.stat().st_size}), flush=True)
                    if elapsed > 600:
                        audit.stop_owned_process_group(process)
                        row['timed_out'] = True
                        break
        row.update(exit_code=process.returncode, duration_seconds=round(time.monotonic() - started, 3),
                   finished_utc=audit.now(), log_sha256=audit.digest(log.read_bytes()))
        row['status'] = 'passed' if row['exit_code'] == 0 and not row.get('timed_out') else 'failed'
        process = None
        save()
        print(json.dumps({k: row[k] for k in ('name', 'status', 'exit_code')}), flush=True)
        return row

    try:
        setup = json.loads(setup_path.read_text())
        if setup['status'] != 'passed' or Path(setup['harness']).resolve() != harness:
            raise ValueError('A completed matching locked setup is required')
        if setup['production_lock_sha256'] != audit.digest((repo / 'pubspec.lock').read_bytes()):
            raise ValueError('Production lock differs from resolved wrapper')
        if setup['final_lock_sha256'] != audit.digest((harness / 'pubspec.lock').read_bytes()):
            raise ValueError('Wrapper lock differs from setup receipt')
        if audit.git(repo, 'rev-parse', 'HEAD') != args.source_commit:
            raise ValueError('Host checkout differs from requested immutable source')
        manifest = json.loads((repo / 'tool/office_fidelity_manifest.json').read_text())
        if manifest['source_commit'] != args.quds_commit:
            raise ValueError('Canonical source differs from host pin')
        roots = ['lib', 'packages', 'tool', 'test', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml']
        subprocess.run(['git', 'diff', '--exit-code', args.source_commit, '--', *roots], cwd=repo, check=True)
        for path in TESTS:
            if (harness / path).resolve() != repo / path:
                raise ValueError('Test is not linked to actual host source: ' + path)
        receipt.update(host_tree=audit.git(repo, 'rev-parse', 'HEAD^{tree}'),
                       canonical_tree=audit.git(quds, 'rev-parse', args.quds_commit + '^{tree}'),
                       parser_source=audit.git(legacy, 'rev-parse', 'HEAD'),
                       managed_files=len(manifest['files']),
                       runtime=json.loads((sdk / 'bin/cache/flutter.version.json').read_text()))
        source_before = audit.source_snapshot(repo)
        deps_before = audit.dependency_snapshot(harness, sdk, repo)
        audit.save(out / 'source-before.json', source_before)
        audit.save(out / 'dependencies-before.json', deps_before)
        config = harness / '.dart_tool/package_config.json'
        graph = json.loads(config.read_text())
        for entry in graph['packages']:
            name = entry['name']
            root = repo if name == 'crisp_cloud' else (repo / 'packages' / name if name in audit.PACKAGES else audit.resolve(config, entry['rootUri']))
            entry['rootUri'] = root.as_uri() + '/'
        previous = target.read_bytes() if target.exists() else None
        previous_mode = stat.S_IMODE(target.stat().st_mode) if target.exists() else None
        receipt.update(analysis_config_preexisting=previous is not None,
                       analysis_config_before_sha256=audit.digest(previous) if previous is not None else None,
                       analysis_config_before_mode=previous_mode)
        if previous is not None:
            audit.write_atomic(out / 'analysis-config-before.bin', previous)
        audit.write_atomic(target, (json.dumps(graph, indent=2) + '\n').encode())
        installed_graph = True
        audit.save(out / 'analysis-package-config.json', graph)
        save()
        guard = [sys.executable, 'tool/verify_office_fidelity.py', '--source', str(quds),
                 '--legacy-source', str(legacy), '--require-tracked']
        run('vendor-before', guard, repo)
        run('host-tests', [*flutter, 'test', '--no-pub', '--concurrency=1', '--reporter=json', *TESTS], harness)
        terminal = json_test_results(out / 'host-tests.log')
        audit.save(out / 'test-terminal-events.json', terminal)
        receipt['test_counts'] = {k: v for k, v in terminal.items() if k != 'records'}
        run('host-analysis', [dart, 'analyze', '--fatal-infos', *TARGETS], repo)
        run('host-format', [dart, 'format', '--output=none', '--set-exit-if-changed', *TARGETS], repo)
        run('python-vendor-tests', [sys.executable, '-m', 'unittest', 'test_sync_office_fidelity',
                                  'test_sync_legacy_doc_parser', '-v'], repo / 'tool')
        run('whitespace', ['git', 'diff', '--check', args.baseline, args.source_commit, '--', *roots], repo)
        run('vendor-after', guard, repo)
        receipt['all_commands_passed'] = all(x['status'] == 'passed' for x in receipt['commands'])
        receipt['test_stream_complete'] = (len(terminal['completion_events']) == 1
            and terminal['completion_events'][-1].get('success') is True
            and terminal['all_terminal_tests_had_start'] and terminal['all_started_tests_terminated']
            and not terminal['duplicate_start_ids'] and not terminal['duplicate_terminal_ids']
            and terminal['passed'] > 0
            and terminal['failed'] == 0 and terminal['skipped'] == 0)
    except BaseException as error:
        receipt['error'] = f'{type(error).__name__}: {error}'
        if process is not None:
            audit.stop_owned_process_group(process)
        receipt['all_commands_passed'] = False
    finally:
        if installed_graph:
            if previous is None:
                target.unlink(missing_ok=True)
            else:
                audit.write_atomic(target, previous)
                target.chmod(previous_mode)
            receipt['analysis_config_restored'] = (not target.exists() if previous is None else
                target.read_bytes() == previous and stat.S_IMODE(target.stat().st_mode) == previous_mode)
        if source_before is not None and deps_before is not None:
            after = audit.source_snapshot(repo)
            deps_after = audit.dependency_snapshot(harness, sdk, repo)
            audit.save(out / 'source-after.json', after)
            audit.save(out / 'dependencies-after.json', deps_after)
            receipt.update(source_unchanged=source_before == after, dependencies_unchanged=deps_before == deps_after,
                source_file_count=len(source_before), dependency_file_count=len(deps_before['dependency_files']),
                source_before_aggregate_sha256=audit.aggregate(source_before), source_after_aggregate_sha256=audit.aggregate(after),
                dependencies_before_aggregate_sha256=audit.aggregate(deps_before), dependencies_after_aggregate_sha256=audit.aggregate(deps_after))
        receipt['head_at_completion'] = audit.git(repo, 'rev-parse', 'HEAD')
        receipt['tracked_inputs_unchanged'] = subprocess.run(
            ['git', 'diff', '--quiet', args.source_commit, '--', 'lib', 'packages', 'tool', 'test',
             'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'], cwd=repo).returncode == 0
        receipt['finished_utc'] = audit.now()
        checks = ['all_commands_passed', 'test_stream_complete', 'analysis_config_restored',
                  'source_unchanged', 'dependencies_unchanged', 'tracked_inputs_unchanged']
        receipt['status'] = 'passed' if all(receipt.get(k) is True for k in checks) else 'failed'
        save()
    print(json.dumps({'status': receipt['status'], 'source': args.source_commit,
                      'test_counts': receipt.get('test_counts'), 'error': receipt.get('error')}), flush=True)
    return int(receipt['status'] != 'passed')


if __name__ == '__main__':
    raise SystemExit(main())
