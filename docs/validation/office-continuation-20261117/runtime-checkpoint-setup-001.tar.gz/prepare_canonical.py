#!/usr/bin/env python3
"""Prepare an isolated canonical workspace with unchanged production manifests."""
from pathlib import Path
import hashlib
import json
import subprocess

RUNTIME = Path(__file__).resolve().parent
REPO = RUNTIME.parent / "quds_office_suite"
TARGET = RUNTIME / "canonical-workspace"
PACKAGES = [
    "packages/legacy_doc_parser",
    "packages/quds_office_engine",
    "packages/quds_proofing_harper",
    "packages/quds_office_engine/example",
    "packages/quds_reports",
    "packages/quds_office_editor",
    "packages/quds_office_editor/example",
    "apps/quds_report_studio",
]
LOCK_SHA256 = "344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not TARGET.exists(), "Refuse to replace an existing canonical workspace"
    lock = REPO / "docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock"
    assert sha(lock) == LOCK_SHA256, "Recorded full-workspace lock changed"
    TARGET.mkdir()
    inputs = {}
    links = []
    for name in ["pubspec.yaml", "analysis_options.yaml"]:
        (TARGET / name).write_bytes((REPO / name).read_bytes())
        inputs[name] = sha(TARGET / name)
    (TARGET / "pubspec.lock").write_bytes(lock.read_bytes())
    inputs["pubspec.lock"] = sha(TARGET / "pubspec.lock")
    excluded = {".dart_tool", "build", ".git", "pubspec.lock", "pubspec.yaml", "pubspec_overrides.yaml"}
    for rel in PACKAGES:
        source = REPO / rel
        target = TARGET / rel
        target.mkdir(parents=True, exist_ok=True)
        (target / "pubspec.yaml").write_bytes((source / "pubspec.yaml").read_bytes())
        inputs[rel + "/pubspec.yaml"] = sha(target / "pubspec.yaml")
        for child in sorted(source.iterdir()):
            if child.name in excluded or str(child.relative_to(REPO)) in PACKAGES:
                continue
            destination = target / child.name
            destination.symlink_to(child, target_is_directory=child.is_dir())
            links.append({"path": str(destination.relative_to(TARGET)), "source": str(child)})
    receipt = {
        "kind": "Canonical workspace preparation; no test result",
        "source_commit_at_setup": subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip(),
        "repo": str(REPO),
        "workspace": str(TARGET),
        "inputs_sha256": inputs,
        "source_links": links,
        "published_lock_source": str(lock.relative_to(REPO)),
        "published_lock_sha256": LOCK_SHA256,
        "dependency_constraints_modified": False,
        "production_files_modified": False,
        "tests_run": False,
    }
    (RUNTIME / "canonical-setup.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "prepared", "workspace": str(TARGET), "inputs": len(inputs), "source_links": len(links)}))


if __name__ == "__main__":
    main()
