#!/usr/bin/env python3
"""Run a named host regression cohort and preserve exact local evidence."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('tests', nargs='+')
parser.add_argument('--plain-name')
args = parser.parse_args()
base = Path(__file__).resolve().parent.parent
runtime = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
out = Path(__file__).resolve().parent
host = base / 'CrispCloud'
sdk = runtime / 'flutter-sdk'
paths = [
    'lib/services/office_document_service.dart',
    'lib/services/archive_viewer_service.dart',
    'packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart',
    'packages/quds_office_engine/lib/src/word/serial/word_deserializer.dart',
    *args.tests,
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    return {p: digest(host / p) for p in paths}

env = os.environ.copy()
env.update(
    FLUTTER_ROOT=str(sdk), PUB_CACHE=str(runtime / 'pub-cache'), CI='true',
    FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true',
    XDG_CONFIG_HOME=str(runtime / 'config'), TMPDIR=str(runtime / 'tmp'),
)
command = [str(sdk / 'bin/cache/dart-sdk/bin/dart'),
           str(sdk / 'bin/cache/flutter_tools.snapshot'), 'test', '--no-pub',
           '--concurrency=1', '--reporter=json', *args.tests]
if args.plain_name:
    command += ['--plain-name', args.plain_name]
record = {
    'command': command, 'cwd': str(base / 'host-harness'),
    'source_head': subprocess.check_output(
        ['git', '-C', str(host), 'rev-parse', 'HEAD'], text=True).strip(),
    'source_is_clean': subprocess.check_output(
        ['git', '-C', str(host), 'status', '--porcelain'], text=True).strip() == '',
    'before': snapshot(),
    'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'package_config_sha256': digest(base / 'host-harness/.dart_tool/package_config.json'),
    'package_lock_sha256': digest(base / 'host-harness/pubspec.lock'),
}
json_path = out / f'{args.name}-result.json'
assert not json_path.exists(), f'Refuse to replace evidence: {json_path}'
json_path.write_text(json.dumps(record, indent=2) + '\n')
stdout = out / f'{args.name}.stdout.jsonl'
stderr = out / f'{args.name}.stderr.log'
with stdout.open('w') as stdout_stream, stderr.open('w') as stderr_stream:
    process = subprocess.run(command, cwd=base / 'host-harness', env=env,
                             stdout=stdout_stream, stderr=stderr_stream)
record.update(exit_code=process.returncode, after=snapshot(),
              finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
json_path.write_text(json.dumps(record, indent=2) + '\n')
events = [json.loads(line) for line in stdout.read_text().splitlines()
          if line.startswith('{')]
results = [event for event in events
           if event.get('type') == 'testDone' and not event.get('hidden')]
print(json.dumps({'evidence': str(json_path), 'exit_code': process.returncode,
                  'unchanged_inputs': record['before'] == record['after'],
                  'passed': sum(event['result'] == 'success' and not event['skipped']
                                for event in results),
                  'failed': sum(event['result'] != 'success' for event in results),
                  'skipped': sum(event['skipped'] for event in results),
                  'errors': [event for event in events if event.get('type') == 'error']},
                 indent=2))
print(stderr.read_text())
