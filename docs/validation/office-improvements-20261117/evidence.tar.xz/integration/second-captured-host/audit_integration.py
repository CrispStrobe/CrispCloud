#!/usr/bin/env python3
"""Snapshot bounded host arrivals and validate a restoration plan without edits.

This script writes evidence only beneath its own directory. It never changes
the product checkout or index. Pass --canonical-ref after the combined source
is committed to compare its exact retained incoming paths and source ancestry.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


BASE = '03625b95ed74df6c8df44a4111e1760985e53ce3'
OLD_MAIN = '0b0557a99c6e5fe6f0b4db1c50bfb12ac5320817'
INCOMING = '78a4ccbbcf320add0830f3c158e385a6b2eb061e'
INVENTORY = '0b0557a99c6e5fe6f0b4db1c50bfb12ac5320817'
MANIFEST = 'tool/office_fidelity_manifest.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def blob(repo, ref, name):
    return git(repo, 'show', ref + ':' + name)


def tree(repo, ref):
    result = {}
    for item in git(repo, 'ls-tree', '-r', '-z', ref).split(b'\0'):
        if item:
            metadata, name = item.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            result[name.decode()] = {'mode': mode, 'kind': kind, 'blob': oid}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--canonical-ref')
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    host, canonical = workspace / 'CrispCloud', workspace / 'quds_office_suite'
    output = Path(__file__).resolve().parent
    plan_path = output / 'restoration-plan.json'
    source_tree, incoming_tree = tree(host, BASE), tree(host, INCOMING)
    base_manifest = json.loads(blob(host, BASE, MANIFEST))
    incoming_manifest = json.loads(blob(host, INCOMING, MANIFEST))
    original_manifest = json.loads(blob(host, OLD_MAIN, MANIFEST))
    managed_arrivals = sorted(
        path for path in set(original_manifest['files']) | set(incoming_manifest['files'])
        if original_manifest['files'].get(path) != incoming_manifest['files'].get(path)
    )
    assert len(managed_arrivals) == 10, managed_arrivals

    if not plan_path.exists():
        index_before = git(host, 'ls-files', '--stage', '-z')
        observed_head = git(host, 'rev-parse', 'HEAD').decode().strip()
        merge_head = git(host, 'rev-parse', 'MERGE_HEAD').decode().strip()
        assert merge_head == INCOMING
        non_documentation = [name for name in git(host, 'diff', '--name-only', BASE, observed_head).decode().splitlines()
                             if not name.startswith('docs/')]
        assert not non_documentation, non_documentation
        changed = git(host, 'diff', '--name-only', OLD_MAIN, INCOMING).decode().splitlines()
        snapshots = []
        for label, ref in (('incoming-main', INCOMING), ('qualified-base', BASE)):
            inventory = incoming_tree if label == 'incoming-main' else source_tree
            for name in sorted(set(changed) | {MANIFEST}):
                if name not in inventory:
                    continue
                data = blob(host, ref, name)
                target = output / label / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                snapshots.append({'snapshot': str(target.relative_to(output)), 'source_ref': ref,
                                  'source_path': name, 'sha256': digest(data), 'bytes': len(data),
                                  **inventory[name]})
        current = []
        for name in sorted(set(managed_arrivals) | {MANIFEST, 'packages/QUDS_FORKS.md'}):
            path = host / name
            assert path.is_file() and not path.is_symlink()
            data = path.read_bytes()
            target = output / 'merged-working-snapshot' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            current.append({'path': name, 'sha256': digest(data), 'bytes': len(data),
                            'snapshot': str(target.relative_to(output))})

        base_canonical_tree = tree(canonical, base_manifest['source_commit'])
        restores = []
        checked = 0
        for name, expected in base_manifest['files'].items():
            path = host / name
            assert path.is_file() and not path.is_symlink(), name
            assert path.resolve().is_relative_to(host), name
            current_data = path.read_bytes()
            source = blob(host, BASE, name)
            assert digest(source) == expected, name
            if not name.startswith('packages/legacy_doc_parser/'):
                assert source_tree[name]['blob'] == base_canonical_tree[name]['blob'], name
            if digest(current_data) != expected:
                assert name in managed_arrivals, 'Unexpected managed drift: ' + name
                restores.append({'path': name, 'current_sha256': digest(current_data),
                                 'restore_sha256': expected, 'restore_git_blob': source_tree[name]['blob'],
                                 'restore_git_mode': source_tree[name]['mode'], 'restore_from': BASE,
                                 'preserved_current_snapshot': 'merged-working-snapshot/' + name})
            checked += 1
        new_paths = [name for name in managed_arrivals if name not in base_manifest['files']]
        assert len(restores) == 2 and len(new_paths) == 1, (restores, new_paths)
        index_after = git(host, 'ls-files', '--stage', '-z')
        assert index_before == index_after, 'Concurrent index mutation during capture'
        (output / 'index-before-restoration.bin').write_bytes(index_before)
        plan = {
            'recorded_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'validated_plan_not_executed', 'host_index_unchanged_by_audit': True,
            'observed_head': observed_head, 'qualified_base': BASE, 'incoming_inventory': INVENTORY,
            'incoming_main': INCOMING, 'previous_main': OLD_MAIN,
            'current_merge_head': merge_head, 'base_canonical_pin': base_manifest['source_commit'],
            'incoming_canonical_pin': incoming_manifest['source_commit'],
            'managed_arrivals': managed_arrivals, 'checked_base_manifest_files': checked,
            'restore_managed_files': restores,
            'restore_manifest': {'path': MANIFEST, 'from': BASE,
                                 'sha256': digest(blob(host, BASE, MANIFEST)),
                                 'reason': 'Restore the authenticated guarded-sync precondition, then regenerate from the committed combined canonical source.'},
            'retain_new_paths': new_paths,
            'new_path_gate': 'Do not remove the incoming new test. Require its bytes to equal the final canonical target before guarded sync; otherwise reconcile it explicitly.',
            'preserved_snapshots': snapshots, 'merged_working_files': current,
            'index_sha256': digest(index_before),
            'execution_preconditions': [
                'Match every current_sha256 and the unresolved manifest snapshot before any restoration; stop on unexpected source movement.',
                'All 2,611 base manifest entries were authenticated; only the two listed managed paths differ. Restoring those and the exact base manifest satisfies the existing-file hash precondition.',
                'Restore file content only to the authenticated base blobs; preserve recorded executable modes.',
                'Use the existing guarded sync against an immutable committed combined canonical SHA; retain its dry-run and applied receipts.',
                'Resolve QUDS_FORKS prose separately using the final manifest pin and counts; preserve additive incoming documentation and evidence.',
                'Require the tracked vendor verifier and full frozen host qualification after sync; prior qualification does not cover the combined source.',
            ],
        }
        plan_path.write_text(json.dumps(plan, indent=2, sort_keys=True) + '\n')
    else:
        plan = json.loads(plan_path.read_text())

    if args.canonical_ref:
        ref = git(canonical, 'rev-parse', args.canonical_ref + '^{commit}').decode().strip()
        final_tree = tree(canonical, ref)
        retention = []
        for name in managed_arrivals:
            incoming = blob(host, INCOMING, name)
            final = blob(canonical, ref, name)
            retention.append({'path': name, 'incoming_sha256': digest(incoming),
                              'canonical_sha256': digest(final),
                              'byte_identical': incoming == final,
                              'incoming_blob': incoming_tree[name]['blob'],
                              'canonical_blob': final_tree[name]['blob'],
                              'requires_combination_review': incoming != final})
        ancestor = subprocess.run(['git', '-C', str(canonical), 'merge-base', '--is-ancestor',
                                  incoming_manifest['source_commit'], ref], capture_output=True)
        report = {'recorded_utc': datetime.now(timezone.utc).isoformat(),
                  'canonical_ref': ref, 'incoming_main': INCOMING,
                  'incoming_canonical_pin': incoming_manifest['source_commit'],
                  'incoming_pin_is_ancestor': ancestor.returncode == 0,
                  'managed_retention': retention,
                  'scope': 'Exact blob comparison and ancestry. Nonidentical combined writer paths require independent source review and source-bound regression qualification.'}
        (output / ('canonical-retention-' + ref[:8] + '.json')).write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
        print(json.dumps(report, indent=2))
    else:
        print(json.dumps({'status': plan['status'], 'observed_head': plan['observed_head'],
                          'managed_arrivals': plan['managed_arrivals'],
                          'restore_paths': [row['path'] for row in plan['restore_managed_files']],
                          'retain_new_paths': plan['retain_new_paths'],
                          'checked_base_manifest_files': plan['checked_base_manifest_files']}, indent=2))


if __name__ == '__main__':
    main()
