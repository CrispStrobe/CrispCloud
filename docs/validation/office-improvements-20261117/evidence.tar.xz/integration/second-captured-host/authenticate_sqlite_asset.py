#!/usr/bin/env python3
"""Authenticate SQLite's unmodified default workflow hook input; never execute it."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import re
import urllib.request
import yaml


BASE = Path(__file__).resolve().parents[2]
EVIDENCE = Path(__file__).resolve().parent / 'sqlite-native-asset'
CACHE = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/pub-cache')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    EVIDENCE.mkdir(exist_ok=False)
    spec = yaml.safe_load((BASE / 'CrispCloud/pubspec.lock').read_text())['packages']['sqlite3']
    assert spec['source'] == 'hosted' and spec['version'] == '3.3.3'
    root = CACHE / 'hosted/pub.dev' / ('sqlite3-' + spec['version'])
    marker = CACHE / 'hosted-hashes/pub.dev' / ('sqlite3-' + spec['version'] + '.sha256')
    assert marker.read_text().strip() == spec['description']['sha256']
    hashes = (root / 'lib/src/hook/asset_hashes.dart').read_text()
    tag = re.search(r"releaseTag = '([^']+)'", hashes).group(1)
    filename = 'libsqlite3.x64.linux.so'
    expected = re.search(r"'" + re.escape(filename) + r"': '([0-9a-f]{64})'", hashes).group(1)
    assert expected == 'e184f6ba2b7a3440e272df64c6d038de5c7b1a997b7c2f9341164602f9bdf024'
    assert platform.system() == 'Linux' and platform.machine() in ('x86_64', 'amd64')
    url = 'https://github.com/simolus3/sqlite3.dart/releases/download/' + tag + '/' + filename
    report = {
        'started_utc': datetime.now(timezone.utc).isoformat(), 'status': 'downloading',
        'package_version': spec['version'], 'package_archive_sha256': spec['description']['sha256'],
        'source_url': url, 'expected_binary_sha256': expected,
        'platform': {'system': platform.system(), 'machine': platform.machine()},
        'hook_inputs': {str(path.relative_to(root)): digest(path.read_bytes())
                        for path in [root / 'hook/build.dart', root / 'lib/src/hook/description.dart',
                                     root / 'lib/src/hook/assets.dart', root / 'lib/src/hook/asset_hashes.dart',
                                     root / 'lib/src/hook/utils.dart', root / 'lib/src/hook/used_symbols.dart']},
        'scope': 'Downloads and hashes the exact default Linux x64 SQLite release asset named by the production-pinned package. No code is executed; no hook or source configuration is changed.',
    }
    try:
        with urllib.request.urlopen(url, timeout=45) as response:
            payload = response.read()
            report['http_status'] = response.status
        actual = digest(payload)
        assert actual == expected, (actual, expected)
        assert payload.startswith(b'\x7fELF')
        target = EVIDENCE / filename
        target.write_bytes(payload)
        report.update(status='authenticated', bytes=len(payload), actual_binary_sha256=actual,
                      saved_path=str(target), finished_utc=datetime.now(timezone.utc).isoformat())
    except BaseException as error:
        report.update(status='failed', error=repr(error), finished_utc=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        (EVIDENCE / 'receipt.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report[key] for key in ['status', 'bytes', 'actual_binary_sha256', 'saved_path']}, indent=2))


if __name__ == '__main__':
    main()
