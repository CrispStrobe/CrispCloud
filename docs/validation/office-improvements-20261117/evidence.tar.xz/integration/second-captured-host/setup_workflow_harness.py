#!/usr/bin/env python3
"""Provision a separate real-source workflow graph using production archive pins.

This does not run tests, edit product sources, or alter the existing host harness.
The optional Rust transport is outside the authored fake-cloud workflow scope;
its unmodified hook is retained, without enabling the app's rust_smb define.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import urllib.request
import yaml


BASE = Path(__file__).resolve().parents[2]
SOURCE = BASE / 'CrispCloud'
PRIOR = BASE / 'host-harness'
TARGET = BASE / 'host-workflow-harness'
EVIDENCE = Path(__file__).resolve().parent / 'workflow-harness-setup'
RUNTIME = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime')
CACHE = RUNTIME / 'pub-cache'
SDK = RUNTIME / 'flutter-sdk'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def profile():
    names = ['pubspec.yaml', 'pubspec.lock', '.dart_tool/package_config.json',
             '.dart_tool/package_graph.json']
    names += [str(p.relative_to(PRIOR)) for p in PRIOR.glob('packages/*/pubspec.yaml')]
    return {name: sha((PRIOR / name).read_bytes()) for name in sorted(names)
            if (PRIOR / name).is_file()}


def sdk_root(name):
    if name == 'sky_engine':
        return SDK / 'bin/cache/pkg/sky_engine'
    return SDK / 'packages' / name


def recover(name, spec):
    key = name + '-' + spec['version']
    expected = spec['description']['sha256']
    target = CACHE / 'hosted/pub.dev' / key
    marker = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
    if target.exists():
        assert marker.is_file() and marker.read_text().strip() == expected, key
        return {'package': name, 'version': spec['version'], 'status': 'existing',
                'archive_sha256': expected, 'cache_root': str(target)}
    assert spec['description']['url'] == 'https://pub.dev'
    url = 'https://pub.dev/api/archives/' + key + '.tar.gz'
    with urllib.request.urlopen(url, timeout=45) as response:
        data = response.read()
    actual = sha(data)
    assert actual == expected, 'Production archive hash mismatch: ' + key
    temporary = CACHE / '_temp' / ('office-workflow-' + key)
    temporary.mkdir(parents=True, exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        archive.extractall(temporary, filter='data')
    temporary.rename(target)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(actual)
    return {'package': name, 'version': spec['version'], 'status': 'downloaded',
            'archive_sha256': actual, 'bytes': len(data), 'url': url,
            'cache_root': str(target)}


def main():
    assert not TARGET.exists(), 'A fresh workflow harness is required'
    assert not EVIDENCE.exists(), 'A fresh setup evidence directory is required'
    EVIDENCE.mkdir(parents=True)
    before = profile()
    receipt = {'status': 'preparing', 'started_utc': datetime.now(timezone.utc).isoformat(),
               'prior_harness_before': before, 'downloads_and_cached_pins': [],
               'source': str(SOURCE), 'target': str(TARGET), 'links': [],
               'package_manifests': {}, 'tested': False,
               'configuration_scope': 'Real menu/dialog/controller workflow with the incoming authored fake-cloud test. The production rust_smb user define is not enabled; the real hook and native sources are retained. Native storage behavior is not qualified.'}
    production_bytes = (SOURCE / 'pubspec.lock').read_bytes()
    production = yaml.safe_load(production_bytes)['packages']
    app_manifest_bytes = (SOURCE / 'pubspec.yaml').read_bytes()
    app_manifest = yaml.safe_load(app_manifest_bytes)
    (EVIDENCE / 'production-pubspec.lock').write_bytes(production_bytes)
    (EVIDENCE / 'production-pubspec.yaml').write_bytes(app_manifest_bytes)
    receipt['production_lock_sha256'] = sha(production_bytes)
    receipt['production_manifest_sha256'] = sha(app_manifest_bytes)
    imports = json.loads((EVIDENCE.parent / 'workflow-import-review.json').read_text())
    direct = set(imports['external_packages']) | {'dart_pdf_editor_assets'}
    previous = yaml.safe_load((PRIOR / 'pubspec.lock').read_text())['packages']
    seen = set()
    pending = set(previous) | direct
    manifests = {}
    dependencies = {}
    try:
        while pending:
            batch = sorted(pending - seen)
            pending.clear()
            if not batch:
                break
            assert all(name in production for name in batch), sorted(set(batch) - set(production))
            with ThreadPoolExecutor(max_workers=6) as executor:
                work = [executor.submit(recover, name, production[name]) for name in batch
                        if production[name]['source'] == 'hosted']
                for future in as_completed(work):
                    record = future.result()
                    receipt['downloads_and_cached_pins'].append(record)
                    if record['status'] == 'downloaded':
                        print('Recovered', record['package'], record['version'], flush=True)
            for name in batch:
                row = production[name]
                if row['source'] == 'hosted':
                    root = CACHE / 'hosted/pub.dev' / (name + '-' + row['version'])
                elif row['source'] == 'path':
                    root = (SOURCE / row['description']['path']).resolve()
                    assert root.is_relative_to(SOURCE)
                elif row['source'] == 'sdk':
                    root = sdk_root(name)
                else:
                    raise RuntimeError('Unresolved production source for ' + name + ': ' + row['source'])
                data = (root / 'pubspec.yaml').read_bytes()
                manifest = yaml.safe_load(data)
                assert manifest['name'] == name
                manifests[name] = {'source': row['source'], 'root': str(root),
                                   'sha256': sha(data), 'bytes': len(data)}
                dependencies[name] = sorted(manifest.get('dependencies', {}))
                pending.update(set(dependencies[name]) - seen)
                seen.add(name)
            write_json(EVIDENCE / 'receipt.json', receipt)

        TARGET.mkdir()
        for name in ('lib', 'test', 'assets'):
            (TARGET / name).symlink_to(SOURCE / name, target_is_directory=True)
            receipt['links'].append({'path': str(TARGET / name), 'target': str(SOURCE / name)})
        local = sorted(name for name in seen if production[name]['source'] == 'path')
        for name in local:
            source = Path(manifests[name]['root'])
            target = TARGET / 'packages' / name
            target.mkdir(parents=True)
            data = (source / 'pubspec.yaml').read_bytes()
            assert b'resolution: workspace' not in data
            (target / 'pubspec.yaml').write_bytes(data)
            receipt['package_manifests'][name] = sha(data)
            for child in source.iterdir():
                if child.name in ('.dart_tool', '.git', 'build', 'pubspec.yaml',
                                  'pubspec.lock', 'pubspec_overrides.yaml'):
                    continue
                (target / child.name).symlink_to(child, target_is_directory=child.is_dir())
                receipt['links'].append({'path': str(target / child.name), 'target': str(child)})

        def requirement(name):
            row = production[name]
            if row['source'] == 'hosted':
                return row['version']
            if row['source'] == 'path':
                return {'path': str(TARGET / 'packages' / name)}
            assert row['source'] == 'sdk'
            return {'sdk': 'flutter'}

        original = yaml.safe_load((PRIOR / 'pubspec.yaml').read_text())
        root_dependencies = (set(original['dependencies']) | direct) - {'flutter_test'}
        manifest = {
            'name': 'crisp_cloud', 'publish_to': 'none',
            'environment': original['environment'],
            'dependencies': {name: requirement(name) for name in sorted(root_dependencies)},
            'dev_dependencies': {name: requirement(name) for name in original['dev_dependencies']},
            'dependency_overrides': {name: requirement(name) for name in sorted(seen)
                                     if production[name]['source'] != 'sdk'},
            'flutter': {**original['flutter'], 'fonts': app_manifest['flutter']['fonts']},
        }
        (TARGET / 'pubspec.yaml').write_text(yaml.safe_dump(manifest, sort_keys=False))
        lock = {'packages': {}, 'sdks': yaml.safe_load((SOURCE / 'pubspec.lock').read_text())['sdks']}
        for name in sorted(seen):
            row = dict(production[name])
            if row['source'] == 'path':
                row['description'] = {'path': str(TARGET / 'packages' / name), 'relative': False}
            if name in root_dependencies:
                row['dependency'] = 'direct main'
            elif name in manifest['dev_dependencies']:
                row['dependency'] = 'direct dev'
            else:
                row['dependency'] = 'transitive'
            lock['packages'][name] = row
        (TARGET / 'pubspec.lock').write_text(yaml.safe_dump(lock, sort_keys=False))
        receipt['package_closure'] = manifests
        receipt['dependency_edges'] = dependencies
        receipt['local_packages'] = local
        receipt['harness_manifest_sha256'] = sha((TARGET / 'pubspec.yaml').read_bytes())
        receipt['seed_lock_sha256'] = sha((TARGET / 'pubspec.lock').read_bytes())
        receipt['prior_harness_after'] = profile()
        assert receipt['prior_harness_after'] == before
        receipt['status'] = 'ready_for_offline_resolution'
        receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
        print('Prepared', len(seen), 'packages with', len(local), 'real local packages', flush=True)
    except BaseException as error:
        receipt['status'] = 'failed'
        receipt['error'] = repr(error)
        raise
    finally:
        receipt['downloads_and_cached_pins'].sort(key=lambda row: row['package'])
        write_json(EVIDENCE / 'receipt.json', receipt)


if __name__ == '__main__':
    main()
