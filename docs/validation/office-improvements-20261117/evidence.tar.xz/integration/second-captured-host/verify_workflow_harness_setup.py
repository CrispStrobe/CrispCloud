#!/usr/bin/env python3
"""Verify the isolated workflow package graph without executing any tests."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.parse import unquote, urljoin, urlparse
import yaml


BASE = Path(__file__).resolve().parents[2]
EVIDENCE = Path(__file__).resolve().parent
HARNESS = BASE / 'host-workflow-harness'
HOST = BASE / 'CrispCloud'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    prepared = json.loads((EVIDENCE / 'workflow-harness-setup-03/receipt.json').read_text())
    resolution = json.loads((EVIDENCE / 'workflow-harness-setup-03/offline-pub-get.json').read_text())
    assert resolution['exit_code'] == 0
    production = yaml.safe_load((HOST / 'pubspec.lock').read_text())['packages']
    locked = yaml.safe_load((HARNESS / 'pubspec.lock').read_text())['packages']
    config = HARNESS / '.dart_tool/package_config.json'
    graph = json.loads(config.read_text())
    assert {p['name'] for p in graph['packages']} == set(locked) | {'crisp_cloud'}
    hosted = {}
    paths = {}
    for name, row in locked.items():
        expected = production[name]
        assert row['version'] == expected['version'], name
        if row['source'] == 'hosted':
            assert expected['source'] == 'hosted'
            assert row['description'] == expected['description'], name
            hosted[name] = {'version': row['version'], 'archive_sha256': row['description']['sha256']}
        elif row['source'] == 'path':
            root = Path(row['description']['path'])
            assert root == HARNESS / 'packages' / name
            if expected['source'] == 'path':
                source = (HOST / expected['description']['path']).resolve()
            else:
                assert expected['source'] == 'git' and name == 'libdbm'
                source = Path(prepared['git_sources'][name]['root'])
                commit = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD']).decode().strip()
                assert commit == expected['description']['resolved-ref']
                assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain']).strip()
                for filename, recorded in prepared['git_sources'][name]['files'].items():
                    assert sha(source / filename) == recorded['sha256'], filename
            assert (root / 'lib').resolve() == source / 'lib', name
            assert sha(root / 'pubspec.yaml') == sha(source / 'pubspec.yaml'), name
            paths[name] = {'wrapper': str(root), 'source': str(source),
                           'manifest_sha256': sha(root / 'pubspec.yaml'),
                           'source_kind': expected['source']}
        else:
            assert row['source'] == expected['source'] == 'sdk'
    for package in graph['packages']:
        root = Path(unquote(urlparse(urljoin(config.as_uri(), package['rootUri'])).path))
        if package['name'] == 'crisp_cloud':
            assert (root / package['packageUri']).resolve() == HOST / 'lib'
        elif package['name'] in paths:
            assert (root / package['packageUri']).resolve() == Path(paths[package['name']]['source']) / 'lib'
    old_before = prepared['prior_harness_before']
    old_after = {name: sha(BASE / 'host-harness' / name) for name in old_before}
    assert old_before == old_after
    test = 'test/widget/office_odf_export_workflow_test.dart'
    assert (HARNESS / test).resolve() == HOST / test
    fixture = 'test/fixtures/office_native_workflows/native-slide-source.pptx'
    assert (HARNESS / fixture).resolve() == HOST / fixture
    resources = {}
    for name in ['Roboto-Regular.ttf', 'Roboto-Medium.ttf', 'Roboto-Bold.ttf', 'RobotoMono-Regular.ttf']:
        path = HOST / 'assets/fonts' / name
        assert (HARNESS / 'assets/fonts' / name).resolve() == path
        resources[str(path)] = sha(path)
    downloads = {}
    attempts = []
    for name in ['workflow-harness-setup', 'workflow-harness-setup-02', 'workflow-harness-setup-03']:
        path = EVIDENCE / name / 'receipt.json'
        receipt = json.loads(path.read_text())
        attempts.append({'path': str(path.relative_to(BASE)), 'status': receipt['status'],
                         'error': receipt.get('error'), 'sha256': sha(path)})
        for row in receipt['downloads_and_cached_pins']:
            if row['status'] == 'downloaded':
                assert row['archive_sha256'] == hosted[row['package']]['archive_sha256']
                downloads[row['package']] = row
    report = {
        'verified_utc': datetime.now(timezone.utc).isoformat(), 'status': 'ready_no_tests_executed',
        'harness': str(HARNESS), 'entrypoint': test, 'expected_widget_cases': 10,
        'entrypoint_sha256': sha(HOST / test), 'fixture_sha256': sha(HOST / fixture),
        'graph_packages_including_root': len(graph['packages']), 'locked_packages': len(locked),
        'hosted_pins_verified': len(hosted), 'new_archives_downloaded': len(downloads),
        'local_host_packages': sum(p['source_kind'] == 'path' for p in paths.values()),
        'pinned_external_git_packages': sum(p['source_kind'] == 'git' for p in paths.values()),
        'hosted_pins': hosted, 'path_packages': paths, 'downloaded_archives': downloads,
        'prior_harness_unchanged': True, 'prior_harness_hashes': old_after,
        'graph_sha256': sha(config), 'lock_sha256': sha(HARNESS / 'pubspec.lock'),
        'manifest_sha256': sha(HARNESS / 'pubspec.yaml'), 'host_font_inputs': resources,
        'setup_attempts': attempts,
        'scope': 'The authored tests use real dialog/menu/controller/import/export implementations with fake cloud and an injected copy destination. No implementation or test stubs were introduced by provisioning. No tests have run.',
        'native_hook_configuration': 'The original crisp_storage hook is retained, without enabling the application rust_smb user define. SQLite3 uses its unmodified default hook and pinned binary hash. Native storage behavior is outside this acceptance scope.',
    }
    (EVIDENCE / 'workflow-harness-ready.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: report[k] for k in ['status', 'graph_packages_including_root', 'locked_packages',
                                           'hosted_pins_verified', 'new_archives_downloaded',
                                           'local_host_packages', 'pinned_external_git_packages',
                                           'prior_harness_unchanged']}, indent=2))


if __name__ == '__main__':
    main()
