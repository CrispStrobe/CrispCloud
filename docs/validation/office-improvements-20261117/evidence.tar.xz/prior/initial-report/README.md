# Office visible-text and export improvements — 17 November 2026

This follow-up improves [PR #238](https://github.com/CrispStrobe/CrispCloud/pull/238)
from checkpoint `83617b79f8a56600e9ca17e73f835d944c79dfa8`. The preceding
[continuation evidence](../office-resume-20261117/README.md) remains intact.

**Accepted host source:**
[`63ca9f46a7c08bd9f1aa64f9aa7cc6ce2a17e66c`](https://github.com/CrispStrobe/CrispCloud/commit/63ca9f46a7c08bd9f1aa64f9aa7cc6ce2a17e66c),
tree `caf25875931991200209e326f001a82e9685b8e9`.
It pins canonical
[`fb502f612da6e87184e3025fdb379ba02fac1aab`](https://github.com/CrispStrobe/quds_office_suite/commit/fb502f612da6e87184e3025fdb379ba02fac1aab).
The final source-specific qualification passed **107 Dart/Flutter tests and
28 Python controls**, with **zero failures and zero skips**.

## Host behavior changes

| Confirmed problem | Result |
| --- | --- |
| Stored ODF deletions and change comments appeared as current document text. | Namespace-qualified text/table revision stores stay out of previews, including history-only files. Live inserted text and foreign lookalikes remain visible; raw XML is preserved. |
| Valid ODT documents using different XML prefixes could produce an empty preview or lose styles, links, notes and header/footer text. | Resolve supported elements and attributes by namespace URI throughout the ODT preview path. Keep the prior narrow tolerance for producer `style:list-style` documents. |
| Multiple note paragraphs and projected note-table cells concatenated words. | Retain paragraph separators before the existing readable-note whitespace normalization. |
| Nested frames were injected into parent cell text and repeated afterward in ODS previews and ODT tables. | Decode each paragraph's own text, followed by its anchored text-box stories once, including nested frames. Notes, annotations and ruby pronunciation remain separate; ruby base and foreign extension text remain visible. |
| Explicit cell spaces, tabs and line breaks were lost. | Decode their namespace-qualified elements and CDATA. CSV retains exact decoded line breaks; Markdown projects each cell onto one physical row line. |

The new decoding path enforces the existing 8 MiB preview allowance cumulatively
across cells, including whitespace later trimmed away. It reserves repeated-cell
text before retaining row values. Decimal count validation and six resource
controls cover oversized, nondecimal and cumulative whitespace expansions.

## Canonical integration

The guarded sync applies nine files with no deletions: five engine changes and
four new test files. The canonical repairs cover stored-revision exclusion,
single decoding of ODS frame stories, missing standalone default header/footer
visuals, equivalent run-color style keys, and native DOCX bookmark endpoints.

The importer normally gives a bookmark end only its numeric ID. The corrected
writer resolves its name from the matching start within the same logical story,
without mutating source boundary objects. Overlapping ranges and independent
body/header/footer/note/comment/frame/covered-cell scopes are tested.

The [canonical report](https://github.com/CrispStrobe/quds_office_suite/blob/codex/office-qualified-resume-20261117/docs/validation/office-improvements-20261117/README.md)
records its separate **606-pass** engine/editor qualification, final old-source
regression controls and strict analysis. Those counts are not combined with the
host's counts or with historical accepted runs.

## Production-path acceptance and controls

An independently authored DOCX fixture passes through `WordDeserializer`,
`OdtDocumentWriter` and the actual `parseOfficeDocument` preview service.
Independent XML assertions check alternating paragraph colors/borders, complete
bookmark ranges, links, numbered lists, tables, exact note whitespace and cached
citation text, annotation ownership, hidden text exclusion, raw XML retention,
and unchanged source bytes/model ownership.

This fixture caught the missing imported bookmark end after its DOCX loading,
note whitespace and paragraph-style assertions had already passed. Its original
expectations were retained; the final acceptance test is byte-identical to that
incoming failure control. A second case checks boundaries between two note
paragraphs and two projected note-table cells.

| Final host cohort | Passes |
| --- | ---: |
| Existing document service | 41 |
| Existing annotation preview | 8 |
| Existing notice registration | 2 |
| Existing Zotero service, citing transport and ribbon | 39 |
| Namespace/revision visibility regressions | 3 |
| ODT/ODS cell-story and whitespace regressions | 6 |
| ODT/ODS decoding resource controls | 6 |
| DOCX export/preview and note-boundary acceptance | 2 |
| **Dart/Flutter total** | **107** |
| Vendor/parser Python controls, separately counted | **28** |

The 107 cases include the original 90-case core and 17 new cases. The earlier
six supplemental writer probes remain archived under their prior qualification;
they are not silently counted as rerun here. The broader earlier continuation
evidence retains its original source attribution.

## Strict gates, preservation and independent review

All nine commands passed: vendor guard before and after execution, the complete
selected host suite, strict host analysis, strict changed-vendor analysis, host
formatting, changed-vendor formatting, 28 Python controls, and whitespace.
The host uses its genuine locked 107-package focused graph; all 97 hosted
package versions and archive hashes match the production lock.

The [preservation audit](preservation.json) verifies **2,607 managed files =
750 canonical + 1,857 unchanged standalone-parser files**. The increase of four
managed files is exactly the four new canonical test files. It also preserves:

- All 50 canonical and 46 host Zotero paths.
- All 20 previously audited host customizations.
- All six original notices and the retained Unicode registration.
- The same 12 inherited executable-mode differences, with no new difference.

The [independent review](independent-review.json) recounts raw JSON test events,
confirms exact suite routing and source URLs, and rehashes the input maps against
the frozen source. Before/after maps match for 5,465 materialized source entries,
4,510 dependency/manifest entries, 514 SDK/runtime entries and 14 workspace
entries. The temporary host analyzer graph stayed unchanged while installed and
was restored to its original absence. The runtime is Flutter 3.47.8 / Dart 3.13.7.

The [runner](run_validation.py), [qualification receipt](qualification.json),
[archive](evidence.tar.xz) and [complete member index](evidence-index.json)
retain exact commands, locks, routing, raw logs, setup and independent reviewers.

## Preserved attempts and precise corrections

The incoming host controls retain the note concatenation, missing bookmark-end,
namespace-alias and revision leaks, and all six cell-story matcher failures.
The first positive service run exposed the existing `style:list-style` tolerance;
the code now preserves that compatibility and the original fixture is unchanged.

The cell-story probe originally placed a literal line break inside its expected
Markdown table row. Independent review identified that this splits a Markdown
row. The final test separately verifies a single physical Markdown row and exact
CSV line breaks; logical cell text and authored fixture bytes are unchanged.
The original probe, failed controls, exact correction patch and reason are
preserved. An earlier uniqueness check was also narrowed to the actual data row
so the generated ODS heading `Cells` could not be counted as cell text.

A final resource-test expression was changed from string concatenation to
equivalent interpolation for strict lint style, with its before/after receipt.
All product behavior assertions remain. Earlier setup failed because 49 exact
host package versions were absent; their recovery records verify each downloaded
archive against the production-pinned hash. No dependency version was relaxed.

## Reproduction and scope

Use a clean checkout at the accepted host source and a canonical checkout at the
manifest pin. Restore the archived focused wrapper and lock, relocate only its
local package paths, and resolve it offline with `--enforce-lockfile`. Setup
manifests, the relocation receipt, package archive pins and the executed setup
scripts are in the archive. Then run:

```sh
python3 run_validation.py --kind host \
  --repo /path/to/CrispCloud --harness /path/to/host-harness \
  --canonical-source /path/to/quds \
  --sdk /path/to/flutter-sdk --cache /path/to/pub-cache \
  --expected-head 63ca9f46a7c08bd9f1aa64f9aa7cc6ce2a17e66c \
  --baseline 83617b79f8a56600e9ca17e73f835d944c79dfa8 \
  --output /path/to/new-evidence-directory
```

Every run needs a fresh output directory. The runner checks that selected tests
resolve to the frozen source and verifies input integrity after all commands.
Independent reviewers can recount saved logs without product execution. Every
archived member is reread and checked against its size and SHA-256 index.

This is production importer/writer/service qualification in a focused genuine
dependency graph. It is not full application or export-dialog acceptance, live
Word/LibreOffice/Zotero interoperability, or native/model/Wasm acceptance. No
optional model or native binary was added.

Publication adds documentation/evidence only; the source-equivalence receipt
checks every non-documentation Git blob and mode against the qualified source.
Remote updates require the observed head and do not force concurrent work.
Commit messages retain `[skip ci]`. No GitHub Actions, workflow, check-run or
CI-status endpoint was queried or awaited.
