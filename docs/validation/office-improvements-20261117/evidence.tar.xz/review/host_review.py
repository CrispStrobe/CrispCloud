#!/usr/bin/env python3
"""Independently audit saved host qualification without executing product tests."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urljoin, urlparse
import yaml


HOST_COMMIT = 'f08035db691d5a1fe7299ad3608b626ab6202d27'
CANONICAL_COMMIT = '7fd2030fd39a2b0bbdb1b1e778840c332ae6bbc3'
HOST_BASELINE = '83617b79f8a56600e9ca17e73f835d944c79dfa8'
CANONICAL_BASELINE = '7a9702c3b74e0e905c76fcf467d608bbb852d004'
RUNNER_SHA256 = '8a70306501527cd61dc38fab5f94b06593ef3a5d9ef4cc5023104e8214f281c7'
RESOURCE_DIRS = ('lib', 'bin', 'assets', 'fonts', 'hook', 'native', 'rust', 'rust_cloud')
SOURCE_PREFIXES = (
    'lib/', 'test/', 'tool/', 'assets/', 'fonts/',
    'packages/quds_office_engine/lib/', 'packages/quds_office_engine/test/',
    'packages/quds_office_engine/third_party/',
    'packages/quds_office_editor/lib/', 'packages/quds_office_editor/test/',
    'packages/quds_office_editor/example/lib/', 'packages/quds_office_editor/example/test/',
    'packages/quds_office_editor/example/assets/', 'packages/quds_office_editor/example/fonts/',
    'packages/quds_proofing_harper/lib/',
    'packages/quds_proofing_aot/lib/', 'packages/quds_proofing_aot/test/',
    'packages/quds_proofing_aot/tool/', 'tools/proofing/german_model/',
    'packages/quds_office_editor/fonts/', 'packages/quds_reports/lib/',
    'packages/legacy_doc_parser/',
)
SUITE_COUNTS = {
    'office_annotation_preview_test.dart': 8,
    'office_document_service_test.dart': 41,
    'office_proofing_licenses_test.dart': 2,
    'office_zotero_test.dart': 21,
    'office_zotero_citing_transport_test.dart': 16,
    'office_zotero_ribbon_test.dart': 2,
    'office_odf_visibility_test.dart': 3,
    'office_odf_cell_story_test.dart': 6,
    'office_odf_cell_limits_test.dart': 6,
    'office_odt_export_acceptance_test.dart': 2,
}
COMMANDS = {
    'vendor-before', 'host-tests', 'host-analysis', 'host-format',
    'vendor-python-controls', 'vendor-after', 'vendor-analysis',
    'changed-dart-format', 'whitespace',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_data(path):
    return os.readlink(path).encode() if path.is_symlink() else path.read_bytes()


def sha_file(path):
    return digest(file_data(path))


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def tree(repo, commit):
    entries = {}
    for record in git(repo, 'ls-tree', '-r', '-z', commit).split(b'\0'):
        if record:
            metadata, name = record.split(b'\t', 1)
            mode, kind, blob = metadata.decode().split()
            entries[name.decode()] = {'mode': mode, 'type': kind, 'blob': blob}
    return entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    base = args.workspace.resolve()
    out = args.output or base / 'final-qualified-review/host-audit.json'
    host = base / 'CrispCloud'
    canonical = base / 'quds_office_suite'
    harness = base / 'host-harness'
    evidence = base / 'qualified-host-f08035db'
    sdk = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk')
    report = {'reviewed_utc': datetime.now(timezone.utc).isoformat(),
              'method': 'Independent raw-event recount and read-only Git, file, graph and log verification; no product tests executed.',
              'host_source': HOST_COMMIT, 'canonical_source': CANONICAL_COMMIT,
              'findings': []}

    def check(condition, message):
        if not condition:
            report['findings'].append(message)

    def load(path):
        return json.loads(path.read_text())

    receipt = load(evidence / 'receipt.json')
    check(receipt['status'] == 'passed', 'Qualification is not terminal passed')
    check(receipt['source_commit'] == HOST_COMMIT, 'Wrong qualified host commit')
    check(receipt['baseline'] == HOST_BASELINE, 'Wrong host baseline')
    for key in ('inputs_unchanged', 'source_head_unchanged', 'analysis_config_restored',
                'analysis_config_unchanged_during_run'):
        check(receipt.get(key) is True, 'Required integrity gate failed: ' + key)
    check(git(host, 'rev-parse', 'HEAD').decode().strip() == HOST_COMMIT,
          'Host checkout moved from the qualified source')
    check(git(canonical, 'rev-parse', 'HEAD').decode().strip() == CANONICAL_COMMIT,
          'Canonical checkout moved from the pinned source')
    for checkout in (host, canonical):
        dirty = git(checkout, 'status', '--porcelain', '--untracked-files=all').decode().splitlines()
        check(all(line[3:].startswith('docs/') for line in dirty),
              'Non-documentation working-tree changes during audit: ' + str(checkout))
    check(git(host, 'rev-parse', HOST_COMMIT + '^{tree}').decode().strip() == receipt['source_tree'],
          'Host tree is not the tree recorded by qualification')

    commands = receipt['commands']
    check(len(commands) == len(COMMANDS) and {c['name'] for c in commands} == COMMANDS,
          'Required command set differs or repeats')
    by_name = {c['name']: c for c in commands}
    for command in commands:
        check(command.get('exit_code') == 0 and command.get('passed') is True,
              'Command did not pass: ' + command['name'])
        for stream in ('stdout', 'stderr'):
            path = evidence / f"{command['name']}.{stream}.log"
            check(sha_file(path) == command.get(stream + '_sha256'),
                  'Command log hash mismatch: ' + path.name)
    for name in ('host-analysis', 'vendor-analysis'):
        check('--fatal-infos' in by_name[name]['command'], 'Analysis was not strict: ' + name)
        check('No issues found!' in (evidence / (name + '.stdout.log')).read_text(),
              'Analyzer did not report clean result: ' + name)
    for name in ('host-format', 'changed-dart-format'):
        check('--set-exit-if-changed' in by_name[name]['command'], 'Formatter was not checking: ' + name)
        check('(0 changed)' in (evidence / (name + '.stdout.log')).read_text(),
              'Formatter reported changes: ' + name)
    report['command_gates'] = {c['name']: c['exit_code'] for c in commands}

    # Reconstruct all starts, terminals and suites directly from the raw stream.
    starts, terminals, suites, completions, errors, non_json = {}, {}, {}, [], [], []
    for number, line in enumerate((evidence / 'host-tests.stdout.log').read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json.append({'line': number, 'text': line})
            continue
        kind = event.get('type')
        if kind == 'testStart':
            test = event['test']
            check(test['id'] not in starts, 'Duplicate test start ID')
            starts[test['id']] = test
        elif kind == 'testDone':
            check(event['testID'] not in terminals, 'Duplicate test terminal ID')
            terminals[event['testID']] = event
        elif kind == 'suite':
            suite = event['suite']
            check(suite['id'] not in suites, 'Duplicate suite ID')
            suites[suite['id']] = suite
        elif kind == 'done':
            completions.append(event)
        elif kind == 'error':
            errors.append(event)
    check(set(starts) == set(terminals), 'Started and completed test sets differ')
    check(len(completions) == 1 and completions[0].get('success') is True,
          'Not exactly one successful run completion')
    check(not errors, 'Raw stream contains errors')
    check(not non_json, 'Raw event stream contains non-JSON output')
    check(all(e['result'] == 'success' and not e.get('skipped') for e in terminals.values()),
          'A raw terminal event is failed or skipped')
    test_command = by_name['host-tests']
    selected = ['test/' + name for name in SUITE_COUNTS]
    check(test_command['selected_files'] == selected, 'Selected file list is not the intended 10 suites')
    check([value for value in test_command['command'] if value.endswith('_test.dart')] == selected,
          'Executed test arguments differ from the selected list')
    resolved_suites = {str(Path(s['path']).resolve()) for s in suites.values()}
    check(len(suites) == len(selected) and resolved_suites == {str(host / p) for p in selected},
          'Actual suite routing differs from intended source files')
    counts = Counter()
    names = []
    url_bindings = Counter()
    for identifier, start in starts.items():
        name = start['name']
        terminal = terminals.get(identifier, {})
        if name.startswith('loading ') or name.endswith(('(setUpAll)', '(tearDownAll)')):
            continue
        check(not terminal.get('hidden'), 'A substantive case was hidden')
        check(not start.get('metadata', {}).get('skip'), 'A substantive case was declared skipped')
        suite_path = Path(suites[start['suiteID']]['path']).resolve()
        origin = start.get('root_url') or start.get('url')
        parsed_origin = urlparse(origin or '')
        check(parsed_origin.scheme == 'file', 'Substantive case lacks a file origin: ' + name)
        check(Path(unquote(parsed_origin.path)).resolve() == suite_path,
              'Substantive test origin does not match its suite: ' + name)
        url_bindings['root_url' if start.get('root_url') else 'url'] += 1
        counts[suite_path.name] += 1
        names.append({'id': identifier, 'suite': str(suite_path.relative_to(host)), 'name': name})
    check(dict(counts) == SUITE_COUNTS, 'Raw per-suite counts differ from expected scope')
    check(sum(counts.values()) == 107, 'Substantive test total is not 107')
    check(len({(row['suite'], row['name']) for row in names}) == 107,
          'Substantive suite/name identities repeat')
    report['dart_flutter'] = {'passed': sum(counts.values()), 'failed': len(errors), 'skipped': 0,
                              'suite_counts': dict(counts), 'test_start_count': len(starts),
                              'test_terminal_count': len(terminals), 'case_records': names,
                              'real_file_origin_bindings': dict(url_bindings)}

    # Python unittest writes its independent case list to stderr.
    python_log = (evidence / 'vendor-python-controls.stderr.log').read_text()
    python_cases = re.findall(r'^(test_\w+) \(([^)]+)\) \.\.\. ok$', python_log, re.MULTILINE)
    check(len(python_cases) == len(set(python_cases)) == 28, 'Python case count/identity is not 28 unique passes')
    check(re.search(r'^Ran 28 tests in .+\n\nOK\s*$', python_log, re.MULTILINE) is not None,
          'Python unittest did not finish with exactly 28 passes')
    report['python'] = {'passed': len(python_cases), 'case_ids': [row[1] for row in python_cases]}

    before, after = load(evidence / 'inputs-before.json'), load(evidence / 'inputs-after.json')
    check(before == after, 'Saved before/after maps are not identical')
    source_tree = tree(host, HOST_COMMIT)
    baseline_tree = tree(host, HOST_BASELINE)
    canonical_tree = tree(canonical, CANONICAL_COMMIT)
    original_canonical_tree = tree(canonical, CANONICAL_BASELINE)
    expected_source_paths = set()
    for path, entry in source_tree.items():
        parts = Path(path).parts
        local_package = (len(parts) > 3 and parts[0] == 'packages' and
                         parts[2] in ('lib', 'assets', 'fonts', 'hook', 'native', 'rust', 'rust_cloud'))
        selected_source = (path.startswith(SOURCE_PREFIXES) or local_package or
                           Path(path).name in ('pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'))
        if entry['type'] == 'blob' and selected_source and (host / path).exists():
            expected_source_paths.add(path)
    check(set(before['source']) == expected_source_paths,
          'Source-map inventory omits or adds materialized tracked library/resource inputs')
    for path, recorded in before['source'].items():
        current = host / path
        data = file_data(current)
        actual_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        actual_mode = '120000' if current.is_symlink() else ('100755' if current.stat().st_mode & 0o111 else '100644')
        check(source_tree.get(path, {}).get('blob') == recorded['git_blob'] == actual_blob,
              'Source blob binding mismatch: ' + path)
        check(source_tree.get(path, {}).get('mode') == recorded['mode'] == actual_mode,
              'Source mode binding mismatch: ' + path)
        check(digest(data) == recorded['sha256'], 'Source SHA mismatch: ' + path)
    for section in ('dependencies', 'workspace'):
        for name, recorded in before[section].items():
            path = Path(name)
            actual = digest(path.read_bytes()) if path.is_file() else None
            check(actual == recorded, section + ' binding mismatch: ' + name)
    python_runtime = receipt['python_runtime']
    for name, recorded in before['runtime'].items():
        path = Path(python_runtime['path']) if name == 'python/executable' else sdk / name
        check(sha_file(path) == recorded, 'Runtime binding mismatch: ' + name)
    check(before['runtime']['python/executable'] == python_runtime['sha256'],
          'Python runtime receipt and input map differ')
    check(Path(by_name['vendor-python-controls']['command'][0]).resolve() ==
          Path(python_runtime['path']), 'Python controls used a different interpreter')
    check(before['runner_sha256'] == sha_file(base / 'run_final_improvement_validation.py'),
          'Executed runner differs from saved identity')
    check(before['runner_sha256'] == RUNNER_SHA256,
          'Executed runner differs from the final reviewed SHA-256')
    check(before['runner_sha256'] == sha_file(
              base / 'concurrent-integration/final-runner-review/run_final_improvement_validation.reviewed.py'),
          'Executed runner differs from the reviewed snapshot')
    config = harness / '.dart_tool/package_config.json'
    check(before['graph_sha256'] == sha_file(config), 'Execution graph hash mismatch')
    check(before['lock_sha256'] == sha_file(harness / 'pubspec.lock'), 'Execution lock hash mismatch')
    report['input_maps'] = {section: len(before[section]) for section in ('source', 'dependencies', 'runtime', 'workspace', 'package_routes')}
    report['input_maps']['before_after_equal'] = before == after
    report['input_maps']['source_inventory_complete'] = set(before['source']) == expected_source_paths

    routing = test_command['test_routing']
    check(len(routing) == len(selected), 'Incomplete saved test routing')
    for row in routing:
        path = host / row['source_path']
        check((harness / row['selected']).resolve() == path == Path(row['resolved']),
              'Test path does not route to the source checkout: ' + row['selected'])
        check(sha_file(path) == row['sha256'] == before['source'][row['source_path']]['sha256'],
              'Executed test hash does not match the frozen source: ' + row['selected'])
    graph = load(config)
    analysis_graph = load(evidence / 'analysis-package-config.json')
    package_names = [package['name'] for package in graph['packages']]
    check(len(package_names) == len(set(package_names)), 'Execution graph has duplicate package identities')
    expected_routes, expected_dependency_paths = {}, set()
    for package in graph['packages']:
        root = Path(unquote(urlparse(urljoin(config.as_uri(), package['rootUri'])).path)).resolve()
        library = (root / package.get('packageUri', 'lib/')).resolve()
        expected_routes[package['name']] = {
            'root': str(root), 'library': str(library),
            'resources': {name: str((root / name).resolve()) for name in RESOURCE_DIRS[2:]
                          if (root / name).exists()},
        }
        for name in ('pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml', 'analysis_options.yaml'):
            expected_dependency_paths.add(str(root / name))
        for name in RESOURCE_DIRS:
            resource = root / name
            if resource.resolve().is_relative_to(host):
                for actual in resource.rglob('*'):
                    if actual.is_file():
                        check(str(actual.resolve().relative_to(host)) in before['source'],
                              'Internal package input is omitted from source map: ' + str(actual))
                continue
            expected_dependency_paths.update(str(path) for path in resource.rglob('*') if path.is_file())
    check(before['package_routes'] == expected_routes,
          'Actual package library/resource destinations differ from the recorded routes')
    check(set(before['dependencies']) == expected_dependency_paths,
          'Dependency-map inventory omits or adds package metadata/library/resource inputs')
    expected_workspace_paths = {harness / name for name in (
        'pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml', 'analysis_options.yaml',
        '.dart_tool/package_config.json', '.dart_tool/package_graph.json')}
    for pattern in ('packages/*/pubspec*.yaml', 'packages/*/example/pubspec*.yaml',
                    'apps/*/pubspec*.yaml', 'packages/*/analysis_options.yaml'):
        expected_workspace_paths.update(harness.glob(pattern))
    check(set(before['workspace']) == {str(path) for path in expected_workspace_paths},
          'Workspace-map inventory differs from the frozen package metadata scope')
    runtime_names = (
        'bin/cache/dart-sdk/bin/dart', 'bin/cache/dart-sdk/bin/dartaotruntime',
        'bin/cache/flutter_tools.snapshot', 'bin/cache/flutter.version.json',
        'bin/cache/artifacts/engine/linux-x64/flutter_tester',
        'bin/cache/dart-sdk/bin/snapshots/frontend_server_aot.dart.snapshot',
        'bin/cache/dart-sdk/bin/snapshots/analysis_server_aot.dart.snapshot',
        'bin/cache/dart-sdk/bin/snapshots/dart2js_aot.dart.snapshot',
        'bin/cache/dart-sdk/bin/snapshots/dartdev_aot.dart.snapshot',
    )
    expected_runtime_paths = {sdk / name for name in runtime_names}
    for directory in ('bin/cache/dart-sdk/lib',
                      'bin/cache/artifacts/engine/common/flutter_patched_sdk',
                      'bin/cache/artifacts/engine/common/flutter_patched_sdk_product'):
        expected_runtime_paths.update(path for path in (sdk / directory).rglob('*') if path.is_file())
    icu = sdk / 'bin/cache/artifacts/engine/linux-x64/icudtl.dat'
    if icu.is_file():
        expected_runtime_paths.add(icu)
    check(set(before['runtime']) == {str(path.relative_to(sdk)) for path in expected_runtime_paths} | {'python/executable'},
          'Runtime-map inventory differs from the reviewed SDK/Python scope')
    report['input_maps'].update(
        dependency_inventory_complete=set(before['dependencies']) == expected_dependency_paths,
        package_routes_reconstructed=before['package_routes'] == expected_routes,
        workspace_inventory_complete=set(before['workspace']) == {str(path) for path in expected_workspace_paths},
    )
    lock = yaml.safe_load((harness / 'pubspec.lock').read_text())['packages']
    production_lock = yaml.safe_load((host / 'pubspec.lock').read_text())['packages']
    check({package['name'] for package in graph['packages']} == set(lock) | {'crisp_cloud'},
          'Execution graph package set differs from the locked graph')
    hosted = {name: row for name, row in lock.items() if row['source'] == 'hosted'}
    check(len(hosted) == 97, 'Hosted package count differs from the preserved lock')
    for name, row in hosted.items():
        original = production_lock.get(name, {})
        check(row['version'] == original.get('version') and
              row['description']['sha256'] == original.get('description', {}).get('sha256'),
              'Hosted package version/archive pin differs from production: ' + name)
    internal = {'crisp_cloud': host, 'quds_office_engine': host / 'packages/quds_office_engine',
                'quds_office_editor': host / 'packages/quds_office_editor',
                'quds_reports': host / 'packages/quds_reports',
                'legacy_doc_parser': host / 'packages/legacy_doc_parser'}
    for package in graph['packages']:
        root = Path(unquote(urlparse(urljoin(config.as_uri(), package['rootUri'])).path))
        if package['name'] in internal:
            check((root / package['packageUri']).resolve() == (internal[package['name']] / 'lib').resolve(),
                  'Execution package resolves to different source: ' + package['name'])
            for source in (root / 'lib').rglob('*.dart'):
                actual = source.resolve()
                check(str(actual.relative_to(host)) in before['source'],
                      'Executed internal library omitted from source map: ' + str(actual))
    for package in analysis_graph['packages']:
        if package['name'] in internal:
            check(Path(unquote(urlparse(package['rootUri']).path)).resolve() == internal[package['name']],
                  'Analyzer package resolves to different source: ' + package['name'])
        recorded_route = expected_routes[package['name']]
        analysis_root = Path(unquote(urlparse(package['rootUri']).path)).resolve()
        check(str((analysis_root / package.get('packageUri', 'lib/')).resolve()) == recorded_route['library'],
              'Analyzer library differs from execution graph: ' + package['name'])
    check(not (host / '.dart_tool/package_config.json').exists(),
          'Temporary host analysis graph was not removed')
    report['package_graph'] = {'package_count': len(graph['packages']),
                               'production_hosted_pins_verified': len(hosted),
                               'internal_libraries_bound': True,
                               'all_library_and_resource_routes_bound': before['package_routes'] == expected_routes,
                               'analysis_graph_restored_to_absent': not (host / '.dart_tool/package_config.json').exists()}

    preservation = load(base / 'concurrent-integration/host-shared-78a4/host-preservation.json')
    manifest = load(host / 'tool/office_fidelity_manifest.json')
    check(preservation['host_ref'] == HOST_COMMIT and preservation['canonical_ref'] == CANONICAL_COMMIT,
          'Preservation report binds different sources')
    check(manifest['source_commit'] == CANONICAL_COMMIT, 'Host manifest canonical pin mismatch')
    check(preservation['passed'] and not preservation['failures'], 'Preservation report has failures')
    managed = preservation['managed_files']
    check(len(managed) == len(manifest['files']) == 2612, 'Managed-file count mismatch')
    check({row['path'] for row in managed} == set(manifest['files']), 'Managed inventory and manifest differ')
    parser_paths, mode_differences = [], []
    for row in managed:
        path = row['path']
        check(source_tree[path] == {key: row[key] for key in ('mode', 'type', 'blob')},
              'Preservation Git entry mismatch: ' + path)
        check(sha_file(host / path) == row['sha256'] == manifest['files'][path],
              'Managed bytes or manifest hash mismatch: ' + path)
        check((host / path).stat().st_size == row['bytes'], 'Managed byte length mismatch: ' + path)
        check(row['source_matches'] and row['manifest_matches'], 'Managed row recorded a mismatch: ' + path)
        if path.startswith('packages/legacy_doc_parser/'):
            parser_paths.append(path)
            check(source_tree[path] == baseline_tree[path], 'Standalone parser changed: ' + path)
        else:
            check(source_tree[path]['blob'] == canonical_tree[path]['blob'], 'Canonical vendor blob mismatch: ' + path)
            if source_tree[path]['mode'] != canonical_tree[path]['mode']:
                mode_differences.append({'path': path, 'host': source_tree[path]['mode'], 'canonical': canonical_tree[path]['mode']})
    check(len(parser_paths) == 1857, 'Parser count differs from 1857')
    check({p for p in baseline_tree if p.startswith('packages/legacy_doc_parser/')} ==
          {p for p in source_tree if p.startswith('packages/legacy_doc_parser/')}, 'Parser path set changed')
    check(sorted(mode_differences, key=lambda r: r['path']) == preservation['mode_differences'],
          'Mode-difference inventory differs')
    check(len(mode_differences) == 12, 'Inherited mode count differs')
    inherited_modes = [
        {'path': row['path'], 'host': baseline_tree[row['path']]['mode'],
         'canonical': original_canonical_tree[row['path']]['mode']}
        for row in managed
        if not row['standalone_parser'] and row['path'] in baseline_tree
        and row['path'] in original_canonical_tree
        and baseline_tree[row['path']]['mode'] != original_canonical_tree[row['path']]['mode']
    ]
    check(sorted(inherited_modes, key=lambda r: r['path']) == sorted(mode_differences, key=lambda r: r['path']),
          'Current mode differences were not all inherited from the incoming checkpoints')
    for category, rows in preservation['protected'].items():
        for row in rows:
            path = row['path']
            check(source_tree[path] == baseline_tree[path] == row['actual'] == row['expected'] and row['unchanged'],
                  'Protected file changed: ' + category + '/' + path)
    for scope, current_tree, original_tree in (
        ('canonical_zotero', canonical_tree, original_canonical_tree),
        ('host_zotero', source_tree, baseline_tree),
    ):
        for row in preservation[scope]:
            path = row['path']
            check(current_tree[path] == original_tree[path] == row['actual'] == row['expected'] and row['unchanged'],
                  'Zotero preservation mismatch: ' + path)
    report['preservation'] = preservation['counts']

    retention = load(base / 'concurrent-integration/host-shared-78a4/canonical-retention-7fd2030f.json')
    check(retention['canonical_ref'] == CANONICAL_COMMIT,
          'Incoming-source retention review binds a different canonical source')
    for row in retention['managed_retention']:
        path = row['path']
        check(canonical_tree[path]['blob'] == row['canonical_blob'] == source_tree[path]['blob'],
              'Retained incoming path differs from the qualified vendor: ' + path)
        check(sha_file(host / path) == row['canonical_sha256'],
              'Retained incoming bytes differ from the qualified vendor: ' + path)
    report['incoming_retention'] = {
        'audited_managed_paths': len(retention['managed_retention']),
        'exact_incoming_files': sum(row['byte_identical'] for row in retention['managed_retention']),
        'combined_files': sum(not row['byte_identical'] for row in retention['managed_retention']),
        'all_final_blobs_match_retention_review': True,
    }

    # Check that the final reviewed code and narrow probe changes are exactly attributed.
    source_review = load(base / 'evidence-extraction/independent-host-cell-review.json')
    helper_path = 'CrispCloud/lib/services/office_document_service.dart'
    check(sha_file(base / helper_path) == source_review['files'][helper_path]['sha256'],
          'Host helper differs from the independently reviewed source')
    reviewed_limits = (base / 'evidence-extraction/review-snapshot/office_odf_cell_limits_test.dart').read_text()
    final_limits = (host / 'test/office_odf_cell_limits_test.dart').read_text()
    replacement = reviewed_limits.replace("_cell('5000000') + _cell('5000000')", "'${_cell('5000000')}${_cell('5000000')}'")
    check(replacement == final_limits, 'Cell-limit test differs beyond string-concatenation interpolation')
    correction = load(base / 'evidence-host-acceptance/markdown-row-probe-correction.json')
    final_story = host / 'test/office_odf_cell_story_test.dart'
    check(sha_file(final_story) == correction['after_sha256'], 'Final cell-story probe differs from recorded correction')
    corrected = final_story.read_text()
    old_block = "  expect(document.markdown, contains('| $expected |'));\n"
    new_block = ("  final readable = expected.replaceAll('\\n', ' ');\n"
                 "  expect(document.markdown, contains('| $readable |'));\n"
                 "  final rows = document.markdown\n"
                 "      .split('\\n')\n"
                 "      .where((line) => line.startsWith('|'));\n"
                 "  expect(rows, hasLength(2));\n")
    check(new_block in corrected and digest(corrected.replace(new_block, old_block).encode()) == correction['before_sha256'],
          'Markdown probe correction includes unreported changes')
    acceptance = host / 'test/office_odt_export_acceptance_test.dart'
    check(acceptance.read_bytes() == (base / 'evidence-host-acceptance/baseline-test.dart').read_bytes(),
          'DOCX-to-ODT acceptance assertions changed after baseline failure')
    report['probe_review'] = {
        'markdown_correction': 'Justified: literal line breaks split pipe-delimited Markdown rows. The final probe independently requires one physical data row and preserves exact decoded newlines in ODS CSV; fixtures, logical expected strings, hidden-payload checks and raw-XML assertions are unchanged.',
        'cell_limits_amendment': 'Only equivalent concatenation-to-interpolation syntax; scenario inputs and assertions are unchanged.',
        'acceptance_test_unchanged_from_baseline': acceptance.read_bytes() == (base / 'evidence-host-acceptance/baseline-test.dart').read_bytes(),
    }
    report['evidence_hashes'] = {str(path.relative_to(base)): sha_file(path) for path in (
        evidence / 'receipt.json', evidence / 'inputs-before.json', evidence / 'inputs-after.json',
        evidence / 'host-tests.stdout.log', evidence / 'vendor-python-controls.stderr.log',
        base / 'concurrent-integration/host-shared-78a4/host-preservation.json',
        base / 'concurrent-integration/host-shared-78a4/canonical-retention-7fd2030f.json',
        base / 'concurrent-integration/host-shared-78a4/semantic-retention-7fd2030f.json',
        Path(__file__).resolve(),
    )}
    report['scope'] = '107 host Dart/Flutter cases plus 28 separate Python controls and nine command gates. These results are a focused local qualification, not full application/dialog, live interoperability, real-model or Wasm acceptance. Historical qualification totals are not added.'
    report['status'] = 'passed' if not report['findings'] else 'failed'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'findings', 'input_maps', 'preservation')}, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
