#!/usr/bin/env python3
"""Independent read-only audit of accepted Office export widget qualification."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from urllib.parse import unquote, urljoin, urlparse
import yaml

BASE = Path(__file__).resolve().parent.parent
HOST = BASE / 'CrispCloud'
CANONICAL = BASE / 'quds_office_suite'
HARNESS = BASE / 'host-workflow-harness'
EVIDENCE = BASE / 'qualified-workflow-f08035db'
SETUP = BASE / 'concurrent-integration/host-shared-78a4'
OUT = Path(__file__).resolve().parent
SDK = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk')
SOURCE = 'f08035db691d5a1fe7299ad3608b626ab6202d27'
PIN = '7fd2030fd39a2b0bbdb1b1e778840c332ae6bbc3'
RUNNER = '8a70306501527cd61dc38fab5f94b06593ef3a5d9ef4cc5023104e8214f281c7'
SUITE = 'test/widget/office_odf_export_workflow_test.dart'
CASES = ['ODT menu export retains authored content and annotation privacy',
         'ODP menu export commits pending title and preserves notes'] + [
    f'{extension} {outcome} export preserves newer edits and save target'
    for extension in ('odt', 'odp')
    for outcome in ('saved', 'downloaded', 'cancelled', 'failed')]
GATES = {'vendor-before', 'workflow-tests', 'workflow-analysis',
         'workflow-format', 'vendor-after', 'whitespace'}
ROUTED = [SUITE, 'test/support/office_test_harness.dart',
          'test/support/workflow_fake_client.dart', 'test/support/workspace_fixture.dart',
          'lib/widgets/office_editor_dialog.dart', 'lib/widgets/office_editor_ribbon.dart',
          'lib/services/office_editor_menu.dart', 'lib/services/office_device_export.dart',
          'lib/services/office_device_export_native.dart', 'lib/services/office_device_export_types.dart',
          'lib/services/office_document_service.dart',
          'test/fixtures/office_native_workflows/native-slide-source.pptx']


def load(path):
    return json.loads(path.read_text())


def data(path):
    return os.readlink(path).encode() if path.is_symlink() else path.read_bytes()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def tree(repo, ref):
    result = {}
    for entry in git(repo, 'ls-tree', '-r', '-z', ref).split(b'\0'):
        if entry:
            meta, path = entry.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            result[path.decode()] = {'mode': mode, 'kind': kind, 'blob': oid}
    return result


def main():
    report = {'reviewed_utc': datetime.now(timezone.utc).isoformat(),
              'host_source': SOURCE, 'canonical_qualified_pin': PIN,
              'method': 'Independent raw-event recount, exact Git/file/graph readback, production-pin verification and native hook/manifest authentication. No tests or builds executed.',
              'findings': []}
    def check(ok, message):
        if not ok:
            report['findings'].append(message)

    receipt = load(EVIDENCE / 'receipt.json')
    check(receipt['status'] == 'passed', 'Workflow receipt is not terminal passed')
    check(receipt['source_commit'] == SOURCE, 'Wrong host source')
    check(receipt['baseline'] == '83617b79f8a56600e9ca17e73f835d944c79dfa8', 'Wrong baseline')
    check(git(HOST, 'rev-parse', 'HEAD').decode().strip() == SOURCE, 'Host HEAD moved')
    check(git(HOST, 'rev-parse', SOURCE + '^{tree}').decode().strip() == receipt['source_tree'], 'Wrong host tree')
    for key in ('inputs_unchanged', 'source_head_unchanged', 'analysis_config_restored',
                'analysis_config_unchanged_during_run'):
        check(receipt.get(key) is True, 'Failed integrity gate: ' + key)
    commands = {row['name']: row for row in receipt['commands']}
    check(set(commands) == GATES and len(receipt['commands']) == 6, 'Six-command selection differs')
    for name, row in commands.items():
        check(row.get('exit_code') == 0 and row.get('passed') is True, 'Failed command: ' + name)
        for stream in ('stdout', 'stderr'):
            check(sha(EVIDENCE / f'{name}.{stream}.log') == row[stream + '_sha256'], 'Log hash mismatch: ' + name + '/' + stream)
    check('--fatal-infos' in commands['workflow-analysis']['command'], 'Analysis not strict')
    check('No issues found!' in (EVIDENCE / 'workflow-analysis.stdout.log').read_text(), 'Analyzer not clean')
    check('--set-exit-if-changed' in commands['workflow-format']['command'] and
          '--language-version=3.13' in commands['workflow-format']['command'], 'Wrong formatting gate')
    check('(0 changed)' in (EVIDENCE / 'workflow-format.stdout.log').read_text(), 'Formatter changed source')
    report['command_gates'] = {name: row['exit_code'] for name, row in commands.items()}

    starts, ends, suites, done, errors, other_lines = {}, {}, {}, [], [], []
    for number, line in enumerate((EVIDENCE / 'workflow-tests.stdout.log').read_text().splitlines(), 1):
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            other_lines.append({'line': number, 'text': line})
            continue
        kind = event.get('type')
        if kind == 'testStart':
            row = event['test']; check(row['id'] not in starts, 'Duplicate start ID'); starts[row['id']] = row
        elif kind == 'testDone':
            check(event['testID'] not in ends, 'Duplicate terminal ID'); ends[event['testID']] = event
        elif kind == 'suite':
            row = event['suite']; check(row['id'] not in suites, 'Duplicate suite ID'); suites[row['id']] = row
        elif kind == 'done':
            done.append(event)
        elif kind == 'error':
            errors.append(event)
    check(set(starts) == set(ends), 'Starts and terminal IDs differ')
    check(len(done) == 1 and done[0].get('success') is True, 'Missing unique successful completion')
    check(not errors, 'Raw error events exist')
    check(all(row['result'] == 'success' and not row.get('skipped') for row in ends.values()), 'Failed/skipped raw terminal')
    # Flutter may print native-assets progress before the JSON test protocol.
    check(all(row['text'].startswith('Running build hooks...') for row in other_lines), 'Unexpected non-JSON test output')
    check(len(suites) == 1 and {Path(row['path']).resolve() for row in suites.values()} == {HOST / SUITE}, 'Actual suite routing differs')
    cases = []
    for identifier, start in starts.items():
        name = start['name']
        if name.startswith('loading ') or name.endswith(('(setUpAll)', '(tearDownAll)')):
            continue
        check(not ends[identifier].get('hidden') and not start.get('metadata', {}).get('skip'), 'Hidden or declared skipped case')
        cases.append({'id': identifier, 'name': name, 'suite': str(Path(suites[start['suiteID']]['path']).resolve())})
    check(Counter(row['name'] for row in cases) == Counter(CASES), 'Case names/counts differ from the ten authored scenarios')
    check(commands['workflow-tests']['selected_files'] == [SUITE], 'Selected test differs')
    check([v for v in commands['workflow-tests']['command'] if v.endswith('_test.dart')] == [SUITE], 'Executed test argument differs')
    report['widget_tests'] = {'passed': len(cases), 'failed': len(errors), 'skipped': 0,
                              'cases': cases, 'start_events': len(starts), 'terminal_events': len(ends),
                              'native_build_progress_lines': other_lines}

    before, after = load(EVIDENCE / 'inputs-before.json'), load(EVIDENCE / 'inputs-after.json')
    check(before == after, 'Before/after input maps differ')
    host_tree = tree(HOST, SOURCE)
    for name, row in before['source'].items():
        path = HOST / name; content = data(path)
        oid = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
        mode = '120000' if path.is_symlink() else ('100755' if path.stat().st_mode & 0o111 else '100644')
        check(host_tree[name]['blob'] == row['git_blob'] == oid and host_tree[name]['mode'] == row['mode'] == mode,
              'Source Git binding mismatch: ' + name)
        check(digest(content) == row['sha256'], 'Source SHA mismatch: ' + name)
    for section in ('dependencies', 'workspace'):
        for name, expected in before[section].items():
            path = Path(name)
            check((sha(path) if path.is_file() else None) == expected, section + ' changed: ' + name)
    for name, expected in before['runtime'].items():
        path = Path(receipt['python_runtime']['path']) if name == 'python/executable' else SDK / name
        check(sha(path) == expected, 'Runtime changed: ' + name)
    check(before['runner_sha256'] == RUNNER == sha(BASE / 'run_final_improvement_validation.py'), 'Runner identity differs')
    counts = {key: len(before[key]) for key in ('source', 'dependencies', 'runtime', 'workspace', 'package_routes')}
    check(counts == {'source': 7494, 'dependencies': 7188, 'runtime': 517, 'workspace': 28, 'package_routes': 180}, 'Input map cardinality differs')
    report['input_maps'] = {**counts, 'before_after_equal': before == after}
    routing = receipt['workflow_input_routing']
    check([row['selected'] for row in routing] == ROUTED, 'Workflow/support/library/fixture selection differs')
    for row in routing:
        path = HOST / row['source_path']
        check((HARNESS / row['selected']).resolve() == path == Path(row['resolved']), 'Workflow route changed: ' + row['selected'])
        check(sha(path) == row['sha256'] == before['source'][row['source_path']]['sha256'], 'Workflow routed input hash differs')

    config = HARNESS / '.dart_tool/package_config.json'
    graph = load(config); analysis = load(EVIDENCE / 'analysis-package-config.json')
    lock = yaml.safe_load((HARNESS / 'pubspec.lock').read_text())['packages']
    production = yaml.safe_load((HOST / 'pubspec.lock').read_text())['packages']
    setup = load(SETUP / 'workflow-harness-ready.json')
    check(sha(config) == before['graph_sha256'] == setup['graph_sha256'], 'Package graph identity differs')
    check(sha(HARNESS / 'pubspec.lock') == before['lock_sha256'] == setup['lock_sha256'], 'Lock identity differs')
    check({row['name'] for row in graph['packages']} == set(lock) | {'crisp_cloud'}, 'Graph/lock package set differs')
    hosted = {name: row for name, row in lock.items() if row['source'] == 'hosted'}
    check(len(hosted) == 162, 'Wrong hosted pin count')
    for name, row in hosted.items():
        check(row['version'] == production[name]['version'] and row['description'] == production[name]['description'], 'Production archive pin differs: ' + name)
    for package in graph['packages']:
        name = package['name']; root = Path(unquote(urlparse(urljoin(config.as_uri(), package['rootUri'])).path)).resolve()
        library = (root / package.get('packageUri', 'lib/')).resolve()
        current = {'root': str(root), 'library': str(library),
                   'resources': {part: str((root / part).resolve()) for part in
                                 ('assets', 'fonts', 'hook', 'native', 'rust', 'rust_cloud') if (root / part).exists()}}
        check(current == before['package_routes'][name], 'Package route changed: ' + name)
        if library.is_relative_to(HOST):
            for path in library.rglob('*.dart'):
                check(str(path.relative_to(HOST)) in before['source'], 'Unbound executed local source: ' + str(path))
    analysis_by_name = {row['name']: row for row in analysis['packages']}
    for name, route in before['package_routes'].items():
        package = analysis_by_name[name]
        root = Path(unquote(urlparse(package['rootUri']).path))
        check((root / package.get('packageUri', 'lib/')).resolve() == Path(route['library']), 'Analysis/execution library mismatch: ' + name)
    check(not (HOST / '.dart_tool/package_config.json').exists(), 'Temporary root config not restored')
    git_source = load(SETUP / 'workflow-harness-setup-03/receipt.json')['git_sources']['libdbm']
    dep = Path(git_source['root'])
    check(git(dep, 'rev-parse', 'HEAD').decode().strip() == git_source['source_commit'] == production['libdbm']['description']['resolved-ref'], 'Git dependency pin differs')
    for name, row in git_source['files'].items():
        check(sha(dep / name) == row['sha256'], 'Pinned libdbm file changed: ' + name)
    fonts = load(SETUP / 'host-font-materialization.json')['files']
    for row in fonts:
        check(before['source'][row['path']]['sha256'] == row['sha256'] == sha(HOST / row['path']), 'Font source binding differs')
    report['package_graph'] = {'packages': len(graph['packages']), 'production_hosted_pins': len(hosted),
                               'host_path_packages': 11, 'external_git_pin': git_source['source_commit'],
                               'four_materialized_fonts_bound': True, 'analysis_config_restored': True}
    manifest = load(HOST / 'tool/office_fidelity_manifest.json')
    check(manifest['source_commit'] == PIN, 'Wrong canonical qualified pin')
    canonical_tree = tree(CANONICAL, PIN)
    for name in manifest['files']:
        if not name.startswith('packages/legacy_doc_parser/'):
            check(host_tree[name]['blob'] == canonical_tree[name]['blob'], 'Canonical vendor differs: ' + name)
    report['canonical_binding'] = {'qualified_pin': PIN, 'managed_files': len(manifest['files']),
                                    'manifest_sha256': sha(HOST / 'tool/office_fidelity_manifest.json'),
                                    'documentation_only_canonical_HEAD_advance_allowed': True}

    preauth = load(SETUP / 'sqlite-native-asset/receipt.json')
    expected = preauth['expected_binary_sha256']
    check(preauth['status'] == 'authenticated' and sha(Path(preauth['saved_path'])) == expected, 'SQLite preauthentication differs')
    metadata_dir = OUT / 'workflow-native-metadata'; metadata_dir.mkdir(exist_ok=True)
    hooks = {}
    for path in sorted((HARNESS / '.dart_tool/hooks_runner').glob('*/*/input.json')):
        inputs = load(path); name = inputs['package_name']; outputs = load(path.with_name('output.json'))
        check(name not in hooks, 'Multiple hook executions for ' + name)
        check(outputs['status'] == 'success', 'Hook failed: ' + name)
        check(inputs['user_defines'] == {}, 'Unexpected native hook user defines: ' + name)
        target = inputs['config']['extensions']['code_assets']
        check(target['target_os'] == 'linux' and target['target_architecture'] == 'x64', 'Wrong native target')
        check(Path(inputs['package_root']).resolve() == Path(before['package_routes'][name]['root']), 'Native hook package route differs')
        metadata = {}
        for source in path.parent.iterdir():
            if source.name == '.lock' or not source.is_file():
                continue
            metadata[source.name] = {'sha256': sha(source), 'bytes': source.stat().st_size}
            if source.suffix == '.json' or source.name in ('stdout.txt', 'stderr.txt', 'hook.dill.d'):
                destination = metadata_dir / name / source.name
                destination.parent.mkdir(exist_ok=True)
                shutil.copyfile(source, destination)
        hooks[name] = {'inputs': inputs, 'outputs': outputs, 'metadata': metadata}
    check(set(hooks) == {'crisp_storage', 'objective_c', 'sqlite3'}, 'Unexpected native hook set')
    for name in ('crisp_storage', 'objective_c'):
        check(not hooks[name]['outputs'].get('assets'), 'Unexpected native output: ' + name)
    assets = hooks['sqlite3']['outputs']['assets']
    check(len(assets) == 1, 'SQLite hook emitted unexpected assets')
    asset = assets[0]['encoding']; identifier = 'package:sqlite3/src/ffi/libsqlite3.g.dart'
    check(asset['id'] == identifier and asset['link_mode']['type'] == 'dynamic_loading_bundle', 'Wrong SQLite hook asset')
    emitted = Path(asset['file']); check(sha(emitted) == expected, 'Hook-selected SQLite bytes differ')
    native_manifest = HARNESS / 'build/native_assets/linux/native_assets.json'
    native = load(native_manifest)
    check(set(native['native-assets']) == {'linux_x64'}, 'Unexpected native manifest targets')
    selected = native['native-assets']['linux_x64']
    check(set(selected) == {identifier} and selected[identifier][0] == 'absolute', 'Unexpected bundled native asset mapping')
    bundled = Path(selected[identifier][1]); check(sha(bundled) == expected, 'Bundled SQLite bytes differ')
    check(emitted.stat().st_size == bundled.stat().st_size == preauth['bytes'] == 1793240, 'SQLite byte size differs')
    shutil.copyfile(native_manifest, metadata_dir / 'native_assets.json')
    report['native_asset'] = {'status': 'authenticated_hook_and_manifest_selection',
                              'expected_sha256': expected, 'actual_hook_sha256': sha(emitted),
                              'actual_bundled_sha256': sha(bundled), 'bytes': bundled.stat().st_size,
                              'hook_selected_path': str(emitted), 'manifest_selected_path': str(bundled),
                              'native_manifest_sha256': sha(native_manifest), 'hooks': hooks,
                              'limitation': 'Confirms exact hook output and runtime native-asset manifest selection. It does not instrument dlopen or prove that these widget scenarios invoked SQLite functions. Optional Rust storage and Apple native assets were not emitted.'}
    report['evidence_hashes'] = {str(path.relative_to(BASE)): sha(path) for path in [
        EVIDENCE / 'receipt.json', EVIDENCE / 'inputs-before.json', EVIDENCE / 'inputs-after.json',
        EVIDENCE / 'workflow-tests.stdout.log', SETUP / 'workflow-harness-ready.json',
        SETUP / 'sqlite-native-asset/receipt.json', Path(__file__).resolve()]}
    report['scope'] = 'Ten real production menu/dialog/controller export widget cases with authored fixtures and cloud/copy-destination test doubles. Six gates. Separate from the 107-case core cohort; no historical totals added. No live OS chooser, cloud transport, Office interoperability, proofing-model or Wasm acceptance.'
    report['status'] = 'passed' if not report['findings'] else 'failed'
    (OUT / 'workflow-audit.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'findings', 'input_maps', 'package_graph')}, indent=2))
    print(json.dumps({key: report['native_asset'][key] for key in ('status', 'bytes', 'actual_bundled_sha256', 'manifest_selected_path')}, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
