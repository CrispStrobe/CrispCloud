#!/usr/bin/env python3
"""Package accepted Office improvements, prior controls and exact review evidence."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
DESTINATION = Path('docs/validation/office-improvements-20261117')
OMIT = {'tmp', 'config', '__pycache__', '.git', '.dart_tool', 'isolated-engine',
        'bookmark-old-engine', 'old-engine', 'node_modules'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(files, name, path):
    assert name not in files, name
    assert path.is_file() and not path.is_symlink(), path
    files[name] = path.read_bytes()


def directory(files, prefix, root):
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if path.is_file() and not path.is_symlink() and not any(p in OMIT for p in relative.parts):
            add(files, prefix + '/' + relative.as_posix(), path)


def top_files(files, prefix, root):
    for path in sorted(root.iterdir()):
        if path.is_file() and not path.is_symlink():
            add(files, prefix + '/' + path.name, path)


def accepted(path):
    value = json.loads(path.read_text())
    assert value['status'] == 'passed', path
    assert not value.get('findings'), path
    return value


def package(kind):
    canonical = kind == 'canonical'
    name = 'quds_office_suite' if canonical else 'CrispCloud'
    repo, dest = BASE / name, BASE / name / DESTINATION
    dest.mkdir(parents=True, exist_ok=True)
    run = BASE / ('qualified-canonical-7fd2030f-r2' if canonical else 'qualified-host-f08035db')
    review = BASE / 'final-qualified-review'
    review_name = 'canonical-review.json' if canonical else 'host-audit.json'
    script_name = 'canonical-review.py' if canonical else 'host_review.py'
    receipt, audited = accepted(run / 'receipt.json'), accepted(review / review_name)
    expected_source = ('7fd2030fd39a2b0bbdb1b1e778840c332ae6bbc3' if canonical else
                       'f08035db691d5a1fe7299ad3608b626ab6202d27')
    assert receipt['source_commit'] == expected_source
    files = {}
    for source, target in [
        (BASE / 'run_final_improvement_validation.py', 'run_validation.py'),
        (BASE / 'verify_improvement_delivery.py', 'verify_delivery.py'),
        (run / 'receipt.json', 'qualification.json'),
        (review / review_name, 'independent-review.json'),
    ]:
        shutil.copyfile(source, dest / target)
    directory(files, 'qualification', run)
    add(files, 'review/' + review_name, review / review_name)
    add(files, 'review/' + script_name, review / script_name)
    for name in ('run_final_improvement_validation.py', 'run_integrated_improvement_validation.py',
                 'run_improvement_validation.py', 'verify_improvement_delivery.py'):
        add(files, 'scripts/' + name, BASE / name)
    add(files, 'scripts/build_final_improvement_evidence.py', Path(__file__))
    for path in sorted((BASE / 'concurrent-integration').glob('*')):
        if path.is_file():
            add(files, 'integration/' + path.name, path)
    for name in ('final-runner-preparation', 'final-runner-review'):
        directory(files, 'integration/' + name, BASE / 'concurrent-integration' / name)
    old_report = BASE / 'qualified-preintegration-docs' / ('quds_office_suite' if canonical else 'CrispCloud')
    for name in ('README.md', 'qualification.json', 'independent-review.json'):
        add(files, 'prior/initial-report/' + name, old_report / name)
    if canonical:
        writer = BASE / 'evidence-writer'
        index = json.loads((writer / 'writer-evidence-index.json').read_text())
        for name, item in index['files'].items():
            data = (writer / name).read_bytes()
            assert (len(data), sha(data)) == (item['bytes'], item['sha256']), name
            add(files, 'controls/writer/' + name, writer / name)
        add(files, 'controls/writer/writer-evidence-index.json', writer / 'writer-evidence-index.json')
        extraction = BASE / 'evidence-extraction'
        for item in json.loads((extraction / 'manifest.json').read_text()):
            data = (extraction / item['path']).read_bytes()
            assert (len(data), sha(data)) == (item['size'], item['sha256']), item['path']
            add(files, 'controls/extraction/' + item['path'], extraction / item['path'])
        add(files, 'controls/extraction/manifest.json', extraction / 'manifest.json')
        for name, prefix in (('evidence-concurrent-writer', 'controls/tabs'),
                             ('evidence-concurrent-columns', 'controls/columns')):
            top_files(files, prefix, BASE / name)
        directory(files, 'controls/tabs/merge-inputs', BASE / 'evidence-concurrent-writer/merge-inputs')
        for name in ('controls-reproduction', 'second-writer-merge', 'setup'):
            directory(files, 'integration/' + name, BASE / 'concurrent-integration' / name)
        for name in ('concurrent-columns-review.json', 'concurrent-columns-review.py'):
            add(files, 'review/' + name, BASE / 'final-independent-review' / name)
        directory(files, 'prior/606/qualification', BASE / 'final-canonical')
        for name in ('canonical-review.py', 'canonical-review.json'):
            add(files, 'prior/606/review/' + name, BASE / 'final-independent-review' / name)
        directory(files, 'prior/1533/qualification', BASE / 'integrated-canonical')
        for path in sorted((BASE / 'integrated-independent-review').glob('canonical*')):
            if path.is_file():
                add(files, 'prior/1533/review/' + path.name, path)
        directory(files, 'interrupted/final-attempt001', BASE / 'qualified-canonical-7fd2030f')
        directory(files, 'preflight/local-source-before-final-binding', BASE / 'final-canonical-001')
        files['preflight/README.txt'] = (
            'The early combined run is a preflight on local commit cca463fd with the same tree as fb502f61. '
            'The runner was subsequently hardened. Its earlier executed hash is recorded; original script '
            'bytes are not bundled. It contributes no final count. The accepted final source is 7fd2030f; '
            'only qualification/ supplies final counts. Prior606/1533 and the interrupted attempt are separate.\n').encode()
        add(files, 'setup/initial-offline-resolution.log', BASE / 'canonical-offline-setup.log')
        for name in ('pubspec.yaml', 'pubspec.lock', '.dart_tool/package_config.json', '.dart_tool/package_graph.json'):
            add(files, 'setup/final/' + name.replace('.dart_tool/', ''), repo / name)
    else:
        workflow = BASE / 'qualified-workflow-f08035db'
        accepted(workflow / 'receipt.json')
        accepted(review / 'workflow-audit.json')
        for source, target in [(workflow / 'receipt.json', 'workflow-qualification.json'),
                               (review / 'workflow-audit.json', 'workflow-independent-review.json'),
                               (BASE / 'concurrent-integration/host-shared-78a4/host-preservation.json', 'preservation.json')]:
            shutil.copyfile(source, dest / target)
        directory(files, 'workflow-qualification', workflow)
        for path in sorted(review.glob('workflow*')):
            if path.is_file():
                add(files, 'review/' + path.name, path)
        directory(files, 'review/workflow-native-metadata', review / 'workflow-native-metadata')
        directory(files, 'controls', BASE / 'evidence-host-acceptance')
        directory(files, 'integration/first-captured-host', BASE / 'concurrent-integration/host')
        directory(files, 'integration/second-captured-host', BASE / 'concurrent-integration/host-shared-78a4')
        directory(files, 'prior/63ca/qualification', BASE / 'final-host')
        for name in ('host_review.py', 'host-audit.json'):
            add(files, 'prior/63ca/review/' + name, BASE / 'final-independent-review' / name)
        directory(files, 'prior/03625/qualification', BASE / 'integrated-host')
        for name in ('host_review.py', 'host-audit.json'):
            add(files, 'prior/03625/review/' + name, BASE / 'integrated-independent-review' / name)
        directory(files, 'setup/first-attempt', BASE / 'host-setup')
        directory(files, 'setup/accepted-focused', BASE / 'host-setup-ready')
        for name in ('host-harness-relocation.json', 'host-package-recovery.json', 'host-package-recovery.log',
                     'setup_host_harness.py', 'recover_host_packages.py'):
            add(files, 'setup/' + name, BASE / name)
        add(files, 'setup/resolve-host-harness-offline.py', BASE / 'prior-host-evidence/scripts/resolve-host-harness-offline.py')
        for name in ('harness-pubspec.yaml', 'harness-pubspec.lock'):
            add(files, 'setup/prior/' + name, BASE / 'prior-host-evidence/setup' / name)
        for harness_name in ('host-harness', 'host-workflow-harness'):
            harness = BASE / harness_name
            for name in ('pubspec.yaml', 'pubspec.lock', '.dart_tool/package_config.json', '.dart_tool/package_graph.json'):
                add(files, 'setup/final/' + harness_name + '/' + name.replace('.dart_tool/', ''), harness / name)
            for path in sorted(harness.glob('packages/*/pubspec.yaml')):
                add(files, 'setup/final/' + harness_name + '/' + path.relative_to(harness).as_posix(), path)
        for name in ('vendor-sync-plan.json', 'vendor-sync-applied.json', 'host-preservation.json'):
            add(files, 'prior/initial-preservation/' + name, BASE / name)
        add(files, 'preservation/audit_preservation.py', repo / 'docs/validation/office-resume-20261117/audit_preservation.py')
    archive_path = dest / 'evidence.tar.xz'
    with tarfile.open(archive_path, 'w:xz', preset=6) as archive:
        for name, data in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode, member.mtime = len(data), 0o644, 0
            archive.addfile(member, io.BytesIO(data))
    expected = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())}
    seen = {}
    with tarfile.open(archive_path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile() and member.name not in seen
            data = archive.extractfile(member).read()
            seen[member.name] = {'bytes': len(data), 'sha256': sha(data)}
    assert seen == expected
    result = {'archive': archive_path.name, 'bytes': archive_path.stat().st_size,
              'sha256': sha(archive_path.read_bytes()), 'member_count': len(expected),
              'qualified_source': expected_source, 'all_members_read_back_and_verified': True,
              'members': expected}
    (dest / 'evidence-index.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'kind': kind, **{key: result[key] for key in ('bytes', 'sha256', 'member_count')}}))


if __name__ == '__main__':
    package('canonical')
    package('host')
