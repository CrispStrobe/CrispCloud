#!/usr/bin/env python3
"""Recover missing archives only, verifying every download against the host lock."""
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import io
import json
from pathlib import Path
import tarfile
import urllib.request
import yaml

BASE = Path(__file__).resolve().parent
CACHE = Path('/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/pub-cache')
packages = yaml.safe_load((BASE / 'host-harness/pubspec.lock').read_text())['packages']

def fetch(item):
    name, spec = item
    key = name + '-' + spec['version']
    expected = spec['description']['sha256']
    target = CACHE / 'hosted/pub.dev' / key
    marker = CACHE / 'hosted-hashes/pub.dev' / (key + '.sha256')
    if target.exists():
        assert marker.read_text().strip() == expected, key
        return {'package': key, 'status': 'existing', 'archive_sha256': expected}
    assert spec['description']['url'] == 'https://pub.dev'
    url = 'https://pub.dev/api/archives/' + key + '.tar.gz'
    with urllib.request.urlopen(url, timeout=45) as response:
        payload = response.read()
    actual = hashlib.sha256(payload).hexdigest()
    assert actual == expected, key
    temp = CACHE / '_temp' / ('office-improvement-' + key)
    temp.mkdir(parents=True, exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        archive.extractall(temp, filter='data')
    temp.rename(target)
    marker.write_text(actual)
    return {'package': key, 'status': 'downloaded', 'archive_sha256': actual, 'bytes': len(payload), 'url': url}

results = []
with ThreadPoolExecutor(max_workers=6) as pool:
    pending = [pool.submit(fetch, (n, s)) for n, s in packages.items() if s['source'] == 'hosted']
    for future in as_completed(pending):
        result = future.result()
        results.append(result)
        if result['status'] == 'downloaded':
            print(result['package'], flush=True)
(BASE / 'host-package-recovery.json').write_text(json.dumps(sorted(results, key=lambda r: r['package']), indent=2) + '\n')
print('Verified', len(results), 'hosted package archive pins')
