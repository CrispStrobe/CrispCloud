#!/usr/bin/env python3
"""Restore the prior focused host graph, changing only local checkout paths."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'CrispCloud'
PRIOR = BASE / 'prior-host-evidence/setup'
TARGET = BASE / 'host-harness'
OLD = '/workspace/scratch/18384bc07dad/runtime-work/host/service-harness'
PACKAGES = ('quds_office_engine', 'quds_office_editor', 'quds_reports', 'legacy_doc_parser')

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert not TARGET.exists()
TARGET.mkdir()
receipt = {'source': str(SOURCE), 'harness': str(TARGET), 'path_relocation': {'from': OLD, 'to': str(TARGET)}, 'inputs': {}, 'package_manifests': {}, 'links': []}
for name in ('pubspec.yaml', 'pubspec.lock'):
    data = (PRIOR / ('harness-' + name)).read_bytes()
    relocated = data.replace(OLD.encode(), str(TARGET).encode())
    (TARGET / name).write_bytes(relocated)
    receipt['inputs'][name] = {'prior_sha256': sha(data), 'relocated_sha256': sha(relocated)}
for name in ('lib', 'test'):
    (TARGET / name).symlink_to(SOURCE / name, target_is_directory=True)
for name in PACKAGES:
    source = SOURCE / 'packages' / name
    target = TARGET / 'packages' / name
    target.mkdir(parents=True)
    manifest = (source / 'pubspec.yaml').read_bytes()
    assert b'resolution: workspace' not in manifest
    (target / 'pubspec.yaml').write_bytes(manifest)
    receipt['package_manifests'][name] = sha(manifest)
    for child in source.iterdir():
        if child.name in ('.dart_tool', 'build', 'pubspec.yaml', 'pubspec.lock', 'pubspec_overrides.yaml'):
            continue
        (target / child.name).symlink_to(child, target_is_directory=child.is_dir())
        receipt['links'].append({'path': str(target / child.name), 'target': str(child)})
(BASE / 'host-harness-relocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(TARGET)
