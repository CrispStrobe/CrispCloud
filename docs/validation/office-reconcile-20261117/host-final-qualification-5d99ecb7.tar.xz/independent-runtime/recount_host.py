#!/usr/bin/env python3
"""Read-only independent host qualification recount and immutable-input audit."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
from urllib.parse import unquote, urljoin, urlparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('run', type=Path)
parser.add_argument('--source', required=True)
parser.add_argument('--canonical-source', required=True)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--repo', type=Path, default=Path('/workspace/scratch/44ccebb41cba/CrispCloud'))
parser.add_argument('--canonical-repo', type=Path, default=Path('/workspace/scratch/44ccebb41cba/quds_office_suite'))
args = parser.parse_args()
run, repo = args.run.resolve(), args.repo.resolve()
receipt = json.loads((run / 'receipt.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
aggregate = lambda value: sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())
load = lambda name: json.loads((run / name).read_text())
git = lambda *parts: subprocess.check_output(['git', *parts], cwd=repo)

assert receipt['status'] == 'passed'
assert receipt['source_commit'] == args.source == receipt['head_at_completion']
assert receipt['canonical_source_commit'] == args.canonical_source
assert receipt['host_tree'] == git('rev-parse', args.source + '^{tree}').decode().strip()
assert receipt['canonical_tree'] == subprocess.check_output(
    ['git', 'rev-parse', args.canonical_source + '^{tree}'], cwd=args.canonical_repo, text=True).strip()
for key in ('github_actions_awaited', 'github_actions_or_status_queried', 'historical_counts_reused'):
    assert receipt[key] is False, key
for key in ('all_commands_passed', 'analysis_config_restored', 'source_unchanged',
            'dependencies_unchanged', 'tracked_inputs_unchanged', 'retained_cohorts_complete',
            'python_cohort_complete', 'test_stream_complete', 'supplemental_stream_complete',
            'supplemental_inputs_unchanged'):
    assert receipt[key] is True, key

expected_commands = [
    'vendor-before', 'host-tests', 'writer-host-probes', 'host-analysis', 'vendor-analysis',
    'host-format', 'viewer-format', 'vendor-format', 'python-vendor-tests',
    'apple-policy-source', 'whitespace', 'vendor-after',
]
assert [c['name'] for c in receipt['commands']] == expected_commands == receipt['expected_commands']
commands = {c['name']: c for c in receipt['commands']}
logs = {}
for name, command in commands.items():
    assert command['exit_code'] == 0 and command['status'] == 'passed', name
    data = (run / command['log']).read_bytes()
    assert sha(data) == command['log_sha256'], name
    logs[name] = data.decode()

source = load('source-before.json')
assert source == load('source-after.json')
assert len(source) == receipt['source_file_count']
assert aggregate(source) == receipt['source_before_aggregate_sha256'] == receipt['source_after_aggregate_sha256']
scope_roots = ('lib', 'packages', 'test', 'tool')
scope_files = {'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml',
               'docs/crypto-inventory.json', 'docs/apple-export-policy.json'}
git_files = {}
for entry in git('ls-tree', '-r', '-z', args.source).split(b'\0'):
    if not entry:
        continue
    metadata, raw_name = entry.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    name = raw_name.decode()
    if name in scope_files or name.split('/')[0] in scope_roots:
        assert kind == 'blob'
        git_files[name] = (mode, blob)
assert set(source) == set(git_files), (set(source) - set(git_files), set(git_files) - set(source))
for name, expected in source.items():
    mode, blob = git_files[name]
    path = repo / name
    data = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
    assert sha(data) == expected, name
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blob, name
    if mode != '120000':
        assert bool(path.stat().st_mode & 0o111) == (mode == '100755'), name
manifest = json.loads((repo / 'tool/office_fidelity_manifest.json').read_text())
assert manifest['source_commit'] == args.canonical_source
assert len(manifest['files']) == receipt['managed_files'] == 2620
assert manifest['standalone_sources']['packages/legacy_doc_parser']['commit'] == receipt['parser_source']

deps = load('dependencies-before.json')
assert deps == load('dependencies-after.json')
assert aggregate(deps) == receipt['dependencies_before_aggregate_sha256'] == receipt['dependencies_after_aggregate_sha256']
assert len(deps['dependency_files']) == receipt['dependency_file_count']
assert deps['package_count'] == len(deps['package_roots']) == 275
harness = Path(receipt['harness'])
config = harness / '.dart_tool/package_config.json'
graph = json.loads(config.read_text())
assert len(graph['packages']) == deps['package_count']
for entry in graph['packages']:
    parsed = urlparse(urljoin(config.as_uri(), entry['rootUri']))
    assert parsed.scheme == 'file' and not parsed.netloc
    root = Path(unquote(parsed.path)).resolve()
    library = (root / entry.get('packageUri', 'lib/')).resolve()
    recorded = deps['package_roots'][entry['name']]
    assert str(root) == recorded['root'] and str(library) == recorded['library']
    assert entry.get('languageVersion') == recorded['language_version']
    assert library.is_dir() == recorded['has_dart_library']
    if entry['name'] == 'crisp_cloud':
        assert library.samefile(repo / 'lib')
    elif entry['name'] in ('quds_office_engine', 'quds_office_editor', 'quds_reports', 'legacy_doc_parser'):
        assert library.samefile(repo / 'packages' / entry['name'] / 'lib')
for name, expected in deps['dependency_files'].items():
    if name.startswith('.dart_tool/') or name == 'analysis_options.yaml':
        path = harness / name
    else:
        package, relative = name.split('/', 1)
        root = deps['package_roots'][package]
        path = (Path(root['library']) / relative[4:] if relative.startswith('lib/')
                else Path(root['root']) / relative)
    assert sha(path.read_bytes()) == expected, name
for name, value in deps['declarations'].items():
    assert name.startswith('harness/')
    data = (harness / name.removeprefix('harness/')).read_bytes()
    assert sha(data) == value['sha256'] and data.decode() == value['text'], name
sdk = Path(commands['host-analysis']['command'][0]).parents[4]
for name, expected in deps['runtime_files'].items():
    assert sha((sdk / name).read_bytes()) == expected, name
for name, expected in deps['native_hook_and_tool_inputs'].items():
    assert sha(Path(name).read_bytes()) == expected, name

scripts = run.parent / 'scripts'
for filename, key in [('run-full-host-qualification.py', 'runner_sha256'),
                      ('run_host.py', 'native_wrapper_sha256'),
                      ('prior_host_qualification.py', 'prior_fingerprint_helper_sha256')]:
    assert sha((scripts / filename).read_bytes()) == receipt[key], filename
setup_path = run.parent / 'setup/full-host-setup.json'
assert sha(setup_path.read_bytes()) == receipt['setup_receipt_sha256']
setup = json.loads(setup_path.read_text())
assert setup['status'] == 'passed' and not setup['production_sources_stubbed'] and not setup['native_hooks_disabled']
for filename in ('pubspec.yaml', 'pubspec.lock'):
    assert (harness / filename).read_bytes() == (repo / filename).read_bytes(), filename
assert sha((repo / 'pubspec.lock').read_bytes()) == setup['production_lock_sha256'] == setup['final_lock_sha256']
assert sha((repo / 'pubspec.yaml').read_bytes()) == setup['production_manifest_sha256']
target = repo / '.dart_tool/package_config.json'
if receipt['analysis_config_preexisting']:
    before = (run / 'analysis-config-before.bin').read_bytes()
    assert sha(before) == receipt['analysis_config_before_sha256']
    assert target.read_bytes() == before
    assert stat.S_IMODE(target.stat().st_mode) == receipt['analysis_config_before_mode']
else:
    assert not target.exists()

expected_by_file = {
    'test/office_annotation_preview_test.dart': 8,
    'test/office_document_service_test.dart': 41,
    'test/office_proofing_licenses_test.dart': 2,
    'test/office_zotero_test.dart': 21,
    'test/office_zotero_citing_transport_test.dart': 16,
    'test/office_zotero_ribbon_test.dart': 2,
    'test/widget/office_odf_export_workflow_test.dart': 11,
    'test/widget/office_odt_field_export_test.dart': 1,
    'test/widget/office_editor_dialog_test.dart': 11,
    'test/widget/odt_image_viewer_test.dart': 1,
    'test/widget/ods_editor_workflow_test.dart': 5,
}
assert receipt['tests'] == list(expected_by_file)
assert commands['host-tests']['command'][3:] == list(expected_by_file)
assert receipt['expected_test_counts_by_file'] == {Path(p).name: n for p, n in expected_by_file.items()}


def recount(text, expected_paths):
    starts, suites, ends, done, errors, non_json = {}, {}, {}, [], [], []
    for line in text.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            non_json.append(line)
            continue
        if event.get('type') == 'testStart':
            test = event['test']
            assert test['id'] not in starts
            starts[test['id']] = test
        elif event.get('type') == 'suite':
            suite = event['suite']
            assert suite['id'] not in suites
            suites[suite['id']] = suite
        elif event.get('type') == 'testDone':
            assert event['testID'] not in ends
            ends[event['testID']] = event
        elif event.get('type') == 'done':
            done.append(event)
        elif event.get('type') == 'error':
            errors.append(event)
    assert len(done) == 1 and done[0]['success'] is True and not errors
    assert set(starts) == set(ends)
    assert set(Path(s['path']).resolve() for s in suites.values()) == set(expected_paths)
    counts, records, administrative = Counter(), [], 0
    for test_id, event in ends.items():
        test = starts[test_id]
        assert event['result'] == 'success' and not event.get('skipped'), test['name']
        is_admin = (event.get('hidden', False) or test['name'].startswith('loading ')
                    or test['name'].endswith('(setUpAll)') or test['name'].endswith('(tearDownAll)'))
        if is_admin:
            administrative += 1
        else:
            path = Path(suites[test['suiteID']]['path']).resolve()
            counts[str(path)] += 1
            records.append({'id': test_id, 'name': test['name'], 'path': str(path), 'result': event['result']})
    assert dict(counts) == {str(p): count for p, count in expected_paths.items()}
    return {'passed': len(records), 'failed': 0, 'skipped': 0,
            'terminal_events': len(ends), 'administrative_events': administrative,
            'unique_start_and_completion_ids': True, 'one_successful_done_event': True,
            'counts_by_file': dict(counts), 'non_json_lines': non_json, 'records': records}


host = recount(logs['host-tests'], {(repo / p).resolve(): count for p, count in expected_by_file.items()})
assert host['passed'] == receipt['test_counts']['passed'] == 119
assert {Path(p).name: n for p, n in host['counts_by_file'].items()} == receipt['test_counts_by_file']
probe_paths = [Path(p) for p in receipt['supplemental_probe_paths']]
assert {p.name for p in probe_paths} == {'odt_writer_host_test.dart', 'odt_list_host_test.dart', 'odt_note_host_test.dart'}
assert commands['writer-host-probes']['command'][3:] == [str(p) for p in probe_paths]
for p in probe_paths:
    assert sha(p.read_bytes()) == receipt['supplemental_probe_sha256'][str(p)]
probes = recount(logs['writer-host-probes'], {p.resolve(): 2 for p in probe_paths})
assert probes['passed'] == receipt['supplemental_test_counts']['passed'] == 6

python_rows = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. (\S+)\s*$', logs['python-vendor-tests'], re.M)
assert len(python_rows) == len({name for name, _ in python_rows}) == 28
assert all(result == 'ok' for _, result in python_rows)
assert re.search(r'^Ran 28 tests in ', logs['python-vendor-tests'], re.M)
assert re.search(r'^OK\s*$', logs['python-vendor-tests'], re.M)
assert receipt['passed_python_tests'] == 28

prior = json.loads((run.parent / 'qualification-83cc5b7c-attempt2/receipt.json').read_text())
host_targets = receipt['analysis_and_format_targets']
vendor_targets = receipt['vendored_analysis_targets']
format_targets = receipt['vendored_format_targets']
assert len(host_targets) == len(set(host_targets)) == 18
assert len(vendor_targets) == len(set(vendor_targets)) == 62
assert len(format_targets) == len(set(format_targets)) == 86
assert set(host_targets) - set(prior['analysis_and_format_targets']) == {'test/widget/office_odt_field_export_test.dart'}
assert set(prior['analysis_and_format_targets']) <= set(host_targets)
assert set(vendor_targets) - set(prior['vendored_analysis_targets']) == {'packages/quds_office_engine/lib/src/word/model/word_bookmarks.dart'}
assert set(prior['vendored_analysis_targets']) <= set(vendor_targets)
assert set(prior['vendored_format_targets']) <= set(format_targets)
for name, targets in [('host-analysis', host_targets), ('vendor-analysis', vendor_targets)]:
    assert commands[name]['command'][1:3] == ['analyze', '--fatal-infos']
    assert commands[name]['command'][3:] == targets
for name, targets in [('host-format', host_targets), ('vendor-format', format_targets)]:
    assert commands[name]['command'][1:4] == ['format', '--output=none', '--set-exit-if-changed']
    assert commands[name]['command'][4:] == targets
for path, entry in receipt['generated_data_manifest_check'].items():
    assert source[path] == entry['sha256']
    assert source[entry['manifest']] == entry['manifest_sha256']
    generated_manifest = json.loads((repo / entry['manifest']).read_text())
    relative = path.removeprefix('packages/quds_office_engine/')
    assert generated_manifest['generated_files'][relative] == entry['sha256']
    assert (repo / path).read_text().startswith('// GENERATED by tool/proofing/')
assert len(receipt['generated_format_exclusions']) == 18
assert set(vendor_targets) - set(format_targets) == set(receipt['generated_format_exclusions'])
assert set(receipt['generated_format_exclusions']) <= set(receipt['generated_data_manifest_check'])

report = {
    'recorded_utc': datetime.now(timezone.utc).isoformat(),
    'passed': True,
    'source_commit': args.source, 'source_tree': receipt['host_tree'],
    'canonical_source_commit': args.canonical_source, 'canonical_tree': receipt['canonical_tree'],
    'run': str(run), 'receipt_sha256': sha((run / 'receipt.json').read_bytes()),
    'reader_sha256': sha(Path(__file__).read_bytes()),
    'substantive_flutter_passes': host['passed'] + probes['passed'],
    'repository_cases': host, 'supplemental_writer_host_cases': probes,
    'python_passes': len(python_rows), 'python_successful_ids': [name for name, _ in python_rows],
    'all_twelve_gates_and_raw_log_hashes_verified': True,
    'source_files_verified_against_git_blob_modes_and_disk': len(source),
    'source_scope_roots': list(scope_roots), 'source_scope_root_files': sorted(scope_files),
    'all_managed_files_in_recorded_source_scope': set(manifest['files']) <= set(source),
    'managed_files': len(manifest['files']),
    'input_closure': {'source_before_after_equal': True, 'dependencies_before_after_equal': True,
                     'source_aggregate_sha256': aggregate(source), 'dependencies_aggregate_sha256': aggregate(deps),
                     'actual_dependency_files_rehashed': len(deps['dependency_files']),
                     'production_package_count': deps['package_count'],
                     'actual_native_hook_and_tool_inputs_rehashed': len(deps['native_hook_and_tool_inputs']),
                     'actual_runtime_files_rehashed': len(deps['runtime_files']),
                     'actual_declarations_rehashed': len(deps['declarations']),
                     'production_lock_and_pubspec_equal_to_harness': True,
                     'analyzer_config_restored': True, 'source_roots_resolve_to_real_host': True},
    'strict_host_targets': len(host_targets), 'strict_vendor_targets': len(vendor_targets),
    'host_format_targets': len(host_targets), 'vendor_format_targets': len(format_targets),
    'viewer_format_gate_passed': True,
    'generated_manifest_files_authenticated': len(receipt['generated_data_manifest_check']),
    'individually_authenticated_generated_format_exclusions': len(receipt['generated_format_exclusions']),
    'prior_scope_used_only_for_file_selection_retention_not_counts': True,
    'historical_counts_reused': False,
    'github_actions_or_status_queried_or_awaited': False,
    'scope': 'Read-only audit of completed local scoped widget/service/probe acceptance, raw events, immutable Git inputs and full production package graph. No new tests, platform release build, live service interaction or distribution action.'
}
assert report['all_managed_files_in_recorded_source_scope']
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('passed', 'source_commit', 'canonical_source_commit',
                                      'substantive_flutter_passes', 'python_passes',
                                      'source_files_verified_against_git_blob_modes_and_disk')}, indent=2))
