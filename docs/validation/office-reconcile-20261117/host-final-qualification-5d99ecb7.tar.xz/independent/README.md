# Final independent host source audit

This read-only audit binds local source `1ba0a6c5b16a7616049947e8b059371a4a69a471` to published source `5d99ecb79ab316058b2db2813932cf2a4849128a`. Both contain the exact tree `343251381590c1c41f3bb546b485d4c0683f2ead` and canonical pin `6a32a919325d71c121c63e3879cfd1b28d64312e`. The mapping record verifies identical tracked bytes, paths and modes; its Git diff is empty.

## Preservation

The immutable Git audit verifies all **2,620 managed files: 763 canonical and 1,857 standalone parser files**, with **20 host customizations**, all **six original notices and the engine license**, **50 canonical and 46 host Zotero paths**, and the exact **12 inherited executable-mode differences** retained. There are no new mode differences. Relative to the previous 83cc5b7c source, the managed update comprises five additions, three changed existing files and zero deletions. The standalone parser remains pinned to `4895712158127b2fc930d796e17035c3ca0dac62`.

The boundary audit confirms unchanged protected dependency declarations/lock and parser metadata, Unicode notice and registration, and no optional AOT/GECToR/Harper package directories or dependency/import additions in the host or canonical core. This is source and dependency inspection, separate from application/runtime acceptance.

## Actual menu workflow source review

The original eleven dialog/menu cases, their supporting harness and relevant product paths are byte-identical to 83cc5b7c. The new separate field case exercises raw-authored DOCX import, the real editor dialog/controllers and registered ODT menu callback, canonical serialization and a real preview parse. It checks native empty fields, styling, plain NUMPAGES placement, conservative styled/nested/malformed cache fallback, absence of hidden instructions and original-document preservation. These are twelve actual menu cases in total; runtime pass counts are recorded only in the final completed qualification. Copy destination, cloud writes and preference/cache isolation are controlled by the harness.

## Technical policy source binding

The 954-path reviewed-source hash was independently recomputed from Git blobs for 83cc5b7c and the final source. Relative to 83cc5b7c, only the Office fidelity manifest changes within that reviewed inventory. Relative to captured host main `fd0cc5de6de1ef9328bf44084ef38ace52765916`, the manifest plus two already qualified formatter wraps in the dialog differ. Only `reviewed_source_sha256` changes in the policy JSON; its other values, source inventory, lock and checker remain unchanged. This verifies technical source binding; it performs no submission or distribution action or decision.

## Evidence and reproduction

`host-preservation-1ba0a6c5.json` records every managed source identity and protected path; `host-boundary-1ba0a6c5.json` records the dependency boundary; `managed-delta-from-wave2.json` lists the exact changes. The two included audit scripts reproduce those immutable Git checks with their command-line arguments. The menu and policy reviews state their exact baselines. `published-source-mapping.json` verifies the local-to-remote mapping, and `index.json` authenticates all other members by length and SHA-256.

No tests were rerun for this source audit, no product checkout was modified, and no GitHub Actions, workflow, check-run or CI-status endpoint was queried or awaited. Fresh canonical and host qualification receipts and raw streams are audited separately.
