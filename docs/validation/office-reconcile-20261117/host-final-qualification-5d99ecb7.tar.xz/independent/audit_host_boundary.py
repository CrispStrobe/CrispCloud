#!/usr/bin/env python3
"""Independently verify the exact Office vendor and optional-package boundary."""
import argparse
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--host', type=Path, required=True)
parser.add_argument('--canonical', type=Path, required=True)
parser.add_argument('--host-ref', required=True)
parser.add_argument('--baseline', default='83617b79f8a56600e9ca17e73f835d944c79dfa8')
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()


def git(repo, *argv):
    return subprocess.check_output(['git', '-C', str(repo), *argv])


def read(repo, ref, path):
    return git(repo, 'show', ref + ':' + path)


def tree(repo, ref):
    entries = {}
    for row in git(repo, 'ls-tree', '-r', '-z', ref).split(b'\0'):
        if row:
            metadata, path = row.split(b'\t', 1)
            mode, kind, blob = metadata.decode().split()
            entries[path.decode()] = {'mode': mode, 'kind': kind, 'blob': blob}
    return entries


def shared(path):
    parts = Path(path).parts
    return (
        parts[:2] == ('tool', 'office-validation')
        or (len(parts) >= 5 and parts[:3] == ('packages', 'quds_office_engine', 'third_party')
            and parts[3] in ('hyphenation', 'proofing', 'fonttools'))
        or (len(parts) >= 3 and parts[0] == 'packages'
            and parts[1] in ('quds_office_engine', 'quds_office_editor', 'quds_reports')
            and parts[2] in ('lib', 'test', 'tool', 'CHANGELOG.md'))
    )


host_ref = git(args.host, 'rev-parse', args.host_ref).decode().strip()
baseline = git(args.host, 'rev-parse', args.baseline).decode().strip()
old = json.loads(read(args.host, baseline, 'tool/office_fidelity_manifest.json'))
new = json.loads(read(args.host, host_ref, 'tool/office_fidelity_manifest.json'))
canonical_ref = new['source_commit']
host = tree(args.host, host_ref)
prior = tree(args.host, baseline)
canonical = tree(args.canonical, canonical_ref)
failures = []

changed = git(args.canonical, 'diff', '--name-only', '--no-renames', old['source_commit'],
              canonical_ref).decode().splitlines()
changed_shared = sorted(path for path in changed if shared(path))
expected = set(old['files']) | set(changed_shared)
for path in changed_shared:
    if path not in canonical:
        expected.discard(path)
if expected != set(new['files']):
    failures.append('Final managed inventory differs from the old inventory plus changed shared source paths')
if any(host.get(path, {}).get('blob') != canonical.get(path, {}).get('blob')
       for path in changed_shared if path in canonical):
    failures.append('Changed shared canonical source does not match the host')

optional = ('quds_proofing_aot', 'quds_proofing_gector', 'quds_proofing_harper')
optional_paths = {name: [path for path in host if path.startswith('packages/' + name + '/')]
                  for name in optional}
pattern = r'package:quds_proofing_(aot|gector|harper)/|^[[:space:]]*quds_proofing_(aot|gector|harper):'
scan = subprocess.run(['git', '-C', str(args.host), 'grep', '-n', '-E', pattern, host_ref,
                       '--', '*.dart', '*pubspec*.yaml'], capture_output=True, text=True)
if scan.returncode not in (0, 1):
    raise RuntimeError(scan.stderr)
if any(optional_paths.values()) or scan.stdout:
    failures.append('An optional proofing package entered the host source/dependency boundary')
canonical_core_scan = subprocess.run(
    ['git', '-C', str(args.canonical), 'grep', '-n', '-E', pattern, canonical_ref, '--',
     'packages/quds_office_engine/lib', 'packages/quds_office_editor/lib',
     'packages/quds_office_engine/pubspec.yaml', 'packages/quds_office_editor/pubspec.yaml'],
    capture_output=True, text=True)
if canonical_core_scan.returncode not in (0, 1):
    raise RuntimeError(canonical_core_scan.stderr)
if canonical_core_scan.stdout:
    failures.append('Canonical engine/editor unexpectedly depends on optional proofing packages')

protected_paths = [
    'pubspec.yaml', 'pubspec.lock', 'packages/quds_office_engine/pubspec.yaml',
    'packages/quds_office_editor/pubspec.yaml', 'packages/quds_reports/pubspec.yaml',
    'packages/legacy_doc_parser/pubspec.yaml', 'packages/legacy_doc_parser/UPSTREAM.json',
    'lib/services/office_proofing_licenses.dart',
    'packages/quds_office_engine/third_party/proofing/UNICODE_INFLECTION_LICENSE',
    'packages/quds_office_engine/third_party/proofing/UNICODE_INFLECTION_NOTICE',
]
protected = {path: {'before': prior.get(path), 'after': host.get(path),
                    'unchanged': prior.get(path) == host.get(path)}
             for path in protected_paths}
for path, detail in protected.items():
    if not detail['unchanged'] or detail['before'] is None:
        failures.append('Dependency/notice boundary changed: ' + path)
metadata = json.loads(read(args.host, host_ref, 'packages/legacy_doc_parser/UPSTREAM.json'))
standalone = new['standalone_sources']['packages/legacy_doc_parser']
pubspec = read(args.host, host_ref, 'pubspec.yaml').decode()
pin = re.search(r'^  legacy_doc_parser:\n    git:\n'
                r'      url: https://github.com/CrispStrobe/legacy-doc-parser.git\n'
                r'      ref: ([0-9a-f]{40})\s*$', pubspec, re.MULTILINE)
override = re.search(r'^dependency_overrides:\n  legacy_doc_parser:\n'
                     r'    path: packages/legacy_doc_parser\s*$', pubspec, re.MULTILINE)
if metadata != {**standalone, 'patches': []} or pin is None or pin[1] != standalone['commit'] or override is None:
    failures.append('Standalone parser metadata, dependency and local override disagree')

result = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'host_ref': host_ref, 'host_tree': git(args.host, 'rev-parse', host_ref + '^{tree}').decode().strip(),
    'baseline_host_ref': baseline, 'baseline_canonical_ref': old['source_commit'],
    'canonical_ref': canonical_ref,
    'managed_count': len(new['files']),
    'managed_groups': dict(sorted(collections.Counter('/'.join(Path(path).parts[:2])
                       for path in new['files']).items())),
    'added_managed_paths': sorted(set(new['files']) - set(old['files'])),
    'removed_managed_paths': sorted(set(old['files']) - set(new['files'])),
    'changed_shared_canonical_paths': changed_shared,
    'all_changed_shared_sources_match_host': not any(
        host.get(path, {}).get('blob') != canonical.get(path, {}).get('blob')
        for path in changed_shared if path in canonical),
    'expected_managed_inventory_matches': expected == set(new['files']),
    'optional_host_paths': optional_paths,
    'optional_host_imports_or_dependency_declarations': scan.stdout.splitlines(),
    'optional_canonical_core_imports_or_dependency_declarations': canonical_core_scan.stdout.splitlines(),
    'protected_dependency_and_notice_paths': protected,
    'standalone_source': standalone, 'standalone_metadata': metadata,
    'unicode_notice_registration_retained': protected['lib/services/office_proofing_licenses.dart']['unchanged'],
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'passed': not failures, 'failures': failures,
    'scope': 'Immutable Git tree and dependency boundary audit; no application or native runtime acceptance claimed.',
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('host_ref', 'canonical_ref', 'managed_count',
                 'managed_groups', 'added_managed_paths', 'removed_managed_paths', 'passed', 'failures')}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
