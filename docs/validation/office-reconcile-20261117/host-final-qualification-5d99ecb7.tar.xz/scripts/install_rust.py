from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,tomllib,hashlib,json,tarfile,subprocess
root=Path(__file__).resolve().parents[1]
out=root/'rust-downloads';out.mkdir(exist_ok=True)
with urllib.request.urlopen('https://static.rust-lang.org/dist/channel-rust-stable.toml',timeout=20) as r: raw=r.read()
(out/'channel-rust-stable.toml').write_bytes(raw)
d=tomllib.loads(raw.decode());target='x86_64-unknown-linux-gnu'
components=['rustc','rust-std','cargo']
records=[]
def fetch(name):
 spec=d['pkg'][name]['target'][target];url=spec['xz_url'];p=out/url.rsplit('/',1)[-1]
 with urllib.request.urlopen(url,timeout=40) as r,p.open('wb') as f:
  while chunk:=r.read(1024*1024):f.write(chunk)
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 if actual!=spec['xz_hash']:raise RuntimeError('hash mismatch '+name)
 record={'name':name,'version':d['pkg'][name]['version'],'url':url,'sha256':actual,'bytes':p.stat().st_size}
 print(json.dumps(record),flush=True)
 with tarfile.open(p) as t:t.extractall(out,filter='data')
 record['source']=str(out/p.name.removesuffix('.tar.xz'))
 return record
with ThreadPoolExecutor(max_workers=3) as pool:
 records=list(pool.map(fetch,components))
for record in records:
 result=subprocess.run(['sh',str(Path(record['source'])/'install.sh'),'--prefix='+str(root/'rust-toolchain'),'--disable-ldconfig'],capture_output=True,text=True)
 record.update(install_exit=result.returncode,install_output=result.stdout+result.stderr)
 if result.returncode:raise RuntimeError(record)
(out/'receipt.json').write_text(json.dumps({'manifest_sha256':hashlib.sha256(raw).hexdigest(),'date':d['date'],'components':records},indent=2)+'\n')
