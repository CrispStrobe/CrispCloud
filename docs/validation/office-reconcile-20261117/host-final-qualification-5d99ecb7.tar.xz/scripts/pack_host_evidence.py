#!/usr/bin/env python3
"""Package a passed source-bound host run and verify every archived byte."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--qualification', required=True, type=Path)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--independent', required=True, type=Path)
    parser.add_argument('--runtime-review', required=True, type=Path)
    parser.add_argument('--runtime-review-runner', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    runtime = Path(__file__).resolve().parent.parent
    qualification = args.qualification.resolve()
    receipt = json.loads((qualification / 'receipt.json').read_text())
    if receipt['status'] != 'passed':
        raise ValueError('The final archive requires a passed complete run')
    for key, name in (
        ('runner_sha256', 'run-full-host-qualification.py'),
        ('native_wrapper_sha256', 'run_host.py'),
        ('prior_fingerprint_helper_sha256', 'prior_host_qualification.py'),
    ):
        if sha256((runtime / 'scripts' / name).read_bytes()) != receipt[key]:
            raise ValueError('Runner bytes changed after qualification: ' + name)
    members = {}

    def add(name, path):
        if name in members:
            raise ValueError('Duplicate member: ' + name)
        members[name] = Path(path).read_bytes()

    def add_tree(prefix, folder):
        if not folder.is_dir():
            raise ValueError('Missing evidence directory: ' + str(folder))
        for path in sorted(folder.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                add(prefix + '/' + path.relative_to(folder).as_posix(), path)

    add_tree('qualification', qualification)
    add_tree('scripts', runtime / 'scripts')
    add_tree('setup', runtime / 'setup')
    add_tree('independent', args.independent.resolve())
    add('independent-runtime/review.json', args.runtime_review)
    add('independent-runtime/recount_host.py', args.runtime_review_runner)
    add_tree('prior-evidence/probes', runtime / 'prior-evidence/probes')
    add_tree('diagnostic-chart-inputs', runtime / 'diagnostic-chart-inputs')
    for relative in (
        'rust-downloads/receipt.json',
        'rust-downloads/channel-rust-stable.toml',
        'clang-downloads/package-selection.json',
        'clang-downloads/install-receipt.json',
    ):
        add(relative, runtime / relative)
    for name in (
        'test/widget/office_odf_export_workflow_test.dart',
        'test/widget/office_odt_field_export_test.dart',
        'test/support/office_test_harness.dart',
    ):
        data = (args.repo / name).read_bytes()
        before = json.loads((qualification / 'source-before.json').read_text())
        if sha256(data) != before[name]:
            raise ValueError('Source changed after qualification: ' + name)
        add('qualified-source/' + name, args.repo / name)
    output = args.output.resolve()
    index_path = output.with_name(output.name.removesuffix('.tar.xz') + '-index.json')
    if output.exists() or index_path.exists():
        raise ValueError('Do not overwrite an existing evidence archive')
    output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    with tarfile.open(output, 'w:xz', preset=9) as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mtime = 0
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
            rows.append({'name': name, 'size': len(data), 'sha256': sha256(data)})
    with tarfile.open(output, 'r:xz') as archive:
        names = archive.getnames()
        if names != [row['name'] for row in rows]:
            raise ValueError('Archive member set differs')
        for row in rows:
            data = archive.extractfile(row['name']).read()
            if len(data) != row['size'] or sha256(data) != row['sha256']:
                raise ValueError('Archive readback differs: ' + row['name'])
    index = {
        'archive': output.name,
        'archive_size': output.stat().st_size,
        'archive_sha256': sha256(output.read_bytes()),
        'source_commit': receipt['source_commit'],
        'canonical_source_commit': receipt['canonical_source_commit'],
        'status': receipt['status'],
        'member_count': len(rows),
        'all_members_read_back_verified': True,
        'members': rows,
        'notes': [
            'Earlier failed qualification attempts remain separate committed archives and retain their original source attribution.',
            'Setup diagnostics and unexecuted field-test drafts are explicitly labeled; their counts are not added to final qualification.',
            'Native compiler and dependency binaries are reproducible from exact-lock metadata and recorded immutable hashes; large caches are not duplicated.',
        ],
    }
    index_path.write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({k: index[k] for k in ('archive', 'archive_size', 'archive_sha256', 'member_count', 'all_members_read_back_verified')}, indent=2))


if __name__ == '__main__':
    main()
