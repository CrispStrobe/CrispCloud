#!/usr/bin/env python3
"""Create the source-linked host harness with exact production declarations.

Dependency resolution is a separate explicit step. This script neither changes
the source checkout nor substitutes any application or native-hook source.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--harness', required=True, type=Path)
args = parser.parse_args()
repo = args.repo.resolve()
harness = args.harness.resolve()
if subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo).strip():
    raise RuntimeError('Use a clean frozen source checkout.')
harness.mkdir(parents=True, exist_ok=False)
names = subprocess.check_output(
    ['git', 'ls-tree', '-z', '--name-only', 'HEAD'], cwd=repo,
).decode().split('\0')
for name in filter(None, names):
    source = repo / name
    target = harness / name
    if name in ('pubspec.yaml', 'pubspec.lock'):
        shutil.copyfile(source, target)
    else:
        target.symlink_to(source, target_is_directory=source.is_dir())
receipt = {
    'source_commit': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=repo, text=True,
    ).strip(),
    'source_tree': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD^{tree}'], cwd=repo, text=True,
    ).strip(),
    'repo': str(repo),
    'harness': str(harness),
    'copied_declarations': {
        name: hashlib.sha256((harness / name).read_bytes()).hexdigest()
        for name in ('pubspec.yaml', 'pubspec.lock')
    },
    'application_source_substituted': False,
    'dependency_resolution_performed': False,
}
print(json.dumps(receipt, indent=2))
