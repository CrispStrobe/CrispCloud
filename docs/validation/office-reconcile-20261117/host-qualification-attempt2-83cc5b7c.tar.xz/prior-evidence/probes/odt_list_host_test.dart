import 'dart:io';
import 'dart:typed_data';

import 'package:crisp_cloud/services/office_document_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

WmlParagraph _paragraph(
  String text, {
  int? numId,
  String? label,
  bool suppressed = false,
}) => WmlParagraph(
  properties: WmlParagraphProps(
    numId: numId,
    listLabel: label,
    numberingSuppressed: suppressed,
  ),
  inlines: [WmlRun(text: text)],
);

XmlElement _body(OpcPackage package) =>
    XmlDocument.parse(package.getPart('/content.xml')!.readText()).root!
        .firstChild('body')!
        .firstChild('text')!;

void main() {
  test(
    'list groups preserve boundaries, order and visible whitespace in host',
    () async {
      final document = WmlDocument(
        sections: [
          WmlSection(
            blocks: [
              _paragraph('First  alpha\tbeta\nline', numId: 10, label: '1. '),
              _paragraph('Second', numId: 10, label: '2. '),
              _paragraph('Between'),
              _paragraph('Third group', numId: 10, label: '1. '),
              _paragraph(
                'Suppressed',
                numId: 10,
                label: '99. ',
                suppressed: true,
              ),
              _paragraph('Bullet A', numId: 20, label: '•'),
              _paragraph('Bullet B', numId: 20, label: '•'),
              _paragraph('Different group', numId: 21, label: '•'),
              _paragraph('Tail'),
            ],
          ),
        ],
      );
      final bytes = OdtDocumentWriter.writeBytes(document);
      final body = _body(OpcPackage.openBytes(bytes));
      expect(
        body.children.whereType<XmlElement>().map((node) => node.localName),
        ['list', 'p', 'list', 'p', 'list', 'list', 'p'],
      );
      final groups = body.childrenNamed('list').toList();
      expect(groups.map((group) => group.childrenNamed('list-item').length), [
        2,
        1,
        2,
        1,
      ]);
      final read = await parseOfficeDocument(
        Uint8List.fromList(bytes),
        'grouped.odt',
      );
      expect(read.fallback, isNull);
      expect(read.markdown.split('\n\n'), [
        '1. First  alpha\tbeta\nline',
        '2. Second',
        'Between',
        '1. Third group',
        'Suppressed',
        '- Bullet A',
        '- Bullet B',
        '- Different group',
        'Tail',
      ]);
    },
  );

  test(
    'Zotero caches inside one ordered list remain visible and unmodified',
    () async {
      final package = OpcPackage.create(OpcPackageKind.word);
      package
          .getPart('/word/document.xml')!
          .writeText(
            File(
              'packages/quds_office_engine/test/fixtures/zotero/word_document.xml',
            ).readAsStringSync(),
          );
      final document = WordDeserializer().read(package);
      final paragraphs = document.sections.single.blocks
          .whereType<WmlParagraph>()
          .toList();
      expect(paragraphs, hasLength(6));
      for (var i = 0; i < paragraphs.length; i++) {
        paragraphs[i].properties
          ..numId = 30
          ..listLabel = '${i + 1}. ';
      }
      final before = WordZotero.fields(document)
          .map((field) => (field.instruction, field.cachedText))
          .toList();
      expect(before, hasLength(4));
      final bytes = OdtDocumentWriter.writeBytes(document);
      final body = _body(OpcPackage.openBytes(bytes));
      final groups = body.childrenNamed('list').toList();
      expect(groups, hasLength(1));
      expect(groups.single.childrenNamed('list-item'), hasLength(6));
      final read = await parseOfficeDocument(
        Uint8List.fromList(bytes),
        'listed-zotero.odt',
      );
      expect(read.fallback, isNull);
      expect(read.plainText.split('\n\n'), [
        '1. A study (Lovelace, 1843) confirmed.',
        '2. (Hopper, 1952)',
        '3. Hopper. Compilers.',
        '4. Lovelace. A & B.',
        '5. Keep malformed cache',
        '6. Keep other manager',
      ]);
      for (final hidden in [
        'ADDIN',
        'ZOTERO_ITEM',
        'CSL_CITATION',
        'ZOTERO_BIBL',
        'CSL_BIBLIOGRAPHY',
        'citationID',
        'broken JSON',
        'ANOTHER_MANAGER',
      ]) {
        expect(read.markdown, isNot(contains(hidden)));
        expect(read.plainText, isNot(contains(hidden)));
      }
      expect(
        WordZotero.fields(document)
            .map((field) => (field.instruction, field.cachedText))
            .toList(),
        before,
      );
    },
  );
}
