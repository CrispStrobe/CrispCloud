import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart' as zip;
import 'package:crisp_cloud/services/office_document_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

const _textNamespace = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';
const _officeNamespace = 'urn:oasis:names:tc:opendocument:xmlns:office:1.0';
const _tableNamespace = 'urn:oasis:names:tc:opendocument:xmlns:table:1.0';

Iterable<XmlElement> _elements(
  XmlElement root,
  String name,
  String namespace,
) sync* {
  if (root.namespaceUri == namespace && root.localName == name) yield root;
  for (final child in root.childElements) {
    yield* _elements(child, name, namespace);
  }
}

Uint8List _authoredOdt(String content) {
  final archive = zip.Archive()
    ..addFile(zip.ArchiveFile.bytes('content.xml', utf8.encode(content)));
  return Uint8List.fromList(zip.ZipEncoder().encode(archive));
}

WmlParagraph _paragraph(String text) =>
    WmlParagraph(inlines: [WmlRun(text: text)]);

WmlParagraph _citation(
  String prefix,
  String cached,
  String secret,
) => WmlParagraph(
  inlines: [
    WmlRun(text: prefix),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.begin),
    WmlFieldBoundary(
      kind: WmlFieldBoundaryKind.instruction,
      text:
          ' ADDIN ZOTERO_ITEM CSL_CITATION {"citationID":"$secret","citationItems":[]}',
    ),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.separate),
    WmlRun(text: cached),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.end),
  ],
);

String _odfText(XmlNode node) {
  if (node is XmlText) return node.text;
  if (node is! XmlElement) return '';
  if (node.namespaceUri == _textNamespace) {
    switch (node.localName) {
      case 's':
        return ' ' *
            int.parse(
              node.getAttribute('c', namespaceUri: _textNamespace) ?? '1',
            );
      case 'tab':
        return '\t';
      case 'line-break':
        return '\n';
    }
  }
  return node.children.map(_odfText).join();
}

void main() {
  test('actual host reads footnote and endnote caches without hidden instructions', () async {
    final document = WmlDocument(
      footnotes: [
        WmlNote(
          id: 41,
          endnote: false,
          paragraphs: [
            _citation('Foot  A\tB\nC ', '(Doe, 2020)', 'foot-secret'),
          ],
        ),
      ],
      endnotes: [
        WmlNote(
          id: 41,
          endnote: true,
          paragraphs: [_citation('End  D\tE\nF ', '(Roe, 2021)', 'end-secret')],
        ),
      ],
      sections: [
        WmlSection(
          blocks: [
            WmlParagraph(
              inlines: [
                WmlRun(text: 'Body  x\ty\nz '),
                WmlRun(noteRefId: 41),
                WmlRun(text: ' / '),
                WmlRun(noteRefId: 41, noteRefEndnote: true),
                WmlRun(text: ' tail'),
              ],
            ),
          ],
        ),
      ],
    );
    final before = WordZotero.fields(document)
        .map((field) => (field.instruction, field.cachedText))
        .toList();
    expect(before, hasLength(2));
    final bytes = OdtDocumentWriter.writeBytes(document);
    final content = OpcPackage.openBytes(bytes)
        .getPart('/content.xml')!
        .readText();
    final paragraph = XmlDocument.parse(content).root!
        .childrenNamed('body', namespaceUri: _officeNamespace)
        .single
        .childrenNamed('text', namespaceUri: _officeNamespace)
        .single
        .childrenNamed('p', namespaceUri: _textNamespace)
        .single;
    // Reference styling intentionally wraps each note in a text:span.
    // Select notes by their namespace within this owning body paragraph.
    final notes = _elements(paragraph, 'note', _textNamespace).toList();
    expect(notes, hasLength(2));
    expect(
      notes.map(
        (note) => note.getAttribute('note-class', namespaceUri: _textNamespace),
      ),
      ['footnote', 'endnote'],
    );
    expect(
      notes.map(
        (note) => note.getAttribute('id', namespaceUri: _textNamespace),
      ),
      ['ftn1', 'end2'],
    );
    expect(
      notes.map(
        (note) => _odfText(
          note.childrenNamed('note-body', namespaceUri: _textNamespace).single,
        ),
      ),
      [
        // WmlNote's default automatic reference contributes one separator.
        // Authored double spaces, tabs, line breaks and field caches stay exact.
        ' Foot  A\tB\nC (Doe, 2020)',
        ' End  D\tE\nF (Roe, 2021)',
      ],
    );
    final read = await parseOfficeDocument(
      Uint8List.fromList(bytes),
      'citation-notes.odt',
    );
    expect(read.fallback, isNull);
    expect(read.markdown, contains('Body  x\ty\nz [1] / [2] tail'));
    // The existing note preview deliberately normalizes each note to one line.
    expect(read.markdown, contains('1. Foot A B C (Doe, 2020)'));
    expect(read.markdown, contains('2. End D E F (Roe, 2021)'));
    for (final hidden in [
      'ADDIN',
      'ZOTERO_ITEM',
      'CSL_CITATION',
      'citationID',
      'foot-secret',
      'end-secret',
    ]) {
      expect(content, isNot(contains(hidden)));
      expect(read.markdown, isNot(contains(hidden)));
      expect(read.plainText, isNot(contains(hidden)));
    }
    expect(
      WordZotero.fields(document)
          .map((field) => (field.instruction, field.cachedText))
          .toList(),
      before,
    );
  });

  test('note table covered stories stay hidden in the actual host', () async {
    final document = WmlDocument(
      footnotes: [
        WmlNote(
          id: 9,
          endnote: false,
          blocks: [
            WmlTable(
              grid: [120],
              rows: [
                WmlTableRow(
                  cells: [
                    WmlTableCell(
                      vMerge: WmlVMerge.restart,
                      blocks: [_paragraph('Visible note anchor ')],
                    ),
                  ],
                ),
                WmlTableRow(
                  cells: [
                    WmlTableCell(
                      vMerge: WmlVMerge.cont,
                      blocks: [
                        _paragraph('HIDDEN COVERED NOTE'),
                        WmlTable(
                          rows: [
                            WmlTableRow(
                              cells: [
                                WmlTableCell(
                                  blocks: [_paragraph('HIDDEN DEEP NOTE')],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                WmlTableRow(
                  cells: [
                    WmlTableCell(blocks: [_paragraph(' Visible note tail')]),
                  ],
                ),
              ],
            ),
          ],
        ),
      ],
      sections: [
        WmlSection(
          blocks: [
            WmlParagraph(
              inlines: [
                WmlRun(text: 'Body '),
                WmlRun(noteRefId: 9),
              ],
            ),
          ],
        ),
      ],
    );
    final sourceTable = document.footnotes.single.blocks.single as WmlTable;
    final sourceCovered = sourceTable.rows[1].cells.single;
    final sourceHidden = sourceCovered.blocks.first as WmlParagraph;
    final sourceNested = sourceCovered.blocks.last as WmlTable;
    final sourceDeep =
        sourceNested.rows.single.cells.single.blocks.single as WmlParagraph;
    final bytes = OdtDocumentWriter.writeBytes(document);
    final content = OpcPackage.openBytes(bytes)
        .getPart('/content.xml')!
        .readText();
    final root = XmlDocument.parse(content).root!;
    final note = _elements(root, 'note', _textNamespace).single;
    final noteBody = note
        .childrenNamed('note-body', namespaceUri: _textNamespace)
        .single;
    // The bounded Writer-compatible export projects visible note cells into
    // paragraphs. It deliberately omits covered stories from exported bytes.
    expect(
      noteBody.childrenNamed('p', namespaceUri: _textNamespace).map(_odfText),
      [' Visible note anchor ', ' Visible note tail'],
    );
    expect(_elements(noteBody, 'table', _tableNamespace), isEmpty);
    expect(_elements(noteBody, 'covered-table-cell', _tableNamespace), isEmpty);
    expect(content, isNot(contains('HIDDEN')));
    expect(
      identical(document.footnotes.single.blocks.single, sourceTable),
      isTrue,
    );
    expect(sourceTable.grid, [120]);
    expect(sourceTable.rows, hasLength(3));
    expect(identical(sourceTable.rows[1].cells.single, sourceCovered), isTrue);
    expect(identical(sourceCovered.blocks.first, sourceHidden), isTrue);
    expect(identical(sourceCovered.blocks.last, sourceNested), isTrue);
    expect(
      identical(
        sourceNested.rows.single.cells.single.blocks.single,
        sourceDeep,
      ),
      isTrue,
    );
    expect(sourceCovered.vMerge, WmlVMerge.cont);
    expect((sourceHidden.inlines.single as WmlRun).text, 'HIDDEN COVERED NOTE');
    expect((sourceDeep.inlines.single as WmlRun).text, 'HIDDEN DEEP NOTE');
    final read = await parseOfficeDocument(
      Uint8List.fromList(bytes),
      'covered-note.odt',
    );
    expect(read.fallback, isNull);
    expect(read.markdown, isNot(contains('HIDDEN')));
    expect(read.plainText, isNot(contains('HIDDEN')));
    expect(read.markdown, contains('1. Visible note anchor Visible note tail'));
    expect(read.rawXml, isNot(contains('HIDDEN')));

    // Independently authored imported ODF still contains hidden covered-cell
    // payload. Host previews must filter it without changing retained raw XML.
    // Alias the real table namespace and retain a foreign lookalike visibly.
    const authored = '''
<office:document-content
 xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"
 xmlns:t="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:foreign="urn:example:foreign-table">
 <office:body><office:text><text:p>Body <text:note text:note-class="footnote" text:id="fn1">
  <text:note-citation>1</text:note-citation><text:note-body>
   <t:table>
    <t:table-row><t:table-cell t:number-rows-spanned="2"><text:p>Visible note anchor </text:p></t:table-cell></t:table-row>
    <t:table-row><t:covered-table-cell>
     <text:p>HIDDEN COVERED NOTE</text:p>
     <t:table><t:table-row><t:table-cell><text:p>HIDDEN DEEP NOTE</text:p></t:table-cell></t:table-row></t:table>
    </t:covered-table-cell></t:table-row>
    <t:table-row><t:table-cell><text:p> Visible note tail</text:p></t:table-cell></t:table-row>
   </t:table>
   <foreign:covered-table-cell><text:p> Foreign visible note</text:p></foreign:covered-table-cell>
  </text:note-body></text:note> tail</text:p></office:text></office:body>
</office:document-content>
''';
    final imported = await parseOfficeDocument(
      _authoredOdt(authored),
      'authored-covered-note.odt',
    );
    expect(imported.fallback, isNull);
    expect(imported.markdown, contains('Body [1] tail'));
    expect(imported.markdown, isNot(contains('HIDDEN')));
    expect(imported.plainText, isNot(contains('HIDDEN')));
    expect(
      imported.markdown,
      contains('1. Visible note anchor Visible note tail Foreign visible note'),
    );
    expect(imported.plainText, contains('Foreign visible note'));
    expect(imported.rawXml, '<!-- content.xml -->\n$authored');
    expect(imported.rawXml, contains('HIDDEN COVERED NOTE'));
    expect(imported.rawXml, contains('HIDDEN DEEP NOTE'));
  });
}
