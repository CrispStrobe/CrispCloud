import 'dart:io';
import 'dart:typed_data';

import 'package:crisp_cloud/services/office_document_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

void main() {
  test(
    'actual host reads exported Zotero visible results without instructions',
    () async {
      final package = OpcPackage.create(OpcPackageKind.word);
      package
          .getPart('/word/document.xml')!
          .writeText(
            File(
              'packages/quds_office_engine/test/fixtures/zotero/word_document.xml',
            ).readAsStringSync(),
          );
      final document = WordDeserializer().read(package);
      final before = WordZotero.fields(document)
          .map((field) => (field.instruction, field.cachedText))
          .toList();
      expect(before, hasLength(4));

      final read = await parseOfficeDocument(
        Uint8List.fromList(OdtDocumentWriter.writeBytes(document)),
        'zotero-export.odt',
      );
      expect(read.kind, OfficeDocumentKind.document);
      expect(read.fallback, isNull);
      expect(read.plainText.split('\n\n'), [
        'A study (Lovelace, 1843) confirmed.',
        '(Hopper, 1952)',
        'Hopper. Compilers.',
        'Lovelace. A & B.',
        'Keep malformed cache',
        'Keep other manager',
      ]);
      for (final secret in [
        'ADDIN',
        'ZOTERO_ITEM',
        'CSL_CITATION',
        'ZOTERO_BIBL',
        'CSL_BIBLIOGRAPHY',
        'citationID',
        'broken JSON',
        'ANOTHER_MANAGER',
      ]) {
        expect(read.plainText, isNot(contains(secret)));
        expect(read.markdown, isNot(contains(secret)));
      }
      expect(
        WordZotero.fields(document)
            .map((field) => (field.instruction, field.cachedText))
            .toList(),
        before,
      );
    },
  );

  test('actual host retains body spacing and reads exported header and footer', () async {
    final document = WmlDocument(
      sections: [
        WmlSection(
          blocks: [
            WmlParagraph(
              inlines: [WmlRun(text: 'Lead  A\tB\r\nC\nD\rE  tail')],
            ),
          ],
          header: [
            WmlParagraph(inlines: [WmlRun(text: 'Head\tA  B')]),
          ],
          footer: [
            WmlParagraph(inlines: [WmlRun(text: 'Foot\nLine 2')]),
          ],
        ),
      ],
    );
    final read = await parseOfficeDocument(
      Uint8List.fromList(OdtDocumentWriter.writeBytes(document)),
      'whitespace-export.odt',
    );
    expect(read.kind, OfficeDocumentKind.document);
    expect(read.fallback, isNull);
    expect(read.plainText, contains('Lead  A\tB\nC\nD\nE  tail'));
    // Header/footer preview intentionally normalizes whitespace into one line.
    expect(read.markdown, contains('> **Header:** Head A B'));
    expect(read.markdown, contains('> **Footer:** Foot Line 2'));
  });
}
