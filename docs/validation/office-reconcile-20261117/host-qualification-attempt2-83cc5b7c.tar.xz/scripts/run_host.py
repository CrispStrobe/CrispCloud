import importlib.util,os,subprocess,sys,json,hashlib,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
repo=root.parent/'CrispCloud'
harness=root/'full-harness'
sdk=Path(os.environ.get('FLUTTER_ROOT', '/home/agent/.codex/skills/remote-skills/.quds-gector-work/runtime/flutter-sdk'))
shared=sdk.parent
env=dict(os.environ,FLUTTER_ROOT=str(sdk),PUB_CACHE=str(root/'pub-cache'),TMPDIR=str(shared/'tmp'),XDG_CONFIG_HOME=str(shared/'config'),CI='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true')
env['PATH']=str(root/'clang-toolchain/usr/lib/llvm-19/bin')+os.pathsep+str(root/'rust-toolchain/bin')+os.pathsep+str(sdk/'bin')+os.pathsep+env.get('PATH','')
env['LD_LIBRARY_PATH']=str(root/'clang-toolchain/usr/lib/x86_64-linux-gnu')+os.pathsep+str(root/'system-libs')+os.pathsep+env.get('LD_LIBRARY_PATH','')
env['CARGO_HOME']=str(root/'cargo-home')
env['CARGO']=str(root/'rust-toolchain/bin/cargo')
spec=importlib.util.spec_from_file_location('sqlite_hook',repo/'tool/with_ci_system_sqlite.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.probe_system_sqlite()
pubspec=harness/'pubspec.yaml';original=pubspec.read_bytes()
pubspec.write_bytes(module.with_system_sqlite_hook(original))
command=[str(sdk/'bin/cache/dart-sdk/bin/dart'),str(sdk/'bin/cache/flutter_tools.snapshot'),'test','--no-pub','--reporter','json',*sys.argv[1:]]
try:
 result=subprocess.run(command,cwd=harness,env=env)
finally:
 pubspec.write_bytes(original)
sys.exit(result.returncode)
