#!/usr/bin/env python3
"""Recover exact native compilers from the archived qualification receipt."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
inputs = json.loads((ROOT / 'historical-qualification/setup/native-reproduction.json').read_text())


def fetch(spec):
    family = 'rust' if spec in inputs['rust_components'] else 'clang'
    directory = ROOT / (family + '-downloads')
    directory.mkdir(exist_ok=True)
    archive = directory / spec['url'].rsplit('/', 1)[-1]
    if not archive.exists() or hashlib.sha256(archive.read_bytes()).hexdigest() != spec['sha256']:
        with urllib.request.urlopen(spec['url'], timeout=60) as response, archive.open('wb') as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
    actual = hashlib.sha256(archive.read_bytes()).hexdigest()
    if actual != spec['sha256'] or archive.stat().st_size != spec['bytes']:
        raise RuntimeError('Immutable component mismatch: ' + spec['name'])
    record = dict(spec, actual_sha256=actual, archive=str(archive), family=family)
    print(json.dumps(record), flush=True)
    return record


with ThreadPoolExecutor(max_workers=6) as pool:
    records = list(pool.map(fetch, [*inputs['rust_components'], *inputs['clang_components']]))
for record in records:
    archive = Path(record['archive'])
    if record['family'] == 'rust':
        with tarfile.open(archive) as stream:
            stream.extractall(archive.parent, filter='data')
        source = archive.parent / archive.name.removesuffix('.tar.xz')
        command = ['sh', str(source / 'install.sh'), '--prefix=' + str(ROOT / 'rust-toolchain'), '--disable-ldconfig']
    else:
        command = ['dpkg-deb', '-x', str(archive), str(ROOT / 'clang-toolchain')]
    result = subprocess.run(command, capture_output=True, text=True)
    record.update(install_exit=result.returncode, install_stdout=result.stdout, install_stderr=result.stderr)
    if result.returncode:
        raise RuntimeError(record)
sqlite = Path(inputs['system_sqlite']['library'])
actual = hashlib.sha256(sqlite.read_bytes()).hexdigest()
if actual != inputs['system_sqlite']['sha256']:
    raise RuntimeError('System SQLite differs from the archived input')
aliases = ROOT / 'system-libs'
aliases.mkdir(exist_ok=True)
alias = aliases / 'libsqlite3.so'
if not alias.exists():
    alias.symlink_to(sqlite)
receipt = {'status': 'passed', 'input_receipt_sha256': hashlib.sha256((ROOT / 'historical-qualification/setup/native-reproduction.json').read_bytes()).hexdigest(), 'components': records, 'system_sqlite': dict(inputs['system_sqlite'], local_loader_alias=str(alias), actual_sha256=actual), 'production_sources_changed': False, 'native_hooks_disabled': False}
(ROOT / 'setup/recovered-native-tools.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Exact native compilers and SQLite alias recovered.', flush=True)
