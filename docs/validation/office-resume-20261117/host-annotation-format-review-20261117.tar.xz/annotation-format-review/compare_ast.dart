import 'dart:convert';
import 'dart:io';

import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/token.dart';
import 'package:crypto/crypto.dart';

Object? normalize(Object entity) {
  if (entity is AstNode) {
    return <Object?>[
      entity.runtimeType.toString(),
      for (final child in entity.childEntities)
        if (child is! Token || child.lexeme != ',') normalize(child),
    ];
  }
  if (entity is Token) {
    return <String>[entity.type.toString(), entity.lexeme];
  }
  throw StateError('Unexpected AST child ${entity.runtimeType}');
}

void calls(AstNode node, String name, List<Object?> result) {
  if (node is MethodInvocation && node.methodName.name == name) {
    result.add(normalize(node));
  }
  for (final child in node.childEntities) {
    if (child is AstNode) calls(child, name, result);
  }
}

Map<String, Object?> analyzeFile(String path) {
  final source = File(path).readAsStringSync();
  final result = parseString(content: source, path: path, throwIfDiagnostics: false);
  if (result.errors.isNotEmpty) {
    throw StateError(result.errors.map((error) => error.message).join('\n'));
  }
  final normalized = jsonEncode(normalize(result.unit));
  File('$path.ast.json').writeAsStringSync('$normalized\n');
  final assertions = <Object?>[];
  final tests = <Object?>[];
  calls(result.unit, 'expect', assertions);
  calls(result.unit, 'test', tests);
  return <String, Object?>{
    'path': path,
    'source_sha256': sha256.convert(utf8.encode(source)).toString(),
    'normalized_ast_sha256': sha256.convert(utf8.encode(normalized)).toString(),
    'assertion_count': assertions.length,
    'assertions_sha256': sha256.convert(utf8.encode(jsonEncode(assertions))).toString(),
    'static_test_call_count': tests.length,
    'test_calls_sha256': sha256.convert(utf8.encode(jsonEncode(tests))).toString(),
    'parse_diagnostics': result.errors.length,
  };
}

void main(List<String> args) {
  if (args.length != 2) throw ArgumentError('Expected two Dart source paths');
  final left = analyzeFile(args[0]);
  final right = analyzeFile(args[1]);
  final same = left['normalized_ast_sha256'] == right['normalized_ast_sha256'];
  stdout.writeln(jsonEncode(<String, Object?>{
    'method': 'Compare parsed AST node hierarchy and every non-comma token type and lexeme; ignore source offsets, whitespace, comments and comma separators, including formatter-managed trailing commas.',
    'left': left,
    'right': right,
    'ast_identical': same,
    'assertions_identical': left['assertions_sha256'] == right['assertions_sha256'],
    'test_calls_identical': left['test_calls_sha256'] == right['test_calls_sha256'],
  }));
  if (!same) exitCode = 1;
}
