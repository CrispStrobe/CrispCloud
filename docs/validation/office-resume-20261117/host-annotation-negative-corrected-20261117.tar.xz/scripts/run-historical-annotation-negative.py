#!/usr/bin/env python3
"""Reproduce annotation leakage on an isolated, exactly pinned host snapshot.

Use the original committed test and all package sources at --source-commit;
replace only the reader with --service-before bytes in a separate harness.
This establishes a historical-source failure, not final-source qualification.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('focused_host', HERE / 'run-focused-host.py')
focused = importlib.util.module_from_spec(spec)
spec.loader.exec_module(focused)
audit = focused.audit
SERVICE = 'lib/services/office_document_service.dart'
TEST = 'test/office_annotation_preview_test.dart'


def lib_snapshot(root):
    return {str(p.relative_to(root)): audit.digest(p.read_bytes())
            for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'harness', 'negative-harness', 'flutter',
                 'shared-runtime', 'setup-receipt', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--service-before', required=True)
    parser.add_argument('--test-file', type=Path)
    parser.add_argument('--expected-test-blob')
    args = parser.parse_args()
    repo, harness, negative, sdk, shared, setup_path, out = (
        getattr(args, key).resolve() for key in (
            'repo', 'harness', 'negative_harness', 'flutter',
            'shared_runtime', 'setup_receipt', 'output'))
    if out.exists() or negative.exists():
        raise ValueError('Use fresh negative harness and output paths')
    if audit.git(repo, 'rev-parse', 'HEAD') != args.source_commit:
        raise ValueError('Isolated checkout differs from requested snapshot')
    subprocess.run(['git', 'diff', '--exit-code', args.source_commit, '--',
                    'lib', 'packages', 'test', 'tool', 'pubspec.yaml',
                    'pubspec.lock', 'analysis_options.yaml'], cwd=repo, check=True)
    setup = json.loads(setup_path.read_text())
    if setup['status'] != 'passed' or Path(setup['harness']).resolve() != harness:
        raise ValueError('Expected completed matching host dependency setup')
    if setup['final_lock_sha256'] != audit.digest((harness / 'pubspec.lock').read_bytes()):
        raise ValueError('Resolved lock changed since setup')
    if setup['production_lock_sha256'] != audit.digest((repo / 'pubspec.lock').read_bytes()):
        raise ValueError('Historical production lock differs from resolved lock graph')
    for path in (SERVICE, TEST):
        committed = subprocess.check_output(
            ['git', 'show', args.source_commit + ':' + path], cwd=repo)
        if committed != (repo / path).read_bytes():
            raise ValueError('Isolated source differs from committed file: ' + path)
    original_test = (repo / TEST).read_bytes()
    test_payload = args.test_file.read_bytes() if args.test_file else original_test
    test_blob = subprocess.check_output(
        ['git', 'hash-object', '--stdin'], input=test_payload, cwd=repo).decode().strip()
    if args.test_file:
        if not args.expected_test_blob or test_blob != args.expected_test_blob:
            raise ValueError('Corrected test differs from its expected Git blob')
        old = 'expect(document.rawXml, xml);'
        new = "expect(document.rawXml, '<!-- content.xml -->\\n$xml');"
        if original_test.decode().count(old) != 5 or original_test.decode().replace(old, new).encode() != test_payload:
            raise ValueError('Only the five exact raw XML contract corrections are permitted')
    out.mkdir(parents=True)
    negative.mkdir(parents=True)
    declaration_map = {}
    for package in ('', *(f'packages/{name}' for name in audit.PACKAGES)):
        for name in ('pubspec.yaml', 'pubspec.lock'):
            source = harness / package / name
            if not source.is_file():
                continue
            before = source.read_text()
            target = negative / package / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(before.replace(str(harness), str(negative)))
            declaration_map[str(target.relative_to(negative))] = {
                'resolved_original_sha256': audit.digest(source.read_bytes()),
                'rebased_sha256': audit.digest(target.read_bytes()),
                'change': 'local harness path rebasing only',
            }
    for name in ('analysis_options.yaml',):
        (negative / name).symlink_to(repo / name,
                                     target_is_directory=(repo / name).is_dir())
    (negative / 'test').mkdir()
    for source in (repo / 'test').iterdir():
        target = negative / 'test' / source.name
        if source.name == Path(TEST).name:
            target.write_bytes(test_payload)
        else:
            target.symlink_to(source, target_is_directory=source.is_dir())
    for name in audit.PACKAGES:
        for source in (repo / 'packages' / name).iterdir():
            if source.name in {'pubspec.yaml', 'pubspec.lock', '.dart_tool', 'build', 'example'}:
                continue
            target = negative / 'packages' / name / source.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.symlink_to(source, target_is_directory=source.is_dir())
    before_bytes = subprocess.check_output(
        ['git', 'show', args.service_before + ':' + SERVICE], cwd=repo)
    for source in sorted((repo / 'lib').rglob('*')):
        target = negative / source.relative_to(repo)
        if source.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif source.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            if str(source.relative_to(repo)) == SERVICE:
                target.write_bytes(before_bytes)
            else:
                target.symlink_to(source)
    original_config = harness / '.dart_tool/package_config.json'
    graph = json.loads(original_config.read_text())
    for entry in graph['packages']:
        if entry['name'] == 'crisp_cloud':
            root = negative
        elif entry['name'] in audit.PACKAGES:
            root = negative / 'packages' / entry['name']
        else:
            root = audit.resolve(original_config, entry['rootUri'])
        entry['rootUri'] = root.as_uri() + '/'
    audit.save(negative / '.dart_tool/package_config.json', graph)
    (negative / '.dart_tool/package_graph.json').write_bytes(
        (harness / '.dart_tool/package_graph.json').read_bytes())
    original_lib = lib_snapshot(repo / 'lib')
    negative_lib_before = lib_snapshot(negative / 'lib')
    differences = sorted(p for p in set(original_lib) | set(negative_lib_before)
                         if original_lib.get(p) != negative_lib_before.get(p))
    if differences != ['services/office_document_service.dart']:
        raise ValueError('Inverse control must differ in exactly the reader source')
    source_before = audit.source_snapshot(repo)
    deps_before = audit.dependency_snapshot(negative, sdk, negative)
    audit.save(out / 'source-before.json', source_before)
    audit.save(out / 'dependencies-before.json', deps_before)
    audit.save(out / 'negative-library-before.json', negative_lib_before)
    (out / 'reader-before.dart').write_bytes(before_bytes)
    (out / 'annotation-tests.dart').write_bytes(test_payload)
    env = dict(os.environ, FLUTTER_ROOT=str(sdk), PUB_CACHE=str(shared / 'pub-cache'),
               XDG_CONFIG_HOME=str(shared / 'config'), TMPDIR=str(shared / 'tmp'),
               FLUTTER_SUPPRESS_ANALYTICS='true', DART_SUPPRESS_ANALYTICS='true', CI='true')
    env['PATH'] = str(sdk / 'bin') + os.pathsep + env.get('PATH', '')
    command = [str(sdk / 'bin/cache/dart-sdk/bin/dart'),
               str(sdk / 'bin/cache/flutter_tools.snapshot'), 'test', '--no-pub',
               '--concurrency=1', '--reporter=json', TEST]
    receipt = {
        'schema_version': 1, 'kind': 'isolated historical-snapshot annotation regression control',
        'status': 'running', 'started_utc': audit.now(),
        'source_commit': args.source_commit,
        'source_tree': audit.git(repo, 'rev-parse', 'HEAD^{tree}'),
        'canonical_pin': json.loads((repo / 'tool/office_fidelity_manifest.json').read_text())['source_commit'],
        'reader_before_commit': args.service_before,
        'reader_before_blob': audit.git(repo, 'rev-parse', args.service_before + ':' + SERVICE),
        'reader_before_sha256': audit.digest(before_bytes),
        'reader_snapshot_blob': audit.git(repo, 'rev-parse', args.source_commit + ':' + SERVICE),
        'test_blob': test_blob,
        'test_sha256': audit.digest(test_payload),
        'snapshot_original_test_blob': audit.git(repo, 'rev-parse', args.source_commit + ':' + TEST),
        'test_contract_corrections': 5 if args.test_file else 0,
        'test_correction_scope': 'exact content.xml inspection marker expectations only' if args.test_file else None,
        'setup_receipt_sha256': audit.digest(setup_path.read_bytes()),
        'runner_sha256': audit.digest(Path(__file__).read_bytes()),
        'terminal_parser_sha256': audit.digest((HERE / 'run-focused-host.py').read_bytes()),
        'fingerprint_helper_sha256': audit.digest((HERE / 'prior_host_qualification.py').read_bytes()),
        'exactly_one_library_source_difference': differences,
        'all_other_library_files_match_snapshot': True,
        'declaration_rebasing': declaration_map,
        'package_count': deps_before['package_count'],
        'command': command, 'cwd': str(negative),
        'runtime_tests_are_expected_to_fail': True,
        'final_source_qualified': False, 'accepted_test_passes': 0,
        'github_actions_or_status_queried': False,
    }
    save = lambda: audit.save(out / 'receipt.json', receipt)
    save()
    started = time.monotonic()
    log = out / 'annotation-negative.log'
    with log.open('w') as stream:
        process = subprocess.Popen(command, cwd=negative, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        try:
            while process.poll() is None:
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    elapsed = time.monotonic() - started
                    print(json.dumps({'active': 'annotation-negative', 'seconds': round(elapsed),
                                      'log_bytes': log.stat().st_size}), flush=True)
                    if elapsed > 600:
                        receipt['timed_out'] = True
                        audit.stop_owned_process_group(process)
                        break
        finally:
            if process.poll() is None:
                audit.stop_owned_process_group(process)
    terminal = focused.json_test_results(log)
    audit.save(out / 'test-terminal-events.json', terminal)
    source_after = audit.source_snapshot(repo)
    deps_after = audit.dependency_snapshot(negative, sdk, negative)
    negative_lib_after = lib_snapshot(negative / 'lib')
    audit.save(out / 'source-after.json', source_after)
    audit.save(out / 'dependencies-after.json', deps_after)
    audit.save(out / 'negative-library-after.json', negative_lib_after)
    errors = []
    for line in log.read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get('type') == 'error':
            errors.append(event)
    audit.save(out / 'assertion-failures.json', errors)
    assertion_failures = bool(errors) and all(x.get('isFailure') is True for x in errors)
    receipt.update(
        exit_code=process.returncode, duration_seconds=round(time.monotonic() - started, 3),
        finished_utc=audit.now(), log_sha256=audit.digest(log.read_bytes()),
        test_counts={k: v for k, v in terminal.items() if k != 'records'},
        all_errors_are_test_assertion_failures=assertion_failures,
        source_unchanged=source_before == source_after,
        dependencies_unchanged=deps_before == deps_after,
        test_unchanged=(negative / TEST).read_bytes() == test_payload,
        inverse_library_unchanged=negative_lib_before == negative_lib_after,
        head_at_completion=audit.git(repo, 'rev-parse', 'HEAD'))
    receipt['expected_failure_observed'] = (
        process.returncode == 1 and terminal['failed'] > 0
        and terminal['passed'] + terminal['failed'] == 8 and terminal['skipped'] == 0
        and len(terminal['completion_events']) == 1
        and terminal['completion_events'][0].get('success') is False
        and terminal['all_terminal_tests_had_start'] and terminal['all_started_tests_terminated']
        and not terminal['duplicate_start_ids'] and not terminal['duplicate_terminal_ids']
        and assertion_failures and not receipt.get('timed_out', False))
    receipt['status'] = 'expected failure verified' if all(receipt[k] for k in (
        'expected_failure_observed', 'source_unchanged', 'dependencies_unchanged',
        'inverse_library_unchanged', 'test_unchanged')) else 'control unsuccessful'
    save()
    print(json.dumps({'status': receipt['status'], 'test_counts': receipt['test_counts']}), flush=True)
    return 0 if receipt['status'] == 'expected failure verified' else 1


if __name__ == '__main__':
    raise SystemExit(main())
