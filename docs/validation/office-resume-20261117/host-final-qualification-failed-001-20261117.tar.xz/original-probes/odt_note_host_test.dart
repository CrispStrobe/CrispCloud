import 'dart:typed_data';

import 'package:crisp_cloud/services/office_document_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quds_office_engine/quds_office_engine.dart';

const _textNamespace = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0';

WmlParagraph _paragraph(String text) =>
    WmlParagraph(inlines: [WmlRun(text: text)]);

WmlParagraph _citation(
  String prefix,
  String cached,
  String secret,
) => WmlParagraph(
  inlines: [
    WmlRun(text: prefix),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.begin),
    WmlFieldBoundary(
      kind: WmlFieldBoundaryKind.instruction,
      text:
          ' ADDIN ZOTERO_ITEM CSL_CITATION {"citationID":"$secret","citationItems":[]}',
    ),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.separate),
    WmlRun(text: cached),
    WmlFieldBoundary(kind: WmlFieldBoundaryKind.end),
  ],
);

String _odfText(XmlNode node) {
  if (node is XmlText) return node.text;
  if (node is! XmlElement) return '';
  if (node.namespaceUri == _textNamespace) {
    switch (node.localName) {
      case 's':
        return ' ' * int.parse(node.getAttribute('c') ?? '1');
      case 'tab':
        return '\t';
      case 'line-break':
        return '\n';
    }
  }
  return node.children.map(_odfText).join();
}

void main() {
  test('actual host reads footnote and endnote caches without hidden instructions', () async {
    final document = WmlDocument(
      footnotes: [
        WmlNote(
          id: 41,
          endnote: false,
          paragraphs: [
            _citation('Foot  A\tB\nC ', '(Doe, 2020)', 'foot-secret'),
          ],
        ),
      ],
      endnotes: [
        WmlNote(
          id: 41,
          endnote: true,
          paragraphs: [_citation('End  D\tE\nF ', '(Roe, 2021)', 'end-secret')],
        ),
      ],
      sections: [
        WmlSection(
          blocks: [
            WmlParagraph(
              inlines: [
                WmlRun(text: 'Body  x\ty\nz '),
                WmlRun(noteRefId: 41),
                WmlRun(text: ' / '),
                WmlRun(noteRefId: 41, noteRefEndnote: true),
                WmlRun(text: ' tail'),
              ],
            ),
          ],
        ),
      ],
    );
    final before = WordZotero.fields(document)
        .map((field) => (field.instruction, field.cachedText))
        .toList();
    expect(before, hasLength(2));
    final bytes = OdtDocumentWriter.writeBytes(document);
    final content = OpcPackage.openBytes(bytes)
        .getPart('/content.xml')!
        .readText();
    final paragraph = XmlDocument.parse(content).root!
        .firstChild('body')!
        .firstChild('text')!
        .firstChild('p')!;
    final notes = paragraph.childrenNamed('note').toList();
    expect(notes, hasLength(2));
    expect(
      notes.map(
        (note) => note.getAttribute('note-class', namespaceUri: _textNamespace),
      ),
      ['footnote', 'endnote'],
    );
    expect(notes.map((note) => _odfText(note.firstChild('note-body')!)), [
      'Foot  A\tB\nC (Doe, 2020)',
      'End  D\tE\nF (Roe, 2021)',
    ]);
    final read = await parseOfficeDocument(
      Uint8List.fromList(bytes),
      'citation-notes.odt',
    );
    expect(read.fallback, isNull);
    expect(read.markdown, contains('Body  x\ty\nz [1] / [2] tail'));
    // The existing note preview deliberately normalizes each note to one line.
    expect(read.markdown, contains('1. Foot A B C (Doe, 2020)'));
    expect(read.markdown, contains('2. End D E F (Roe, 2021)'));
    for (final hidden in [
      'ADDIN',
      'ZOTERO_ITEM',
      'CSL_CITATION',
      'citationID',
      'foot-secret',
      'end-secret',
    ]) {
      expect(content, isNot(contains(hidden)));
      expect(read.markdown, isNot(contains(hidden)));
      expect(read.plainText, isNot(contains(hidden)));
    }
    expect(
      WordZotero.fields(document)
          .map((field) => (field.instruction, field.cachedText))
          .toList(),
      before,
    );
  });

  test('note table covered stories stay hidden in the actual host', () async {
    final document = WmlDocument(
      footnotes: [
        WmlNote(
          id: 9,
          endnote: false,
          blocks: [
            WmlTable(
              grid: [120],
              rows: [
                WmlTableRow(
                  cells: [
                    WmlTableCell(
                      vMerge: WmlVMerge.restart,
                      blocks: [_paragraph('Visible note anchor ')],
                    ),
                  ],
                ),
                WmlTableRow(
                  cells: [
                    WmlTableCell(
                      vMerge: WmlVMerge.cont,
                      blocks: [
                        _paragraph('HIDDEN COVERED NOTE'),
                        WmlTable(
                          rows: [
                            WmlTableRow(
                              cells: [
                                WmlTableCell(
                                  blocks: [_paragraph('HIDDEN DEEP NOTE')],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                WmlTableRow(
                  cells: [
                    WmlTableCell(blocks: [_paragraph(' Visible note tail')]),
                  ],
                ),
              ],
            ),
          ],
        ),
      ],
      sections: [
        WmlSection(
          blocks: [
            WmlParagraph(
              inlines: [
                WmlRun(text: 'Body '),
                WmlRun(noteRefId: 9),
              ],
            ),
          ],
        ),
      ],
    );
    final bytes = OdtDocumentWriter.writeBytes(document);
    final content = OpcPackage.openBytes(bytes)
        .getPart('/content.xml')!
        .readText();
    expect(content, contains('<table:covered-table-cell>'));
    expect(content, contains('HIDDEN COVERED NOTE'));
    expect(content, contains('HIDDEN DEEP NOTE'));
    final read = await parseOfficeDocument(
      Uint8List.fromList(bytes),
      'covered-note.odt',
    );
    expect(read.fallback, isNull);
    expect(read.markdown, isNot(contains('HIDDEN')));
    expect(read.plainText, isNot(contains('HIDDEN')));
    expect(read.markdown, contains('1. Visible note anchor Visible note tail'));
    expect(read.rawXml, contains('HIDDEN COVERED NOTE'));
  });
}
