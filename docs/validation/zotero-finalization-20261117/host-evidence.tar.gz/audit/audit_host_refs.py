#!/usr/bin/env python3
"""Replay the bounded CrispCloud incoming-ref audit using local Git objects.

No network, CI API, or moving-ref lookup is used by the replay. The caller must
materialize the frozen commits and their trees before running this script.
"""

import argparse
import collections
import json
import os
from pathlib import Path
import subprocess


def audit(repo: Path, snapshot: dict) -> dict:
    env = dict(os.environ, GIT_NO_LAZY_FETCH="1")

    def git(*args: str) -> str:
        return subprocess.check_output(
            ["git", "-C", str(repo), *args], text=True, env=env
        ).strip()

    main = snapshot["main"]
    ancestors = set(git("rev-list", main).splitlines())
    trees: dict[str, list[str]] = collections.defaultdict(list)
    for line in git("log", "--format=%H %T", main).splitlines():
        commit, tree = line.split()
        trees[tree].append(commit)
    for matches in trees.values():
        matches.sort()

    entries = []
    for ref in snapshot["refs"]:
        sha = ref["sha"]
        tree = git("rev-parse", sha + "^{tree}")
        result = dict(ref, tree=tree)
        if sha in ancestors:
            result["disposition"] = "ancestor_of_frozen_main"
        elif sha == snapshot["outgoing_recovery"]:
            result["disposition"] = "outgoing_recovery"
        elif tree in trees:
            result["disposition"] = "exact_tree_alias_of_main_ancestor"
            result["matching_ancestor_commits"] = trees[tree]
        else:
            result["disposition"] = "incoming_work_to_integrate"
            result["paths_since_main"] = git(
                "diff-tree", "--no-commit-id", "--name-only", "-r", main, sha
            ).splitlines()
        entries.append(result)

    counts = dict(sorted(collections.Counter(
        entry["disposition"] for entry in entries
    ).items()))
    return {
        "schema_version": 1,
        "repository": "CrispStrobe/CrispCloud",
        "observed_utc": snapshot["observed_utc"],
        "frozen_main": main,
        "outgoing_recovery": snapshot["outgoing_recovery"],
        "ref_count": len(entries),
        "branch_count": sum(e["ref"].startswith("refs/heads/") for e in entries),
        "pr_head_count": sum(e["ref"].startswith("refs/pull/") for e in entries),
        "counts": counts,
        "scope": "Frozen branch and PR heads fetched by the parent session; no CI lookup, wait, workflow API, or moving-ref refresh in this replay.",
        "method": "Commit reachability from frozen main, followed by exact full Git tree equality to a reachable commit. The two outgoing recovery references are classified separately. No patch-similarity inference is used.",
        "entries": entries,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--snapshot", type=Path, default=Path(__file__).with_name("host-ref-snapshot.json"))
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("host-incoming-audit.json"))
    parser.add_argument("--integrated-head", help="Optionally replay against a delivered integration commit, retaining the original observation and main identity")
    args = parser.parse_args()
    snapshot = json.loads(args.snapshot.read_text())
    if args.integrated_head:
        original_main = snapshot["main"]
        snapshot = dict(snapshot, main=args.integrated_head)
    report = audit(args.repo, snapshot)
    if args.integrated_head:
        report["frozen_main"] = original_main
        report["integrated_head"] = args.integrated_head
        names = {
            "ancestor_of_frozen_main": "ancestor_of_integrated_head",
            "exact_tree_alias_of_main_ancestor": "exact_tree_alias_of_integrated_ancestor",
        }
        report["counts"] = {names.get(k, k): v for k, v in report["counts"].items()}
        for entry in report["entries"]:
            entry["disposition"] = names.get(entry["disposition"], entry["disposition"])
        report["method"] = "Commit reachability from the supplied integrated head, followed by exact full Git tree equality to a reachable commit. All original frozen observations, including the former outgoing recovery refs, are evaluated. No patch-similarity inference or moving-ref refresh is used."
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "entries"}, indent=2))
