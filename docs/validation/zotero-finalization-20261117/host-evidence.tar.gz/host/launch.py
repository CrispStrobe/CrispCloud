#!/usr/bin/env python3
"""Bind a reviewed prepared invocation, then execute it once."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

output = Path(__file__).resolve().parent
invocation_path = output / 'invocation.json'
invocation = json.loads(invocation_path.read_text())
if (output / 'receipt.json').exists():
    raise SystemExit('Existing receipt: choose a new run directory; do not overwrite evidence.')
command = invocation['command']
if '__HOST_SOURCE_COMMIT__' in command:
    if len(sys.argv) != 2 or not re.fullmatch(r'[a-f0-9]{40}', sys.argv[1]):
        raise SystemExit('Pass the final published 40-character host implementation commit.')
    pin = sys.argv[1]
    repo = invocation['repo']
    verified = subprocess.check_output(['git', '-C', repo, 'rev-parse', '--verify', pin + '^{commit}'], text=True).strip()
    if verified != pin:
        raise SystemExit('Host commit cannot be resolved exactly.')
    invocation['source_commit'] = pin
    invocation['expected_tree'] = subprocess.check_output(['git', '-C', repo, 'rev-parse', pin + '^{tree}'], text=True).strip()
    command = [pin if x == '__HOST_SOURCE_COMMIT__' else x for x in command]
    invocation['command'] = command
elif len(sys.argv) != 1:
    raise SystemExit('This invocation is already bound; no source argument is accepted.')
runner = Path(command[1])
if hashlib.sha256(runner.read_bytes()).hexdigest() != invocation['runner_sha256']:
    raise SystemExit('Runner differs from the reviewed invocation.')
for name, value in invocation.get('environment', {}).items():
    os.environ[name] = value
invocation['status'] = 'launched'
invocation['launcher_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
invocation_path.write_text(json.dumps(invocation, indent=2) + '\n')
print(json.dumps({'event': 'launch', 'source_commit': invocation['source_commit'], 'runner_sha256': invocation['runner_sha256'], 'command': command}), flush=True)
os.execv(sys.executable, [sys.executable, *command[1:]])
