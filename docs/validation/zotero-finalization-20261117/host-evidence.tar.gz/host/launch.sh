#!/usr/bin/env bash
set -euo pipefail
source /workspace/scratch/76a795caf82b/runtime/env.sh
run_dir=/workspace/scratch/76a795caf82b/runtime/host-final
if [[ -e "$run_dir/receipt.json" ]]; then
  printf 'Existing receipt; refusing to overwrite evidence.\n' >&2
  exit 1
fi
python3 "$run_dir/launch.py" "$@" > >(tee "$run_dir/launcher.stdout.log") 2> >(tee "$run_dir/launcher.stderr.log" >&2)
