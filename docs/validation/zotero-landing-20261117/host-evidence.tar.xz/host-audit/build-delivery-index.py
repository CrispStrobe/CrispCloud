#!/usr/bin/env python3
"""List exact small evidence files, excluding caches and linked source trees."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent

def main():
    files = set()
    names = [
        'README.md', 'run-baseline.py', 'prepare-host-harness.py',
        'resolve-host-harness.py', 'run-host-qualification.py',
        'run-supplemental.py', 'audit-preservation.py', 'build-delivery-index.py',
        'audit-provenance.json', 'runner-provenance.json',
        'harness-preparation.json', 'harness-final-inputs.json',
        'recovered-archive-integrity.json', 'final-preservation.json',
        'post-qualification-preservation.json',
        'probes/odt_writer_host_test.dart',
        'prior-attempt/review/host-independent-audit.py',
        'prior-attempt/runner/run-integrated-host.py',
        'prior-setup/continuation-setup/harness-inputs-current.json.gz',
        'setup/receipt.json',
        'service-harness/pubspec.yaml', 'service-harness/pubspec.lock',
        'service-harness/.dart_tool/package_config.json',
        'service-harness/.dart_tool/package_graph.json',
    ]
    for package in ('legacy_doc_parser', 'quds_office_engine', 'quds_office_editor', 'quds_reports'):
        names.append(f'service-harness/packages/{package}/pubspec.yaml')
    for name in names:
        files.add(ROOT / name)
    for dirname in ('baseline', 'qualification', 'supplemental', 'audit-attempts', 'independent-review', 'setup/logs'):
        for path in (ROOT / dirname).iterdir():
            if path.is_file() and path.suffix in ('.json', '.log', '.py', '.bin'):
                files.add(path)
    index = ROOT / 'delivery-files.json'
    records = {}
    for path in sorted(files):
        assert path.is_file() and not path.is_symlink(), path
        assert path.resolve().is_relative_to(ROOT), path
        payload = path.read_bytes()
        records[str(path.relative_to(WORKSPACE))] = {
            'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(),
        }
    result = {
        'schema_version': 1,
        'base_directory': str(WORKSPACE),
        'files': sorted([*records, str(index.relative_to(WORKSPACE))]),
        'records': records,
        'self_excluded_from_hash_records': str(index.relative_to(WORKSPACE)),
        'source_commit': '96c514eb98f7ba596a385c8f60496bc6c5994307',
        'canonical_commit': '837d06edbde08a2465e99cbbb15927ee4c87d8ac',
        'excluded': ['SDK and pub-cache binaries', 'compiled harness caches/build output',
                     'source symlinks and source directories', 'previous large evidence archives',
                     'temporary files and analytics configuration'],
    }
    index.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'files_including_index': len(result['files']),
                      'indexed_bytes_excluding_index': sum(r['bytes'] for r in records.values()),
                      'index': str(index)}))

if __name__ == '__main__':
    main()
