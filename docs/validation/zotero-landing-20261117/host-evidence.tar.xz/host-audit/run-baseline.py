#!/usr/bin/env python3
"""Run read-only baseline preservation guards and the existing Python cohort."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'crispcloud'
OUT = ROOT / 'baseline'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    OUT.mkdir(exist_ok=True)
    assert not (OUT / 'receipt.json').exists(), 'Do not overwrite previous evidence'
    receipt = {'kind': 'Baseline Python and source guards; no Dart application qualification',
               'source_commit': git('rev-parse', 'HEAD'),
               'source_tree': git('rev-parse', 'HEAD^{tree}'),
               'started_utc': datetime.now(timezone.utc).isoformat(),
               'status_before': git('status', '--porcelain', '--untracked-files=no'),
               'script_sha256': sha(Path(__file__)), 'commands': []}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    commands = [
        ('preservation', [sys.executable, str(ROOT / 'prior-attempt/review/host-independent-audit.py'),
                         '--host', str(REPO), '--canonical', str(ROOT.parent / 'quds'),
                         '--host-ref', receipt['source_commit'], '--output', str(OUT / 'preservation.json')], ROOT),
        ('vendor-tracked', [sys.executable, 'tool/verify_office_fidelity.py', '--require-tracked'], REPO),
        ('python-sync-verifier-tests', [sys.executable, '-m', 'unittest', 'test_sync_office_fidelity',
                                       'test_sync_legacy_doc_parser', '-v'], REPO / 'tool'),
    ]
    for name, command, cwd in commands:
        start = time.monotonic()
        result = subprocess.run(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log = OUT / (name + '.log')
        log.write_bytes(result.stdout)
        row = {'name': name, 'command': command, 'cwd': str(cwd), 'exit_code': result.returncode,
               'duration_seconds': round(time.monotonic() - start, 3), 'log': log.name, 'log_sha256': sha(log)}
        if name == 'python-sync-verifier-tests':
            match = re.search(rb'Ran (\d+) tests? in', result.stdout)
            row['test_count'] = int(match[1]) if match else None
        receipt['commands'].append(row)
        print(name, result.returncode, row.get('test_count'))
    receipt['status_after'] = git('status', '--porcelain', '--untracked-files=no')
    receipt['source_head_unchanged'] = git('rev-parse', 'HEAD') == receipt['source_commit']
    receipt['tracked_source_unchanged'] = receipt['status_before'] == receipt['status_after'] == ''
    receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
    receipt['passed'] = (all(x['exit_code'] == 0 for x in receipt['commands'])
                         and receipt['source_head_unchanged'] and receipt['tracked_source_unchanged']
                         and receipt['commands'][-1]['test_count'] == 28)
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'passed': receipt['passed'], 'source_commit': receipt['source_commit']}))
    return 0 if receipt['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
