#!/usr/bin/env python3
"""Qualify two cross-component writer/host-reader probes on the frozen source."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('host_qualification', ROOT / 'run-host-qualification.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--source', required=True)
    parser.add_argument('--harness', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    repo, harness, out = args.repo.resolve(), args.harness.resolve(), args.output.resolve()
    sdk = Path(os.environ['FLUTTER_ROOT']).resolve()
    out.mkdir(parents=True, exist_ok=True)
    assert not (out / 'receipt.json').exists(), 'Do not overwrite prior evidence'
    assert q.git(repo, 'rev-parse', 'HEAD') == args.source
    assert subprocess.run(['git', 'diff', '--quiet', args.source, '--', 'lib', 'packages', 'test', 'tool', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'], cwd=repo).returncode == 0
    source_before = q.source_snapshot(repo)
    dependency_before = q.dependency_snapshot(harness, sdk, repo)
    probe = ROOT / 'probes/odt_writer_host_test.dart'
    fixture = 'packages/quds_office_engine/test/fixtures/zotero/word_document.xml'
    command = [str(sdk / 'bin/cache/dart-sdk/bin/dart'), str(sdk / 'bin/cache/flutter_tools.snapshot'),
               'test', '--no-pub', '--concurrency=1', '--reporter', 'expanded', 'probes/odt_writer_host_test.dart']
    receipt = {'kind': 'Supplemental actual ODT writer to host reader qualification; no UI acceptance',
               'status': 'running', 'started_utc': q.now(), 'source_commit': args.source,
               'source_tree': q.git(repo, 'rev-parse', args.source + '^{tree}'),
               'canonical_source': json.loads((repo / 'tool/office_fidelity_manifest.json').read_text())['source_commit'],
               'probe_sha256': q.digest(probe.read_bytes()), 'probe_path': str(probe),
               'fixture_path': fixture, 'fixture_git_blob': q.git(repo, 'rev-parse', args.source + ':' + fixture),
               'fixture_sha256': q.digest((repo / fixture).read_bytes()),
               'script_sha256': q.digest(Path(__file__).read_bytes()), 'command': command,
               'source_before_aggregate_sha256': q.aggregate(source_before),
               'dependencies_before_aggregate_sha256': q.aggregate(dependency_before),
               'expected_test_count': 2, 'log': 'odt-writer-host.log'}
    q.save(out / 'receipt.json', receipt)
    q.save(out / 'source-before.json', source_before)
    q.save(out / 'dependencies-before.json', dependency_before)
    log = out / receipt['log']
    started = time.monotonic()
    timed_out = False
    with log.open('w') as stream:
        process = subprocess.Popen(command, cwd=harness, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        while True:
            try:
                process.wait(timeout=15)
                break
            except subprocess.TimeoutExpired:
                elapsed = time.monotonic() - started
                print(json.dumps({'active': 'odt-writer-host', 'seconds': round(elapsed), 'log_bytes': log.stat().st_size}), flush=True)
                if elapsed > 600:
                    timed_out = True
                    q.stop_owned_process_group(process)
                    break
    payload = log.read_bytes()
    match = re.search(rb'\+(\d+)(?:\s+~(\d+))?: All tests passed!', payload)
    source_after = q.source_snapshot(repo)
    dependency_after = q.dependency_snapshot(harness, sdk, repo)
    tracked_equal = subprocess.run(['git', 'diff', '--quiet', args.source, '--', 'lib', 'packages', 'test', 'tool', 'pubspec.yaml', 'pubspec.lock', 'analysis_options.yaml'], cwd=repo).returncode == 0
    receipt.update(exit_code=process.returncode, timed_out=timed_out, log_sha256=q.digest(payload),
                   duration_seconds=round(time.monotonic()-started,3), finished_utc=q.now(),
                   passed_tests=int(match[1]) if match else None,
                   skipped_tests=int(match[2] or 0) if match else None,
                   source_unchanged=source_before == source_after,
                   dependencies_unchanged=dependency_before == dependency_after,
                   tracked_inputs_match_source=tracked_equal,
                   probe_unchanged=q.digest(probe.read_bytes()) == receipt['probe_sha256'],
                   source_after_aggregate_sha256=q.aggregate(source_after),
                   dependencies_after_aggregate_sha256=q.aggregate(dependency_after))
    receipt['status'] = ('passed' if process.returncode == 0 and not timed_out and receipt['passed_tests'] == 2
                         and receipt['skipped_tests'] == 0 and receipt['source_unchanged'] and receipt['dependencies_unchanged']
                         and tracked_equal and receipt['probe_unchanged'] else 'failed')
    q.save(out / 'source-after.json', source_after)
    q.save(out / 'dependencies-after.json', dependency_after)
    q.save(out / 'receipt.json', receipt)
    print(json.dumps({k: receipt[k] for k in ('status','passed_tests','skipped_tests','source_unchanged','dependencies_unchanged','exit_code')}), flush=True)
    if receipt['status'] != 'passed':
        print(payload.decode(errors='replace')[-7000:], flush=True)
    return int(receipt['status'] != 'passed')

if __name__ == '__main__':
    raise SystemExit(main())
