#!/usr/bin/env python3
"""Package the separate note amendment evidence without generated build outputs."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()

def main():
    result=json.loads((ROOT/'qualification/receipt.json').read_text())
    setup=json.loads((ROOT/'setup-receipt.json').read_text())
    negative=json.loads((ROOT/'negative/receipt.json').read_text())
    preservation=json.loads((ROOT/'qualification/preservation.json').read_text())
    patch=json.loads((ROOT/'reader-patch/receipt.json').read_text())
    assert result['status']=='passed' and preservation['passed']
    assert result['cohorts']=={'odt-service-tests':{'passed':12,'skipped':0},'note-host-probes':{'passed':2,'skipped':0}}
    assert negative['expected_failure_observed'] and not negative['accepted_qualification']
    assert negative['probe_sha256']==result['probe_sha256']['odt_note_host_test.dart']
    source=result['source_commit'];pin=result['canonical_commit']
    repo=Path(result['source']);canonical=Path(result['canonical'])
    assert pin==negative['canonical_commit']
    fix_paths=git(repo,'diff','--name-only',negative['source_commit'],source,'--','lib','test').splitlines()
    assert fix_paths==['lib/services/office_document_service.dart','test/office_document_service_test.dart']
    source_bindings=[]
    for name in fix_paths:
        before=git(repo,'rev-parse',negative['source_commit']+':'+name)
        after=git(repo,'rev-parse',source+':'+name)
        assert before==patch['paths'][name]['baseline_git_blob']
        assert after==patch['paths'][name]['working_git_blob']
        source_bindings.append({'path':name,'negative_control_blob':before,'accepted_blob':after})
    release=[]
    incoming='d4524de90dd403c9ce350a1d271ac70ce511256b'
    for name in ('pubspec.yaml','pubspec.lock','.github/workflows/macos-release.yml',
                 'docs/apple-export-policy.json','docs/crypto-inventory.json'):
        before=git(repo,'rev-parse',incoming+':'+name);after=git(repo,'rev-parse',source+':'+name)
        assert before==after,name
        release.append({'path':name,'incoming_blob':before,'accepted_blob':after,'equal':True})
    protected=[]
    for name,start,end in (
        ('packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart','      case WmlFieldBoundary():','      case WmlContentControlBoundary()'),
        ('packages/quds_office_engine/lib/src/odf/odf_text.dart','void writeOdfText(', '/// Repeated whitespace or decoded text'),
    ):
        old=git(canonical,'show',result['baseline_canonical']+':'+name)
        new=git(canonical,'show',pin+':'+name)
        before=old[old.index(start):old.index(end,old.index(start))]
        after=new[new.index(start):new.index(end,new.index(start))]
        assert before==after,name
        protected.append({'path':name,'protected_start':start.strip(),'before_sha256':sha(before.encode()),'after_sha256':sha(after.encode()),'equal':True})
    scope={'kind':'Read-only source scope and identity review; not a runtime test',
           'host_source':source,'canonical_source':pin,
           'negative_control_host':negative['source_commit'],
           'prior_accepted_host':result['baseline_host'],'prior_accepted_canonical':result['baseline_canonical'],
           'reader_and_regression_bindings':source_bindings,
           'canonical_library_delta':git(canonical,'diff','--name-only',result['baseline_canonical'],pin,'--','packages/quds_office_engine/lib').splitlines(),
           'protected_field_and_whitespace_logic':protected,
           'incoming_release_metadata':release,
           'production_dependency_declarations_unchanged':setup['production_dependency_declarations_unchanged'],
           'production_lock_unchanged':setup['production_lock_unchanged'],
           'production_lock_sha256':setup['production_lock_sha256'],
           'negative_and_accepted_probe_identical':True}
    save(ROOT/'scope-review.json',scope)
    gate_rows='\n'.join(f"| `{row['name']}` | {str(row['passed_tests'])+' passed; 0 skipped' if 'passed_tests' in row else 'passed'} | `{row['log']}` |" for row in result['commands'])
    modes=preservation['all_canonical_mode_differences']
    assert len(modes)==12 and all(row['inherited_and_permitted'] for row in modes)
    readme=f'''# Host note amendment evidence — 17 November 2026

All **9 bounded gates passed** on CrispCloud `{source}` (tree
`{result['source_tree']}`), pinned to canonical Quds `{pin}` (tree
`{result['canonical_tree']}`). The run passed **12 focused service tests** and
**2 writer-to-actual-host-reader probes**, each with zero skipped tests.
The scopes and source identities are separate from all earlier receipts.

The immediately preceding host ODF amendment remains accepted at
`{result['baseline_host']}` / Quds `{result['baseline_canonical']}` with
40 service + 2 existing writer-reader + 2 list probes. The original broad
41 host + 39 service + 28 Python receipt remains bound to host
`96c514eb98f7ba596a385c8f60496bc6c5994307` / Quds
`837d06edbde08a2465e99cbbb15927ee4c87d8ac`, with its separate 2 probes.
Repeated tests are not additional unique coverage.

Source: [host commit](https://github.com/CrispStrobe/CrispCloud/commit/{source})
and [canonical commit](https://github.com/CrispStrobe/quds_office_suite/commit/{pin}).

## Observed defect and minimal correction

The incoming writer adds ODT footnotes and endnotes by writing note bodies
through its existing block writer. This correctly retains covered table-cell
stories in the package. The host's ODT note preview previously traversed every
descendant of a note body, including retained covered cells. Its separate
ordinary-table ancestor filter did not cover this inline traversal.

Before changing the reader, the exact focused writer-to-reader probe ran on
published host `{negative['source_commit']}` (tree
`{negative['source_tree']}`), already synchronized to the same canonical note
writer. It failed the intended assertion with Flutter exit 1: the preview
contained `HIDDEN COVERED NOTE` and `HIDDEN DEEP NOTE` between visible note
text. The original log, source/dependency maps and source identities are in
`negative/`. The result is an **expected failing negative control, with zero
accepted passes**. Source and dependency inputs were stable; it was an assertion
failure rather than a disk or compilation failure.

The correction adds four lines to the ODT-only inline switch. It stops at an
element only when both its local name and namespace identify an ODF covered
table cell. The new committed service regression checks a nondefault ODF table
prefix, covered and deeply nested hidden stories, ordinary visible text and a
foreign namespace element with the same local name. Hidden content remains in
the raw XML. `reader-patch/` preserves the prepared patch and exact before/after
blobs, and `scope-review.json` verifies those blobs are the accepted commits.

The negative probe source is byte-identical to the final accepted probe source.
Its baseline working checkout was advanced only after the negative run ended;
the archived before/after maps and immutable baseline Git identity describe
that run, rather than the later contents of the same checkout path.

## Executed gates

| Gate | Outcome | Raw log under `qualification/` |
| --- | --- | --- |
{gate_rows}

The 12 selected service tests comprise all ten preexisting ODT service tests,
the already accepted ODF nested-cell regression, and the new covered-note
regression. Selection uses `--name '^(ODT |ODF nested covered stories)'` on the
actual committed service test file. This covers headings, ordinary tables and
lists, inline styles/links/notes, named styles, headers/footers, text boxes,
pictures and image geometry. The other document formats and unchanged broad
host/Python cohorts were not rerun for this ODT-only change.

The two scratch probes use the actual production writer and host service.
The first uses footnote and endnote definitions with the same native ID to
check correct note-class lookup, visible cached Zotero results, suppressed
instruction payload and unchanged source field data. It verifies exact authored
spaces/tabs/newlines in the emitted note-body XML, retained body whitespace and
the host's existing one-line normalization for each displayed note. The second
exports a note table containing merged covered-cell and deeper descendant
stories, then confirms the actual host hides those stories while keeping
visible note text and preserving the raw package payload.

The strict reader gates run `dart analyze --fatal-infos` and a no-output,
exit-on-change formatter against the changed reader and service test. The
temporary analyzer config is archived and restored after execution. Exact
command argv, working directories, timing, terminal counts and raw-log hashes
are recorded in `qualification/receipt.json`.

## Source, graph and preservation

The final run binds **{result['source_file_count']:,} source files** and
**{result['dependency_file_count']:,} dependency entries**, plus runtime binary,
manifest, graph and probe hashes. Source/dependency maps match before and after;
tracked inputs still match the published source; analyzer restoration passed.
The isolated wrapper contains {setup['package_count']} packages, including
{setup['hosted_packages_matching_production']} hosted packages whose exact
versions/archive hashes match production. Dependency declarations and the
production lock are unchanged; no `pub get` ran during this amendment.

All **{preservation['managed_count']:,}** managed paths pass content/tracked
guards: **{preservation['canonical_count']:,}** canonical paths and
**{preservation['parser_count']:,}** standalone parser paths. The parser
subtree/pin, 20 host customization blobs/modes and six notices remain unchanged.
All **12 inherited executable-mode differences** remain preserved, with no new
mode difference. Full baseline/current identities and paths are in
`qualification/preservation.json`; the correction from the old limited eight
mode inventory is documented in the earlier sealed host evidence.

`scope-review.json` also confirms unchanged incoming application version,
production lock, macOS workflow and Apple policy/inventory files. The field
boundary suppression branch and authored whitespace encoder remain
byte-identical to the preceding accepted canonical source. The full inline
writer changes only as recorded by the separate canonical note amendment;
canonical runtime counts are not claimed by this host receipt.

## Reproduction

Restore the official Flutter 3.47.8 / Dart 3.13.7 runtime using the companion
`validation-runtime` evidence and its bootstrap, and populate the original
focused dependency cache using the original `host-audit` prepare/resolve helpers
and saved historical lock inputs. These are setup prerequisites; earlier test
suites need not run again. Use clean host/canonical checkouts at the exact
commits above, and the exported environment described by the runtime kit.

Run from a workspace containing this `host-note-audit` directory, source
checkouts `host-latest` / `quds-landing`, and `runtime`:

```bash
export PYTHONDONTWRITEBYTECODE=1
mkdir -p host-note-replay
python3 host-note-audit/prepare-harness.py \\
  --source "$PWD/host-latest" --commit {source} \\
  --runtime "$PWD/runtime" \\
  --harness "$PWD/host-note-replay/service-harness" \\
  --receipt "$PWD/host-note-replay/setup-receipt.json"
python3 host-note-audit/run-bounded.py \\
  --repo "$PWD/host-latest" --source {source} \\
  --canonical "$PWD/quds-landing" --canonical-commit {pin} \\
  --harness "$PWD/host-note-replay/service-harness" \\
  --setup-receipt "$PWD/host-note-replay/setup-receipt.json" \\
  --output "$PWD/host-note-replay/qualification"
```

Preparation verifies the saved template hashes, unchanged dependency
declarations/production lock, all hosted lock identities and the 107-package
graph, then rebases paths and links actual source. The runner refuses changed
source identities, mismatched canonical pin, untracked execution inputs or an
existing output receipt. Keep source checkouts frozen until it finishes.

For an optional negative-control replay, use a separate clean host checkout at
`{negative['source_commit']}` and the same canonical source. Prepare a distinct
harness with `--receipt` pointing into a new output directory, then run
`run-negative-control.py` with its `--repo`, `--source`, `--canonical`,
`--canonical-commit`, `--harness` and `--output` options. Do not overwrite the
delivered evidence. A successfully reproduced expected failure remains outside
accepted pass counts.

## Limits and evidence contents

The host note preview intentionally normalizes each note to one line. Raw
authored note whitespace is checked separately. Incoming note numbering follows
encounter order; full native numbering formats, restarts, custom marks, repeated
references and malformed recursive note models are outside these assertions.
The host probes establish note preview behavior, not canonical note-body search
coverage. The shared canonical decoder's treatment of inline notes is covered
only to the extent stated in its separate evidence.

This does not claim complete viewer/export-dialog workflows, a full application
or native build, native/Wasm Harper, live Zotero/desktop integration, or
Word/LibreOffice interoperability. Release workflow and policy files are bound
as source inputs; no workflow, signing or release execution was performed.
No GitHub Actions, workflow, check-run or CI-status endpoint was queried or
awaited.

`delivery-files.json` lists the exact small evidence set, including scripts,
template/lock/graph inputs, probes, raw logs, negative control, patch and source
maps. It excludes generated build caches, SDK/cache binaries and live source
symlink trees. The independent review is published separately beside the
archive by the parent landing record. Earlier sealed evidence is unchanged.
'''
    (ROOT/'README.md').write_text(readme)
    selected=[ROOT/name for name in ('README.md','build-delivery.py','prepare-harness.py','run-negative-control.py','run-bounded.py','harness-template.json','setup-receipt.json','scope-review.json','completed-cache-cleanup.json')]
    for subdir in ('support','probes','negative','qualification','reader-patch'):
        selected.extend(path for path in (ROOT/subdir).rglob('*') if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts)
    selected=sorted(set(selected));assert all(path.is_file() for path in selected)
    records={str(path.relative_to(BASE)):{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} for path in selected}
    own=str((ROOT/'delivery-files.json').relative_to(BASE))
    save(ROOT/'delivery-files.json',{'base_directory':str(BASE),'files':sorted([*records,own]),'records':records,'recorded_bytes':sum(row['bytes'] for row in records.values()),'index_self_hash_excluded':True})
    print(json.dumps({'files':len(records)+1,'recorded_bytes':sum(row['bytes'] for row in records.values()),'source':source,'canonical':pin}))

if __name__=='__main__':main()
