#!/usr/bin/env python3
"""Bounded final note-writer amendment checks on an exact host source pair."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prior_host_qualification',ROOT/'support/run-host-qualification.py')
q=importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)

GATES=('vendor-source','vendor-tracked','odt-service-tests','note-host-probes',
       'reader-analysis','reader-format','source-preservation',
       'whitespace','vendor-tracked-final')
READER_TARGETS=('lib/services/office_document_service.dart','test/office_document_service_test.dart')
METADATA=('.github/workflows/macos-release.yml','docs/apple-export-policy.json',
          'docs/crypto-inventory.json','docs/release-testflight-20261117.md',
          'README.md','packages/QUDS_FORKS.md','docs/file-format-viewers.md',
          'docs/office-remaining-gaps-20261115.md')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',required=True,type=Path)
    parser.add_argument('--source',required=True)
    parser.add_argument('--canonical',required=True,type=Path)
    parser.add_argument('--canonical-commit',required=True)
    parser.add_argument('--harness',type=Path,default=ROOT/'service-harness')
    parser.add_argument('--setup-receipt',type=Path,default=ROOT/'setup-receipt.json')
    parser.add_argument('--output',type=Path,default=ROOT/'qualification')
    args=parser.parse_args()
    repo,canonical,harness,out=(p.resolve() for p in (args.repo,args.canonical,args.harness,args.output))
    sdk=Path(os.environ['FLUTTER_ROOT']).resolve()
    assert q.git(repo,'rev-parse','HEAD')==args.source
    assert q.git(canonical,'rev-parse','HEAD')==args.canonical_commit
    assert json.loads((repo/'tool/office_fidelity_manifest.json').read_text())['source_commit']==args.canonical_commit
    setup_path=args.setup_receipt.resolve()
    setup=json.loads(setup_path.read_text())
    assert setup['status']=='passed' and setup['source_commit']==args.source
    assert setup['production_lock_sha256']==q.digest((repo/'pubspec.lock').read_bytes())
    assert Path(setup['harness']).resolve()==harness
    assert (harness/READER_TARGETS[1]).resolve()==repo/READER_TARGETS[1]
    input_roots=['lib','packages','test','tool','pubspec.yaml','pubspec.lock','analysis_options.yaml',*METADATA]
    def source_snapshot():
        result=q.source_snapshot(repo)
        for name in METADATA:
            result[name]=q.digest((repo/name).read_bytes())
        return result
    def tracked_equal():
        return subprocess.run(['git','diff','--quiet',args.source,'--',*input_roots],cwd=repo).returncode==0
    assert tracked_equal()
    assert not q.git(repo,'ls-files','--others','--exclude-standard','--',*input_roots), 'Untracked execution inputs'
    out.mkdir(parents=True,exist_ok=True)
    assert not (out/'receipt.json').exists(),'Never overwrite prior qualification'
    source_before=source_snapshot()
    deps_before=q.dependency_snapshot(harness,sdk,repo)
    probes={name:q.digest((ROOT/'probes'/name).read_bytes()) for name in ('odt_note_host_test.dart',)}
    receipt={'schema_version':1,'status':'running','started_utc':q.now(),
             'kind':'Bounded final note-writer amendment and covered-note reader regression; no untouched broad-suite repetition',
             'source_commit':args.source,'source_tree':q.git(repo,'rev-parse','HEAD^{tree}'),
             'canonical_commit':args.canonical_commit,'canonical_tree':q.git(canonical,'rev-parse','HEAD^{tree}'),
             'baseline_host':'a8cc440260369214fce5cbae8b0230f425a46829',
             'baseline_canonical':'f510060e35d580cbc361985a123927705c92ddc4',
             'source':str(repo),'canonical':str(canonical),'harness':str(harness),
             'setup_receipt_sha256':q.digest(setup_path.read_bytes()),
             'script_sha256':q.digest(Path(__file__).read_bytes()),
             'support_script_sha256':q.digest((ROOT/'support/run-host-qualification.py').read_bytes()),
             'expected_commands':list(GATES),'commands':[],
             'source_before_aggregate_sha256':q.aggregate(source_before),
             'dependencies_before_aggregate_sha256':q.aggregate(deps_before),
             'source_file_count':len(source_before),'dependency_file_count':len(deps_before['dependency_files']),
             'probe_sha256':probes,'pub_get_rerun':False,
             'reader_analysis_targets':list(READER_TARGETS),
             'service_cohort_description':'10 existing ODT service tests, the previously accepted ODF nested-cell regression, and one new covered-note regression; selected by an explicit name pattern',
             'cohorts':{},'counts_kept_separate_from_earlier_source_qualification':True,
             'limitations':['No complete viewer/export-dialog or application-build acceptance',
                            'No live Zotero, Word or LibreOffice acceptance',
                            'Note preview intentionally normalizes each note to one line; authored raw note whitespace is checked separately',
                            'Note labels follow the incoming writer encounter-order behavior; full native numbering/restart/custom-mark fidelity is not claimed',
                            'macOS workflow/release metadata is preserved and fingerprinted; no workflow, signing or release execution claimed',
                            'No GitHub Actions or CI/status endpoints queried or awaited']}
    q.save(out/'source-before.json',source_before)
    q.save(out/'dependencies-before.json',deps_before)
    q.save(out/'receipt.json',receipt)
    analyzer_graph=json.loads((harness/'.dart_tool/package_config.json').read_text())
    for entry in analyzer_graph['packages']:
        name=entry['name']
        root=repo if name=='crisp_cloud' else (repo/'packages'/name if name in q.PACKAGES else q.resolve(harness/'.dart_tool/package_config.json',entry['rootUri']))
        entry['rootUri']=root.as_uri()+'/'
    config_target=repo/'.dart_tool/package_config.json'
    config_previous=config_target.read_bytes() if config_target.exists() else None
    receipt['analysis_config_preexisting']=config_previous is not None
    receipt['analysis_config_before_sha256']=q.digest(config_previous) if config_previous is not None else None
    if config_previous is not None:q.write_atomic(out/'analysis-config-before.bin',config_previous)
    q.save(out/'analysis-package-config.json',analyzer_graph)
    receipt['analysis_config_sha256']=q.digest((out/'analysis-package-config.json').read_bytes())
    q.save(out/'receipt.json',receipt)
    def interrupted(signum,frame):
        raise InterruptedError(f'Received signal {signum}')
    signal.signal(signal.SIGTERM,interrupted)
    def run(name,command,cwd,expected_count=None):
        log=out/(name+'.log');start=time.monotonic()
        row={'name':name,'command':command,'cwd':str(cwd),'log':log.name,'started_utc':q.now(),'status':'running'}
        receipt['commands'].append(row);q.save(out/'receipt.json',receipt)
        print(name+': started',flush=True)
        timeout=False;proc=None;execution_error=None
        try:
            with log.open('w') as stream:
                proc=subprocess.Popen(command,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
                row['process_id']=proc.pid
                q.save(out/'receipt.json',receipt)
                while True:
                    try:proc.wait(timeout=15);break
                    except subprocess.TimeoutExpired:
                        elapsed=time.monotonic()-start
                        print(json.dumps({'active':name,'seconds':round(elapsed),'log_bytes':log.stat().st_size}),flush=True)
                        if elapsed>600:
                            timeout=True;q.stop_owned_process_group(proc);break
        except BaseException as error:
            execution_error=f'{type(error).__name__}: {error}'
            if proc is not None and proc.poll() is None:q.stop_owned_process_group(proc)
        payload=log.read_bytes()
        row.update(exit_code=proc.returncode if proc is not None else None,timed_out=timeout,execution_error=execution_error,duration_seconds=round(time.monotonic()-start,3),finished_utc=q.now(),log_sha256=q.digest(payload))
        if expected_count is not None:
            match=re.search(rb'\+(\d+)(?:\s+~(\d+))?: All tests passed!',payload)
            row['passed_tests']=int(match[1]) if match else None
            row['skipped_tests']=int(match[2] or 0) if match else None
            row['expected_test_count']=expected_count
        row['status']='passed' if row['exit_code']==0 and not timeout and execution_error is None and (expected_count is None or (row['passed_tests']==expected_count and row['skipped_tests']==0)) else 'failed'
        if expected_count is not None:receipt['cohorts'][name]={'passed':row['passed_tests'],'skipped':row['skipped_tests']}
        q.save(out/'receipt.json',receipt)
        print(name+': '+row['status'],flush=True)
        if row['status']!='passed':
            print(payload.decode(errors='replace')[-7000:],flush=True)
            raise RuntimeError(name+' failed')
    flutter=[str(sdk/'bin/cache/dart-sdk/bin/dart'),str(sdk/'bin/cache/flutter_tools.snapshot'),'test','--no-pub','--concurrency=1','--reporter','expanded']
    dart=str(sdk/'bin/cache/dart-sdk/bin/dart')
    failure=None
    try:
        q.write_atomic(config_target,(out/'analysis-package-config.json').read_bytes())
        run('vendor-source',[sys.executable,'tool/verify_office_fidelity.py','--source',str(canonical)],repo)
        run('vendor-tracked',[sys.executable,'tool/verify_office_fidelity.py','--source',str(canonical),'--require-tracked'],repo)
        run('odt-service-tests',[*flutter,'test/office_document_service_test.dart','--name','^(ODT |ODF nested covered stories)'],harness,12)
        run('note-host-probes',[*flutter,'probes/odt_note_host_test.dart'],harness,2)
        run('reader-analysis',[dart,'analyze','--fatal-infos',*READER_TARGETS],repo)
        run('reader-format',[dart,'format','--output=none','--set-exit-if-changed',*READER_TARGETS],repo)
        run('source-preservation',[sys.executable,str(ROOT/'support/audit-preservation.py'),'--host',str(repo),'--canonical',str(canonical),'--host-ref',args.source,'--output',str(out/'preservation.json')],ROOT)
        run('whitespace',['git','diff','--check',receipt['baseline_host'],args.source,'--',*input_roots],repo)
        run('vendor-tracked-final',[sys.executable,'tool/verify_office_fidelity.py','--source',str(canonical),'--require-tracked'],repo)
    except BaseException as error:
        failure=f'{type(error).__name__}: {error}'
    finally:
        if config_previous is None:
            config_target.unlink(missing_ok=True)
            try:config_target.parent.rmdir()
            except OSError:pass
        else:q.write_atomic(config_target,config_previous)
        config_restored=(config_target.read_bytes() if config_target.exists() else None)==config_previous
        source_after=source_snapshot();deps_after=q.dependency_snapshot(harness,sdk,repo)
        q.save(out/'source-after.json',source_after);q.save(out/'dependencies-after.json',deps_after)
        receipt.update(finished_utc=q.now(),source_unchanged=source_before==source_after,dependencies_unchanged=deps_before==deps_after,
                       source_after_aggregate_sha256=q.aggregate(source_after),dependencies_after_aggregate_sha256=q.aggregate(deps_after),
                       tracked_inputs_match_source_at_completion=tracked_equal(),
                       probes_unchanged=all(q.digest((ROOT/'probes'/name).read_bytes())==digest for name,digest in probes.items()),
                       analyzer_config_written=True,analysis_config_restored=config_restored)
        receipt['all_required_commands_completed']=[row['name'] for row in receipt['commands'] if row['status']=='passed']==list(GATES)
        stable=all(receipt[key] for key in ('source_unchanged','dependencies_unchanged','tracked_inputs_match_source_at_completion','probes_unchanged','all_required_commands_completed','analysis_config_restored'))
        receipt['status']='passed' if failure is None and stable else 'failed'
        receipt['error']=failure if failure else None if stable else 'Incomplete gates or input instability'
        q.save(out/'receipt.json',receipt)
    print(json.dumps({key:receipt[key] for key in ('status','cohorts','source_unchanged','dependencies_unchanged','error')}),flush=True)
    return int(receipt['status']!='passed')

if __name__=='__main__':
    raise SystemExit(main())
