#!/usr/bin/env python3
"""Record a covered-note assertion failure on an immutable synced host source."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prior_host',ROOT/'support/run-host-qualification.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--source',required=True)
    parser.add_argument('--canonical',type=Path,required=True)
    parser.add_argument('--canonical-commit',required=True)
    parser.add_argument('--harness',type=Path,default=ROOT/'negative-harness')
    parser.add_argument('--output',type=Path,default=ROOT/'negative')
    args=parser.parse_args()
    repo,canonical,harness,out=(path.resolve() for path in (args.repo,args.canonical,args.harness,args.output))
    sdk=Path(os.environ['FLUTTER_ROOT']).resolve()
    assert q.git(repo,'rev-parse','HEAD')==args.source
    assert q.git(canonical,'rev-parse','HEAD')==args.canonical_commit
    assert json.loads((repo/'tool/office_fidelity_manifest.json').read_text())['source_commit']==args.canonical_commit
    assert subprocess.run(['git','diff','--quiet',args.source,'--','lib','packages','test','tool','pubspec.yaml','pubspec.lock'],cwd=repo).returncode==0
    assert not (out/'receipt.json').exists()
    out.mkdir(parents=True,exist_ok=True)
    before=q.source_snapshot(repo);deps=q.dependency_snapshot(harness,sdk,repo)
    q.save(out/'source-before.json',before);q.save(out/'dependencies-before.json',deps)
    probe=ROOT/'probes/odt_note_host_test.dart'
    command=[str(sdk/'bin/cache/dart-sdk/bin/dart'),str(sdk/'bin/cache/flutter_tools.snapshot'),
             'test','--no-pub','--concurrency=1','--reporter','expanded',
             'probes/odt_note_host_test.dart','--plain-name',
             'note table covered stories stay hidden in the actual host']
    receipt={'kind':'Expected failing covered-note writer-to-host negative control',
             'source_commit':args.source,'source_tree':q.git(repo,'rev-parse','HEAD^{tree}'),
             'canonical_commit':args.canonical_commit,'canonical_tree':q.git(canonical,'rev-parse','HEAD^{tree}'),
             'reader_git_blob':q.git(repo,'rev-parse',args.source+':lib/services/office_document_service.dart'),
             'reader_sha256':q.digest((repo/'lib/services/office_document_service.dart').read_bytes()),
             'writer_git_blob':q.git(repo,'rev-parse',args.source+':packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart'),
             'probe_sha256':q.digest(probe.read_bytes()),'script_sha256':q.digest(Path(__file__).read_bytes()),
             'command':command,'cwd':str(harness),'source':str(repo),'canonical':str(canonical),
             'started_utc':q.now(),'status':'running','passed_tests':0,'accepted_qualification':False}
    q.save(out/'receipt.json',receipt)
    log=out/'covered-note-negative.log';started=time.monotonic()
    with log.open('w') as stream:
        process=subprocess.Popen(command,cwd=harness,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        while True:
            try:process.wait(timeout=15);break
            except subprocess.TimeoutExpired:
                elapsed=time.monotonic()-started
                print(json.dumps({'active':'covered-note-negative','seconds':round(elapsed),'log_bytes':log.stat().st_size}),flush=True)
                if elapsed>600:
                    q.stop_owned_process_group(process);raise TimeoutError('Negative control timed out')
    payload=log.read_bytes()
    after=q.source_snapshot(repo);deps_after=q.dependency_snapshot(harness,sdk,repo)
    q.save(out/'source-after.json',after);q.save(out/'dependencies-after.json',deps_after)
    observed=(process.returncode!=0 and b'HIDDEN COVERED NOTE' in payload
              and b'HIDDEN DEEP NOTE' in payload
              and b'Some tests failed' in payload and b'Expected: not contains' in payload
              and b'Actual:' in payload)
    receipt.update(status='expected_failure_recorded' if observed else 'unexpected_outcome',
                   expected_failure_observed=observed,exit_code=process.returncode,
                   finished_utc=q.now(),duration_seconds=round(time.monotonic()-started,3),
                   log=log.name,log_sha256=q.digest(payload),
                   source_unchanged=before==after,dependencies_unchanged=deps==deps_after,
                   source_head_unchanged=q.git(repo,'rev-parse','HEAD')==args.source,
                   canonical_head_unchanged=q.git(canonical,'rev-parse','HEAD')==args.canonical_commit)
    q.save(out/'receipt.json',receipt)
    print(json.dumps({key:receipt[key] for key in ('status','exit_code','source_unchanged','dependencies_unchanged')}),flush=True)
    print(payload.decode(errors='replace')[-5000:],flush=True)
    return int(not (observed and before==after and deps==deps_after and receipt['source_head_unchanged'] and receipt['canonical_head_unchanged']))

if __name__=='__main__':raise SystemExit(main())
