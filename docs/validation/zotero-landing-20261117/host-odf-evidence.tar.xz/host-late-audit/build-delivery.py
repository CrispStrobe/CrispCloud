#!/usr/bin/env python3
"""Write the final source-bound explanation and exact small-evidence inventory."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parent

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()

def main():
    receipt=json.loads((ROOT/'qualification/receipt.json').read_text())
    setup=json.loads((ROOT/'setup-receipt.json').read_text())
    preservation=json.loads((ROOT/'qualification/preservation.json').read_text())
    negative=json.loads((ROOT/'negative/receipt.json').read_text())
    assert receipt['status']=='passed' and preservation['passed']
    assert negative['expected_failure_observed'] and not negative['accepted_qualification']
    assert receipt['cohorts']=={
        'service-tests':{'passed':40,'skipped':0},
        'existing-odt-host-probes':{'passed':2,'skipped':0},
        'list-host-probes':{'passed':2,'skipped':0},
    }
    repo=Path(receipt['source']);canonical=Path(receipt['canonical'])
    source=receipt['source_commit'];pin=receipt['canonical_commit']
    baseline=receipt['baseline_host'];canonical_baseline=receipt['baseline_canonical']
    incoming='ecdc83b5ab1f3923f5102a7f78094e25beb65e9d'
    host_library_delta=git(repo,'diff','--name-only',baseline,source,'--','lib').splitlines()
    host_test_delta=git(repo,'diff','--name-only',baseline,source,'--','test').splitlines()
    assert host_library_delta==['lib/services/office_document_service.dart']
    assert host_test_delta==['test/office_document_service_test.dart']
    release_paths=['pubspec.yaml','pubspec.lock','.github/workflows/macos-release.yml',
                   'docs/apple-export-policy.json','docs/crypto-inventory.json',
                   'docs/release-testflight-20261117.md']
    release=[]
    for name in release_paths:
        before=git(repo,'rev-parse',incoming+':'+name)
        after=git(repo,'rev-parse',source+':'+name)
        assert before==after,name
        release.append({'path':name,'incoming_blob':before,'final_blob':after,'equal':True})
    protected=[]
    for name,start,end in (
        ('packages/quds_office_engine/lib/src/word/serial/odt_document_writer.dart','  static void _writeInline(', '  static void _writeTable('),
        ('packages/quds_office_engine/lib/src/odf/odf_text.dart','void writeOdfText(', '/// Repeated whitespace or decoded text'),
    ):
        old=git(canonical,'show',canonical_baseline+':'+name)
        new=git(canonical,'show',pin+':'+name)
        old_body=old[old.index(start):old.index(end,old.index(start))]
        new_body=new[new.index(start):new.index(end,new.index(start))]
        assert old_body==new_body,name
        protected.append({'path':name,'function_start':start.strip(),'baseline_sha256':sha(old_body.encode()),'final_sha256':sha(new_body.encode()),'equal':True})
    scope={
        'kind':'Read-only source scope and preserved incoming metadata review; not a runtime test',
        'host_source':source,'canonical_source':pin,
        'baseline_host':baseline,'baseline_canonical':canonical_baseline,
        'incoming_host_main':incoming,
        'host_library_delta':host_library_delta,'host_test_delta':host_test_delta,
        'canonical_library_delta':git(canonical,'diff','--name-only',canonical_baseline,pin,'--','packages/quds_office_engine/lib').splitlines(),
        'canonical_test_delta':git(canonical,'diff','--name-status',canonical_baseline,pin,'--','packages/quds_office_engine/test').splitlines(),
        'incoming_release_metadata':release,
        'protected_functions_byte_identical':protected,
        'production_dependency_declarations_unchanged':setup['production_dependency_declarations_unchanged'],
        'production_lock_unchanged':setup['production_lock_unchanged'],
        'production_lock_sha256':setup['production_lock_sha256'],
        'new_reader_behavior':'A paragraph is excluded only when an ancestor below the selected ordinary cell is an ODF table covered-table-cell; ordinary nested content and foreign namespace names remain visible.',
        'static_writer_review':'Contiguous list groups, headers/footers and recursive table content route through _writeParagraph and the protected _writeInline field writer; writeOdfText retains authored whitespace behavior. Runtime coverage and its limits are described by the separate receipts.',
    }
    save(ROOT/'scope-review.json',scope)
    rows=[]
    for row in receipt['commands']:
        count=str(row['passed_tests'])+' passed, 0 skipped' if 'passed_tests' in row else 'passed'
        rows.append(f"| `{row['name']}` | {count} | `{row['log']}` |")
    modes=preservation['all_canonical_mode_differences']
    assert len(modes)==12 and all(row['inherited_and_permitted'] for row in modes)
    mode_rows='\n'.join(f"| `{row['path']}` | `{row['host_mode']}` | `{row['canonical_mode']}` |" for row in modes)
    command_rows='\n'.join(rows)
    readme=f'''# Final host ODF amendment evidence — 17 November 2026

The **10 bounded gates passed** at CrispCloud `{source}` (tree
`{receipt['source_tree']}`), paired with canonical Quds `{pin}` (tree
`{receipt['canonical_tree']}`). The executed service cohort passed **40 tests**
(39 inherited tests and one new nested covered-cell regression, which checks
both ODT and ODS). Two existing writer-to-host-reader probes passed separately;
two new list-group/Zotero-list probes also passed separately. All three cohorts
completed with zero skips.

These are new, source-bound results. The earlier 41 host + 39 service + 28
Python passes and its separate two probes remain bound to host `{baseline}` /
Quds `{canonical_baseline}` in the original landing evidence. Repeated tests
must not be added to those counts as unique coverage. The unchanged host 41 and
Python 28 cohorts were not rerun in this bounded amendment.

Source: [CrispCloud commit](https://github.com/CrispStrobe/CrispCloud/commit/{source})
and [Quds commit](https://github.com/CrispStrobe/quds_office_suite/commit/{pin}).

## Confirmed reader defect and regression

The final canonical work retains covered table-cell stories in ODF packages
while suppressing them from visible extraction. The inherited host reader
already skipped direct covered cells, but recursively collected every paragraph
inside an ordinary cell. A nested table therefore exposed retained covered-cell
payload in the visible preview.

The isolated negative control ran against the immutable original host
`{baseline}` and reader Git blob `{negative['reader_git_blob']}`. It failed the
intended assertion with Flutter exit `{negative['exit_code']}`: the actual
preview included both `HIDDEN COVERED STORY` and `HIDDEN DEEP STORY`.
`negative/receipt.json`, its raw log, source maps, dependency maps and exact
scratch probe preserve that failure. This expected failure is **not an accepted
test pass**. Source and dependency inputs were unchanged; the failure was an
assertion, with no disk or compilation failure.

The 14-line production change filters paragraph ancestors only when their name
and namespace identify an ODF `table:covered-table-cell`. It preserves visible
nested paragraphs and similarly named foreign elements. The new committed
regression checks these positive controls, suppresses both hidden stories in
ODT and ODS previews, and verifies retained hidden XML remains available in
the raw package view. `reader-patch/` preserves the exact prepared patch and
its inherited/changed blob identities; the accepted runtime result is in the
final 40-test service log.

## Executed commands and integrity

| Gate | Outcome | Raw log under `qualification/` |
| --- | --- | --- |
{command_rows}

The exact argv and working directory for each command are in
`qualification/receipt.json`. Strict reader analysis uses `dart analyze
--fatal-infos` on the actual reader and service test, followed by a no-output,
exit-on-change format check. A temporary analyzer graph resolves genuine local
and hosted packages; its full input is archived and the prior config was
restored. Neither production manifests nor the service lock were rewritten.

The final run fingerprints **{receipt['source_file_count']:,} source files**
and **{receipt['dependency_file_count']:,} dependency entries**, plus runtime,
graph, wrapper declarations and probe hashes. Before/after maps are identical,
tracked inputs still match the source commit, and analyzer restoration passed.
The harness contains {setup['package_count']} packages; all
{setup['hosted_packages_matching_production']} hosted package versions and
archive hashes match the production lock. Production dependency declarations
and lock are unchanged. Application metadata retains version
`{setup['application_version_after']}` from incoming host main. The setup rebased
paths and source links in an independently reconstructed wrapper without
running `pub get` again during this amendment.

`scope-review.json` records exact source differences and demonstrates that the
only changed host library/test are the reader and its regression. It also binds
the incoming application version, production lock, macOS workflow and Apple
release metadata byte-for-byte. Those release files were inspected and
fingerprinted; no workflow or signing operation was executed.

## Probe scope

`probes/odt_writer_host_test.dart` contains the two original supplemental checks:
the authored Zotero fixture through actual ODT writer and host reader, and
authored whitespace/header/footer preview behavior. They check visible text,
hidden instruction suppression and preservation of original field data.

`probes/odt_list_host_test.dart` adds two focused checks. One verifies contiguous
ordered and bullet groups, boundaries after ordinary/suppressed paragraphs,
XML group lengths, visible order, spaces, tabs and newlines. The other places
the Zotero fixture in an ordered list and checks six visible numbered results,
suppression of instructions and unchanged source field data. The exact scratch
sources are included. Canonical writer, extractor, table, header/footer and
presentation suites are qualified separately; their counts are not claimed by
this host receipt.

## Preservation and inherited modes

All **{preservation['managed_count']:,}** managed paths pass exact content and
tracked-source guards: **{preservation['canonical_count']:,}** canonical paths
plus **{preservation['parser_count']:,}** standalone parser paths. The parser
subtree/pin, all 20 host customization blobs/modes and six original notices are
unchanged. `qualification/preservation.json` records their exact identities.

There are **12 inherited executable-mode differences and zero newly introduced
mode differences**. The earlier limited inventory recorded eight. Four others
were already present at the baseline host/Quds pair but became newly included
in the expanded managed inventory. The original eight-only failed audit is
retained in the companion original landing evidence; it is not an exhaustive
mode proof. The current audit derives the complete set from immutable trees at
host `fae07f9e84036328aee271b5c14cda6b082cfab4` and Quds
`732fc3d0bc7a1118f3eb86e6c762fe70182c4fd2` and verifies every current difference.

| Managed path | Preserved host mode | Canonical mode |
| --- | --- | --- |
{mode_rows}

## Reproduction

Use a Linux workspace containing clean source checkouts at the exact commits
above, plus the original `host-audit` and `validation-runtime` companion
evidence. Follow `validation-runtime/README.md` and its `bootstrap-current.py`
to restore official Flutter 3.47.8 / Dart 3.13.7, then run the documented Linux
engine precache. Restore the original focused dependency cache with the original
host evidence's `prepare-host-harness.py` and `resolve-host-harness.py`, using
its supplied historical lock inputs and the same `runtime/pub-cache`. These
setup steps resolve dependencies only; no earlier test suite needs to run.
The runtime and original host setup scripts, locks and archive hashes are
required companions; SDK/cache binaries are intentionally excluded here.

With `FLUTTER_ROOT`, `PUB_CACHE`, `TMPDIR`, `XDG_CONFIG_HOME`, analytics
suppression and `CI=true` exported as documented in the runtime instructions,
reconstruct a fresh final wrapper and keep the delivered evidence untouched:

```bash
export PYTHONDONTWRITEBYTECODE=1
mkdir -p host-late-replay
python3 host-late-audit/prepare-harness.py \\
  --source "$PWD/host-latest" --commit {source} \\
  --runtime "$PWD/runtime" \\
  --harness "$PWD/host-late-replay/service-harness" \\
  --receipt "$PWD/host-late-replay/setup-receipt.json"
python3 host-late-audit/run-bounded.py \\
  --repo "$PWD/host-latest" --source {source} \\
  --canonical "$PWD/quds-latest" --canonical-commit {pin} \\
  --harness "$PWD/host-late-replay/service-harness" \\
  --setup-receipt "$PWD/host-late-replay/setup-receipt.json" \\
  --output "$PWD/host-late-replay/qualification"
```

`prepare-harness.py` verifies all saved template hashes, unchanged production
dependency declarations (version alone may differ), identical production lock,
all hosted lock identities and the 107-node graph before linking actual source.
The final runner refuses a changed source/pin or existing output receipt. Keep
both checkouts frozen until it completes. Historical absolute paths in the
saved executed maps describe this run; preparation rebases paths for replay.

The optional historical negative-control replay requires a separate clean
workspace with original host `{baseline}` at `crispcloud`, a copy of this
evidence's scripts/probes/template at `host-late-audit`, and the same runtime
cache. Reconstruct `host-late-audit/negative-harness` with
`--receipt host-late-audit/negative/setup-receipt.json`, then invoke
`run-negative-control.py` in that clean evidence copy. Do not overwrite the
delivered negative receipt. Its expected failure remains outside acceptance.

## Limits

This is bounded local qualification. It does not establish a complete viewer
or export-dialog workflow, a full application/native build, native/Wasm Harper,
live Zotero/desktop integration, or Word/LibreOffice interoperability. The
service graph deliberately excludes the full viewer dependency closure.
Flat contiguous list grouping is covered; nested list levels, custom numbering
formats and explicit restart values are outside this feature's checked scope.

No GitHub Actions, workflow, check-run or CI-status endpoint was queried or
awaited. Canonical and host source checkpoints are independently identified;
publication and branch integration are recorded by the parent landing record.
The small evidence inventory in `delivery-files.json` excludes generated
build caches, SDK binaries, dependency packages and live source symlink trees.
'''
    (ROOT/'README.md').write_text(readme)
    top=['README.md','build-delivery.py','prepare-harness.py','run-bounded.py',
         'run-negative-control.py','harness-template.json','probe-provenance.json',
         'setup-receipt.json','scope-review.json']
    selected=[ROOT/name for name in top]
    for subdir in ('support','probes','negative','qualification','reader-patch','independent-review'):
        selected.extend(path for path in (ROOT/subdir).rglob('*') if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts)
    selected=sorted(set(selected))
    assert all(path.is_file() for path in selected)
    records={str(path.relative_to(WORKSPACE)):{'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} for path in selected}
    own=str((ROOT/'delivery-files.json').relative_to(WORKSPACE))
    save(ROOT/'delivery-files.json',{'base_directory':str(WORKSPACE),'files':sorted([*records,own]),'records':records,'recorded_bytes':sum(row['bytes'] for row in records.values()),'index_self_hash_excluded':True})
    print(json.dumps({'files':len(records)+1,'recorded_bytes':sum(row['bytes'] for row in records.values()),'source':source,'canonical':pin}))

if __name__=='__main__':main()
