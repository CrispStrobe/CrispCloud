#!/usr/bin/env python3
"""Rebase the accepted host graph onto a new immutable source without pub get."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone
import yaml

ROOT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--runtime', type=Path, default=ROOT.parent/'runtime')
    parser.add_argument('--harness', type=Path, default=ROOT/'service-harness')
    parser.add_argument('--receipt', type=Path, default=ROOT/'setup-receipt.json')
    args = parser.parse_args()
    repo, runtime, harness = (path.resolve() for path in (args.source,args.runtime,args.harness))
    assert not harness.exists(), 'Use a fresh harness directory'
    assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==args.commit
    assert subprocess.run(['git','-C',str(repo),'diff','--quiet',args.commit,'--','lib','packages','test','tool','pubspec.yaml','pubspec.lock'],check=False).returncode==0
    template_path=ROOT/'harness-template.json'
    template=json.loads(template_path.read_text())
    old_pubspec=yaml.safe_load(template['source_pubspec_text'])
    new_pubspec=yaml.safe_load((repo/'pubspec.yaml').read_text())
    old_version=old_pubspec.pop('version')
    new_version=new_pubspec.pop('version')
    assert old_pubspec==new_pubspec, 'Dependency declarations changed; this graph may not be reused'
    assert sha((repo/'pubspec.lock').read_bytes())==template['source_lock_sha256'], 'Production lock changed'
    def rebase(text):
        return text.replace(template['base_harness'],str(harness)).replace(template['base_runtime'],str(runtime))
    written={}
    for name,record in template['inputs'].items():
        assert sha(record['text'].encode())==record['sha256'],name
        if record['is_symlink']:
            continue
        path=harness/name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(rebase(record['text']))
        written[name]=sha(path.read_bytes())
    links={}
    for name,relative in template['source_links'].items():
        target=repo/relative
        assert target.exists(), target
        link=harness/name
        link.parent.mkdir(parents=True,exist_ok=True)
        assert not link.exists() and not link.is_symlink(),link
        link.symlink_to(target,target_is_directory=target.is_dir())
        links[name]=str(target)
    (harness/'probes').symlink_to(ROOT/'probes',target_is_directory=True)
    links['probes']=str(ROOT/'probes')
    old_lock=yaml.safe_load(template['inputs']['pubspec.lock']['text'])
    new_lock=yaml.safe_load((harness/'pubspec.lock').read_text())
    assert yaml.safe_load(rebase(template['inputs']['pubspec.lock']['text']))==new_lock
    production=yaml.safe_load((repo/'pubspec.lock').read_text())['packages']
    hosted=0
    for name,entry in new_lock['packages'].items():
        if entry['source']=='hosted':
            hosted+=1
            assert entry==old_lock['packages'][name]
            assert (entry['version'],entry['description']['sha256'])==(production[name]['version'],production[name]['description']['sha256']),name
    graph=json.loads((harness/'.dart_tool/package_config.json').read_text())
    assert len(graph['packages'])==107
    receipt={'status':'passed','created_utc':datetime.now(timezone.utc).isoformat(),
             'source_commit':args.commit,'source':str(repo),'harness':str(harness),
             'template_sha256':sha(template_path.read_bytes()),'script_sha256':sha(Path(__file__).read_bytes()),
             'baseline_source':template['base_source'],'production_dependency_declarations_unchanged':True,
             'production_lock_unchanged':True,'production_lock_sha256':template['source_lock_sha256'],
             'application_version_before':old_version,'application_version_after':new_version,
             'package_count':107,'hosted_packages_matching_production':hosted,
             'changes_only_harness_runtime_paths_and_source_links':True,
             'pub_get_rerun':False,'application_tests_run':False,
             'written_input_sha256':written,'source_links':links}
    args.receipt.parent.mkdir(parents=True,exist_ok=True)
    args.receipt.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:receipt[k] for k in ['status','source_commit','package_count','hosted_packages_matching_production','application_version_before','application_version_after']}))

if __name__=='__main__':
    main()
