import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:crisp_cloud/services/office_document_service.dart';
import 'package:flutter_test/flutter_test.dart';

const nestedCoveredFixture = '''
<office:document-content
 xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"
 xmlns:foreign="urn:example:foreign-table">
 <office:body><office:text><table:table><table:table-row><table:table-cell>
  <text:p>Outer before</text:p>
  <table:table>
   <table:table-row>
    <table:table-cell table:number-rows-spanned="2"><text:p>Visible anchor</text:p></table:table-cell>
   </table:table-row>
   <table:table-row>
    <table:covered-table-cell>
     <text:p>HIDDEN COVERED STORY</text:p>
     <table:table><table:table-row><table:table-cell><text:p>HIDDEN DEEP STORY</text:p></table:table-cell></table:table-row></table:table>
    </table:covered-table-cell>
   </table:table-row>
   <table:table-row><table:table-cell><text:p>Visible nested end</text:p></table:table-cell></table:table-row>
  </table:table>
  <foreign:covered-table-cell><text:p>Foreign visible story</text:p></foreign:covered-table-cell>
  <text:p>Outer after</text:p>
 </table:table-cell></table:table-row></table:table></office:text></office:body>
</office:document-content>
''';

void main() {
  test(
    'ODT nested covered stories stay hidden while visible content survives',
    () async {
      final archive = Archive()
        ..addFile(
          ArchiveFile.bytes('content.xml', utf8.encode(nestedCoveredFixture)),
        );
      final doc = await parseOfficeDocument(
        Uint8List.fromList(ZipEncoder().encode(archive)),
        'nested-covered.odt',
      );
      expect(doc.fallback, isNull);
      expect(doc.markdown, isNot(contains('HIDDEN')));
      expect(doc.plainText, isNot(contains('HIDDEN')));
      expect(
        doc.markdown,
        contains(
          'Outer before Visible anchor Visible nested end Foreign visible story Outer after',
        ),
      );
      expect(doc.rawXml, contains('HIDDEN COVERED STORY'));
    },
  );
}
