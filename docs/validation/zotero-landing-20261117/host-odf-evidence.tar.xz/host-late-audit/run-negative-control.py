#!/usr/bin/env python3
"""Record the inherited nested-covered-story failure; never a pass claim."""
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('prior_host',ROOT/'support/run-host-qualification.py')
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)

def main():
    repo=ROOT.parent/'crispcloud';harness=ROOT/'negative-harness';out=ROOT/'negative'
    sdk=Path(os.environ['FLUTTER_ROOT']).resolve()
    source='96c514eb98f7ba596a385c8f60496bc6c5994307'
    assert q.git(repo,'rev-parse','HEAD')==source
    assert not (out/'receipt.json').exists()
    before=q.source_snapshot(repo);deps=q.dependency_snapshot(harness,sdk,repo)
    q.save(out/'source-before.json',before);q.save(out/'dependencies-before.json',deps)
    probe=ROOT/'probes/nested_covered_host_test.dart'
    command=[str(sdk/'bin/cache/dart-sdk/bin/dart'),str(sdk/'bin/cache/flutter_tools.snapshot'),
             'test','--no-pub','--concurrency=1','--reporter','expanded','probes/nested_covered_host_test.dart']
    receipt={'kind':'Expected failing negative control of inherited host reader',
             'source_commit':source,'source_tree':q.git(repo,'rev-parse','HEAD^{tree}'),
             'reader_git_blob':q.git(repo,'rev-parse',source+':lib/services/office_document_service.dart'),
             'reader_sha256':q.digest((repo/'lib/services/office_document_service.dart').read_bytes()),
             'probe_sha256':q.digest(probe.read_bytes()),'script_sha256':q.digest(Path(__file__).read_bytes()),
             'command':command,'cwd':str(harness),'started_utc':q.now(),'status':'running',
             'passed_tests':0,'accepted_qualification':False}
    q.save(out/'receipt.json',receipt)
    log=out/'nested-covered-negative.log';started=time.monotonic()
    with log.open('w') as stream:
        process=subprocess.Popen(command,cwd=harness,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        while True:
            try:process.wait(timeout=15);break
            except subprocess.TimeoutExpired:
                elapsed=time.monotonic()-started
                print(json.dumps({'active':'negative-control','seconds':round(elapsed),'log_bytes':log.stat().st_size}),flush=True)
                if elapsed>600:
                    q.stop_owned_process_group(process);raise TimeoutError('Negative control timed out')
    payload=log.read_bytes()
    after=q.source_snapshot(repo);deps_after=q.dependency_snapshot(harness,sdk,repo)
    q.save(out/'source-after.json',after);q.save(out/'dependencies-after.json',deps_after)
    observed=(process.returncode!=0 and b'HIDDEN COVERED STORY' in payload
              and b'Some tests failed' in payload and b'Expected:' in payload and b'Actual:' in payload)
    receipt.update(status='expected_failure_recorded' if observed else 'unexpected_outcome',
                   expected_failure_observed=observed,exit_code=process.returncode,
                   finished_utc=q.now(),duration_seconds=round(time.monotonic()-started,3),
                   log=log.name,log_sha256=q.digest(payload),
                   source_unchanged=before==after,dependencies_unchanged=deps==deps_after)
    q.save(out/'receipt.json',receipt)
    print(json.dumps({key:receipt[key] for key in ('status','exit_code','source_unchanged','dependencies_unchanged')}),flush=True)
    print(payload.decode(errors='replace')[-5000:],flush=True)
    return int(not (observed and before==after and deps==deps_after))

if __name__=='__main__':
    raise SystemExit(main())
