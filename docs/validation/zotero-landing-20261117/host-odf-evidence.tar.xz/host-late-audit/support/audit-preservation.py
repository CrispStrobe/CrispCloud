#!/usr/bin/env python3
"""Read-only checks of a frozen combined host source against recovery."""
import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def tree_entry(repo, ref, path):
    record = git(repo, 'ls-tree', ref, '--', path).decode().strip()
    if not record:
        return None
    fields = record.split('\t')[0].split()
    return {'mode': fields[0], 'type': fields[1], 'oid': fields[2]}


def tree_map(repo, ref):
    result = {}
    for record in git(repo, 'ls-tree', '-rz', ref).split(b'\0'):
        if not record:
            continue
        metadata, raw_path = record.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        result[raw_path.decode()] = {'mode': mode, 'type': kind, 'oid': oid}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', type=Path, required=True)
    parser.add_argument('--canonical', type=Path, required=True)
    parser.add_argument('--host-ref', default='HEAD')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    baseline = 'fae07f9e84036328aee271b5c14cda6b082cfab4'
    host_ref = git(args.host, 'rev-parse', args.host_ref).decode().strip()
    evidence_path = 'docs/validation/zotero-finalization-20261117/late-main-host-final.json'
    prior = json.loads(git(args.host, 'show', f'{baseline}:{evidence_path}'))
    manifest_path = 'tool/office_fidelity_manifest.json'
    manifest = json.loads(git(args.host, 'show', f'{host_ref}:{manifest_path}'))
    canonical = manifest['source_commit']
    baseline_tree = tree_map(args.host, baseline)
    baseline_manifest = json.loads(git(args.host, 'show', f'{baseline}:{manifest_path}'))
    baseline_canonical = baseline_manifest['source_commit']
    baseline_canonical_tree = tree_map(args.canonical, baseline_canonical)
    host_tree = tree_map(args.host, host_ref)
    canonical_tree = tree_map(args.canonical, canonical)
    failures = []
    preservation = []
    for item in prior['unmanaged_and_host_only']:
        path = item['path']
        before = baseline_tree.get(path)
        after = host_tree.get(path)
        equal = before == after
        preservation.append({'path': path, 'before': before, 'after': after, 'equal': equal})
        if not equal:
            failures.append(f'Host customization changed: {path}')
    modes = []
    for item in prior['inherited_modes']:
        path = item['path']
        after = host_tree.get(path)
        equal = after['mode'] == item['inherited_mode']
        modes.append({'path': path, 'expected': item['inherited_mode'], 'actual': after['mode'], 'equal': equal})
        if not equal:
            failures.append(f'Inherited executable mode changed: {path}')
    parser_before = tree_entry(args.host, baseline, 'packages/legacy_doc_parser')
    parser_after = tree_entry(args.host, host_ref, 'packages/legacy_doc_parser')
    if parser_before != parser_after:
        failures.append('Standalone parser subtree changed')
    notices = []
    for path in prior['six_notices_unchanged']:
        before = baseline_tree.get(path)
        after = host_tree.get(path)
        equal = before == after
        notices.append({'path': path, 'before': before, 'after': after, 'equal': equal})
        if not equal:
            failures.append(f'Original notice changed: {path}')
    canonical_paths = []
    canonical_mode_differences = []
    # Derive mode exceptions from immutable baseline trees, including paths
    # newly admitted to the managed inventory since the earlier eight-item list.
    allowed_modes = {}
    baseline_mode_differences = []
    for path in manifest['files']:
        host_before = baseline_tree.get(path)
        canonical_before = baseline_canonical_tree.get(path)
        if (host_before is not None and canonical_before is not None
                and host_before['type'] == canonical_before['type'] == 'blob'
                and host_before['oid'] == canonical_before['oid']
                and host_before['mode'] != canonical_before['mode']):
            allowed_modes[path] = host_before['mode']
            baseline_mode_differences.append({'path': path, 'host_before': host_before, 'canonical_before': canonical_before})
    standalone_paths = []
    for path, digest in manifest['files'].items():
        data = (args.host / path).read_bytes()
        object_id = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        actual_mode = '100755' if (args.host / path).stat().st_mode & 0o111 else '100644'
        if actual_mode != host_tree[path]['mode']:
            failures.append(f'Worktree mode differs from source commit: {path}')
        if object_id != host_tree[path]['oid']:
            failures.append(f'Worktree differs from source commit: {path}')
        if hashlib.sha256(data).hexdigest() != digest:
            failures.append(f'Manifest mismatch: {path}')
        if path.startswith('packages/legacy_doc_parser/'):
            standalone_paths.append(path)
        else:
            canonical_paths.append(path)
            expected = canonical_tree.get(path)
            actual = host_tree.get(path)
            if expected is None or expected['oid'] != actual['oid']:
                failures.append(f'Canonical content mismatch: {path}')
            if expected is not None and expected['mode'] != actual['mode']:
                permitted = allowed_modes.get(path) == actual['mode']
                canonical_mode_differences.append({'path': path, 'canonical_mode': expected['mode'], 'host_mode': actual['mode'], 'inherited_and_permitted': permitted})
                if not permitted:
                    failures.append(f'Unreviewed canonical mode difference: {path}')
    report = {
        'observed_utc': datetime.now(timezone.utc).isoformat(),
        'kind': 'Independent source preservation audit; not a test receipt',
        'baseline': baseline,
        'host_source': host_ref,
        'canonical_source': canonical,
        'managed_count': len(manifest['files']),
        'canonical_count': len(canonical_paths),
        'parser_count': len(standalone_paths),
        'standalone_sources': manifest['standalone_sources'],
        'host_customizations': preservation,
        'inherited_modes': modes,
        'all_canonical_mode_differences': canonical_mode_differences,
        'baseline_canonical_source': baseline_canonical,
        'baseline_mode_differences_for_current_inventory': baseline_mode_differences,
        'parser_subtree': {'before': parser_before, 'after': parser_after, 'equal': parser_before == parser_after},
        'notices': notices,
        'failures': failures,
        'passed': not failures,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('host_source', 'canonical_source', 'managed_count', 'canonical_count', 'parser_count', 'passed', 'failures')}, indent=2))
    return int(bool(failures))


if __name__ == '__main__':
    raise SystemExit(main())
