# Continuation runtime and dependency setup

This archive records setup performed for the 17 November 2026 main-branch integration. It contains no application-test results. Canonical, host, and ODT control results belong to their separate qualification receipts.

The genuine runtime is Flutter 3.47.8, framework `737ba8f885dc774b53b442759999a312c9461e4e`, engine `cf636b1dfb818dd6a3ff16e390e93b1a036969c8`, and Dart 3.13.7. The official Dart archive and Dart/tester executable hashes match the previously published identities. The recorded Flutter-tool dependency lock remained byte-identical. The JIT tool snapshot was freshly compiled; its new hash is recorded in `runtime/runtime-download.json`.

## Executed setup

`setup/scripts/bootstrap-runtime.py` executed successfully from the previously published setup archive. `setup/scripts/prepare-continuation-workspaces.py` is the published preparation helper with explicit source-commit arguments and the current repository directory names; its lock and clean-source guards remain intact.

While integration was still moving, three preparation attempts correctly stopped at a source identity or clean-tree assertion, before wrapper creation. Those setup-only guards are not tests and do not contribute validation counts. The successful preparation used canonical `3abe089d7e31ecbf4ee224788c617b442cee81ac` and a clean detached host setup worktree at `a7fb56f18cb22cbd3da9563ba66161c3472edc6d`. No dependency manifests changed in subsequent source integration.

`retarget-host-source.py` verified all six host dependency manifest/lock inputs against that clean setup worktree, then retargeted the host wrapper links to the frozen actual host `d93ca912fc99b9fe521f78734e31902a785e605e`. The exact comparison and link changes are in `runtime/host-source-retarget.json`. Canonical library/test links already resolved to the actual checkout; the readiness receipt records final canonical source `bacce8e11c6ab5596d01532b074ebaf9a377db90`.

`runtime/finish-setup.py` precached the Linux runtime and completed four Flutter-managed `pub get --enforce-lockfile` resolutions without changing the application locks. They contain 55 engine, 79 editor, 64 focused Studio, and 96 actual-host packages. `prepare-canonical-ready.py` completed the three engine example links before the unrelated final graphs finished, verified runtime hashes and selected locks, and emitted `runtime/canonical-setup-ready.json`. The canonical validation agent subsequently ran its own source/dependency stability gates.

The full Harper/Studio workspace uses the unchanged published lock with SHA-256 `344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130`. The initial offline resolver exited 69 because `printing` was absent from cache; the online enforced-lock retry passed with that lock unchanged and resolved 108 packages. Both logs are retained.

The previously published revised `prior-late/late-main/prepare-service-harness.py` was executed end to end successfully in this continuation. It copied the locked host graph into an isolated cache, verified eleven additional archive hashes against the production lock, and completed two offline enforced-lock resolutions. The resulting service graph has 107 packages; all 97 hosted versions and archive hashes match the production lock. Its repeated final lock is byte-stable, and the base harness and SDK hashes remain unchanged. This newly executed setup supersedes the earlier uncertainty about that helper's fresh-run execution, without changing the attribution of earlier test results.

## Current invocation paths

Set `R` to the absolute runtime directory and source `R/env.sh`. Engine and editor harnesses are `R/harness/quds_office_engine` and `R/harness/quds_office_editor`; the full workspace is `R/harper-workspace`. The actual service harness is `R/service-setup/service-harness`, its separate cache is `R/service-setup/pub-cache`, and its completed setup receipt is `R/service-setup/service-setup-receipt.json`.

Engine tests use the genuine `R/flutter-sdk/bin/cache/dart-sdk/bin/dart`. Flutter tests use that Dart executable plus `R/flutter-sdk/bin/cache/flutter_tools.snapshot`, with `--no-pub`. Analyzer graph installation and restoration belong to the qualification runner, not to this setup.

## Fresh reproduction

Keep this evidence archive outside a fresh runtime directory. Use clean repository checkouts named `quds_office_suite` and `CrispCloud` at the two frozen source commits above. The adapted preparation helper accepts explicit commits and all published dependency locks remain enforced:

```bash
python3 /path/to/evidence/setup/scripts/bootstrap-runtime.py --runtime /absolute/path/new-runtime
python3 /path/to/evidence/setup/scripts/prepare-continuation-workspaces.py \
  --workspace /absolute/path/containing-both-checkouts \
  --runtime /absolute/path/new-runtime \
  --quds-commit bacce8e11c6ab5596d01532b074ebaf9a377db90 \
  --crisp-commit d93ca912fc99b9fe521f78734e31902a785e605e
python3 /absolute/path/new-runtime/finish-setup.py
python3 /absolute/path/new-runtime/resolve-full-workspace.py
python3 /path/to/evidence/prior-late/late-main/prepare-service-harness.py \
  --repo /absolute/path/containing-both-checkouts/CrispCloud \
  --base-harness /absolute/path/new-runtime/crisp-host-harness \
  --flutter /absolute/path/new-runtime/flutter-sdk \
  --output-root /absolute/path/new-runtime/service-setup
```

This direct-final-source recipe omits the temporary setup worktree and link retargeting used while integration was moving. The components were executed in this session as described above; the exact combined direct-final invocation was not repeated. Do not replace existing runtime/harness evidence, edit assertions, or resolve dependencies during a qualification run.

## Preserved evidence

`harness-inputs-current.json.gz` retains exact manifests, locks, package graphs, and runtime-tool metadata with byte counts and SHA-256. `artifact-index.json` binds every archived file; archive creation read every member back and verified its bytes. Complete setup logs, launch journals, executed helper scripts, readiness/retarget receipts, and the production-lock comparison are included. SDK binaries, downloaded package archives, dependency caches, and application-test results are excluded.

No GitHub Actions, workflow, checks, or CI-status endpoints were queried or awaited. No application dependency constraint or production source file was modified by setup.
