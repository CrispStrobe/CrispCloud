#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile,yaml,subprocess
root=Path(__file__).resolve().parent
runtime=root/'runtime'
workspace=root.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
production=yaml.safe_load((workspace/'CrispCloud/pubspec.lock').read_text())['packages']
service=yaml.safe_load((runtime/'service-setup/service-harness/pubspec.lock').read_text())['packages']
comparisons=[]
for name,entry in service.items():
 if entry['source']!='hosted':continue
 original=production[name]
 same=(entry['version'],entry['description']['sha256'])==(original['version'],original['description']['sha256'])
 assert same,name
 comparisons.append({'package':name,'version':entry['version'],'archive_sha256':entry['description']['sha256'],'matches_production':same})
comparison={'status':'passed','hosted_package_count':len(comparisons),'production_lock_sha256':sha(workspace/'CrispCloud/pubspec.lock'),'packages':comparisons}
(runtime/'service-setup/full-production-lock-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
input_paths=[]
for relative in ['harness','crisp-host-harness','harper-workspace','service-setup/service-harness']:
 base=runtime/relative
 for path in base.rglob('*'):
  if path.is_symlink() or not path.is_file():continue
  if path.name in ['pubspec.yaml','pubspec.lock','analysis_options.yaml'] or (path.parent.name=='.dart_tool' and path.name in ['package_config.json','package_graph.json']):
   input_paths.append(path)
for relative in ['flutter-sdk/packages/flutter_tools/pubspec.yaml','flutter-sdk/packages/flutter_tools/pubspec.lock','flutter-sdk/packages/flutter_tools/.dart_tool/package_config.json','flutter-sdk/bin/cache/flutter.version.json']:
 input_paths.append(runtime/relative)
inputs={str(p.relative_to(runtime)):{'sha256':sha(p),'bytes':p.stat().st_size,'text':p.read_text()} for p in sorted(set(input_paths))}
with gzip.open(root/'harness-inputs-current.json.gz','wb') as stream:stream.write((json.dumps(inputs,sort_keys=True,indent=2)+'\n').encode())
expected={'runtime/current-setup-receipt.json':'passed','runtime/harper-workspace-resolution.json':'passed','runtime/service-setup/service-setup-receipt.json':'passed','runtime/canonical-setup-ready.json':'passed'}
for name,status in expected.items():assert json.loads((root/name).read_text())['status']==status
receipt={'recorded_utc':datetime.now(timezone.utc).isoformat(),'status':'passed','scope':'runtime/dependency setup only; application validation belongs to separate runners','canonical_frozen_source':'bacce8e11c6ab5596d01532b074ebaf9a377db90','host_frozen_source':'d93ca912fc99b9fe521f78734e31902a785e605e','setup_baselines':{'canonical':'3abe089d7e31ecbf4ee224788c617b442cee81ac','host':'a7fb56f18cb22cbd3da9563ba66161c3472edc6d'},'package_counts':{'engine':55,'editor':79,'focused_studio':64,'host':96,'full_workspace':108,'service':107},'service_hosted_packages_match_production':len(comparisons),'harness_text_input_count':len(inputs),'harness_inputs_gzip_sha256':sha(root/'harness-inputs-current.json.gz'),'source_repository_writes':False,'application_tests_run_by_setup':False,'github_actions_or_ci_endpoints_used':False,'offline_diagnostic':{'exit_code':69,'reason':'printing package absent in cache','online_enforced_lock_retry':'passed with original lock unchanged'},'fresh_service_helper_executed_end_to_end':True,'previous_setup_archive':{'source_commit':'c929960790274e7f552587cb05ff8020f6afc425','path':'docs/validation/zotero-finalization-20261117/setup-evidence.tar.gz','sha256':sha(root/'validation-setup-evidence.tar.gz')},'previous_service_helper_archive':{'source_commit':'c929960790274e7f552587cb05ff8020f6afc425','path':'docs/validation/zotero-finalization-20261117/late-main-evidence.tar.gz','sha256':sha(root/'late-main-evidence.tar.gz')}}
(root/'setup-handoff.json').write_text(json.dumps(receipt,indent=2)+'\n')
paths=[root/'README.md',root/'setup-handoff.json',root/'harness-inputs-current.json.gz']
paths += list((root/'setup/scripts').glob('*.py'))
paths += [root/'setup/records/sdk-tool-inputs.json.gz',root/'prior-late/late-main/prepare-service-harness.py']
paths += list(root.glob('*.py'))
paths += [root/'remaining-setup-launch.log',root/'service-setup-launch.log']
paths += [p for p in runtime.glob('*.json') if p.is_file()]
paths += [runtime/'env.sh',runtime/'finish-setup.py',runtime/'resolve-full-workspace.py']
paths += list((runtime/'logs').glob('*.log'))
paths += [runtime/'service-setup/service-setup-receipt.json',runtime/'service-setup/full-production-lock-comparison.json']
paths += list((runtime/'service-setup/logs').glob('*.log'))
paths=sorted(set(paths))
for p in paths: assert p.is_file(),p
index={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths}
(root/'artifact-index.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
paths.append(root/'artifact-index.json')
archive=root/'continuation-setup-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as bundle:
 for p in paths:bundle.add(p,arcname='continuation-setup/'+str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
 for member in bundle.getmembers():
  if member.name.endswith('/artifact-index.json'):continue
  relative=member.name.removeprefix('continuation-setup/')
  data=bundle.extractfile(member).read()
  assert len(data)==index[relative]['bytes'] and hashlib.sha256(data).hexdigest()==index[relative]['sha256'],relative
summary={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(paths),'all_member_bytes_read_back_and_verified':True,'setup_status':'passed','application_test_count':0}
(root/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
