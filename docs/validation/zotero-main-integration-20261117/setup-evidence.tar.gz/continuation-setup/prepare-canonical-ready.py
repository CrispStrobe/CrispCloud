#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,subprocess
root=Path(__file__).resolve().parent/'runtime'
source=root.parent.parent/'quds_office_suite'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
setup=json.loads((root/'current-setup-receipt.json').read_text())
rows={row['name']:row for row in setup['commands']}
required=['precache-linux','harness-quds_office_engine-pub-get','harness-quds_office_editor-pub-get']
assert all(rows[n]['status']=='passed' for n in required)
example=root/'harness/quds_office_engine/example'
assert not example.is_symlink()
example.mkdir(exist_ok=True)
links=[]
for name in ['pdf_widgets_invoice.dart','pdf_widgets_proposal.dart','pdf_widgets_report.dart']:
 target=example/name; origin=source/'packages/quds_office_engine/example'/name
 if target.is_symlink(): assert target.resolve()==origin
 else: target.symlink_to(origin)
 links.append({'path':str(target),'source':str(origin),'sha256':sha(origin)})
assert not (example/'pubspec.yaml').exists()
inputs={}
for package in ['quds_office_engine','quds_office_editor']:
 folder=root/'harness'/package
 assert sha(folder/'pubspec.lock')==setup['lock_sha256_before']['harness/'+package]
 graph=json.loads((folder/'.dart_tool/package_config.json').read_text())
 assert graph['flutterRoot']==(root/'flutter-sdk').as_uri() and graph['flutterVersion']=='3.47.8'
 assert (folder/'lib').resolve()==source/'packages'/package/'lib'
 assert (folder/'test').resolve()==source/'packages'/package/'test'
 inputs[package]={name:sha(folder/name) for name in ['pubspec.yaml','pubspec.lock','.dart_tool/package_config.json','.dart_tool/package_graph.json']}
 inputs[package]['package_count']=len(graph['packages'])
expected={'bin/cache/dart-sdk/bin/dart':'01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb','bin/cache/artifacts/engine/linux-x64/flutter_tester':'800f4ca182df7dd2fb46a42dea5d76277b9dbc5e8cd2915e02bcbc978681b45f'}
for name,digest in expected.items(): assert sha(root/'flutter-sdk'/name)==digest
receipt={'status':'passed','scope':'engine/editor locked harnesses and runtime ready; other independent graphs still resolving','canonical_source_commit_at_readiness':subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),'selected_setup_commands':required,'harness_inputs':inputs,'runtime_binaries':expected,'example_links':links,'application_tests_run':False,'source_files_modified':False}
(root/'canonical-setup-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
