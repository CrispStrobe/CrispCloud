#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,subprocess
from datetime import datetime,timezone
root=Path(__file__).resolve().parent
workspace=root.parent
old=root/'setup-host'
source=workspace/'CrispCloud'
runtime=root/'runtime'
expected='d93ca912fc99b9fe521f78734e31902a785e605e'
def git(*args): return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD')==expected
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
paths=['pubspec.yaml','pubspec.lock']+[f'packages/{p}/pubspec.yaml' for p in ['legacy_doc_parser','quds_office_engine','quds_office_editor','quds_reports']]
inputs={}
for name in paths:
 assert (old/name).read_bytes()==(source/name).read_bytes(),name
 inputs[name]=sha(source/name)
links=[]
for target,new in [
 (runtime/'workspace/CrispCloud',source),
 (runtime/'crisp-host-harness/packages/quds_office_engine/third_party',source/'packages/quds_office_engine/third_party')]:
 assert target.is_symlink(),target
 before=os.readlink(target)
 target.unlink(); target.symlink_to(new,target_is_directory=True)
 links.append({'path':str(target),'before':before,'after':str(new)})
for target,expected_target in [
 (runtime/'crisp-host-harness/lib',source/'lib'),
 (runtime/'crisp-host-harness/test/office_document_service_test.dart',source/'test/office_document_service_test.dart'),
 (runtime/'crisp-host-harness/packages/quds_office_engine/lib',source/'packages/quds_office_engine/lib')]:
 assert target.resolve()==expected_target,(target,target.resolve())
receipt={'recorded_utc':datetime.now(timezone.utc).isoformat(),'source_commit':expected,'source_tree':git('rev-parse','HEAD^{tree}'),'manifest_inputs_unchanged_from_setup_snapshot':inputs,'symlink_changes':links,'application_tests_run':False,'production_files_modified':False}
(runtime/'host-source-retarget.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
