#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,time,json
root=Path(__file__).resolve().parent/'runtime'
start=time.monotonic()
while not (root/'runtime-download.json').exists():
    if time.monotonic()-start>300: raise TimeoutError('Verified bootstrap did not complete')
    print(json.dumps({'waiting':'verified runtime bootstrap','seconds':round(time.monotonic()-start)}),flush=True)
    time.sleep(10)
for script in ['finish-setup.py','resolve-full-workspace.py']:
    print(json.dumps({'start':script}),flush=True)
    subprocess.run([sys.executable,str(root/script)],check=True)
