#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,time,json,os
root=Path(__file__).resolve().parent
runtime=root/'runtime'
start=time.monotonic()
while True:
    p=runtime/'current-setup-receipt.json'
    if p.exists() and json.loads(p.read_text()).get('status')=='passed': break
    if time.monotonic()-start>900: raise TimeoutError('Base harness setup did not complete')
    print(json.dumps({'waiting':'locked base harness setup','seconds':round(time.monotonic()-start)}),flush=True)
    time.sleep(10)
command=[sys.executable,str(root/'prior-late/late-main/prepare-service-harness.py'),
 '--repo',str(root.parent/'CrispCloud'),
 '--base-harness',str(runtime/'crisp-host-harness'),
 '--flutter',str(runtime/'flutter-sdk'),
 '--output-root',str(runtime/'service-setup')]
print(json.dumps({'command':command}),flush=True)
subprocess.run(command,check=True)
