export FLUTTER_ROOT='/workspace/scratch/5ce2ad01fc79/validation-runtime/runtime/flutter-sdk'
export PUB_CACHE='/workspace/scratch/5ce2ad01fc79/validation-runtime/runtime/pub-cache'
export TMPDIR='/workspace/scratch/5ce2ad01fc79/validation-runtime/runtime/tmp'
export XDG_CONFIG_HOME='/workspace/scratch/5ce2ad01fc79/validation-runtime/runtime/config'
export PATH="$FLUTTER_ROOT/bin:$PATH"
export CI=true FLUTTER_SUPPRESS_ANALYTICS=true DART_SUPPRESS_ANALYTICS=true
