#!/usr/bin/env python3
"""Restore the previously qualified full workspace lock for Harper/Studio."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT=Path(__file__).resolve().parent
SDK=ROOT/'flutter-sdk'
WORKSPACE=ROOT/'harper-workspace'
LOCK='344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    assert json.loads((ROOT/'current-setup-receipt.json').read_text())['status']=='passed'
    assert digest(WORKSPACE/'pubspec.lock')==LOCK
    env=os.environ.copy()
    env.update(FLUTTER_ROOT=str(SDK),PUB_CACHE=str(ROOT/'pub-cache'),TMPDIR=str(ROOT/'tmp'),
               XDG_CONFIG_HOME=str(ROOT/'config'),CI='true',FLUTTER_SUPPRESS_ANALYTICS='true',DART_SUPPRESS_ANALYTICS='true')
    args=[str(SDK/'bin/cache/dart-sdk/bin/dart'),str(SDK/'bin/cache/flutter_tools.snapshot'),'pub','get','--enforce-lockfile']
    receipt={'commands':[],'lock_sha256_before':LOCK,'tests_run':False,'production_files_modified':False}
    def save(): (ROOT/'harper-workspace-resolution.json').write_text(json.dumps(receipt,indent=2)+'\n')
    for mode in ['offline','online']:
        command=args+(['--offline'] if mode=='offline' else [])
        log=ROOT/'logs'/f'harper-workspace-{mode}-pub-get.log'
        started=time.monotonic(); row={'mode':mode,'command':command,'cwd':str(WORKSPACE),'log':str(log),'status':'running'}
        receipt['commands'].append(row);save()
        print(json.dumps({'start':mode}),flush=True)
        with log.open('w') as stream:
            p=subprocess.Popen(command,cwd=WORKSPACE,env=env,stdout=stream,stderr=subprocess.STDOUT)
            while p.poll() is None:
                try:p.wait(timeout=15)
                except subprocess.TimeoutExpired:print(json.dumps({'active':mode,'seconds':round(time.monotonic()-started)}),flush=True)
                if time.monotonic()-started>600:
                    p.terminate();p.wait(timeout=5);raise RuntimeError('Resolver exceeded 600 seconds')
        row.update(exit_code=p.returncode,status='passed' if p.returncode==0 else 'failed',elapsed_seconds=round(time.monotonic()-started,3),log_sha256=digest(log));save()
        assert digest(WORKSPACE/'pubspec.lock')==LOCK,'Original workspace lock changed'
        print(json.dumps(row),flush=True)
        if p.returncode==0:break
    assert receipt['commands'][-1]['exit_code']==0,'Could not restore exact workspace lock'
    config=WORKSPACE/'.dart_tool/package_config.json'; graph=json.loads(config.read_text())
    assert graph['flutterRoot']==SDK.as_uri(),graph.get('flutterRoot')
    assert graph['flutterVersion']=='3.47.8'
    inputs=json.loads((ROOT/'harper-workspace-setup.json').read_text())
    for path,expected in inputs['manifests_sha256'].items():assert digest(WORKSPACE/path)==expected,path
    assert digest(WORKSPACE/'analysis_options.yaml')==inputs['root_analysis_options_sha256']
    assert digest(WORKSPACE/'pubspec.yaml')==inputs['root_manifest_sha256']
    receipt.update(status='passed',package_count=len(graph['packages']),lock_sha256_after=digest(WORKSPACE/'pubspec.lock'),package_config_sha256=digest(config),manifest_inputs_unchanged=True)
    save();print('FULL WORKSPACE READY',flush=True)

if __name__=='__main__':main()
