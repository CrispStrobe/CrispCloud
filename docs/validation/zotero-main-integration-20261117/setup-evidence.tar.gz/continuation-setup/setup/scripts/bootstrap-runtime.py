#!/usr/bin/env python3
"""Reproduction helper: install verified official artifacts and recorded tool lock.

Assembled during publication; not executed during the active qualification.
It does not modify source repositories or run application tests.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import subprocess
import zipfile

FRAMEWORK = '737ba8f885dc774b53b442759999a312c9461e4e'
ENGINE = 'cf636b1dfb818dd6a3ff16e390e93b1a036969c8'
ARCHIVE = 'b52a1d890575d6c286079bd51650dc77f90c2dddfdcb073a052ae06a5fdb276d'
DART = '01e869e4af277734b02ab8898b870c6b00c9bec61bbcf9c923cd14de7ed85fbb'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime', type=Path, required=True)
    args = parser.parse_args()
    root = args.runtime.resolve()
    assert not root.exists(), 'Use a fresh runtime directory; existing evidence is never replaced.'
    root.mkdir(parents=True)
    for name in ['logs', 'tmp', 'config', 'pub-cache']:
        (root / name).mkdir()
    sdk = root / 'flutter-sdk'
    env = os.environ.copy()
    env.update(FLUTTER_ROOT=str(sdk), PUB_CACHE=str(root / 'pub-cache'),
               TMPDIR=str(root / 'tmp'), XDG_CONFIG_HOME=str(root / 'config'),
               CI='true', DART_SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true')
    def run(name, command, cwd=root):
        with (root / 'logs' / (name + '.log')).open('w') as stream:
            subprocess.run(command, cwd=cwd, env=env, stdout=stream,
                           stderr=subprocess.STDOUT, check=True, timeout=900)
    run('framework-clone', ['git', '-c', 'http.version=HTTP/1.1', 'clone',
                           '--depth', '1', '--branch', '3.47.8',
                           'https://github.com/flutter/flutter.git', str(sdk)])
    assert subprocess.check_output(['git', '-C', str(sdk), 'rev-parse', 'HEAD'], text=True).strip() == FRAMEWORK
    archive = root / 'dart-sdk-linux-x64.zip'
    url = f'https://storage.googleapis.com/flutter_infra_release/flutter/{ENGINE}/dart-sdk-linux-x64.zip'
    run('dart-download', ['curl', '--fail', '--location', '--http1.1', '--retry', '3',
                         '--connect-timeout', '30', '--max-time', '900',
                         '--output', str(archive), url])
    assert archive.stat().st_size == 238851283
    assert digest(archive) == ARCHIVE
    with zipfile.ZipFile(archive) as contents:
        for name in contents.namelist():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts, name
            assert name.startswith('dart-sdk/') or name == 'LICENSE.dart_sdk_archive.md', name
    run('dart-extract', ['unzip', '-oq', str(archive), '-d', str(sdk / 'bin/cache')])
    run('engine-stamp', ['bash', str(sdk / 'bin/internal/update_engine_version.sh')])
    engine = (sdk / 'bin/cache/engine.stamp').read_text()
    assert engine.strip() == ENGINE
    (sdk / 'bin/cache/engine-dart-sdk.stamp').write_text(engine)
    dart = sdk / 'bin/cache/dart-sdk/bin/dart'
    assert digest(dart) == DART

    # Resolve the recorded Flutter-tool graph instead of accepting new versions
    # from the framework launcher's normal first-run `pub upgrade`.
    records = Path(__file__).resolve().parents[1] / 'records'
    tool_inputs = json.loads(gzip.decompress((records / 'sdk-tool-inputs.json.gz').read_bytes()))
    for value in tool_inputs.values():
        data = value['text'].encode()
        assert len(data) == value['bytes']
        assert hashlib.sha256(data).hexdigest() == value['sha256']
    assert digest(sdk / 'packages/flutter_tools/pubspec.yaml') == tool_inputs['packages/flutter_tools/pubspec.yaml']['sha256']
    lock = sdk / 'packages/flutter_tools/pubspec.lock'
    lock.write_text(tool_inputs['packages/flutter_tools/pubspec.lock']['text'])
    run('flutter-tools-locked-get', [str(dart), 'pub', 'get', '--enforce-lockfile'], sdk / 'packages/flutter_tools')
    assert digest(lock) == tool_inputs['packages/flutter_tools/pubspec.lock']['sha256']

    # These compilation flags and cache stamp are the unmodified framework's
    # bin/internal/shared.sh recipe, after the locked resolution above.
    snapshot = sdk / 'bin/cache/flutter_tools.snapshot'
    config = sdk / 'packages/flutter_tools/.dart_tool/package_config.json'
    run('flutter-tools-compile', [str(dart), '--verbosity=error',
        '--snapshot=' + str(snapshot), '--snapshot-kind=app-jit',
        '--packages=' + str(config), '--no-enable-mirrors',
        str(sdk / 'packages/flutter_tools/bin/flutter_tools.dart')])
    (sdk / 'bin/cache/flutter_tools.stamp').write_text(FRAMEWORK + ':\n')
    run('flutter-version', [str(dart), str(snapshot), '--version', '--machine'])
    version = json.loads((sdk / 'bin/cache/flutter.version.json').read_text())
    assert version['frameworkRevision'] == FRAMEWORK
    assert version['engineRevision'] == ENGINE
    assert version['frameworkVersion'] == '3.47.8'
    assert version['dartSdkVersion'] == '3.13.7'
    assert subprocess.check_output(['git', '-C', str(sdk), 'status', '--porcelain', '--untracked-files=no'], text=True) == ''
    (root / 'runtime-download.json').write_text(json.dumps({
        'archive_sha256': ARCHIVE, 'archive_bytes': archive.stat().st_size,
        'dart_sha256': DART, 'framework_sha': FRAMEWORK, 'engine_sha': ENGINE,
        'tool_lock_sha256': digest(lock), 'tool_snapshot_sha256': digest(snapshot),
        'runtime': version, 'application_tests_run': False,
        'reproduction_helper_not_original_bootstrap': True,
    }, indent=2) + '\n')

if __name__ == '__main__':
    main()
