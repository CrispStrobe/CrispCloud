#!/usr/bin/env python3
"""Recreate preserved source links and notice overlays for explicit continuation commits.

Derived from the published setup helper; all original dependency lock checks retained.
Source repositories and their dependency declarations are never written.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys

LOCK = '344190a0224b9e6dcc2161cbfb1be3b7a9569a3a03a809f42801d99f9052e130'
PACKAGES = ['packages/legacy_doc_parser', 'packages/quds_office_engine',
            'packages/quds_proofing_harper', 'packages/quds_office_engine/example',
            'packages/quds_reports', 'packages/quds_office_editor',
            'packages/quds_office_editor/example', 'apps/quds_report_studio']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--quds-commit', required=True)
    parser.add_argument('--crisp-commit', required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    root = args.runtime.resolve()
    scripts = Path(__file__).resolve().parent
    quds, crisp = workspace / 'quds_office_suite', workspace / 'CrispCloud'
    QUDS, CRISP = args.quds_commit, args.crisp_commit
    for source, commit in [(quds, QUDS), (crisp, CRISP)]:
        assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == commit
        assert subprocess.check_output(['git', '-C', str(source), 'diff', '--name-only'], text=True) == ''
        assert subprocess.check_output(['git', '-C', str(source), 'diff', '--cached', '--name-only'], text=True) == ''
    assert (root / 'flutter-sdk').is_dir(), 'Install the verified runtime first.'
    for name in ['harness', 'crisp-host-harness', 'harper-workspace', 'workspace']:
        assert not (root / name).exists(), f'Refusing to replace {root / name}'
    alias = root / 'workspace'
    alias.mkdir()
    for name, target in [('quds_office_suite', quds), ('CrispCloud', crisp), ('zotero-toolchain', root)]:
        (alias / name).symlink_to(target, target_is_directory=True)
    subprocess.run([sys.executable, str(scripts / 'reconstruct-harnesses.py'),
                    '--workspace', str(alias), '--toolchain', str(root)], check=True)
    subprocess.run([sys.executable, str(scripts / 'prepare-harness-assets.py'),
                    '--workspace', str(alias), '--output', str(root / 'harness-assets.json')], check=True)
    host = root / 'crisp-host-harness/pubspec.yaml'
    text = host.read_text()
    for name in ['ENGLISH_US_LICENSE', 'ENGLISH_GB_LICENSE']:
        asset = 'packages/quds_office_engine/third_party/hyphenation/' + name
        assert (crisp / asset).is_file()
        line = '    - ' + asset + '\n'
        if line not in text:
            text += line
    host.write_text(text)

    target = root / 'harper-workspace'
    target.mkdir()
    historical_lock = quds / 'docs/validation/proofing-20261116/integration-resume/workspace-pubspec.lock'
    assert digest(historical_lock) == LOCK
    for name in ['pubspec.yaml', 'analysis_options.yaml']:
        (target / name).write_bytes((quds / name).read_bytes())
    (target / 'pubspec.lock').write_bytes(historical_lock.read_bytes())
    manifests, links = {}, []
    excluded = {'.dart_tool', 'build', '.git', 'pubspec.lock', 'pubspec.yaml', 'pubspec_overrides.yaml'}
    for relative in PACKAGES:
        source = quds / relative
        folder = target / relative
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'pubspec.yaml').write_bytes((source / 'pubspec.yaml').read_bytes())
        manifests[relative + '/pubspec.yaml'] = digest(folder / 'pubspec.yaml')
        for child in source.iterdir():
            if child.name in excluded or str(child.relative_to(quds)) in PACKAGES:
                continue
            destination = folder / child.name
            destination.symlink_to(child, target_is_directory=child.is_dir())
            links.append({'path': str(destination.relative_to(target)), 'source': str(child)})
    (root / 'harper-workspace-setup.json').write_text(json.dumps({
        'source_commit_at_setup': QUDS, 'root_manifest_sha256': digest(target / 'pubspec.yaml'),
        'root_analysis_options_sha256': digest(target / 'analysis_options.yaml'),
        'published_lock_source': str(historical_lock), 'published_lock_sha256': LOCK,
        'manifests_sha256': manifests, 'source_links': links,
        'dependency_constraints_modified': False, 'tests_run': False, 'production_files_modified': False,
    }, indent=2) + '\n')
    for name in ['finish-setup.py', 'resolve-full-workspace.py']:
        shutil.copyfile(scripts / name, root / name)

if __name__ == '__main__':
    main()
