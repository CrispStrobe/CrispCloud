import 'dart:convert';
import 'dart:io';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';
Map<String,Object?> block(LegacyWordBlock b) => switch(b){
 LegacyWordParagraph()=>{'kind':'paragraph','startCp':b.startCp,'endCp':b.endCp,'styleIndex':b.style.styleIndex,'styleName':b.style.styleName,'runs':[for(final r in b.runs){'startCp':r.startCp,'endCp':r.endCp,'text':r.text,'italic':r.style.italic,'font':r.style.fontName,'fontSize':r.style.fontSizeHalfPoints,'spacing':r.style.spacingTwips,'kerning':r.style.kerningThresholdHalfPoints}]},
 LegacyWordTable()=>{'kind':'table','startCp':b.startCp,'endCp':b.endCp,'rows':[for(final row in b.rows){'originTwips':row.originTwips,'autoFit':row.autoFit,'defaultMargins':{for(final e in row.defaultCellMargins.entries)e.key.name:e.value},'cells':[for(final c in row.cells){'widthTwips':c.widthTwips,'blocks':c.blocks.map(block).toList()}]}]},
};
void main(List<String> args){
 final file=File(args[0]);final bytes=file.readAsBytesSync();final doc=parseLegacyWordDocument(bytes);final cfb=BoundedCfbReader(bytes);
 for(final name in ['WordDocument','0Table','1Table']){final data=cfb.readPath(name);if(data!=null)File('${args[1]}.$name').writeAsBytesSync(data);}
 File('${args[1]}.model.json').writeAsStringSync('${jsonEncode({'stories':[for(final s in doc.stories){'id':s.id,'kind':s.kind.name,'startCp':s.startCp,'endCp':s.endCp,'blocks':s.blocks.map(block).toList()}]})}\n');
}
