import sys,zipfile,copy,json,pathlib,xml.etree.ElementTree as E,fitz
root=pathlib.Path('/workspace/scratch/b8f8221a5e6e/parser-table-gaps');sys.path.insert(0,str(root/'tool/fidelity'));from run import office_convert
base=pathlib.Path('/workspace/scratch/b8f8221a5e6e/validation-20261113/table-gaps');office='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice';W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';ns={'w':W[1:-1]}
with zipfile.ZipFile(base/'word16-parser.docx') as z: source={n:z.read(n) for n in z.namelist()}
results={}
for kind in ['omit-balance','balance-false','balance-off','balance-true']:
 parts=dict(source);settings=E.fromstring(parts['word/settings.xml']);c=settings.find('w:compat',ns);flag=c.find('w:balanceSingleByteDoubleByteWidth',ns)
 if kind=='omit-balance':c.remove(flag)
 else:flag.set(W+'val',{'balance-false':'false','balance-off':'off','balance-true':'1'}[kind])
 parts['word/settings.xml']=E.tostring(settings);target=base/('word16-'+kind+'.docx')
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)
 pdf=office_convert(office,target,base/('probe-'+kind),'pdf')
 with fitz.open(pdf) as d:words=[(w[4],round(w[0],3),round(w[1],3)) for w in d[0].get_text('words')]
 results[kind]=words;print(kind,words,flush=True)
(base/'word16-balance-results.json').write_text(json.dumps(results,indent=2)+'\n')
