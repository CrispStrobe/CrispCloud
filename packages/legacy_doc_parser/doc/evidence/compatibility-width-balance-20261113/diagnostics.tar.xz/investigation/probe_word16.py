import sys,zipfile,copy,json,pathlib,xml.etree.ElementTree as E,fitz
root=pathlib.Path('/workspace/scratch/b8f8221a5e6e/parser-table-gaps')
sys.path.insert(0,str(root/'tool/fidelity'))
from run import office_convert
base=pathlib.Path('/workspace/scratch/b8f8221a5e6e/validation-20261113/table-gaps')
office='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
ns={'w':W[1:-1]}
with zipfile.ZipFile(base/'word16-parser.docx') as z: source={n:z.read(n) for n in z.namelist()}
results={}
for kind in ['baseline','language','no-kern','compat11','style-spacing','style-rpr','drawing-rpr','szcs']:
 parts=dict(source);doc=E.fromstring(parts['word/document.xml']);styles=E.fromstring(parts['word/styles.xml']);settings=E.fromstring(parts['word/settings.xml'])
 if kind=='language':
  for rp in doc.findall('.//w:rPr',ns):E.SubElement(rp,W+'lang',{W+'val':'de-DE',W+'eastAsia':'zh-CN',W+'bidi':'ar-SA'})
 if kind=='no-kern':
  for rp in doc.findall('.//w:rPr',ns):
   for n in rp.findall('w:kern',ns):rp.remove(n)
 if kind=='compat11':E.SubElement(settings.find('w:compat',ns),W+'compatSetting',{W+'name':'compatibilityMode',W+'uri':'http://schemas.microsoft.com/office/word',W+'val':'11'})
 if kind in ['style-spacing','style-rpr']:
  for s in styles.findall('w:style',ns):
   if s.attrib.get(W+'styleId')=='Legacy17':
    rp=E.SubElement(s,W+'rPr')
    if kind=='style-spacing':E.SubElement(rp,W+'spacing',{W+'val':'4'})
    else:
     default=doc.find('.//w:pPr/w:rPr',ns)
     for item in default:rp.append(copy.deepcopy(item))
  if kind=='style-spacing':
   for rp in doc.findall('.//w:rPr',ns):
    for n in rp.findall('w:spacing',ns):rp.remove(n)
 if kind=='drawing-rpr':
  for p in doc.findall('.//w:p',ns):
   rp=p.find('w:pPr/w:rPr',ns)
   if rp is not None:
    for r in p.findall('w:r',ns):
     if r.find('w:drawing',ns) is not None and r.find('w:rPr',ns) is None:r.insert(0,copy.deepcopy(rp))
 if kind=='szcs':
  for rp in doc.findall('.//w:rPr',ns):E.SubElement(rp,W+'szCs',{W+'val':'12'})
 parts['word/document.xml']=E.tostring(doc);parts['word/styles.xml']=E.tostring(styles);parts['word/settings.xml']=E.tostring(settings)
 target=base/('word16-'+kind+'.docx')
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)
 pdf=office_convert(office,target,base/('probe-'+kind),'pdf')
 with fitz.open(pdf) as d:
  words=[(w[4],round(w[0],3),round(w[1],3)) for w in d[0].get_text('words')]
 results[kind]=words
 print(kind,words,flush=True)
(base/'word16-probe-results.json').write_text(json.dumps(results,indent=2)+'\n')
