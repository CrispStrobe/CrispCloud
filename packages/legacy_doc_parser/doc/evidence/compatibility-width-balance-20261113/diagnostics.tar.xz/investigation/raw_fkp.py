import struct,pathlib,json,sys
base=pathlib.Path(sys.argv[1]);word=pathlib.Path(str(base)+'.WordDocument').read_bytes()
u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
u32=lambda b,o:struct.unpack_from('<I',b,o)[0]
table=pathlib.Path(str(base)+('.1Table' if u16(word,10)&0x200 else '.0Table')).read_bytes()
pair=lambda i:(u32(word,154+i*8),u32(word,158+i*8))
off,size=pair(33);clx=off
while table[clx]==1:clx+=3+u16(table,clx+1)
count=(u32(table,clx+1)-4)//12;clx+=5;records=clx+4*(count+1)
pieces=[];units=[]
for i in range(count):
 start,end=u32(table,clx+i*4),u32(table,clx+(i+1)*4);packed=u32(table,records+i*8+2);compressed=bool(packed&0x40000000);fc=(packed&0x3fffffff)//(2 if compressed else 1)
 text=word[fc:fc+end-start].decode('cp1252') if compressed else word[fc:fc+2*(end-start)].decode('utf-16-le')
 pieces.append({'startCp':start,'endCp':end,'fc':fc,'compressed':compressed});units.extend(text.encode('utf-16-le')[j]+256*text.encode('utf-16-le')[j+1] for j in range(0,len(text.encode('utf-16-le')),2))
def ops(data,origin):
 result=[];at=0
 while at+2<=len(data):
  code=u16(data,at)
  if code==0 and not any(data[at:]):break
  start=at;at+=2;kind=code>>13;size=[1,1,2,4,2,2,0,3][kind];prefix=0
  if kind==6:
   if code in (0xd608,0xd606):size=u16(data,at)+1;prefix=2
   else:size=data[at]+1;prefix=1
  payload=data[at+prefix:at+size]
  result.append({'wordStreamOffset':origin+start,'sprm':f'0x{code:04x}','operandHex':payload.hex()})
  at+=size
 return result
fkp={}
for kind,idx,width in [('paragraph',13,13),('character',12,1)]:
 off,size=pair(idx);cnt=(size-4)//8;rows=[]
 for i in range(cnt):
  page=u32(table,off+4*(cnt+1)+4*i)&0x3fffff;start=page*512;data=word[start:start+512];nr=data[511];desc=4*(nr+1)
  for j in range(nr):
   first,last=u32(data,4*j),u32(data,4*(j+1));ptr=data[desc+j*width]*2;style=None;dataStart=None;prls=[]
   if ptr:
    cb=data[ptr];beg=ptr+1;end=beg+cb
    if kind=='paragraph':
     if cb==0:beg=ptr+2;end=beg+2*data[ptr+1]
     else:end=ptr+2*cb
     style=u16(data,beg);beg+=2
    dataStart=start+beg;prls=ops(data[beg:end],dataStart)
   rows.append({'firstFc':first,'lastFc':last,'page':page,'propertyOffset':dataStart,'style':style,'operations':prls})
 fkp[kind]=rows
result={'pieces':pieces,'text':''.join(map(chr,units)),'fkp':fkp}
pathlib.Path(str(base)+'.raw-fkp.json').write_text(json.dumps(result,indent=2)+'\n')
for p in pieces:
 start=max(p['startCp'],int(sys.argv[2]));end=min(p['endCp'],int(sys.argv[3]))
 if end<=start:continue
 fc=p['fc']+(start-p['startCp'])*(1 if p['compressed'] else 2);lim=fc+(end-start)*(1 if p['compressed'] else 2)
 print('PIECE',p,'selectedCp',start,end,'units',units[start:end])
 for row in fkp['paragraph']:
  if row['firstFc']<lim and row['lastFc']>fc: print('PAPX',json.dumps(row))
