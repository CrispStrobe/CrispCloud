import 'dart:io';
import 'dart:typed_data';
import '/workspace/scratch/c1ca2a1344e9/parser-ink-next/lib/src/legacy_word_ink.dart';
List<int> u(int n) {final b=<int>[]; do {var v=n&127; n>>=7; b.add(v|(n==0?0:128));}while(n!=0);return b;}
Uint8List wrap(List<int> b)=>Uint8List.fromList([0,...u(b.length),...b]);
void main() {
 final b=File('/workspace/scratch/c1ca2a1344e9/parser-ink-oracle/test/fixtures/ink_wpf/single-dot/uncompressed.isf').readAsBytesSync();
 var p=1; int read(){var n=0,s=0;while(true){final v=b[p++];n|=(v&127)<<s;if(v<128)return n;s+=7;}}
 read(); final bodyStart=p;final tag=read();final length=read();if(tag!=3)throw StateError('Expected initial DA block');
 final remainder=b.sublist(p+length);
 final cases=<String,Uint8List>{'original':b,'empty-paint-table':wrap([2,0,...remainder]),'empty-paint-block':wrap([3,0,...remainder]),'no-paint-table':wrap(remainder),'empty-descriptor-table':wrap([4,0,...b.sublist(bodyStart)])};
 for(final e in cases.entries){final r=decodeLegacyWordInk(e.value);print('${e.key}: ${r.status.name}, strokes=${r.strokes.length}, flags=${r.strokes.firstOrNull?.drawingFlags}, width=${r.strokes.firstOrNull?.widthHimetric}, reason=${r.reason}');}
}
