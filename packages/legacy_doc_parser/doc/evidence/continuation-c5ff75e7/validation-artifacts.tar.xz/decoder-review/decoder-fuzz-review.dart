import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import '/workspace/scratch/c1ca2a1344e9/parser-ink-next/lib/src/legacy_word_ink.dart';
List<int> u(int n){final r=<int>[];do {final q=n&127;n>>=7;r.add(q|(n==0?0:128));}while(n!=0);return r;}
void main(){
 final files=Directory('/workspace/scratch/c1ca2a1344e9/parser-ink-oracle/test/fixtures/ink_wpf').listSync(recursive:true).whereType<File>().where((f)=>f.path.endsWith('.isf')).toList();
 var calls=0,truncated=0,unknown=0,mutations=0;final counts=<String,int>{};
 LegacyWordInkDecodeResult check(Uint8List b){final before=Uint8List.fromList(b);final r=decodeLegacyWordInk(b);calls++;counts.update(r.status.name,(n)=>n+1,ifAbsent:()=>1);if(r.status!=LegacyWordInkDecodeStatus.decoded&&r.strokes.isNotEmpty)throw StateError('Partial failure strokes');for(var i=0;i<b.length;i++){if(before[i]!=b[i])throw StateError('Source changed');}return r;}
 for(final f in files){final b=f.readAsBytesSync();for(var n=0;n<b.length;n++){if(check(Uint8List.sublistView(b,0,n)).status==LegacyWordInkDecodeStatus.decoded)throw StateError('Truncated decoded');truncated++;}if(check(Uint8List.fromList([...b,0])).status!=LegacyWordInkDecodeStatus.invalid)throw StateError('Trailing byte accepted');
  var start=1;while((b[start++]&128)!=0){} final body=[...b.sublist(start),99];final r=check(Uint8List.fromList([0,...u(body.length),...body]));if(r.status!=LegacyWordInkDecodeStatus.unsupported||r.strokes.isNotEmpty)throw StateError('Unknown extension retained partial strokes');unknown++;
  for(var i=0;i<b.length;i++)for(var bit=0;bit<8;bit++){final copy=Uint8List.fromList(b);copy[i]^=1<<bit;check(copy);mutations++;}
 }
 final random=Random(0x15f);for(var i=0;i<10000;i++){check(Uint8List.fromList(List.generate(random.nextInt(256),(_)=>random.nextInt(256))));}
 print(jsonEncode({'calls':calls,'truncationsRejected':truncated,'unknownTailNoPartialStrokes':unknown,'oneBitMutations':mutations,'randomShortInputs':10000,'counts':counts,'uncaughtExceptions':0,'sourceMutations':0}));
}
