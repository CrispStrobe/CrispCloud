#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Replay one falsified command receipt without changing retained evidence."""
import copy
import hashlib
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/c1ca2a1344e9')
REPO = ROOT / 'parser-independent-combined'
DATA = ROOT / 'path-matrix-baseline-c05f187b'
OBSERVER = ROOT / 'path-matrix-observer-c05f187b'
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / 'tool/fidelity'))
import verify_path_matrix as verifier


def identity(path):
    value = path.read_bytes()
    return {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}


report = verifier.read(DATA / 'report.json')
source = REPO / 'tool/fidelity/verify_path_matrix.py'
source_bytes = source.read_bytes()
source_identity = identity(source)
(OUT / ('verify_path_matrix-' + source_identity['sha256'] + '.py')).write_bytes(source_bytes)
observer = verifier.load_observer(OBSERVER, report)
changed = copy.deepcopy(report)
command = next(c for c in changed['commands'] if c['directory'].endswith('/native-docx/command'))
original = copy.deepcopy(command)
command['argv'][0] = '/usr/bin/true'
original_read = verifier.read
verifier.read = lambda path: command if Path(path) == DATA / command['directory'] / 'command.json' else original_read(path)
try:
    verified = verifier.verify(DATA, changed, observer)
    outcome = {'accepted': True, 'verifiedDocuments': verified['verifiedDocuments'],
               'verifiedCommands': verified['verifiedCommands']}
except ValueError as error:
    outcome = {'accepted': False, 'rejection': str(error)}
finally:
    verifier.read = original_read
if source.read_bytes() != source_bytes:
    raise ValueError('Verifier changed during replay')
receipt = {'schema': 'legacy-doc-parser/path-matrix-independent-counterexample', 'version': 1,
           'observedUtc': datetime.now(timezone.utc).isoformat(),
           'measuredRuntime': report['repository']['commit'],
           'source': {'path': str(source), **source_identity},
           'report': {'path': str(DATA / 'report.json'), **identity(DATA / 'report.json')},
           'reviewSource': identity(Path(__file__)),
           'originalCommand': original, 'substitutedCommand': command, 'outcome': outcome,
           'scope': 'Read-only replay with matching command JSON supplied in memory, exactly bypassing the outer duplicate receipt guard. All document, stream, AST, XML, source and comparison records remain original. No native/conversion command executed.'}
target = OUT / ('argv-counterexample-' + source_identity['sha256'][:12] + '.json')
target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'receipt': str(target), **identity(target), 'outcome': outcome}, sort_keys=True))
