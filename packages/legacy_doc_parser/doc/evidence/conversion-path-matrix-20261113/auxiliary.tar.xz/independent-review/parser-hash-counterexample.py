#!/usr/bin/env python3
# SPDX-License-Identifier: MPL-2.0
"""Check retained parser executable attribution without invoking it."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/c1ca2a1344e9')
REPO = ROOT / 'parser-independent-combined'
DATA = ROOT / 'path-matrix-baseline-c05f187b'
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO / 'tool/fidelity'))


def identity(path):
    value = path.read_bytes()
    return {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}


sources = [
    next(OUT.glob('verify_path_matrix-f5afbcb4ddef*.py')),
    REPO / 'tool/fidelity/verify_path_matrix.py',
]
outcomes = []
for index, source in enumerate(sources):
    source_bytes = source.read_bytes()
    spec = importlib.util.spec_from_file_location('_review_matrix_hash_' + str(index), source)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    report = verifier.read(DATA / 'report.json')
    observer = verifier.load_observer(ROOT / 'path-matrix-observer-c05f187b', report)
    changed = copy.deepcopy(report)
    changed['parserIdentity']['sha256'] = '0' * 64
    try:
        result = verifier.verify(DATA, changed, observer)
        outcome = {'accepted': True, 'verifiedDocuments': result['verifiedDocuments']}
    except ValueError as error:
        outcome = {'accepted': False, 'rejection': str(error)}
    if source.read_bytes() != source_bytes:
        raise ValueError('Verifier source changed during replay')
    source_id = identity(source)
    retained_source = OUT / ('verify_path_matrix-' + source_id['sha256'] + '.py')
    retained_source.write_bytes(source_bytes)
    outcomes.append({'source': {'path': str(source), **source_id},
                     'originalParserIdentity': report['parserIdentity'],
                     'substitutedParserIdentity': changed['parserIdentity'], 'outcome': outcome})
if not outcomes[0]['outcome']['accepted'] or outcomes[1]['outcome']['accepted']:
    raise ValueError('Expected original bypass and corrected rejection were not both observed')
receipt = {'schema': 'legacy-doc-parser/path-matrix-parser-identity-review', 'version': 1,
           'observedUtc': datetime.now(timezone.utc).isoformat(),
           'report': {'path': str(DATA / 'report.json'), **identity(DATA / 'report.json')},
           'retainedParser': {'path': str(DATA / 'parser'), **identity(DATA / 'parser')},
           'reviewSource': identity(Path(__file__)), 'replays': outcomes,
           'scope': 'Read-only replay; changed only report.parserIdentity.sha256. No executable or converter invoked and no retained observation modified.'}
target = OUT / 'parser-hash-counterexample-review.json'
target.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'receipt': str(target), **identity(target), 'replays': [x['outcome'] for x in outcomes]}, sort_keys=True))
