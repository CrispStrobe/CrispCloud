#!/usr/bin/env python3
"""Bounded source-input permutation experiment; never rewrites a golden."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

WORKSPACE = Path('/workspace/scratch/c1ca2a1344e9')
REPO = WORKSPACE / 'parser-path-matrix'
sys.path.insert(0, str(REPO / 'tool/fidelity'))
from path_matrix import PROFILE
OUT = WORKSPACE / 'note-order-paths-20261113'
OUT.mkdir(exist_ok=False)
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
OFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
PARSER = WORKSPACE / 'path-matrix-baseline-c05f187b/parser'
SOURCE = REPO / 'test/fixtures/fidelity/semantic-contracts/note-joins.docx'

def identity(path):
    raw = Path(path).read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def joins(path):
    with zipfile.ZipFile(path) as z:
        notes = ET.fromstring(z.read('word/footnotes.xml'))
        doc = ET.fromstring(z.read('word/document.xml'))
    by_id = {n.get('{'+W+'}id'): ''.join(t.text or '' for t in n.iter('{'+W+'}t')) for n in notes}
    return [{'reference': n.get('{'+W+'}id'), 'text': by_id.get(n.get('{'+W+'}id'))}
            for n in doc.iter('{'+W+'}footnoteReference')]

record = {'schema': 'note-order-controlled-paths', 'version': 1,
          'source': {'path': str(SOURCE), **identity(SOURCE)},
          'native': {'path': str(OFFICE), **identity(OFFICE.resolve())},
          'parser': {'path': str(PARSER), **identity(PARSER), 'buildReport': str(PARSER.parent/'report.json'),
                     'sourceCommit': 'c05f187b99e46b6d8d1b6aed6610307f33e1725c',
                     'runtimeUnchangedFrom': 'c5ff75e76163d9abbdd44a9f2a7c5ad210929289'},
          'script': identity(__file__), 'commands': [], 'cases': [],
          'contract': ['NOTE-A:α', 'NOTE-B:β'],
          'scope': 'Four authored-equivalent note ID/part-order inputs; native OOXML-only and binary paths are separate. No production input rewriting.'}

def call(args, label):
    folder = OUT / label
    folder.mkdir(parents=True, exist_ok=False)
    command = {'argv': [str(a) for a in args], 'cwd': str(REPO), 'startedUtc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    process = subprocess.Popen(command['argv'], cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
                               env=os.environ | {'TMPDIR': str(WORKSPACE/'tmp')})
    timeout = False
    try:
        stdout, stderr = process.communicate(timeout=60)
    except subprocess.TimeoutExpired:
        timeout = True
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate()
    for name, raw in [('stdout', stdout), ('stderr', stderr)]:
        (folder/name).write_bytes(raw)
        command[name] = identity(folder/name)
    command.update(returncode=process.returncode, timedOut=timeout, directory=label)
    record['commands'].append(command)
    save(folder/'command.json',command)
    save(OUT/'report.json',record)
    if process.returncode or timeout:
        raise ValueError('Failed '+label)

def native(path, label, kind):
    destination = OUT / label
    destination.mkdir(parents=True, exist_ok=False)
    profile = destination/'profile'
    (profile/'user').mkdir(parents=True)
    (profile/'user/registrymodifications.xcu').write_text(PROFILE)
    option = 'doc:MS Word 97' if kind=='doc' else 'docx:Office Open XML Text'
    call([OFFICE, '-env:UserInstallation='+profile.as_uri(), '--headless', '--norestore', '--nodefault', '--convert-to', option,
          '--outdir', destination, path], label+'/command')
    result = destination/(path.stem+'.'+kind)
    if not result.is_file(): raise ValueError('No native output')
    return result

call([OFFICE,'--version'],'tools/office')
source_before = identity(SOURCE)
with zipfile.ZipFile(SOURCE) as z:
    infos = z.infolist()
    original = {i.filename:z.read(i) for i in infos}
for name, renumber, reorder in [('original',False,False),('ids-only',True,False),('order-only',False,True),('ids-and-order',True,True)]:
    folder = OUT/name
    folder.mkdir()
    parts = dict(original)
    if reorder:
        raw = parts['word/footnotes.xml']
        bstart = raw.index(b'<w:footnote w:id="7">')
        astart = raw.index(b'<w:footnote w:id="19">')
        end = raw.index(b'</w:footnotes>')
        parts['word/footnotes.xml'] = raw[:bstart] + raw[astart:end] + raw[bstart:astart] + raw[end:]
    if renumber:
        for part in ('word/document.xml','word/footnotes.xml'):
            parts[part] = parts[part].replace(b'w:id="19"',b'w:id="1"').replace(b'w:id="7"',b'w:id="2"')
    source = folder/(name+'.docx')
    if name=='original':
        shutil.copyfile(SOURCE,source)
    else:
        with zipfile.ZipFile(source,'x') as z:
            for info in infos: z.writestr(info,parts[info.filename])
    initial = joins(source)
    if [r['text'] for r in initial] != record['contract']: raise ValueError('Source contract changed')
    row = {'name':name,'renumberedIds':renumber,'reorderedPart':reorder,'nodes':{}}
    record['cases'].append(row)
    paths = {'source':source}
    paths['ooxml-resave'] = native(source,name+'/ooxml-resave','docx')
    paths['binary'] = native(source,name+'/binary','doc')
    paths['native-import'] = native(paths['binary'],name+'/native-import','docx')
    parser = folder/'parser.docx'
    call([PARSER,paths['binary'],parser],name+'/parser-command')
    paths['parser-import'] = parser
    for role,path in paths.items():
        value = {'path':str(path.relative_to(OUT)), **identity(path)}
        if path.suffix=='.docx':
            value['joins'] = joins(path)
            value['contractPreserved'] = [r['text'] for r in value['joins']] == record['contract']
        row['nodes'][role] = value
    save(OUT/'report.json',record)
if identity(SOURCE)!=source_before: raise ValueError('Original input changed')
record['sourceUnchanged'] = True
record['completed'] = True
save(OUT/'report.json',record)
print(json.dumps({c['name']:{n:v.get('contractPreserved') for n,v in c['nodes'].items() if 'contractPreserved' in v} for c in record['cases']},indent=2))
