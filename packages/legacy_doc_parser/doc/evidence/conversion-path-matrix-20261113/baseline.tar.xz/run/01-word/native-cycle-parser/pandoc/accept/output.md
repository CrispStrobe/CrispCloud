# **Imported heading**

[Body text]{.mark}[^1][^2]

[Body link]{.underline}

1.  List item

  -----------------------------------------------------------------------
  Cell text

  -----------------------------------------------------------------------

![](media/image1.png){width="0.48333333333333334in" height="0.48333333333333334in"}

[^1]: Footnote text

    [Note link]{.underline}

[^2]: Endnote text
