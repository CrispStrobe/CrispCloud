# **Imported heading**

[Body text]{.mark}[^1][^2]

Body link

1.  List item

  -----------------------------------------------------------------------
  Cell text

  -----------------------------------------------------------------------

![](media/image1.png){width="0.5in" height="0.5in"}

[^1]: Footnote text

    [Note link]{.underline}

[^2]: Endnote text
