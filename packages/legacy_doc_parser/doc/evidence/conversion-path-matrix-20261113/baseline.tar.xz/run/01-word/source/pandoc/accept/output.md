# Imported heading

[Body text]{.mark}[^1][^2]

[Body link](https://example.com/body)

1.  List item

  -----------------------------------------------------------------------
  Cell text

  -----------------------------------------------------------------------

![Fixture image](media/source.png){width="0.5in" height="0.5in"}

[^1]: Footnote text

    [Note link](https://example.com/note)

[^2]: Endnote text
