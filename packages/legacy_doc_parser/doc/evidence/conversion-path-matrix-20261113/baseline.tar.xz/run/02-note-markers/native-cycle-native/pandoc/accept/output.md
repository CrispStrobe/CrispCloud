Authored automatic note markers

References [^1][^2][^3][^4][^5][^6][^7][^8][^9]

[^1]: Conventional footnote

[^2]: Unmarked footnote

[^3]: Before after

[^4]: Opening paragraph

    Later paragraph

[^5]: first **~second\ tail~**

[^6]: After note table

[^7]: Conventional endnote

[^8]: Unmarked endnote

[^9]: End before middle tail
