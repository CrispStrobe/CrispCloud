[]{#Target_A .anchor}ANCHOR-α

REF:\[ANCHOR-α\]

LINK:\[[CACHED-LINK](#Target_A)\]

QUOTE:\[CACHED-QUOTE\]
