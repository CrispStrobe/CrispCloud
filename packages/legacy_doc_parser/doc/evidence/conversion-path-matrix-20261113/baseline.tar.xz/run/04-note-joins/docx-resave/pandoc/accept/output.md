MAIN-A\[[^1]\] MAIN-B\[[^2]\]

[^1]: NOTE-B:β

[^2]: NOTE-A:α
