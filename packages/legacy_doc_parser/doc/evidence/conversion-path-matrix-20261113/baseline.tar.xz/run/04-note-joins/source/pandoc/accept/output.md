MAIN-A\[[^1]\] MAIN-B\[[^2]\]

[^1]: NOTE-A:α

[^2]: NOTE-B:β
