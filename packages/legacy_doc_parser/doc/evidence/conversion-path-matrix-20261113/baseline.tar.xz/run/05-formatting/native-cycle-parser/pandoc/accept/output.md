# **Installed Office conversion fixture**

Unicode café --- 東京 😀. **Bold red text** *and italic text.*

  ----------------------------------- -----------------------------------
  Column A                            Column B

  Cell one                            Cell two
  ----------------------------------- -----------------------------------

![](media/image1.png){width="1.3972222222222221in" height="0.8375in"}

A footnote remains attached here[^1]

A second paragraph after the footnote.

[^1]: Footnote content survives conversion.
