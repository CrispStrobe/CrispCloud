# Independent note authoring

Cite this note [^1], and cite it again [^1]. Undefined [99] remains literal.

[^1]: A **bold** and *italic* [link](https://example.test/note).

