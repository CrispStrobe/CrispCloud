from pathlib import Path
import sys,json
sys.path.insert(0,'/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from run import command
from table_origin_probe import text_positions
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-controls')
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
results=[]
previous={c['name']:c for c in json.loads((root/'result.json').read_text())['cases']}
for case in json.loads((root/'manifest.json').read_text()):
 name=case['name']
 path=root/(name+'-d11fa0e.docx')
 meta=command(['/workspace/scratch/b8f8221a5e6e/validation/word16-main-d11fa0e/convert',root/(name+'.doc'),path])
 (root/(name+'-d11fa0e-converter.json')).write_text(meta)
 baseline=text_positions(office,path,root/(name+'-d11fa0e-pdf'))
 original=previous[name]['source']
 current=previous[name]['converted']
 rel=lambda x:round(x['CELL']['xMin']-x['BODY']['xMin'],4)
 result={'name':name,'sourceRelativeX':rel(original),'d11fa0eRelativeX':rel(baseline),'f70c4beRelativeX':rel(current),'d11fa0eDrift':round(rel(baseline)-rel(original),4),'f70c4beDrift':round(rel(current)-rel(original),4),'baseline':baseline}
 results.append(result)
 print(json.dumps(result),flush=True)
(root/'baseline-result.json').write_text(json.dumps(results,indent=2)+'\n')
