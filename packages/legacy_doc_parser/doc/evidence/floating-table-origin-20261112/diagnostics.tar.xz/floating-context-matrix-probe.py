from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from concurrent.futures import ThreadPoolExecutor
import sys,json,re,hashlib,xml.etree.ElementTree as ET
sys.path.insert(0,'/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from run import command,office_convert
from table_origin_probe import text_positions
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-context-matrix')
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def props(path):
 with ZipFile(path) as z: r=ET.fromstring(z.read('word/document.xml'))
 t=r.find('.//'+W+'tblpPr')
 return {k.removeprefix(W):v for k,v in t.attrib.items()}
def probe(case):
 name=case['name']; source=root/(name+'.doc');base=root/(name+'-d11fa0e.docx');candidate=root/(name+'-context.docx')
 meta=command(['/workspace/scratch/b8f8221a5e6e/validation/word16-main-d11fa0e/convert',source,base])
 (root/(name+'-d11fa0e-converter.json')).write_text(meta)
 with ZipFile(root/(name+'-f70c4be.docx')) as z:
  xml=z.read('word/document.xml').decode()
  correction=case['defaultMarginTwips']+case['singleBorderEighthPoints']*5//4
  xml=re.sub(r'w:tblpX="(-?\d+)"',lambda m:f'w:tblpX="{int(m[1])+correction}"',xml)
  with ZipFile(candidate,'w',ZIP_DEFLATED) as target:
   for item in z.infolist(): target.writestr(item,xml.encode() if item.filename=='word/document.xml' else z.read(item))
 stages={}
 for stage,path in [('source',source),('d11fa0e',base),('f70c4be',root/(name+'-f70c4be.docx')),('context',candidate)]:
  stages[stage]=text_positions(office,path,root/(name+'-'+stage+'-pdf'))
 native=office_convert(office,source,root/(name+'-native-docx'),'docx')
 rel=lambda s:round(s['CELL']['xMin']-s['BODY']['xMin'],4)
 result={**case,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'contextCorrectionTwips':correction,'nativePosition':props(native),'contextPosition':props(candidate),'relativeX':{k:rel(v) for k,v in stages.items()},'relativeDrift':{k:round(rel(v)-rel(stages['source']),4) for k,v in stages.items()},'stages':stages}
 (root/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ['stages']}),flush=True)
 return result
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(probe,json.loads((root/'manifest.json').read_text())))
(root/'result.json').write_text(json.dumps({'parserCommit':'f70c4bef610353ec81e208f51552df35569eecb5','mode':'output-only context hypothesis; runtime unchanged','cases':results},indent=2)+'\n')
