import 'dart:convert';
import 'dart:io';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import '../parser-table-origin/test/support/structured_word_fixture.dart';
import '../parser-table-origin/test/support/table_word_fixture.dart';

void main() {
  final out = Directory('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-context-matrix')..createSync();
  final manifest = <Map<String,Object?>>[];
  for (final (name, storedX, margin, perCell, borderWidth, rtl) in <(String,int,int,int?,int,bool)>[
    ('zero',1441,0,null,0,false),
    ('default',1441,108,null,0,false),
    ('wide',1441,240,null,0,false),
    ('negative-wide',-361,240,null,0,false),
    ('border-1pt',-361,240,null,8,false),
    ('border-075pt',-361,240,null,6,false),
    ('border-125pt',-361,240,null,10,false),
    ('override-zero',1441,240,0,0,false),
    ('override-wide',1441,0,240,0,false),
    ('rtl-wide',1441,240,null,8,true),
    ('align-left',0,240,null,8,false),
    ('align-center',-4,240,null,8,false),
    ('align-right',-8,240,null,8,false),
  ]) {
    final paragraphs = [
      const TableFixtureParagraph('BODY\r'),
      const TableFixtureParagraph('CELL\x07', depth:1, cell:true),
      TableFixtureParagraph('\x07', depth:1, row:true, widths:[2400], extra:[
        ...wordSprm(0x360d, [0x50]),
        ...wordSprm(0x940e, wordU16(storedX)),
        ...wordSprm(0x940f, wordU16(2161)),
        ...wordSprm(0xd634, [6,0,1,10,3,...wordU16(margin)]),
        if(perCell != null) ...wordSprm(0xd632, [6,0,1,2,3,...wordU16(perCell)]),
        if(borderWidth > 0) ...wordSprm(0xd613,[48,for(var side=0;side<6;side++) ...[0,0,0,0,borderWidth,1,0,0]]),
        if(rtl) ...wordSprm(0x560b,wordU16(1)),
      ]),
      const TableFixtureParagraph('AFTER\r'),
    ];
    final font=[...List<int>.filled(40,0),for(final unit in 'Liberation Serif'.codeUnits) ...wordU16(unit),...wordU16(0)];
    font[0]=font.length-1;
    final source = tableFixture(paragraphs,
      styles:{0:WordFixtureStyle(name:'Normal',builtinId:0,paragraphProperties:[...wordSprm(0x6412,[...wordU16(-240),...wordU16(0)]),...wordSprm(0xa413,wordU16(0)),...wordSprm(0xa414,wordU16(0))],characterProperties:[...wordSprm(0x4a4f,wordU16(0)),...wordSprm(0x4a43,wordU16(24))])},
      extraTablePairs:{15:[...wordU16(1),...wordU16(0),...font]},
      sections:[WordFixtureSection(paragraphs.fold<int>(0,(n,p)=>n+p.text.length),[
        ...wordSprm(0xb01f,wordU16(7200)),...wordSprm(0xb020,wordU16(6000)),
        ...wordSprm(0xb021,wordU16(720)),...wordSprm(0xb022,wordU16(720)),
        ...wordSprm(0x9023,wordU16(720)),...wordSprm(0x9024,wordU16(720)),
      ])]);
    File('${out.path}/$name.doc').writeAsBytesSync(source);
    File('${out.path}/$name-f70c4be.docx').writeAsBytesSync(convertLegacyWordToStructuredDocx(source).bytes);
    manifest.add({'name':name,'sourceStoredX':storedX,'sourceStoredY':2161,'defaultMarginTwips':margin,'perCellMarginTwips':perCell,'singleBorderEighthPoints':borderWidth,'rtl':rtl});
  }
  File('${out.path}/manifest.json').writeAsStringSync(jsonEncode(manifest));
}
