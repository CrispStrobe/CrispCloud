from pathlib import Path
import sys, json, hashlib
sys.path.insert(0,'/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from table_origin_probe import text_positions
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-controls')
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
results=[]
for case in json.loads((root/'manifest.json').read_text()):
 name=case['name']
 original=text_positions(office,root/(name+'.doc'),root/(name+'-source-pdf'))
 actual=text_positions(office,root/(name+'-converted.docx'),root/(name+'-converted-pdf'))
 delta={k:round(actual['CELL'][k]-original['CELL'][k],4) for k in original['CELL']}
 result={**case,'sourceSha256':hashlib.sha256((root/(name+'.doc')).read_bytes()).hexdigest(),'source':original,'converted':actual,'cellDelta':delta}
 results.append(result)
 print(json.dumps(result),flush=True)
(root/'result.json').write_text(json.dumps({'parserCommit':'f70c4bef610353ec81e208f51552df35569eecb5','cases':results},indent=2)+'\n')
