import 'dart:convert';
import 'dart:io';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import '../parser-table-origin/test/support/structured_word_fixture.dart';
import '../parser-table-origin/test/support/table_word_fixture.dart';
import '../parser-table-origin/test/support/table_border_fixture.dart';

void main() {
  final out = Directory('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-controls')..createSync();
  final manifest = <Map<String,Object>>[];
  for (final (name, storedX, margin, border) in [
    ('margin-zero', 1441, 0, false),
    ('negative-zero', -361, 0, false),
    ('negative-wide-border', -361, 240, true),
  ]) {
    final source = tableFixture([
      const TableFixtureParagraph('BODY\r'),
      const TableFixtureParagraph('CELL\x07', depth:1, cell:true),
      TableFixtureParagraph('\x07', depth:1, row:true, widths:[2400], extra:[
        ...wordSprm(0x360d, [0x40]),
        ...wordSprm(0x940e, wordU16(storedX)),
        ...wordSprm(0x940f, wordU16(721)),
        ...wordSprm(0xd634, [6,0,1,10,3,...wordU16(margin)]),
        if (border) ...tableBorderProperties(),
      ]),
      const TableFixtureParagraph('AFTER\r'),
    ]);
    File('${out.path}/$name.doc').writeAsBytesSync(source);
    File('${out.path}/$name-converted.docx').writeAsBytesSync(convertLegacyWordToStructuredDocx(source).bytes);
    manifest.add({'name':name,'sourceStoredX':storedX,'sourceStoredY':721,'defaultMarginTwips':margin,'border':border});
  }
  File('${out.path}/manifest.json').writeAsStringSync(jsonEncode(manifest));
}
