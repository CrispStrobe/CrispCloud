from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from concurrent.futures import ThreadPoolExecutor
import sys,json,re,hashlib,xml.etree.ElementTree as ET
sys.path.insert(0,'/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from run import command,office_convert
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-edge-matrix')
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def text_positions(source, output):
 pdf=office_convert(office,source,output,'pdf')
 bbox=command(['pdftotext','-bbox-layout',pdf,'-']);(output/'bbox.xhtml').write_text(bbox)
 return {e.text:{k:float(v) for k,v in e.attrib.items()} for e in ET.fromstring(bbox).iter() if e.tag.endswith('}word')}
def props(path):
 with ZipFile(path) as z:r=ET.fromstring(z.read('word/document.xml'))
 return {k.removeprefix(W):v for k,v in r.find('.//'+W+'tblpPr').attrib.items()}
def probe(case):
 name=case['name'];source=root/(name+'.doc')
 stages={}
 for suffix,extra in [('first-left',247),('last-right',260)]:
  with ZipFile(root/(name+'-f70c4be.docx')) as z:
   xml=z.read('word/document.xml').decode()
   xml=re.sub(r'w:tblpX="(-?\d+)"',lambda m:f'w:tblpX="{int(m[1])+extra}"',xml)
   with ZipFile(root/(name+'-'+suffix+'.docx'),'w',ZIP_DEFLATED) as target:
    for item in z.infolist():target.writestr(item,xml.encode() if item.filename=='word/document.xml' else z.read(item))
 for stage,path in [('source',source),('f70c4be',root/(name+'-f70c4be.docx')),('first-left',root/(name+'-first-left.docx')),('last-right',root/(name+'-last-right.docx'))]:
  stages[stage]=text_positions(path,root/(name+'-'+stage+'-pdf'))
 native=office_convert(office,source,root/(name+'-native-docx'),'docx')
 rel=lambda s:{k:round(v['xMin']-s['BODY']['xMin'],4) for k,v in s.items() if k.startswith('CELL')}
 source_x=rel(stages['source'])
 result={**case,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'nativePosition':props(native),'relativeX':{k:rel(v) for k,v in stages.items()},'drift':{k:{w:round(x-source_x[w],4) for w,x in rel(v).items()} for k,v in stages.items()},'stages':stages}
 (root/(name+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='stages'}),flush=True);return result
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(probe,json.loads((root/'manifest.json').read_text())))
(root/'result.json').write_text(json.dumps(results,indent=2)+'\n')
