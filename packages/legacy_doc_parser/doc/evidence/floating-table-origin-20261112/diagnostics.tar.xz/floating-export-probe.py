from pathlib import Path
import sys,json
from zipfile import ZipFile
import xml.etree.ElementTree as ET
sys.path.insert(0,'/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from run import office_convert
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-controls')
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
for case in json.loads((root/'manifest.json').read_text()):
 name=case['name']
 native=office_convert(office,root/(name+'.doc'),root/(name+'-native-docx'),'docx')
 for kind,path in [('native',native),('converted',root/(name+'-converted.docx'))]:
  with ZipFile(path) as z:r=ET.fromstring(z.read('word/document.xml'))
  t=r.find(f'.//{W}tblPr')
  print(name,kind,ET.tostring(t,encoding='unicode'),flush=True)
