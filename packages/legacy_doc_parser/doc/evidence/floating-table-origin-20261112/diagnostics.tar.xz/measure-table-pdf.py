from pathlib import Path
import hashlib,json,fitz
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-context-matrix')
results=[]
for case in json.loads((root/'manifest.json').read_text()):
 name=case['name'];stages={}
 for stage in ['source','context']:
  path=next((root/(name+'-'+stage+'-pdf')).glob('*.pdf'))
  doc=fitz.open(path);p=doc[0];pix=p.get_pixmap(matrix=fitz.Matrix(1,1),colorspace=fitz.csRGB,alpha=False)
  stages[stage]={'pdfSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rgb72Sha256':hashlib.sha256(pix.samples).hexdigest(),'dimensions':[pix.width,pix.height],'drawings':[{'rect':list(v['rect']),'width':v['width'],'type':v['type'],'lineCap':v['lineCap'],'lineJoin':v['lineJoin'],'color':v['color'],'fill':v['fill'],'dashes':v['dashes']} for v in p.get_drawings()]}
 results.append({'name':name,'rgb72Equal':stages['source']['rgb72Sha256']==stages['context']['rgb72Sha256'],'vectorsEqual':stages['source']['drawings']==stages['context']['drawings'],'stages':stages})
 print(name,results[-1]['rgb72Equal'],results[-1]['vectorsEqual'])
(root/'pdf-geometry.json').write_text(json.dumps({'renderer':'PyMuPDF '+fitz.VersionBind,'measurement':'72dpi RGB all-page raster and exact PDF vector border rectangles/widths; already retained PDFs','cases':results},indent=2)+'\n')
