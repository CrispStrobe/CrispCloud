import 'dart:io';
import 'dart:convert';
import '../parser-table-origin/test/support/structured_word_fixture.dart';
import '../parser-table-origin/test/support/table_word_fixture.dart';

List<int> margin(int code,int width,{int unit=3})=>wordSprm(code,[6,0,1,10,unit,...wordU16(width)]);
void main(){
 final root=Directory('/workspace/scratch/b8f8221a5e6e/geometry-inspection/table-margin-schema-controls')..createSync();
 final names=<String>[];
 for(final (name,extra,styled) in <(String,List<int>,bool)>[
  ('default-reset',[],false),
  ('nil-reset',margin(0xd634,0,unit:0),false),
  ('explicit-reset',margin(0xd634,180),false),
  ('inherited-style-reset',[],true),
 ]){
  final source=tableFixture([
   const TableFixtureParagraph('FIRST\x07',depth:1,cell:true),
   TableFixtureParagraph('\x07',depth:1,row:true,widths:[2400],extra:[
    if(styled)...wordSprm(0x563a,wordU16(21)),
    ...margin(0xd634,0),...margin(0xd632,240),
   ]),
   const TableFixtureParagraph('SECOND\x07',depth:1,cell:true),
   TableFixtureParagraph('\x07',depth:1,row:true,widths:[2400],extra:[
    if(styled)...wordSprm(0x563a,wordU16(21)),...extra,
   ]),
  ],styles:{
   0:const WordFixtureStyle(name:'Normal',builtinId:0),
   if(styled)20:WordFixtureStyle(name:'Base padding',table:true,tableProperties:margin(0xd634,300)),
   if(styled)21:const WordFixtureStyle(name:'Child padding',table:true,parentIndex:20),
  });
  File('${root.path}/$name.doc').writeAsBytesSync(source);names.add(name);
 }
 File('${root.path}/manifest.json').writeAsStringSync(jsonEncode(names));
}
