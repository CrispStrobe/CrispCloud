import sys, json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import xml.etree.ElementTree as ET
sys.path.insert(0, '/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from run import office_convert, command
root = Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/table-origin-variants')
root.mkdir(exist_ok=False)
base = Path('/workspace/scratch/b8f8221a5e6e/validation/word16-main-d11fa0e/word16-page-origin')
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
ref = json.loads((base / 'binary-render.json').read_text())['pages'][0]['words']
results = []
for name, fix_plus, fix_margins in [('plus-one', True, False), ('table-margins', False, True), ('combined', True, True)]:
    with ZipFile(base / 'converted.docx') as source:
        xml = source.read('word/document.xml').decode()
        if fix_plus:
            xml = xml.replace('w:tblpX="856"', 'w:tblpX="857"').replace('w:tblpY="2544"', 'w:tblpY="2545"')
        if fix_margins:
            xml = xml.replace('<w:tblLook ', '<w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="0" w:type="dxa"/><w:bottom w:w="113" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar><w:tblLook ', 1)
        path = root / (name + '.docx')
        with ZipFile(path, 'w', ZIP_DEFLATED) as target:
            for item in source.infolist():
                target.writestr(item, xml.encode() if item.filename == 'word/document.xml' else source.read(item))
    pdf = office_convert(Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'), path, root / (name + '-pdf'), 'pdf')
    bbox = command(['pdftotext', '-bbox-layout', pdf, '-'])
    (root / (name + '.html')).write_text(bbox)
    words = [{'text': el.text, 'box': [float(el.get(k)) for k in ['xMin','yMin','xMax','yMax']]} for el in ET.fromstring(bbox).iter() if el.tag.endswith('}word')]
    result = {'name':name, 'words':words, 'delta': [{'text': b['text'], 'dx':round(b['box'][0]-a['box'][0],6), 'dy':round(b['box'][1]-a['box'][1],6)} for a,b in zip(ref,words)]}
    results.append(result)
    print(json.dumps(result), flush=True)
(root/'result.json').write_text(json.dumps(results, indent=2)+'\n')
