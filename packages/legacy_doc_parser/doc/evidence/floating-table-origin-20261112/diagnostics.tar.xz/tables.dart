import 'dart:convert';
import 'dart:io';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
void main(List<String> args) {
 for(final p in args){final d=parseLegacyWordDocument(File(p).readAsBytesSync());
 Map<String,Object?> info(LegacyWordTable t)=>{'position':t.position==null?null:{'x':t.position!.horizontalOffsetTwips,'y':t.position!.verticalOffsetTwips},'rows':[for(final r in t.rows){'origin':r.originTwips,'defaults':r.defaultCellMargins.map((k,v)=>MapEntry(k.name,v)),'halfgap':r.halfGapTwips,'cells':[for(final c in r.cells){'width':c.widthTwips,'margins':c.formatting.margins.map((k,v)=>MapEntry(k.name,v)),'borders':c.formatting.borders.map((k,v)=>MapEntry(k.name,{'style':v.style,'width':v.widthEighthPoints}))}]}]};
 print(jsonEncode({'file':p,'tables':[for(final t in d.blocks.whereType<LegacyWordTable>()) info(t)]}));}
}
