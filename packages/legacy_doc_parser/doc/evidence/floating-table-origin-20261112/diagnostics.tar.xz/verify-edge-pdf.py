from pathlib import Path
import sys,json,fitz,hashlib
sys.path.insert(0,'/workspace/scratch/b8f8221a5e6e/parser-table-origin/tool/fidelity')
from run import office_convert
root=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection/floating-edge-matrix')
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
results=[]
for c in json.loads((root/'manifest.json').read_text()):
 n=c['name']
 if n.startswith('origin-'):
  actual=office_convert(office,root/(n+'-76fa966.docx'),root/(n+'-76fa966-pdf'),'pdf');kind='actual runtime render'
 else:actual=next((root/(n+'-first-left-pdf')).glob('*.pdf'));kind='hypothesis render; every OPC part equals final runtime (separate receipt)'
 source=next((root/(n+'-source-pdf')).glob('*.pdf'))
 stages={}
 for name,path in [('source',source),('finalEquivalent',actual)]:
  d=fitz.open(path);p=d[0];pix=p.get_pixmap(matrix=fitz.Matrix(1,1),colorspace=fitz.csRGB,alpha=False)
  stages[name]={'pdfSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rgb72Sha256':hashlib.sha256(pix.samples).hexdigest(),'drawings':[{'rect':list(v['rect']),'width':v['width'],'type':v['type'],'color':v['color'],'fill':v['fill']} for v in p.get_drawings()]}
 result={'name':n,'finalComparisonKind':kind,'rgb72Equal':stages['source']['rgb72Sha256']==stages['finalEquivalent']['rgb72Sha256'],'vectorsEqual':stages['source']['drawings']==stages['finalEquivalent']['drawings'],'stages':stages}
 results.append(result);print(n,result['rgb72Equal'],result['vectorsEqual'],flush=True)
(root/'pdf-geometry.json').write_text(json.dumps({'renderer':'PyMuPDF '+fitz.VersionBind,'cases':results},indent=2)+'\n')
