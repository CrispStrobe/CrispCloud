from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import subprocess,hashlib,json,re
base=Path('/workspace/scratch/b8f8221a5e6e/geometry-inspection')
exe=base/'table-context-convert'
results=[]
for group in ['floating-context-matrix','floating-edge-matrix']:
 root=base/group
 for case in json.loads((root/'manifest.json').read_text()):
  name=case['name'];source=root/(name+'.doc');output=root/(name+'-76fa966.docx')
  command=[str(exe),str(source),str(output)]
  proc=subprocess.run(command,check=True,capture_output=True,text=True)
  (root/(name+'-76fa966-converter.json')).write_text(proc.stdout)
  if group=='floating-context-matrix':expected=root/(name+'-context.docx')
  else:
   expected=root/(name+'-final-context.docx')
   with ZipFile(root/(name+'-first-left.docx')) as z:
    xml=z.read('word/document.xml').decode()
    xml=re.sub(r'w:tblpX="(-?\d+)"',lambda m:f'w:tblpX="{int(m[1])+case["rowOriginTwips"]}"',xml)
    with ZipFile(expected,'w',ZIP_DEFLATED) as target:
     for item in z.infolist():target.writestr(item,xml.encode() if item.filename=='word/document.xml' else z.read(item))
  with ZipFile(output) as a,ZipFile(expected) as b:
   diffs=[n for n in set(a.namelist())|set(b.namelist()) if n not in a.namelist() or n not in b.namelist() or a.read(n)!=b.read(n)]
  assert not diffs,(name,diffs)
  results.append({'group':group,'name':name,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'outputSha256':hashlib.sha256(output.read_bytes()).hexdigest(),'matchedOutputOnlyCandidateParts':True})
word16=Path('/workspace/scratch/b8f8221a5e6e/validation/word16-table-f70c4be/word16-page-origin')
source=word16/'source.doc';output=base/'word16-final-76fa966.docx'
proc=subprocess.run([str(exe),str(source),str(output)],check=True,capture_output=True,text=True)
with ZipFile(output) as a,ZipFile(word16/'converted.docx') as b:
 diffs=[n for n in set(a.namelist())|set(b.namelist()) if n not in a.namelist() or n not in b.namelist() or a.read(n)!=b.read(n)]
assert not diffs,diffs
report={'parserCommit':'76fa966d9b2b68cce69ebeba013705c5577ef8ba','parserWorktreeDirty':False,'converterSha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'cases':results,'word16AllPartsMatchThreeCycleF70Output':True,'word16OutputSha256':hashlib.sha256(output.read_bytes()).hexdigest()}
(base/'final-table-converter-equivalence.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'matchedCases':len(results),'word16AllPartsMatchThreeCycleF70Output':True}))
