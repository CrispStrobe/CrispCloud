import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';

void main(List<String> args) {
 for(final path in args){
  final cfb=BoundedCfbReader(File(path).readAsBytesSync());
  final word=ByteData.sublistView(cfb.readPath('WordDocument')!);
  final table=ByteData.sublistView(cfb.readPath(word.getUint16(10,Endian.little)&0x200==0?'0Table':'1Table')!);
  int u16(int at)=>table.getUint16(at,Endian.little);int u32(int at)=>table.getUint32(at,Endian.little);
  (int,int) pair(int n)=>(word.getUint32(154+n*8,Endian.little),word.getUint32(158+n*8,Endian.little));
  final result=<String,Object>{'file':path,'body':word.getUint32(76,Endian.little),'headers':word.getUint32(84,Endian.little)};
  final (h,hl)=pair(11);result['headersCP']=[for(var at=h;at<h+hl;at+=4)u32(at)];
  for(final (name,n,size) in [('spaMain',40,26),('spaHeader',41,26),('txbxMain',56,22),('txbxHeader',58,22)]){
   final (offset,length)=pair(n);if(length==0)continue;final count=(length-4)~/(size+4),records=offset+(count+1)*4;
   result[name]={'offset':offset,'length':length,'cps':[for(var i=0;i<=count;i++)u32(offset+4*i)],'records':[
    for(var i=0;i<count;i++)size==26? {'shape':u32(records+26*i),'rect':[for(var k=1;k<=4;k++)table.getInt32(records+26*i+4*k,Endian.little)],'flags':u16(records+26*i+20)}:{'count':u32(records+22*i),'reusable':u16(records+22*i+8),'lid':u32(records+22*i+14)},
   ]};
  }
  final (art,artLen)=pair(50);final shapes=<Object>[];
  void record(int first,int end,int label){
   var p=first;
   while(p<end){
    if(p+8>end)throw StateError('truncated OfficeArt header');final vi=u16(p),kind=u16(p+2),finish=p+8+u32(p+4);if(finish>end)throw StateError('bad OfficeArt extent');
    if(kind==0xf004){final info=<String,Object>{'label':label,'offset':p};var q=p+8;
     while(q<finish){final v=u16(q),k=u16(q+2),len=u32(q+4);if(q+8+len>finish)throw StateError('bad shape child');
      if(k==0xf00a)info.addAll({'id':u32(q+8),'type':v>>4,'flags':u32(q+12)});
      if(k==0xf00d)info['clientTextbox']=u32(q+8);
      if(k==0xf00b||k==0xf121||k==0xf122){final props=<String,Object>{};for(var i=0;i<v>>4;i++){final id=u16(q+8+6*i)&0x3fff;if([0x80,0x8a,0x38f,0x390,0x391,0x392].contains(id))props[id.toRadixString(16)]=u32(q+10+6*i);}info['properties${k.toRadixString(16)}']=props;}
      q+=8+len;
     }shapes.add(info);
    }else if(vi&15==15){record(p+8,finish,label);}
    p=finish;
   }
  }
  if(artLen>0){var p=art;record(p,p+8+u32(p+4),-1);p+=8+u32(p+4);while(p<art+artLen){final label=table.getUint8(p++);final end=p+8+u32(p+4);record(p,end,label);p=end;}}
  result['shapes']=shapes;print(jsonEncode(result));
 }
}
