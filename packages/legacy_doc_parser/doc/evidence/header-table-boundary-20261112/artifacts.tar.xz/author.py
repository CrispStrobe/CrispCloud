from pathlib import Path
import zipfile,sys
sys.path.insert(0,'tool/fidelity')
from run import command,office_convert
root=Path('build/header-table-native').resolve()
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
dart=Path('/home/agent/.codex/skills/remote-skills/office-recovery-0905ba96fd2d/flutter-3.47.8/bin/cache/dart-sdk/bin/dart')
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';P='http://schemas.openxmlformats.org/package/2006/relationships'
font='<w:rFonts w:ascii="Liberation Serif" w:hAnsi="Liberation Serif"/><w:sz w:val="24"/>'
def p(text):return '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:rPr>'+font+'</w:rPr></w:pPr><w:r><w:rPr>'+font+'</w:rPr><w:t>'+text+'</w:t></w:r></w:p>'
def table():return '<w:tbl><w:tblPr><w:tblW w:w="2880" w:type="dxa"/><w:jc w:val="left"/><w:tblInd w:w="720" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="2880"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="2880" w:type="dxa"/><w:tcMar><w:left w:w="240" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tcMar></w:tcPr>'+p('CELL')+'</w:tc></w:tr></w:tbl>'
for footer in (False,True):
 for trailing in (False,True):
  role='footer' if footer else 'header';name=role+'-'+('paragraph' if trailing else 'table');folder=root/name;folder.mkdir()
  section='<w:sectPr><w:'+role+'Reference w:type="default" r:id="story"/><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>'
  document=f'<w:document xmlns:w="{W}" xmlns:r="{R}"><w:body>'+p('BODY')+section+'</w:body></w:document>'
  story=f'<w:{"ftr" if footer else "hdr"} xmlns:w="{W}">'+p('STORY')+table()+(p('AFTER') if trailing else '')+f'</w:{"ftr" if footer else "hdr"}>'
  parts={'word/document.xml':document,'word/'+role+'1.xml':story,'word/_rels/document.xml.rels':f'<Relationships xmlns="{P}"><Relationship Id="story" Type="{R}/{role}" Target="{role}1.xml"/></Relationships>','_rels/.rels':f'<Relationships xmlns="{P}"><Relationship Id="main" Type="{R}/officeDocument" Target="word/document.xml"/></Relationships>','[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'+f'<Override PartName="/word/{role}1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.{role}+xml"/></Types>'}
  source=folder/'authored.docx'
  with zipfile.ZipFile(source,'x',compression=zipfile.ZIP_DEFLATED) as z:
   for key,text in parts.items():z.writestr(key,text)
  binary=office_convert(office,source,folder/'bridge','doc')
  try:print(name,command([dart,'tool/fidelity/convert.dart',binary,folder/'converted.docx']),flush=True)
  except Exception as e:print(name,repr(e),flush=True)
