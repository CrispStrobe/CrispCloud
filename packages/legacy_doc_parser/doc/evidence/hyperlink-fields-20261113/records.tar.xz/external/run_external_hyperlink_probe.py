#!/usr/bin/env python3
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from xml.etree import ElementTree as ET

BASE = Path('/workspace/scratch/c1ca2a1344e9')
REPO = BASE / 'parser-hyperlink-probes'
ROOT = BASE / 'hyperlink-validation-20261113' / 'external'
DART = BASE / 'toolchains/dart-3.13.7/dart-sdk/bin/dart'
OFFICE = '/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
ENV = {**os.environ, 'TMPDIR': str(BASE / 'tmp'), 'PUB_CACHE': str(BASE / 'toolchains/pub-cache'), 'DART_SUPPRESS_ANALYTICS': 'true'}
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def run(name, argv, inputs=(), cwd=REPO, timeout=60):
    before = {str(p): sha(p.read_bytes()) for p in inputs}
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run([str(a) for a in argv], cwd=cwd, env=ENV, capture_output=True, timeout=timeout)
    (ROOT / (name + '.stdout')).write_bytes(result.stdout)
    (ROOT / (name + '.stderr')).write_bytes(result.stderr)
    after = {str(p): sha(p.read_bytes()) for p in inputs}
    r = {'argv': [str(a) for a in argv], 'cwd': str(cwd), 'started': start,
         'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': result.returncode,
         'stdoutSha256': sha(result.stdout), 'stderrSha256': sha(result.stderr),
         'inputsBefore': before, 'inputsAfter': after, 'timeoutSeconds': timeout}
    (ROOT / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
    if result.returncode or before != after:
        raise RuntimeError(name + ': ' + result.stderr.decode(errors='replace'))
    return result.stdout


def opc(path):
    result = {}
    with zipfile.ZipFile(path) as z:
        for name in z.namelist():
            if not (name.startswith('word/') and name.endswith('.xml') and name.count('/') == 1):
                continue
            root = ET.fromstring(z.read(name))
            relname = 'word/_rels/' + name.split('/')[-1] + '.rels'
            rels = {r.attrib['Id']: r.attrib for r in ET.fromstring(z.read(relname))} if relname in z.namelist() else {}
            result[name] = {'instructions': [e.text or '' for e in root.iter(W + 'instrText')],
                            'links': [{'text': ''.join(e.itertext()), 'anchor': e.get(W + 'anchor'),
                                       'relationship': rels.get(e.get(R + 'id'))} for e in root.iter(W + 'hyperlink')],
                            'text': ''.join(e.text or '' for e in root.iter(W + 't'))}
    return result


def main():
    ROOT.mkdir(parents=True, exist_ok=False)
    original = BASE / 'office-oracle-research-20261113/inputs/word'
    for source, dest in [('source.doc', 'source.doc'), ('authored.docx', 'authored.docx'),
                         ('parser.docx', 'baseline-parser.docx'), ('libreoffice.docx', 'baseline-native.docx')]:
        shutil.copyfile(original / source, ROOT / dest)
    shutil.copyfile(__file__, ROOT / 'run_external_hyperlink_probe.py')
    sources = ['lib/src/word_field_binary_metadata.dart', 'lib/src/word_story_writer.dart',
               'test/legacy_word_external_hyperlink_test.dart', 'test/legacy_word_binary_hyperlink_test.dart',
               'test/fixtures/word_native/external-hyperlinks-native.doc']
    source_receipt = {p: sha((REPO / p).read_bytes()) for p in sources}
    (ROOT / 'runtime-sources.json').write_text(json.dumps(source_receipt, indent=2) + '\n')
    (ROOT / 'runtime.patch').write_bytes(subprocess.check_output(['git', 'diff', 'HEAD'], cwd=REPO))
    run('analyze', [DART, 'analyze', 'lib', 'test/legacy_word_external_hyperlink_test.dart'])
    run('tests', [DART, 'test', '--reporter=json', 'test/legacy_word_binary_hyperlink_test.dart',
                  'test/legacy_word_external_hyperlink_test.dart', 'test/legacy_word_stories_fields_test.dart',
                  'test/legacy_word_display_field_revisions_test.dart', 'test/legacy_word_structured_conversion_test.dart'], timeout=120)
    run('convert', [DART, 'tool/fidelity/convert.dart', ROOT / 'source.doc', ROOT / 'parser.docx'], [ROOT / 'source.doc'])
    run('native-version', [OFFICE, '--version'])
    native = ROOT / 'native'
    native.mkdir()
    profile = ROOT / 'profile'
    (profile / 'user').mkdir(parents=True)
    registry = '''<?xml version="1.0"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry">
<item oor:path="/org.openoffice.Office.Common/Security/Scripting"><prop oor:name="MacroSecurityLevel" oor:op="fuse"><value>3</value></prop><prop oor:name="DisableMacrosExecution" oor:op="fuse"><value>true</value></prop><prop oor:name="BlockUntrustedRefererLinks" oor:op="fuse"><value>true</value></prop></item>
<item oor:path="/org.openoffice.Office.Writer/Content/Update"><prop oor:name="Link" oor:op="fuse"><value>0</value></prop><prop oor:name="Field" oor:op="fuse"><value>false</value></prop><prop oor:name="Chart" oor:op="fuse"><value>false</value></prop></item>
</oor:items>'''
    (profile / 'user/registrymodifications.xcu').write_text(registry)
    (ROOT / 'initial-profile.xcu').write_text(registry)
    run('native-export', [OFFICE, '-env:UserInstallation=' + profile.as_uri(), '--headless', '--norestore', '--nodefault',
                           '--convert-to', 'docx:Office Open XML Text', '--outdir', native, ROOT / 'parser.docx'], [ROOT / 'parser.docx'])
    for path, name in [(ROOT / 'parser.docx', 'parser-pandoc'), (native / 'parser.docx', 'native-pandoc')]:
        run(name, ['/usr/bin/pandoc', '+RTS', '-N1', '-M256m', '-K32m', '-RTS', '--from=docx', '--to=json', str(path)], [path])
    observations = {p: opc(ROOT / p) for p in ['authored.docx', 'baseline-parser.docx', 'baseline-native.docx', 'parser.docx', 'native/parser.docx']}
    (ROOT / 'opc-observations.json').write_text(json.dumps(observations, ensure_ascii=False, indent=2) + '\n')
    if source_receipt != {p: sha((REPO / p).read_bytes()) for p in sources}:
        raise RuntimeError('runtime source changed during probe')
    print(json.dumps({'completed': True, 'files': len(list(ROOT.rglob('*'))), 'nativeOutput': sha((native / 'parser.docx').read_bytes()),
                      'fieldCounts': {p: sum(len(v['instructions']) for v in view.values()) for p, view in observations.items()},
                      'linkCounts': {p: sum(len(v['links']) for v in view.values()) for p, view in observations.items()}}, indent=2))


if __name__ == '__main__':
    main()
