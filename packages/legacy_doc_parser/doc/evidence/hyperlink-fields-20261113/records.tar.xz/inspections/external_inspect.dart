// SPDX-License-Identifier: MPL-2.0
import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';

void main(List<String> args) {
  final bytes = File(args.single).readAsBytesSync();
  final document = parseLegacyWordDocument(bytes);
  stdout.writeln(const JsonEncoder.withIndent('  ').convert({
    'source': args.single,
    'sourceSize': bytes.length,
    'sourceSha256': sha256.convert(bytes).toString(),
    'fields': [for (final f in document.fields) {
      'id': f.id, 'story': f.storyId, 'type': f.type,
      'startCp': f.startCp, 'separatorCp': f.separatorCp, 'endCp': f.endCp,
      'instruction': f.instruction, 'storedResult': f.storedResult,
      'locked': f.locked, 'dirty': f.dirty, 'privateResult': f.privateResult,
      'parentId': f.parentId,
    }],
    'binaryData': [for (final a in document.media.artifacts)
      if (a.kind == LegacyWordArtifactKind.binaryData) {
        'id': a.id, 'stream': a.source.streamPath, 'offset': a.source.offset,
        'length': a.source.length, 'structure': a.source.structure,
        'cp': a.source.cp, 'sha256': sha256.convert(a.bytes).toString(),
        'hex': a.bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join(),
      }],
    'sourceAfterSha256': sha256.convert(bytes).toString(),
  }));
}
