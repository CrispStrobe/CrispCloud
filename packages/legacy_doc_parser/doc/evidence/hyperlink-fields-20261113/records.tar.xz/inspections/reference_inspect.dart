import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';
import 'package:crypto/crypto.dart';

void main(List<String> args) {
  final bytes = File(args.single).readAsBytesSync();
  final document = parseLegacyWordDocument(bytes);
  final cfb = BoundedCfbReader(bytes);
  final word = cfb.readPath('WordDocument')!;
  final w = ByteData.sublistView(word);
  final table = cfb.readPath(w.getUint16(10, Endian.little) & 0x200 != 0 ? '1Table' : '0Table')!;
  final t = ByteData.sublistView(table);
  final cslwAt = 34 + 2 * w.getUint16(32, Endian.little);
  final pairsAt = cslwAt + 2 + 4 * w.getUint16(cslwAt, Endian.little) + 2;
  final binOffset = w.getUint32(pairsAt + 12 * 8, Endian.little);
  final binLength = w.getUint32(pairsAt + 12 * 8 + 4, Endian.little);
  final binCount = (binLength - 4) ~/ 8;
  final raw = <Map<String, Object?>>[];
  final pages = <int>{};
  for (var i = 0; i < binCount; i++) {
    final page = t.getUint32(binOffset + (binCount + 1) * 4 + i * 4, Endian.little) & 0x3fffff;
    if (!pages.add(page)) continue;
    final at = page * 512;
    final count = word[at + 511];
    for (var j = 0; j < count; j++) {
      final offset = 2 * word[at + (count + 1) * 4 + j];
      final data = offset == 0 ? Uint8List(0) : word.sublist(at + offset + 1, at + offset + 1 + word[at + offset]);
      raw.add({'startFc': w.getUint32(at + j * 4, Endian.little), 'endFc': w.getUint32(at + (j + 1) * 4, Endian.little), 'chpxHex': data.map((v) => v.toRadixString(16).padLeft(2, '0')).join()});
    }
  }
  stdout.writeln(jsonEncode({
    'sourceSha256': sha256.convert(bytes).toString(),
    'plainText': document.plainText,
    'fields': document.fields.map((f) => {'id':f.id,'story':f.storyId,'startCp':f.startCp,'separatorCp':f.separatorCp,'endCp':f.endCp,'instruction':f.instruction,'instructionCodeUnits':f.instruction.codeUnits,'type':f.type,'storedResult':f.storedResult,'locked':f.locked}).toList(),
    'artifacts': document.media.artifacts.map((a) => {'id':a.id,'kind':a.kind.name,'cp':a.source.cp,'offset':a.source.offset,'length':a.source.length,'stream':a.source.streamPath,'structure':a.source.structure,'sha256':sha256.convert(a.bytes).toString(),'base64':base64Encode(a.bytes)}).toList(),
    'literalChpx':raw,
  }));
}
