#!/usr/bin/env python3
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

BASE = Path('/workspace/scratch/c1ca2a1344e9')
REPO = BASE / 'parser-hyperlink-probes'
ROOT = BASE / 'hyperlink-validation-20261113/javascript-owner-bound'
DART = BASE / 'toolchains/dart-3.13.7/dart-sdk/bin/dart'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    ROOT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, ROOT / 'run_owner_field_js.py')
    cases = []
    for name, file in [('external', 'external-hyperlinks-native.doc'), ('reference', 'reference-hyperlink-native.doc')]:
        data = (REPO / 'test/fixtures/word_native' / file).read_bytes()
        cases.append({'name': name, 'base64': base64.b64encode(data).decode()})
    encoded = base64.b64encode(json.dumps(cases).encode()).decode()
    (ROOT / 'acceptance.dart').write_text("import 'dart:convert';\nimport '" + (REPO / 'tool/field_metadata_web_acceptance.dart').as_uri() + "';\nvoid main() { print(jsonEncode(verifyFieldMetadataWebAcceptance(jsonDecode(utf8.decode(base64Decode('" + encoded + "'))) as List))); }\n")
    state = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
             'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip(),
             'trackedDiff': subprocess.check_output(['git', 'diff', 'HEAD', '--', 'lib', 'tool', 'test', 'pubspec.yaml', 'pubspec.lock'], cwd=REPO, text=True),
             'helperSha256': sha((REPO / 'tool/field_metadata_web_acceptance.dart').read_bytes()),
             'compilerSha256': sha(DART.read_bytes())}
    if state['trackedDiff']:
        raise RuntimeError('Frozen runtime changed')
    (ROOT / 'checkout.json').write_text(json.dumps(state, indent=2) + '\n')
    node = shutil.which('node')
    commands = {
        'dart-version': [str(DART), '--version'], 'node-version': [node, '--version'],
        'compile': [str(DART), 'compile', 'js', '--packages=' + str(REPO / '.dart_tool/package_config.json'),
                    '-O1', '-o', str(ROOT / 'acceptance.js'), str(ROOT / 'acceptance.dart')],
        'node': [node, '-e', 'globalThis.self=globalThis; require(process.argv[1]);', str(ROOT / 'acceptance.js')],
    }
    env = {**os.environ, 'TMPDIR': str(BASE / 'tmp'), 'PUB_CACHE': str(BASE / 'toolchains/pub-cache'), 'DART_SUPPRESS_ANALYTICS': 'true'}
    for name, argv in commands.items():
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        result = subprocess.run(argv, cwd=REPO, env=env, capture_output=True, timeout=180 if name == 'compile' else 60)
        (ROOT / (name + '.stdout')).write_bytes(result.stdout)
        (ROOT / (name + '.stderr')).write_bytes(result.stderr)
        receipt = {'argv': argv, 'cwd': str(REPO), 'started': started,
                   'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exitCode': result.returncode,
                   'stdoutSha256': sha(result.stdout), 'stderrSha256': sha(result.stderr)}
        (ROOT / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError(name + ': ' + result.stderr.decode(errors='replace'))
    outputs = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
               for p in sorted(ROOT.glob('acceptance.js*'))]
    (ROOT / 'generated-outputs.json').write_text(json.dumps(outputs, indent=2) + '\n')
    print((ROOT / 'node.stdout').read_text())


if __name__ == '__main__':
    main()
