Authored table border cases[^1]

  -----------------------------------------------------------------------
  Unbordered body table

  Inherited table borders

  Explicitly hidden borders
  -----------------------------------------------------------------------

[^1]: Note table follows

    Unbordered note table
