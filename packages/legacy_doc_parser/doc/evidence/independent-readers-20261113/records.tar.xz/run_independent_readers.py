#!/usr/bin/env python3
"""Probe independent readers against unchanged retained c5ff75e7 source bytes."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
EVIDENCE = WORKSPACE / 'legacy-doc-parser/doc/evidence/native-corpus-c5ff75e7'
ANTIWORD = ROOT / 'antiword-src/antiword'
CASES = ['word', 'table-borders', 'note-markers', 'bookmarks',
         'poi-simple-table2', 'header-textbox-alias']
sha = lambda data: hashlib.sha256(data).hexdigest()


def bounded():
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))


def run(name, command, inputs, stdout=None):
    destination = ROOT / 'outputs' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    before = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in inputs}
    env = os.environ.copy()
    env.update(TMPDIR=str(WORKSPACE / 'tmp'), LC_ALL='C.UTF-8',
               ANTIWORDHOME=str(ROOT / 'antiword-src/Resources'))
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True,
                            timeout=30, preexec_fn=bounded)
    outpath = stdout or destination.with_suffix(destination.suffix + '.stdout.log')
    outpath.write_bytes(result.stdout)
    errpath = destination.with_suffix(destination.suffix + '.stderr.log')
    errpath.write_bytes(result.stderr)
    after = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in inputs}
    record = {'command': command, 'cwd': str(ROOT), 'started': started,
              'finished': datetime.now(timezone.utc).isoformat(), 'exitCode': result.returncode,
              'environment': {k: env[k] for k in ['TMPDIR', 'LC_ALL', 'ANTIWORDHOME']},
              'limits': {'addressSpaceBytes': 512 * 1024 * 1024, 'cpuSeconds': 20, 'wallSeconds': 30},
              'inputsBefore': before, 'inputsAfter': after, 'inputsUnchanged': before == after,
              'stdout': {'path': str(outpath.relative_to(ROOT)), 'bytes': len(result.stdout), 'sha256': sha(result.stdout)},
              'stderr': {'path': str(errpath.relative_to(ROOT)), 'bytes': len(result.stderr), 'sha256': sha(result.stderr)}}
    destination.with_suffix(destination.suffix + '.command.json').write_text(json.dumps(record, indent=2) + '\n')
    if before != after:
        raise RuntimeError('Input was modified')
    return result


def ast_summary(node):
    counts, strings = Counter(), []
    def walk(value):
        if isinstance(value, dict):
            if 't' in value:
                counts[value['t']] += 1
                if value['t'] == 'Str':
                    strings.append(value['c'])
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    walk(node.get('blocks', []))
    return {'nodes': dict(sorted(counts.items())), 'strings': strings,
            'text': ' '.join(strings)}


def main():
    manifest = json.loads((EVIDENCE / 'sealed/native-artifacts.manifest.json').read_bytes())
    if manifest['sourceCommit'] != 'c5ff75e76163d9abbdd44a9f2a7c5ad210929289':
        raise RuntimeError('Wrong measured parser source')
    archive = EVIDENCE / 'sealed/native-artifacts.tar.xz'
    if sha(archive.read_bytes()) != manifest['archive']['sha256']:
        raise RuntimeError('Retained source archive differs')
    expected = {item['path']: item for item in manifest['files']}
    selected, receipts, cases = {}, [], {}
    for case in CASES:
        binary = f'inputs/{case}.doc'
        if binary not in expected:
            binary = f'run/{case}/bridge/{case}.doc'
        files = {'source.doc': binary,
                 'parser.docx': f'run/{case}/converted.docx',
                 'libreoffice.docx': f'run/{case}/native-docx/' + ('source.docx' if binary.startswith('inputs/') else case + '.docx')}
        if f'inputs/{case}.docx' in expected:
            files['authored.docx'] = f'inputs/{case}.docx'
        cases[case] = files
        for local, member in files.items():
            selected[member] = ROOT / 'inputs' / case / local
    with tarfile.open(archive, 'r:xz') as source:
        for member in source:
            if member.name not in selected:
                continue
            data = source.extractfile(member).read()
            item = expected[member.name]
            if len(data) != item['bytes'] or sha(data) != item['sha256']:
                raise RuntimeError('Source member differs: ' + member.name)
            target = selected[member.name]
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                raise RuntimeError('Probe input already exists')
            target.write_bytes(data)
            receipts.append({'path': str(target.relative_to(ROOT)), 'archiveMember': member.name,
                             'bytes': len(data), 'sha256': sha(data)})
    source_receipt = {'parserCommit': manifest['sourceCommit'], 'archiveSha256': manifest['archive']['sha256'],
                      'archiveBytes': manifest['archive']['bytes'], 'evidencePath': str(EVIDENCE),
                      'files': sorted(receipts, key=lambda x: x['path'])}
    (ROOT / 'probe-inputs.json').write_text(json.dumps(source_receipt, indent=2) + '\n')
    summary = {}
    for case in CASES:
        folder = ROOT / 'inputs' / case
        output = ROOT / 'outputs' / case
        output.mkdir(parents=True, exist_ok=True)
        doc = folder / 'source.doc'
        result = {}
        for mode, options, suffix in [('text', ['-t', '-w', '0'], 'txt'), ('docbook', ['-x', 'db'], 'xml')]:
            destination = output / ('antiword.' + suffix)
            process = run(case + '/antiword-' + mode, [str(ANTIWORD), '-m', 'UTF-8.txt', *options, str(doc)], [doc], destination)
            entry = {'exitCode': process.returncode, 'bytes': len(process.stdout), 'sha256': sha(process.stdout),
                     'text': process.stdout.decode('utf-8', errors='replace'),
                     'stderr': process.stderr.decode('utf-8', errors='replace')}
            if mode == 'docbook' and process.returncode == 0:
                try:
                    tree = ET.fromstring(process.stdout)
                    entry['xmlElements'] = dict(sorted(Counter(n.tag for n in tree.iter()).items()))
                    entry['xmlText'] = ' '.join(tree.itertext())
                except ET.ParseError as error:
                    entry['xmlParseError'] = str(error)
            result['antiword-' + mode] = entry
        for local in sorted(cases[case]):
            if not local.endswith('.docx'):
                continue
            source = folder / local
            tag = Path(local).stem
            ast_path = output / (tag + '.pandoc.json')
            process = run(case + '/' + tag + '-pandoc-json', ['/usr/bin/pandoc', '--from=docx', '--to=json', str(source)], [source], ast_path)
            entry = {'exitCode': process.returncode, 'stderr': process.stderr.decode('utf-8', errors='replace')}
            if process.returncode == 0:
                entry.update(ast_summary(json.loads(process.stdout)))
            result[tag + '-pandoc'] = entry
            run(case + '/' + tag + '-pandoc-markdown', ['/usr/bin/pandoc', '--from=docx', '--to=markdown', '--wrap=none', str(source)], [source], output / (tag + '.pandoc.md'))
        summary[case] = result
    (ROOT / 'probe-results.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({case: {tool: {'exitCode': data['exitCode'],
                                   'nodes': data.get('nodes'), 'xmlElements': data.get('xmlElements'),
                                   'stderr': data['stderr']} for tool, data in tools.items()}
                      for case, tools in summary.items()}, indent=2))


if __name__ == '__main__':
    main()
