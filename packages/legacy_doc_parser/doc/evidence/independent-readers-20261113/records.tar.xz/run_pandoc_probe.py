#!/usr/bin/env python3
"""Retry the retained inputs using GHC heap limits instead of RLIMIT_AS."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
from xml.etree import ElementTree as ET
import zipfile

from run_independent_readers import ast_summary

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'outputs-pandoc'
PANDOC = '/usr/bin/pandoc'
RTS = ['+RTS', '-N1', '-M256m', '-K32m', '-RTS']
sha = lambda data: hashlib.sha256(data).hexdigest()


def cpu_limit():
    resource.setrlimit(resource.RLIMIT_CPU, (20, 20))


def run(source, output, format):
    output.parent.mkdir(parents=True, exist_ok=True)
    command = [PANDOC, *RTS, '--from=docx', '--to=' + format, '--wrap=none', str(source)]
    before = sha(source.read_bytes())
    env = os.environ.copy()
    env.update(TMPDIR=str(ROOT.parent / 'tmp'), LC_ALL='C.UTF-8')
    started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run(command, env=env, cwd=ROOT, capture_output=True,
                             preexec_fn=cpu_limit, timeout=30)
    output.write_bytes(process.stdout)
    output.with_suffix(output.suffix + '.stderr.log').write_bytes(process.stderr)
    receipt = {'command': command, 'cwd': str(ROOT), 'started': started,
               'finished': datetime.now(timezone.utc).isoformat(), 'exitCode': process.returncode,
               'input': str(source.relative_to(ROOT)), 'inputBeforeSha256': before,
               'inputAfterSha256': sha(source.read_bytes()),
               'limits': {'ghcMaxHeap': '256m', 'ghcMaxStack': '32m', 'ghcCapabilities': 1,
                          'cpuSeconds': 20, 'wallSeconds': 30, 'addressSpaceLimit': None},
               'output': str(output.relative_to(ROOT)), 'outputBytes': len(process.stdout),
               'outputSha256': sha(process.stdout), 'stderrSha256': sha(process.stderr)}
    output.with_suffix(output.suffix + '.command.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if before != receipt['inputAfterSha256']:
        raise RuntimeError('Input changed')
    if process.returncode:
        raise RuntimeError(process.stderr.decode(errors='replace'))
    return process.stdout


def stories(data):
    result = {}
    with zipfile.ZipFile(__import__('io').BytesIO(data)) as archive:
        for name in archive.namelist():
            if name.startswith('word/') and name.endswith('.xml') and any(
                    name.startswith('word/' + stem) for stem in ['document', 'header', 'footer', 'footnotes', 'endnotes']):
                root = ET.fromstring(archive.read(name))
                ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
                result[name] = {'text': ' '.join(n.text or '' for n in root.findall('.//w:t', ns)),
                                'tables': len(root.findall('.//w:tbl', ns)),
                                'footnoteReferences': len(root.findall('.//w:footnoteReference', ns)),
                                'endnoteReferences': len(root.findall('.//w:endnoteReference', ns))}
    return result


def main():
    OUT.mkdir(exist_ok=False)
    results = {}
    for source in sorted((ROOT / 'inputs').rglob('*.docx')):
        name = source.relative_to(ROOT / 'inputs').with_suffix('').as_posix()
        ast_raw = run(source, OUT / (name + '.json'), 'json')
        run(source, OUT / (name + '.md'), 'markdown')
        results[name] = {'ast': ast_summary(json.loads(ast_raw)), 'sourceStories': stories(source.read_bytes())}
    roundtrips = {}
    for name in ['word/authored', 'note-markers/authored']:
        source = ROOT / 'inputs' / (name + '.docx')
        target = OUT / (name + '.roundtrip.docx')
        run(source, target, 'docx')
        roundtrip = json.loads(run(target, OUT / (name + '.roundtrip.json'), 'json'))
        source_ast = json.loads((OUT / (name + '.json')).read_bytes())
        roundtrips[name] = {'before': results[name], 'after': {'ast': ast_summary(roundtrip),
                             'stories': stories(target.read_bytes())},
                           'exactAstEqual': source_ast == roundtrip}
    (ROOT / 'pandoc-results.json').write_text(json.dumps(results, indent=2, ensure_ascii=False) + '\n')
    (ROOT / 'pandoc-roundtrips.json').write_text(json.dumps(roundtrips, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'successfulDocxInputs': len(results),
                      'nodes': {name: result['ast']['nodes'] for name, result in results.items()},
                      'roundtripAstEqual': {name: value['exactAstEqual'] for name, value in roundtrips.items()}}, indent=2))


if __name__ == '__main__':
    main()
