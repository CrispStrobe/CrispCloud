import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';

void main(List<String> args) {
  final bytes=File(args.single).readAsBytesSync();
  final cfb=BoundedCfbReader(bytes),word=ByteData.sublistView(cfb.readPath('WordDocument')!);
  final tableName=word.getUint16(10,Endian.little)&0x200 == 0?'0Table':'1Table';
  final table=cfb.readPath(tableName)!,data=ByteData.sublistView(table);
  final cslw=34+word.getUint16(32,Endian.little)*2;
  final pairs=cslw+2+word.getUint16(cslw,Endian.little)*4+2;
  final start=word.getUint32(pairs+15*8,Endian.little),length=word.getUint32(pairs+15*8+4,Endian.little);
  var position=start;if(data.getUint16(position,Endian.little)==0xffff)position+=2;
  final count=data.getUint16(position,Endian.little),extra=data.getUint16(position+2,Endian.little);position+=4;
  final fonts=<Map<String,Object?>>[];
  for(var i=0;i<count;i++) {
    final size=table[position]+1;
    final names=<String>[];final current=<int>[];
    for(var p=position+40;p<position+size;p+=2) {
      final unit=data.getUint16(p,Endian.little);
      if(unit==0){names.add(String.fromCharCodes(current));current.clear();}else{current.add(unit);}
    }
    fonts.add({'index':i,'tableOffset':position,'recordSize':size,'flags':table[position+1],
      'weight':data.getUint16(position+2,Endian.little),'charset':table[position+4],'alternateNameOffset':table[position+5],
      'names':names,'panose':table.sublist(position+6,position+16),'signature':table.sublist(position+16,position+40)});
    position+=size+extra;
  }
  if(position!=start+length)throw FormatException('Unexpected font table extent');
  stdout.writeln(jsonEncode({'sourceSha256':sha256.convert(bytes).toString(),'table':tableName,'offset':start,'length':length,'fonts':fonts}));
}
