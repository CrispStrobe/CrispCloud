#!/usr/bin/env python3
"""Bounded native measurement of the retained authored symbol control."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

REPOSITORY = Path(sys.argv[1]).resolve()
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPOSITORY / 'tool/fidelity'))
from run import command, digest, office_convert, render, tool_receipt
from goldens import compare_render
from oracle import snapshot

OUT = BASE / 'symbol-native-measurements'
OUT.mkdir(exist_ok=False)
OFFICE = '/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
REPORT = {'scope': 'One independently authored CSymbol DOC control; native DOC render is the reference. Original native export and authored patch remain distinct.',
          'status': 'running', 'sourceSha256': digest(BASE/'csymbol.doc'),
          'beforeConverterSha256': digest(BASE/'convert-before'),
          'afterConverterSha256': digest(BASE/'symbol-after-convert'),
          'tools': {'office': tool_receipt(OFFICE), **{name: tool_receipt(name, ('-v',)) for name in ('pdfinfo','pdftoppm','pdftotext')}},
          'imports': [], 'renders': {}, 'cycles': []}


def write():
    (OUT/'report.json').write_text(json.dumps(REPORT, indent=2, ensure_ascii=False)+'\n')


def convert(label, executable, source):
    output = OUT/(label+'.docx')
    argv = [str(executable),str(source),str(output)]
    r = subprocess.run(argv, cwd=REPOSITORY, capture_output=True, text=True, timeout=45)
    REPORT['imports'].append({'label':label,'argv':argv,'cwd':str(REPOSITORY),
        'sourceSha256':digest(source),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    write()
    if r.returncode: raise RuntimeError(r.stderr)
    (OUT/(label+'-snapshot.json')).write_text(json.dumps(snapshot(output),indent=2,ensure_ascii=False)+'\n')
    return output


def measure(label, source):
    facts = render(OFFICE,source,OUT/label,72,raster_storage='gzip')
    REPORT['renders'][label] = {'inputSha256':digest(source),**facts}
    write()
    return facts


try:
    fonts=command(['fc-list','--format','%{family}|%{style}|%{file}\n'])
    (OUT/'fonts.txt').write_text(fonts)
    (OUT/'font-files.json').write_text(json.dumps({path:digest(Path(path)) for path in sorted({line.rsplit('|',1)[1] for line in fonts.splitlines()})},indent=2)+'\n')
    REPORT['fontInventorySha256']=digest(OUT/'fonts.txt')
    REPORT['fontFilesSha256']=digest(OUT/'font-files.json')
    write()
    reference=measure('source',BASE/'csymbol.doc')
    before=convert('before',BASE/'convert-before',BASE/'csymbol.doc')
    after=convert('after',BASE/'symbol-after-convert',BASE/'csymbol.doc')
    before_render=measure('before-render',before)
    after_render=measure('after-render',after)
    REPORT['beforeAgainstSource']=compare_render(reference,before_render)
    REPORT['afterAgainstSource']=compare_render(reference,after_render)
    write()
    print(json.dumps({'before':REPORT['beforeAgainstSource'],'after':REPORT['afterAgainstSource']}),flush=True)
    previous=after
    for cycle in (1,2):
        binary=office_convert(OFFICE,previous,OUT/f'cycle-{cycle}-binary','doc')
        native=office_convert(OFFICE,binary,OUT/f'cycle-{cycle}-native','docx')
        (OUT/f'cycle-{cycle}-native-snapshot.json').write_text(json.dumps(snapshot(native),indent=2,ensure_ascii=False)+'\n')
        current=convert(f'cycle-{cycle}-converted',BASE/'symbol-after-convert',binary)
        binary_render=measure(f'cycle-{cycle}-binary-render',binary)
        current_render=measure(f'cycle-{cycle}-converted-render',current)
        REPORT['cycles'].append({'cycle':cycle,'binarySha256':digest(binary),'nativeDocxSha256':digest(native),
            'convertedSha256':digest(current),'againstOwnBinary':compare_render(binary_render,current_render),
            'againstInitialSource':compare_render(reference,current_render)})
        write(); previous=current
        print('Completed symbol cycle '+str(cycle),flush=True)
    REPORT['status']='complete';write()
except Exception as error:
    REPORT['status']='error';REPORT['error']=str(error);write();raise
