import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';
import 'package:legacy_doc_parser/src/compound/cfbf_writer.dart';

void require(bool value, String message) {
  if (!value) throw FormatException(message);
}

void main(List<String> args) {
  require(args.length == 3, 'input.doc new.doc symbol|nonspecial|ordinary');
  final input = File(args[0]), output = File(args[1]), mode = args[2];
  require(!output.existsSync(), 'Output already exists');
  require({'symbol','nonspecial','ordinary','implicit','cleared'}.contains(mode), 'Unknown control');
  final bytes = input.readAsBytesSync();
  require(sha256.convert(bytes).toString() == 'c16d1e2f9ac6c7d53a762526553a36feea466231068709f9bb00ea0c129fcdc1', 'Unexpected native parent');
  final source = BoundedCfbReader(bytes), oldWord = source.readPath('WordDocument')!;
  final word = Uint8List.fromList(oldWord), data = ByteData.sublistView(word);
  final tableName = data.getUint16(10, Endian.little) & 0x200 == 0 ? '0Table' : '1Table';
  final table = ByteData.sublistView(source.readPath(tableName)!);
  final cslwAt = 34 + 2 * data.getUint16(32, Endian.little);
  final pairsAt = cslwAt + 2 + 4 * data.getUint16(cslwAt, Endian.little) + 2;
  final binAt = data.getUint32(pairsAt + 12*8, Endian.little), binLength = data.getUint32(pairsAt + 12*8 + 4, Endian.little);
  require(binLength == 12, 'Expected one CHPX bin');
  final pageAt = (table.getUint32(binAt + 8, Endian.little) & 0x3fffff) * 512;
  final count = word[pageAt + 511];
  require(count == 7, 'Unexpected CHPX run count');
  final boundaries = [for(var i=0; i<=count; i++)data.getUint32(pageAt+i*4,Endian.little)];
  require(boundaries[1] == 2068 && boundaries[2] == 2070 && data.getUint16(2068,Endian.little) == 0xf061, 'Unexpected target literal');
  final groups = <List<int>>[];
  for(var i=0;i<count;i++) {
    final offset = 2*word[pageAt+(count+1)*4+i];
    groups.add(offset==0 ? [] : word.sublist(pageAt+offset+1,pageAt+offset+1+word[pageAt+offset]));
  }
  final oldGroup = List<int>.from(groups[1]);
  require(oldGroup.map((v)=>v.toRadixString(16).padLeft(2,'0')).join() == '504a04005e4a04004f4a0100514a0100', 'Unexpected original run properties');
  // MS-DOC: U+0028 is a symbol only with CFSpec; CSymbolOperand is
  // uint16 font-table index then uint16 font-specific character code.
  const symbol = [0x09,0x6a,1,0,0x61,0xf0];
  groups[1] = switch(mode) {
    'ordinary' => [],
    'implicit' => symbol,
    'cleared' => [...symbol,0x55,0x08,0],
    _ => [0x55,0x08,mode=='symbol'?1:0,...symbol],
  };
  final page = Uint8List(512), pageData = ByteData.sublistView(page);
  for(var i=0;i<=count;i++)pageData.setUint32(i*4,boundaries[i],Endian.little);
  final headerEnd = (count+1)*4+count;
  var cursor=510;
  for(var i=0;i<count;i++) {
    if(groups[i].isEmpty) continue;
    cursor=(cursor-groups[i].length-1)&~1;
    require(cursor>=headerEnd,'CHPX control does not fit');
    page[(count+1)*4+i]=cursor~/2;
    page[cursor]=groups[i].length;
    page.setRange(cursor+1,cursor+1+groups[i].length,groups[i]);
  }
  page[511]=count;
  word.setRange(pageAt,pageAt+512,page);
  data.setUint16(2068,0x28,Endian.little);
  final root=source.root;
  final writer=CfbfWriter(clsid:root.clsid,stateBits:root.stateBits,createdFiletime:root.createdFiletime,modifiedFiletime:root.modifiedFiletime);
  final streamReceipts=<Map<String,Object?>>[];
  void copy(CfbfDirectoryEntry parent,String prefix) {
    for(final entry in source.childrenOf(parent)) {
      final name=prefix.isEmpty?entry.name:'$prefix/${entry.name}';
      if(entry.isStorage) {
        writer.addStorage(name,clsid:entry.clsid,stateBits:entry.stateBits,createdFiletime:entry.createdFiletime,modifiedFiletime:entry.modifiedFiletime);copy(entry,name);
      } else {
        final before=source.readEntry(entry),after=name=='WordDocument'?word:before;
        writer.addStream(name,after,clsid:entry.clsid,stateBits:entry.stateBits,createdFiletime:entry.createdFiletime,modifiedFiletime:entry.modifiedFiletime);
        streamReceipts.add({'path':name,'beforeSha256':sha256.convert(before).toString(),'afterSha256':sha256.convert(after).toString(),'bytes':before.length});
      }
    }
  }
  copy(root,'');final result=writer.build();output.writeAsBytesSync(result);
  stdout.writeln(jsonEncode({'control':mode,'origin':'Independent authored CSymbol/CFSpec control applied to retained native DOC export; not a Word-authored source.','inputSha256':sha256.convert(bytes).toString(),'outputSha256':sha256.convert(result).toString(),'literalFc':2068,'beforeCodeUnit':0xf061,'afterCodeUnit':0x28,'chpxPageOffset':pageAt,'sourceFcBoundaries':boundaries,'beforeProperties':oldGroup,'afterProperties':groups[1],'streams':streamReceipts}));
}
