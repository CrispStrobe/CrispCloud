#!/usr/bin/env python3
"""Independent DOCX control for the built-in Line Number character style."""
import io
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path('/workspace/scratch/c1ca2a1344e9/parser-layout-next')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tool/fidelity'))
import run

DART = '/workspace/scratch/c1ca2a1344e9/toolchains/dart-3.13.7/dart-sdk/bin/dart'


def source():
    parts = {
        '[Content_Types].xml': '''<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>''',
        '_rels/.rels': '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>''',
        'word/_rels/document.xml.rels': '''<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="styles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>''',
        'word/document.xml': '''<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>First numbered paragraph</w:t></w:r></w:p><w:p><w:r><w:t>Second numbered paragraph</w:t></w:r></w:p><w:p><w:r><w:t>Third numbered paragraph</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/><w:lnNumType w:countBy="1" w:start="0" w:distance="240" w:restart="newPage"/></w:sectPr></w:body></w:document>''',
        'word/styles.xml': '''<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="22"/></w:rPr></w:style><w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/></w:style><w:style w:type="character" w:styleId="LineNumber"><w:name w:val="line number"/><w:basedOn w:val="DefaultParagraphFont"/><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/><w:b/><w:color w:val="CC2233"/><w:sz w:val="28"/></w:rPr></w:style></w:styles>''',
    }
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, value in parts.items():
            z.writestr(name, value)
    return buffer.getvalue()


def main():
    out = HERE / 'line-style-control'
    out.mkdir(exist_ok=False)
    original = out / 'line-style.docx'
    original.write_bytes(source())
    office = shutil.which('soffice')
    binary = run.office_convert(office, original, out / 'binary', 'doc')
    converted = out / 'converted.docx'
    log = run.command([DART, 'tool/fidelity/convert.dart', binary, converted], cwd=ROOT)
    (out / 'conversion.json').write_text(log)
    run.office_convert(office, binary, out / 'native-docx', 'docx')
    results = {}
    for name, path in [('original', original), ('binary', binary), ('converted', converted)]:
        results[name] = run.render(office, path, out / (name + '-render'), 72, raster_storage='gzip')
        run.write_json(out / (name + '-render.json'), results[name])
    run.write_json(out / 'comparison.json', run.render_comparison(results['binary'], results['converted']))
    for name, result in results.items():
        print(name, json.dumps(result['pages']), flush=True)


if __name__ == '__main__':
    main()
