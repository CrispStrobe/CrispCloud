#!/usr/bin/env python3
"""Output-only diagnostics; never changes source DOC or runtime code."""
import copy
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile
import zipfile

from lxml import etree as ET

ROOT = Path('/workspace/scratch/c1ca2a1344e9/parser-layout-next')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tool/fidelity'))
import run

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
NS = {'w': W[1:-1]}


def change(source, kind):
    with zipfile.ZipFile(io.BytesIO(source)) as z:
        parts = {name: z.read(name) for name in z.namelist()}
    if kind == 'omit-enabled-width-balance':
        tree = ET.fromstring(parts['word/settings.xml'])
        for node in tree.findall('w:compat/w:balanceSingleByteDoubleByteWidth', NS):
            node.getparent().remove(node)
        parts['word/settings.xml'] = ET.tostring(tree, xml_declaration=True, encoding='UTF-8', standalone=True)
    else:
        styles = ET.fromstring(parts['word/styles.xml'])
        for story in ['footnote', 'endnote']:
            tree = ET.fromstring(parts[f'word/{story}s.xml'])
            for index, node in enumerate(tree.findall('.//w:' + story + 'Ref', NS)):
                props = node.getparent().find('w:rPr', NS)
                style_id = f'Legacy{story}Marker{index}'
                if kind == 'builtin-marker-style':
                    style_id = story.title() + 'Reference'
                style = ET.SubElement(styles, W + 'style', {W + 'type': 'character', W + 'styleId': style_id})
                ET.SubElement(style, W + 'name', {W + 'val': story + ' reference' if kind == 'builtin-marker-style' else style_id})
                style.append(copy.deepcopy(props))
                props.insert(0, ET.Element(W + 'rStyle', {W + 'val': style_id}))
            parts[f'word/{story}s.xml'] = ET.tostring(tree, xml_declaration=True, encoding='UTF-8', standalone=True)
        parts['word/styles.xml'] = ET.tostring(styles, xml_declaration=True, encoding='UTF-8', standalone=True)
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, content in parts.items():
            z.writestr(name, content)
    return out.getvalue()


def main():
    output = HERE / 'generated-label-results'
    output.mkdir(exist_ok=False)
    results = {'scope': 'Output-only probes, not runtime changes or acceptance.', 'cases': {}}
    for case, folder, variants in [
        ('word', '02-word', ['custom-marker-style', 'builtin-marker-style']),
        ('bookmarks', '08-bookmarks', ['omit-enabled-width-balance']),
    ]:
        archive = ROOT / 'doc/evidence/native-corpus-48bf3a/sealed' / folder / 'native-artifacts.tar.xz'
        with tarfile.open(archive) as t:
            source = t.extractfile(f'run/{case}/converted.docx').read()
            binary = json.load(t.extractfile(f'run/{case}/binary-render.json'))
            original = json.load(t.extractfile(f'run/{case}/converted-render.json'))
        results['cases'][case] = {'original': run.render_comparison(binary, original), 'probes': {}}
        for variant in variants:
            path = output / (case + '-' + variant + '.docx')
            path.write_bytes(change(source, variant))
            render = run.render(shutil.which('soffice'), path, output / path.stem, 72, raster_storage='gzip')
            run.write_json(output / (path.stem + '-render.json'), render)
            comparison = run.render_comparison(binary, render)
            results['cases'][case]['probes'][variant] = {
                'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'comparison': comparison,
                'words': [word for page in render['pages'] for word in page['words']],
            }
            run.write_json(output / 'summary.json', results)
            print(case, variant, json.dumps(comparison), flush=True)


if __name__ == '__main__':
    main()
