#!/usr/bin/env python3
"""Bounded committed-runtime Line Number style acceptance; no corpus edits."""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--dart', required=True)
    parser.add_argument('--office', required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sys.path.insert(0, str(root / 'tool/fidelity'))
    import run

    def saved_command(name, argv):
        result = subprocess.run([str(x) for x in argv], cwd=root, capture_output=True,
                                text=True, timeout=180)
        (output / (name + '.stdout.log')).write_text(result.stdout)
        (output / (name + '.stderr.log')).write_text(result.stderr)
        run.write_json(output / (name + '.command.json'), {
            'argv': [str(x) for x in argv], 'cwd': str(root), 'exitCode': result.returncode,
            'stdoutSha256': run.digest(output / (name + '.stdout.log')),
            'stderrSha256': run.digest(output / (name + '.stderr.log')),
        })
        if result.returncode:
            raise RuntimeError(name + ' failed: ' + result.stderr[-1000:])
        return result.stdout

    head = saved_command('git-head', ['git', 'rev-parse', 'HEAD']).strip()
    dirty = bool(saved_command('git-status', ['git', 'status', '--porcelain']).strip())
    if dirty:
        raise ValueError('Runtime acceptance requires a clean committed tree')
    report = {
        'schema': 'legacy-doc-parser/line-number-style-acceptance', 'version': 1,
        'status': 'running', 'parserCommit': head, 'parserWorktreeDirty': dirty,
        'runtimeTree': saved_command('git-tree', ['git', 'rev-parse', 'HEAD^{tree}']).strip(),
        'wrapperSha256': run.digest(Path(__file__)),
        'scope': 'One explicit source Line Number style; three successive native DOC imports. '
                 'Old word, word-compatibility, and bookmarks outputs are byte-compared to retained baseline.',
        'sourcesBefore': run.source_receipt(root), 'python': sys.version,
        'platform': platform.platform(), 'tools': {},
    }
    run.write_json(output / 'report.json', report)
    try:
        for name, executable, version_args in [
            ('dart', args.dart, ('--version',)), ('office', args.office, ('--version',)),
            ('pdftotext', 'pdftotext', ('-v',)), ('pdftoppm', 'pdftoppm', ('-v',)),
            ('pdfinfo', 'pdfinfo', ('-v',)),
        ]:
            report['tools'][name] = run.tool_receipt(executable, version_args)
        fonts = saved_command('fonts', ['fc-list', '--format', '%{family}|%{style}|%{file}\n'])
        report['fontInventorySha256'] = hashlib.sha256(
            '\n'.join(sorted(fonts.splitlines())).encode()).hexdigest()
        font_paths = {line.rsplit('|', 1)[-1] for line in fonts.splitlines()}
        font_files = {path: run.digest(Path(path)) for path in sorted(font_paths)}
        run.write_json(output / 'font-files.json', font_files)
        report['fontFilesSha256'] = hashlib.sha256(
            json.dumps(font_files, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        executable = output / 'convert'
        saved_command('compile', [args.dart, 'compile', 'exe', 'tool/fidelity/convert.dart', '-o', executable])
        report['executable'] = {'path': executable.name, 'sha256': run.digest(executable),
                                'sizeBytes': executable.stat().st_size}
        report['sourcesAfterCompilation'] = run.source_receipt(root)
        if report['sourcesBefore'] != report['sourcesAfterCompilation']:
            raise ValueError('Compilation inputs changed')
        case = {
            'id': 'line-number-style', 'path': 'test/fixtures/word_native/line-number-style.doc',
            'sha256': run.digest(root / 'test/fixtures/word_native/line-number-style.doc'),
            'features': ['explicit-Line-Number-character-style', 'generated-labels'],
        }
        run.write_json(output / 'case.json', case)
        options = argparse.Namespace(office=Path(args.office).resolve(), dpi=72,
                                     raster_storage='gzip', no_roundtrip=False, roundtrip_cycles=3)
        result = run.measure_case(case, options, executable, output / case['id'])
        report['case'] = result
        if run.case_has_errors(result):
            raise ValueError('Native measurement has incomplete or failed stages')
        source_docx = root / 'test/fixtures/fidelity/line-number-style.docx'
        original = run.render(options.office, source_docx, output / 'original-render', 72,
                              raster_storage='gzip')
        run.write_json(output / 'original-render.json', original)
        binary = json.loads((output / case['id'] / 'binary-render.json').read_text())
        report['originalDocxSha256'] = run.digest(source_docx)
        report['originalToRetainedBinary'] = run.render_comparison(original, binary)
        report['renderExact'] = report['originalToRetainedBinary']['exactOnThisRenderer'] and all(
            comparison['exactOnThisRenderer'] for comparison in [result['pagination'],
                result['nativeConversionPagination'], *(cycle[key] for cycle in result['roundtripCycles']
                for key in ('paginationFromBinaryDoc', 'paginationFromPreviousImport', 'paginationFromFirstImport'))])
        if not report['renderExact']:
            raise ValueError('The committed explicit style does not preserve exact native rendering')
        # Directly reuse the same binary sources and output bytes from the sealed
        # earlier corpus; no new bridge, source patch, or golden replacement.
        old = []
        for name, directory in [('word', '02-word'), ('word-compatibility', '03-word-compatibility'),
                                 ('bookmarks', '08-bookmarks')]:
            archive_path = root / 'doc/evidence/native-corpus-48bf3a/sealed' / directory / 'native-artifacts.tar.xz'
            target = output / 'unchanged' / name
            target.mkdir(parents=True)
            with tarfile.open(archive_path) as archive:
                members = archive.getmembers()
                source_members = [m for m in members if m.isfile() and m.name.endswith('/bridge/' + name + '.doc')]
                converted_members = [m for m in members if m.isfile() and m.name.endswith('/' + name + '/converted.docx')]
                if len(source_members) != 1 or len(converted_members) != 1:
                    raise ValueError('Ambiguous retained case paths: ' + name)
                source_bytes = archive.extractfile(source_members[0]).read()
                converted_bytes = archive.extractfile(converted_members[0]).read()
            source = target / 'source.doc'
            baseline = target / 'baseline.docx'
            current = target / 'current.docx'
            source.write_bytes(source_bytes)
            baseline.write_bytes(converted_bytes)
            metadata = run.parser_convert(executable, source, current)
            run.write_json(target / 'conversion.json', metadata)
            item = {'case': name, 'archiveSha256': run.digest(archive_path),
                    'sourceArchiveMember': source_members[0].name,
                    'baselineArchiveMember': converted_members[0].name,
                    'sourceSha256': run.digest(source), 'baselineSha256': run.digest(baseline),
                    'currentSha256': run.digest(current), 'unchanged': baseline.read_bytes() == current.read_bytes()}
            old.append(item)
            report['unchangedCases'] = old
            run.write_json(output / 'report.json', report)
            if not item['unchanged'] or run.digest(source) != hashlib.sha256(source_bytes).hexdigest():
                raise ValueError('An old case changed unexpectedly: ' + name)
        saved_command('focused-tests', [args.dart, 'test', 'test/legacy_word_line_number_style_test.dart',
                      'test/legacy_word_native_section_direction_test.dart',
                      'test/legacy_word_script_fonts_test.dart', '--reporter=expanded'])
        report['sourcesAfter'] = run.source_receipt(root)
        if report['sourcesBefore'] != report['sourcesAfter']:
            raise ValueError('Build or measurement input changed')
        report['status'] = 'passed'
    except Exception as error:
        report.update(status='error', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        run.write_json(output / 'report.json', report)
    print(json.dumps({'status': report['status'], 'runtime': head, 'renderExact': report['renderExact'],
                      'unchangedCases': [case['case'] for case in report['unchangedCases']]}), flush=True)


if __name__ == '__main__':
    main()
