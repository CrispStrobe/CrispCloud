#!/usr/bin/env python3
"""Package the exact completed Line Number runtime and diagnostic records."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/c1ca2a1344e9/parser-layout-next')
PROBES = Path(__file__).resolve().parent
OUT = ROOT / 'doc/evidence/line-number-style-20261113'
COMMIT = 'a1784cde69397e70fa6e8d6dd4dfe9c96e03f08a'
TREE = 'f19662675e270f377d6356138ca064a71ab91283'
files, omitted = {}, []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(path, data):
    return {'path': path, 'size': len(data), 'sha256': sha(data)}


def collect(directory, prefix):
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(directory)
        if set(relative.parts) & {'profile', 'dotnet-home', '__pycache__'}:
            continue
        name = prefix + '/' + relative.as_posix()
        data = path.read_bytes()
        if name == 'native/convert' or (prefix == 'schema' and relative.parts[0] == 'validator' and path.suffix == '.dll'):
            omitted.append(record(name, data))
        else:
            files[name] = data


collect(PROBES / 'runtime-acceptance-a1784cde', 'native')
collect(PROBES / 'schema-a1784cde', 'schema')
collect(PROBES / 'line-style-control', 'diagnostic/line-style-control')
collect(PROBES / 'generated-label-results', 'diagnostic/generated-label-results')
for name in ['runtime_acceptance.py', 'line_style_control.py', 'probe_generated_labels.py', 'seal.py']:
    files['probes/' + name] = (PROBES / name).read_bytes()
native = json.loads(files['native/report.json'])
schema = json.loads(files['schema/report.json'])
sources = dict(native['sourcesBefore']['files'])
for name, digest in schema['source']['files'].items():
    if name in sources and sources[name] != digest:
        raise ValueError('Cross-gate source mismatch: ' + name)
    sources[name] = digest
for name, digest in sorted(sources.items()):
    data = (ROOT / name).read_bytes()
    if sha(data) != digest:
        raise ValueError('Source changed: ' + name)
    files['source/' + name] = data
for path in ['test/fixtures/fidelity/line-number-style.docx',
             'test/fixtures/word_native/line-number-style.provenance.json']:
    files['control-source/' + Path(path).name] = (ROOT / path).read_bytes()
for kind, oid in [('commit', COMMIT), ('tree', TREE)]:
    files['source-identity/git-' + kind + '.raw'] = subprocess.check_output(
        ['git', '-C', str(ROOT), 'cat-file', kind, oid])
spec = importlib.util.spec_from_file_location('audit', OUT / 'audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
files['source-audit.json'] = (json.dumps(audit.audit_control(
    files['source/test/fixtures/word_native/line-number-style.doc']), indent=2) + '\n').encode()
archive_path = OUT / 'artifacts.tar.xz'
with tarfile.open(archive_path, 'w:xz', preset=6) as packed:
    for name, data in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(data), 0o644, 0
        packed.addfile(item, io.BytesIO(data))
archive = archive_path.read_bytes()
manifest = {'version': 1, 'runtimeCommit': COMMIT, 'runtimeTree': TREE,
            'archive': record(archive_path.name, archive),
            'files': [record(name, data) for name, data in sorted(files.items())],
            'omittedReproducibleBinaries': sorted(omitted, key=lambda item: item['path']),
            'helpers': {name: sha((OUT / name).read_bytes()) for name in
                        ['audit.py', 'verify.py', 'test_verifier.py']}}
(OUT / 'artifacts.manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(files), 'uncompressedBytes': sum(map(len, files.values())),
                  'archiveBytes': len(archive), 'archiveSha256': sha(archive),
                  'sourceFiles': len(sources), 'omittedBinaries': len(omitted)}))
