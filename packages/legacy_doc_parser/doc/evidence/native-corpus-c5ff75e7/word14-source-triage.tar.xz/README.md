# Word14 retained-source and tiled-fill review

This read-only review compares the retained Word14 packages from parser
`74420eb2e0ec14401a0db5bcbb30ab6d202a2340` and
`c5ff75e76163d9abbdd44a9f2a7c5ad210929289`. No renderer was invoked and no
runtime or original observation was changed.

## Result and practical limit

No discarded explicit tile-coordinate operand or incorrect image selection was
found in the three repeated DOC imports. The loss of three raster-exact
comparisons is real and remains a reported limitation. It occurs in newly
retained tiled fills that the older output replaced with flat colors. The
available evidence does not justify a parser offset, image recoloring, or
removal of those fills to recover the old exactness count.

The separate pixel review finds repeat mismatches only in the regions occupied
by texture 1026 and former-pattern 1030: respectively 6,092/6,092/5,908 and
18/10/3,831 changed pixels across cycles one to three. Its regions are analysis
masks partitioned by whitespace, not source bounding boxes. Picture, solid,
and both gradient regions have zero repeated DOC-to-parser pixel differences.
Initial DOC-to-parser mismatch falls from 35,146 to 30,704 pixels and summed
absolute RGB error from 10,774,592 to 6,725,615. These numerical improvements do
not certify whole-document fidelity.

## Exact package and operand findings

`inspect_word14.py` reads 14 existing DOCX packages and checks framing of the
retained OfficeArt records. `word14-source-paint.json` retains their identities,
every FOPT layer, global defaults, BLIP-store references, source payload hashes,
VML attributes, image dimensions/density, and native DrawingML fill attributes.

- The original binary source is identical between both runs. All six VML
  textbox styles, including position, dimensions and wrap settings, are
  identical between old and new output at the initial import and each repeat.
- At every repeat, shapes 1026 and 1030 have source `fillType=2` and fill Boolean
  word `0x00140014`: explicitly used filled=true and shape alignment=true.
  No image/shape origin, tile size, unit selector, alternate fill rectangle,
  gradient coordinate or other operand in `0x0189..0x019c` occurs in their
  shape layers or drawing defaults.
- The scalar `fillBlip` operands carry `fBid`. Their one-based BLIP-store entry,
  delayed source offset, retained raw payload and output image relationship
  agree exactly. Every repeated texture image is byte-identical to its source
  payload. The 64-by-64, 75-DPI JPEG is unchanged through all repeats; the
  former pattern uses the same 103-byte, 8-by-8 colored PNG throughout.
- The original monochrome pattern is an 80-byte DIB. Initial output adds only
  the required 14-byte BMP header. The first native DOC bridge replaces this
  source with the colored PNG and type-2 texture. None of the repeated outputs
  contains a BMP wrapper, excluding that wrapper as a direct cause of their
  raster mismatch.
- All three native DOCX bridges represent both textures with `a:tile` values
  `tx=0`, `ty=0`, `sx=100000`, `sy=100000`, `algn=ctr`. Their picture uses
  stretch and an empty fill rectangle. Parser output uses the corresponding
  `v:fill type=tile` or `type=frame`, with default tile-coordinate attributes.

## Defaults and separate native paths

`primary-sources.json` records the exact Microsoft pages and excerpts from
the measured LibreOffice commit `2c87e51eeaa2b413ff4ae097b2705eea1995d8e5`.
MS-ODRAW's image and shape origins default to numeric zero; its size selector
defaults to `msodztypeDefault`, for which explicit fill width/height are ignored.
The used rotation flag is distinct from shape-relative alignment, which
defaults true. VML alignment also defaults true and size defaults to the
original image. Generic VML documentation describes centered origin/position;
the Office implementation notes explicitly specify an origin default of
`0,0`. That distinction is retained and is not treated as proof of actual
Microsoft Word behavior.

The pinned binary importer supplies texture graphics to a tiled legacy brush
(`GPOS_TILED`); the VML importer supplies a bitmap fill, recoloring a monochrome
pattern into its own graphic. These are separate measured format paths. Exact
image and FOPT retention, equal geometry, and the two-region pixel partition
support a remaining tiled-fill interoperability discrepancy. They do not prove
that every differing pixel is a defect in one particular native function.

## Original Word14 effects remain outside the bounded claim

The original shape 1026 metroBlob contains Word-authored DrawingML with
`rotWithShape=1`, an empty source rectangle, and a tile using `algn=tl`, full
scale, zero offsets and no flip. The original shape 1030 metroBlob contains a
`ltVert` preset pattern in green and yellow. Those blobs are preserved and
explicitly unsupported; the native DOC bridge removes them. Its later
center-aligned DrawingML therefore cannot establish the original Word-authored
texture's full semantics. The original effect/relative-size guards and the
0.75-point text drift remain separate unresolved Word14 limitations.

## Reproduction without a native rerun

```sh
python3 inspect_word14.py \
  --before /workspace/scratch/c1ca2a1344e9/parser-native-74420eb/word14-margin-origin \
  --after /workspace/scratch/c1ca2a1344e9/final-native-c5ff75e7/word14-margin-origin \
  --out word14-source-paint.json
```

The inspection uses Python and Pillow for image metadata. All guards use
explicit exceptions. Original binary and raster bytes remain in the separate
native evidence archives; this directory contains read-only derivations.
