#!/usr/bin/env python3
"""Read retained native packages; never invoke a renderer or change inputs."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET
import zipfile

from PIL import Image

V = "{urn:schemas-microsoft-com:vml}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def record(raw):
    return {"bytes": len(raw), "sha256": sha(raw)}


def officeart(raw):
    shapes, defaults, blips = [], [], []

    def header(offset, end):
        require(offset + 8 <= end, "Truncated OfficeArt header")
        version, kind, size = struct.unpack_from("<HHI", raw, offset)
        require(offset + 8 + size <= end, "Truncated OfficeArt record")
        return version, kind, size

    def properties(offset, version, size):
        count = version >> 4
        require(count * 6 <= size, "Truncated FOPT table")
        entries, complex_offset = [], offset + 8 + count * 6
        for index in range(count):
            opid, value = struct.unpack_from("<HI", raw, offset + 8 + 6 * index)
            entry = {"opid": f"0x{opid & 0x3fff:04x}", "rawOpid": f"0x{opid:04x}",
                     "value": value, "fBid": bool(opid & 0x4000), "fComplex": bool(opid & 0x8000)}
            if opid & 0x8000:
                require(complex_offset + value <= offset + 8 + size, "Truncated complex FOPT")
                entry["complex"] = record(raw[complex_offset:complex_offset + value])
                complex_offset += value
            entries.append(entry)
        require(complex_offset == offset + 8 + size, "Unclaimed FOPT bytes")
        return entries

    def walk(start, end, shape=None):
        cursor = start
        while cursor < end:
            version, kind, size = header(cursor, end)
            limit = cursor + 8 + size
            if kind == 0xf004:
                item = {"offset": cursor, "record": record(raw[cursor:limit]), "layers": []}
                shapes.append(item)
                walk(cursor + 8, limit, item)
            elif kind == 0xf00a:
                require(shape is not None and size == 8, "Unexpected FSP")
                shape["shapeId"], shape["flags"] = struct.unpack_from("<II", raw, cursor + 8)
                shape["shapeType"] = version >> 4
            elif kind in (0xf00b, 0xf121, 0xf122):
                layer = {"kind": f"0x{kind:04x}", "offset": cursor,
                         "properties": properties(cursor, version, size)}
                (shape["layers"] if shape is not None else defaults).append(layer)
            elif kind == 0xf007:
                require(size >= 36, "Truncated FBSE")
                size_bytes, references, delay = struct.unpack_from("<III", raw, cursor + 8 + 20)
                blips.append({"oneBasedIndex": len(blips) + 1, "type": raw[cursor + 8],
                              "recordBytes": size_bytes, "references": references,
                              "delayedOffset": delay})
            elif version & 15 == 15:
                walk(cursor + 8, limit, shape)
            cursor = limit
        require(cursor == end, "OfficeArt framing mismatch")

    version, kind, size = header(0, len(raw))
    require(kind == 0xf000, "OfficeArtContent must start with DggContainer")
    walk(0, size + 8)
    cursor = size + 8
    while cursor < len(raw):
        require(raw[cursor] in (0, 1), "Unknown drawing label")
        cursor += 1
        version, kind, size = header(cursor, len(raw))
        require(kind == 0xf002, "Expected DgContainer")
        walk(cursor, cursor + size + 8)
        cursor += size + 8
    return {"source": record(raw), "drawingDefaults": defaults,
            "shapes": shapes, "blipStore": blips}


def package(path):
    original = path.read_bytes()
    with zipfile.ZipFile(io.BytesIO(original)) as packed:
        root = ET.fromstring(packed.read("word/document.xml"))
        relationships = {
            item.get("Id"): "word/" + item.get("Target")
            for item in ET.fromstring(packed.read("word/_rels/document.xml.rels"))
            if item.get("Type", "").endswith("/image")
        }
        shapes = []
        for element in root.iter():
            if element.tag not in (V + "shape", V + "rect"):
                continue
            fill = element.find(V + "fill")
            shapes.append({"attributes": element.attrib,
                           "fill": None if fill is None else fill.attrib,
                           "mediaPart": None if fill is None else relationships.get(fill.get(R + "id"))})
        images = {}
        for name in packed.namelist():
            if not name.startswith("word/media/"):
                continue
            raw = packed.read(name)
            image = Image.open(io.BytesIO(raw))
            images[name] = {**record(raw), "dimensions": list(image.size), "mode": image.mode,
                            "format": image.format, "dpi": image.info.get("dpi"),
                            "rgbSha256": sha(image.convert("RGB").tobytes())}
        result = {"path": str(path), **record(original), "vmlShapes": shapes, "images": images,
                  "drawingmlFills": [ET.tostring(element, encoding="unicode") for element in root.iter()
                                     if element.tag == A + "blipFill"]}
        if "word/evidence/manifest.json" in packed.namelist():
            evidence = json.loads(packed.read("word/evidence/manifest.json"))
            artifacts = [entry for entry in evidence["records"] if entry["kind"] == "officeArt"]
            content = [entry for entry in artifacts if entry["source"]["structure"] == "OfficeArtContent"]
            require(len(content) == 1, "Expected exactly one retained OfficeArtContent")
            result["officeArt"] = officeart(packed.read(content[0]["part"]))
            result["officeArt"]["sourceReference"] = content[0]["source"]
            source_content = packed.read(content[0]["part"])
            result["metroFills"] = []
            for shape in result["officeArt"]["shapes"]:
                if shape.get("shapeId") not in (1026, 1030):
                    continue
                for layer in shape["layers"]:
                    position = layer["offset"] + 8 + 6 * len(layer["properties"])
                    for prop in layer["properties"]:
                        if not prop["fComplex"]:
                            continue
                        raw = source_content[position:position + prop["value"]]
                        position += prop["value"]
                        if prop["opid"] != "0x03a9":
                            continue
                        with zipfile.ZipFile(io.BytesIO(raw)) as metro:
                            xml = metro.read("drs/e2oDoc.xml")
                        result["metroFills"].append({"shapeId": shape["shapeId"], "blob": record(raw),
                                                    "part": "drs/e2oDoc.xml", "partIdentity": record(xml),
                                                    "fills": [ET.tostring(element, encoding="unicode")
                                                              for element in ET.fromstring(xml).iter()
                                                              if element.tag in (A + "blipFill", A + "pattFill")]})
            result["retainedBlips"] = []
            for entry in artifacts:
                if entry["source"]["structure"] != "OfficeArtBlip":
                    continue
                raw = packed.read(entry["part"])
                version, kind, size = struct.unpack_from("<HHI", raw)
                require(size + 8 == len(raw), "BLIP record size")
                # All observed bitmap BLIPs have one UID and a one-byte tag.
                require(kind in (0xf01d, 0xf01e, 0xf01f) and version >> 4 in (0x46a, 0x6e0, 0x7a8),
                        "Unexpected BLIP instance; inspect before extending")
                payload = raw[25:]
                result["retainedBlips"].append({"source": entry["source"], "record": record(raw),
                                                "kind": f"0x{kind:04x}", "payload": record(payload),
                                                "matchingMedia": [name for name in images
                                                                  if packed.read(name) == payload or
                                                                  (packed.read(name).startswith(b"BM") and packed.read(name)[14:] == payload)]})
        require(path.read_bytes() == original, "Source package changed while reading")
        return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--before", type=Path, required=True)
    parser.add_argument("--after", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = {"scope": "Read-only retained Word14 package/FOPT/media inspection; no renderer execution.",
              "scriptSha256": sha(Path(__file__).read_bytes()), "runs": {}}
    for label, directory in (("before", args.before), ("after", args.after)):
        paths = ["converted.docx"]
        for cycle in range(1, 4):
            paths += [f"roundtrip-{cycle:02}/import.docx",
                      f"roundtrip-{cycle:02}/native-docx/" + ("converted.docx" if cycle == 1 else "import.docx")]
        result["runs"][label] = [package(directory / path) for path in paths]
        result["runs"][label][0]["binarySource"] = record((directory / "source.doc").read_bytes())
    require(result["runs"]["before"][0]["binarySource"] == result["runs"]["after"][0]["binarySource"],
            "Original binary source differs across runs")
    comparisons = []
    coordinate_properties = [f"0x{value:04x}" for value in range(0x0189, 0x019d)]
    for index, cycle in ((0, 0), (1, 1), (3, 2), (5, 3)):
        before, after = result["runs"]["before"][index], result["runs"]["after"][index]
        by_id = lambda value: {shape["attributes"]["id"]: shape for shape in value["vmlShapes"]}
        old_shapes, new_shapes = by_id(before), by_id(after)
        require(old_shapes.keys() == new_shapes.keys(), "Changed textbox shape identities")
        require(all(old_shapes[key]["attributes"]["style"] == value["attributes"]["style"]
                    for key, value in new_shapes.items()), "Changed textbox geometry/style")
        entry = {"cycle": cycle, "vmlStylesIdenticalAcrossVersions": True, "fills": []}
        for identifier in (1026, 1030):
            shape = next(item for item in after["officeArt"]["shapes"] if item["shapeId"] == identifier)
            props = {prop["opid"]: prop for layer in after["officeArt"]["drawingDefaults"] + shape["layers"]
                     for prop in layer["properties"]}
            specified_coordinates = [key for key in coordinate_properties if key in props]
            require(not specified_coordinates, "Unexpected explicit tile coordinate/size operand")
            fill_ref = props["0x0186"]
            require(fill_ref["fBid"] and not fill_ref["fComplex"], "Unqualified fill BLIP reference")
            bse = after["officeArt"]["blipStore"][fill_ref["value"] - 1]
            blip = next(item for item in after["retainedBlips"] if item["source"]["offset"] == bse["delayedOffset"])
            vml = new_shapes["_legacyTextboxShape" + str(identifier)]
            require(vml["mediaPart"] in blip["matchingMedia"], "VML media differs from referenced BLIP")
            if cycle:
                require(props["0x0180"]["value"] == 2 and props["0x01bf"]["value"] == 0x00140014,
                        "Unexpected repeated texture flags/type")
                require(after["images"][vml["mediaPart"]]["format"] != "BMP", "Repeated DIB wrapper unexpectedly present")
            entry["fills"].append({"shapeId": identifier, "fillType": props["0x0180"]["value"],
                                   "fillFlagsByLayer": [hex(prop["value"]) for layer in shape["layers"]
                                                        for prop in layer["properties"] if prop["opid"] == "0x01bf"],
                                   "explicitCoordinateOperands": specified_coordinates,
                                   "fillBlipIndex": fill_ref["value"], "mediaPart": vml["mediaPart"],
                                   "sourcePayloadMatchesEmbeddedImage": True,
                                   "image": after["images"][vml["mediaPart"]]})
        comparisons.append(entry)
    result["verifiedComparisons"] = comparisons
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"verified": True, "packages": sum(len(x) for x in result["runs"].values()),
                      "output": str(args.out), "outputSha256": sha(args.out.read_bytes())}))


if __name__ == "__main__":
    main()
