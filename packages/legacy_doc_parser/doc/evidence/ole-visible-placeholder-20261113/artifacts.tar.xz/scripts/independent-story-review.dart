import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import 'package:xml/xml.dart';
import '/workspace/scratch/c1ca2a1344e9/parser-review-next/test/support/media_word_fixture.dart';
void require(bool value,String text){if(!value)throw StateError(text);}
void main(){
 final original=parseLegacyWordDocument(oleWordFixture());
 final object=original.media.embeddedObjects.single;
 final doc=LegacyWordDocument(blocks:original.blocks,sections:original.sections,plainText:original.plainText,safeHtml:original.safeHtml,fields:original.fields,stories:[
   LegacyWordStory(id:'header',kind:LegacyWordStoryKind.header,startCp:100,endCp:101,blocks:[],plainText:'',safeHtml:''),
   LegacyWordStory(id:'footer',kind:LegacyWordStoryKind.footer,startCp:102,endCp:103,blocks:[],plainText:'',safeHtml:'')
 ],media:LegacyWordMediaCatalog.from(embeddedObjects:[object,
   for(final (id,cp) in [('header',100),('footer',102)])LegacyWordEmbeddedObject(id:id,cp:cp,storage:object.storage,progId:object.progId,linked:object.linked,canEmbed:object.canEmbed,presentation:const LegacyWordMediaPresentation(inserted:true,deleted:true,hidden:true))
 ]));
 final result=convertLegacyWordDocument(doc);
 final parts={for(final f in ZipDecoder().decodeBytes(result.bytes))if(f.isFile)f.name:f.content};
 require(result.preservedCounts['generatedPlaceholderImages']==1,'Generated image not deduplicated');
 require(result.preservedCounts['embeddedObjectPlaceholders']==3,'Occurrence count differs');
 require(result.preservedCounts['images']==null,'Generated image mislabeled as source image');
 require(parts.keys.where((x)=>x.startsWith('word/media/')).length==1,'Extra generated image');
 final shapeIds=<String>{};
 for(final name in ['document','header1','footer1']) {
   final xml=XmlDocument.parse(utf8.decode(parts['word/$name.xml']!));
   final rel=XmlDocument.parse(utf8.decode(parts['word/_rels/$name.xml.rels']!));
   final image=xml.findAllElements('imagedata',namespace:'urn:schemas-microsoft-com:vml').single;
   final ole=xml.findAllElements('OLEObject',namespace:'urn:schemas-microsoft-com:office:office').single;
   final shape=xml.findAllElements('shape',namespace:'urn:schemas-microsoft-com:vml').single;
   require(shapeIds.add(shape.getAttribute('id')!), 'Shape id reused');
   for(final e in [image,ole]) {
     final id=e.getAttribute('id',namespace:'http://schemas.openxmlformats.org/officeDocument/2006/relationships');
     final r=rel.findAllElements('Relationship').singleWhere((r)=>r.getAttribute('Id')==id);
     require(parts.containsKey('word/${r.getAttribute('Target')}'),'Missing local relation target');
     require(r.getAttribute('TargetMode')==null,'External generated relation');
   }
   if(name!='document') {
     require(xml.findAllElements('ins',namespace:'http://schemas.openxmlformats.org/wordprocessingml/2006/main').length==1,'Lost insertion');
     require(xml.findAllElements('del',namespace:'http://schemas.openxmlformats.org/wordprocessingml/2006/main').length==1,'Lost deletion');
     require(xml.findAllElements('vanish',namespace:'http://schemas.openxmlformats.org/wordprocessingml/2006/main').length==1,'Lost hidden flag');
   }
 }
 for(final bytes in parts.entries.where((e)=>e.key.startsWith('word/embeddings/')).map((e)=>e.value)) {
   require(bytes.length==object.storage.bytes.length && List.generate(bytes.length,(i)=>bytes[i]==object.storage.bytes[i]).every((x)=>x),'Embedded storage bytes differ');
 }
 print(jsonEncode({'perPartRelationships':3,'uniqueShapes':shapeIds.length,'generatedImageParts':1,'placeholders':3,'sourceImageCount':result.preservedCounts['images'],'payloadBytesUnchanged':true,'hiddenDualRevisionsRetained':true}));
}
