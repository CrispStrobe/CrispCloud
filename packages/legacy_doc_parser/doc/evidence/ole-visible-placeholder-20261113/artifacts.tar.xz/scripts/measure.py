"""Measure the exact saved OLE icon writer without activating embedded handlers."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

import fitz
from lxml import etree as ET
from PIL import Image


REPO = Path('/workspace/scratch/c1ca2a1344e9/parser-review-next')
OUTPUT = Path('/workspace/scratch/c1ca2a1344e9/root-gap-probes/ole/d086-native')
DART = Path('/workspace/scratch/c1ca2a1344e9/toolchains/dart-3.13.7/dart-sdk/bin/dart')
DOTNET = Path('/workspace/scratch/c1ca2a1344e9/toolchains/dotnet-8.0.428/dotnet')
VALIDATOR = Path('/workspace/scratch/c1ca2a1344e9/parser-schema-final/validator/OfficeValidation.dll')
OFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
COMMIT = 'd08627583500063f6cf67a1a1d756dae3f9594f4'
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
sys.path.insert(0, str(REPO / 'tool/fidelity'))
from run import office_convert


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def inputs():
    names = git('ls-files').splitlines() + ['pubspec.lock', '.dart_tool/package_config.json']
    return {name: sha((REPO / name).read_bytes()) for name in sorted(names)}


def command(name, args):
    result = subprocess.run([str(a) for a in args], cwd=REPO, capture_output=True, text=True)
    raw = result.stdout + result.stderr
    (OUTPUT / (name + '.log')).write_text(raw)
    stage = {'name': name, 'args': [str(a) for a in args], 'exitCode': result.returncode,
             'logSha256': sha(raw.encode())}
    report['commands'].append(stage)
    save()
    if result.returncode:
        raise RuntimeError(name + ' failed; see retained stage log')


def save():
    (OUTPUT / 'receipt.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')


def project(source, target, retain):
    with zipfile.ZipFile(source) as original:
        content = {n: original.read(n) for n in original.namelist()}
    doc = ET.fromstring(content['word/document.xml'])
    changes = doc.findall('.//{' + W + '}ins')
    if len(changes) != 1:
        raise ValueError('Expected the one independently authored insertion')
    for node in changes:
        parent = node.getparent()
        index = parent.index(node)
        if retain:
            for child in list(node):
                parent.insert(index, child)
                index += 1
        parent.remove(node)
    content['word/document.xml'] = ET.tostring(doc, xml_declaration=True, encoding='UTF-8')
    with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED) as output:
        for name, data in content.items():
            output.writestr(name, data)
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(target) as projected:
        changed = [n for n in original.namelist() if original.read(n) != projected.read(n)]
        if changed != ['word/document.xml']:
            raise ValueError('Projection modified non-document bytes')
    return {'path': str(target.relative_to(OUTPUT)), 'sha256': sha(target.read_bytes()),
            'insertionRetained': retain, 'changedMembers': changed,
            'originalObjectPayloadUnchanged': True}


os.environ['TMPDIR'] = '/workspace/scratch/c1ca2a1344e9/tmp'
os.environ['DART_SUPPRESS_ANALYTICS'] = 'true'
os.environ['PUB_CACHE'] = '/workspace/scratch/c1ca2a1344e9/toolchains/pub-cache'
if git('rev-parse', 'HEAD') != COMMIT or git('status', '--porcelain'):
    raise ValueError('Measurement requires the exact clean saved runtime')
OUTPUT.mkdir(parents=True, exist_ok=False)
before = inputs()
report = {'schema': 'legacy-doc-parser/visible-ole-placeholder', 'version': 1,
          'sourceCommit': COMMIT, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
          'sourceFilesBefore': before, 'commands': [], 'status': 'running',
          'nativeHandlerActivationAttempted': False,
          'nativeHelperSha256': sha((REPO / 'tool/fidelity/run.py').read_bytes()),
          'measurementScriptSha256': sha(Path(__file__).read_bytes()),
          'compilerSha256': sha(DART.read_bytes()), 'validatorSha256': sha(VALIDATOR.read_bytes()),
          'validatorSourceSha256': sha((REPO / 'tool/office-validation/Program.cs').read_bytes()),
          'renderer': subprocess.check_output([str(OFFICE), '--version'], text=True).strip()}
save()
try:
    fixtures = OUTPUT / 'schema/fixtures'
    command('generate-media-review-fixtures', [DART, 'run', 'tool/fidelity/media_review_fixture.dart', fixtures])
    reference = REPO / 'test/fixtures/word_native/generated-ole-placeholder.png'
    source_png = reference.read_bytes()
    (OUTPUT / 'reference-placeholder.png').write_bytes(source_png)
    source_rgb = Image.open(io.BytesIO(source_png)).convert('RGB')
    expected_pixels = source_rgb.tobytes()
    original = fixtures / 'embedded-object-inserted.docx'
    source = fixtures / 'embedded-object-inserted.doc'
    if sha(source.read_bytes()) != '935edaa1bcd2776ebe319e238301c373bed7760c2761eb1a24d10f12579ef29f':
        raise ValueError('Historical source fixture was changed')
    accepted, rejected = OUTPUT / 'schema/accepted.docx', OUTPUT / 'schema/rejected.docx'
    report['projections'] = [project(original, accepted, True), project(original, rejected, False)]
    with zipfile.ZipFile(original) as package:
        report['embeddedPayloadSha256'] = sha(package.read('word/embeddings/oleObject1.bin'))
        if package.read('word/media/embedded-object-placeholder.png') != source_png:
            raise ValueError('Writer did not emit the reviewed PNG')
    if report['embeddedPayloadSha256'] != '084937f7a5a65cc3ceeb6c16171420643f091d93c70935049c260f36f51cbc0d':
        raise ValueError('Original OLE bytes changed')
    report['originalSourceSha256'] = sha(source.read_bytes())
    report['convertedDocxSha256'] = sha(original.read_bytes())
    report['reviewedPixelSha256'] = sha(expected_pixels)
    report['native'] = {}
    for name, document, expect_image in [('reviewed', original, True), ('accepted', accepted, True),
                                         ('rejected', rejected, False)]:
        before_doc = sha(document.read_bytes())
        pdf = office_convert(OFFICE, document, OUTPUT / ('native-' + name), 'pdf')
        with fitz.open(pdf) as native:
            if len(native) != 1:
                raise ValueError('Unexpected page count')
            page = native[0]
            records = []
            for image in page.get_images(full=True):
                item = native.extract_image(image[0])
                decoded = Image.open(io.BytesIO(item['image'])).convert('RGB')
                pixels = decoded.tobytes()
                image_file = OUTPUT / ('native-' + name) / ('image-' + str(image[0]) + '.' + item['ext'])
                image_file.write_bytes(item['image'])
                records.append({'size': list(decoded.size), 'pixelSha256': sha(pixels),
                                'matchesReviewedPixels': pixels == expected_pixels,
                                'rectangles': [list(rect) for rect in page.get_image_rects(image[0])]})
            if (expect_image and (len(records) != 1 or not records[0]['matchesReviewedPixels'])) or (
                    not expect_image and records):
                raise ValueError('Native placeholder pixels or projection visibility differ')
            page.get_pixmap(matrix=fitz.Matrix(2, 2)).save(OUTPUT / ('native-' + name) / 'page.png')
            page.get_pixmap(matrix=fitz.Matrix(3, 3), clip=fitz.Rect(65, 60, 180, 125)).save(
                OUTPUT / ('native-' + name) / 'placeholder-crop.png')
            report['native'][name] = {'pdfSha256': sha(pdf.read_bytes()), 'pageCount': 1,
                                      'pageText': page.get_text(), 'images': records,
                                      'sourcePackageUnchanged': sha(document.read_bytes()) == before_doc}
        save()
    command('independent-schema', [DOTNET, VALIDATOR, OUTPUT / 'schema', OUTPUT / 'schema-report.json'])
    schema = json.loads((OUTPUT / 'schema-report.json').read_bytes())
    if schema['Files'] != 26 or schema['Failures'] != 0:
        raise ValueError('Schema output coverage differs')
    report['schema'] = {'files': schema['Files'], 'failures': schema['Failures'],
                        'reportSha256': sha((OUTPUT / 'schema-report.json').read_bytes())}
    report['sourceFilesAfter'] = inputs()
    if report['sourceFilesAfter'] != before or git('status', '--porcelain'):
        raise ValueError('Measured runtime inputs changed')
    report['status'] = 'completed'
    report['allRuntimeInputsUnchanged'] = True
    save()
    print(json.dumps({'status': report['status'], 'runtime': COMMIT, 'schemaFiles': schema['Files'],
                      'nativeCases': len(report['native']), 'sourceInputs': len(before)}))
except BaseException as error:
    report['status'] = 'failed'
    report['error'] = str(error)
    save()
    raise
