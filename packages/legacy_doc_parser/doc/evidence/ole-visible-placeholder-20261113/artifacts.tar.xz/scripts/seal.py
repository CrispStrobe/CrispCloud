"""Seal exact retained experiments; omit disposable native profiles only."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile
BASE=Path('/workspace/scratch/c1ca2a1344e9')
SOURCE=BASE/'root-gap-probes/ole'
REPO=BASE/'parser-review-next'
OUT=REPO/'doc/evidence/ole-visible-placeholder-20261113'
OUT.mkdir(parents=True,exist_ok=True)
files={}
for p in sorted((SOURCE/'d086-native').rglob('*')):
    if p.is_file() and 'profile' not in p.parts:
        files['final/'+str(p.relative_to(SOURCE/'d086-native'))]=p.read_bytes()
for name in ['focused-tests.log','focused-tests-tempdir-failure.log','analysis.log','independent-story-review.log','d086-native.console.log']:
    files['logs/'+name]=(SOURCE/name).read_bytes()
files['scripts/measure.py']=(SOURCE/'measure.py').read_bytes()
files['scripts/independent-story-review.dart']=(BASE/'ole-independent-review.dart').read_bytes()
files['scripts/seal.py']=Path(__file__).read_bytes()
for p in sorted((SOURCE/'reproduced-image').iterdir()):
    files['image-recipe/'+p.name]=p.read_bytes()
for name in ['source.doc','baseline.docx','image-placeholder.docx','image75-minimal.docx','image75-builtin.docx','image-native-crop.png','image75-minimal-crop.png','image75-builtin-crop.png']:
    files['prototypes/'+name]=(SOURCE/name).read_bytes()
for folder in ['image-native','image75-minimal-native','image75-builtin-native']:
    for p in sorted((SOURCE/folder).iterdir()):
        if p.is_file(): files['prototypes/'+folder+'/'+p.name]=p.read_bytes()
paths=subprocess.check_output(['git','-C',str(REPO),'diff','--name-only','4518f43c4eae84c5495a95068c0343f077d67ea0','d08627583500063f6cf67a1a1d756dae3f9594f4'],text=True).splitlines()
paths+=['tool/fidelity/run.py','tool/fidelity/media_review_fixture.dart','test/support/media_word_fixture.dart','tool/office-validation/Program.cs','pubspec.yaml','pubspec.lock','.dart_tool/package_config.json']
for name in sorted(set(paths)): files['runtime/'+name]=(REPO/name).read_bytes()
archive=OUT/'artifacts.tar.xz'
with tarfile.open(archive,'w:xz',format=tarfile.PAX_FORMAT,preset=6) as tar:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name); info.size=len(data);info.mode=0o644;info.mtime=0
        tar.addfile(info,io.BytesIO(data))
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={'schema':'legacy-doc-parser/visible-ole-placeholder-artifacts','version':1,'runtimeCommit':'d08627583500063f6cf67a1a1d756dae3f9594f4','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'fileCount':len(files),'totalBytes':sum(map(len,files.values())),'omissions':['Disposable LibreOffice user profiles; all document, PDF, image, receipt and log outputs are retained.'],'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
(OUT/'artifacts.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
for src,dest in [('receipt.json','receipt.json'),('schema-report.json','schema-report.json')]: (OUT/dest).write_bytes(files['final/'+src])
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
