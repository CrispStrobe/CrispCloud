import 'package:legacy_doc_parser/src/compound/byte_source.dart';

void main() {
  for (final value in [1, 0x100000001, 9007199254740991]) {
    final sink = ByteSink()..u64le(value);
    final bytes = sink.takeBytes();
    print('$value ${bytes.toList()} ${ByteCursor(bytes).u64le()}');
  }
}
