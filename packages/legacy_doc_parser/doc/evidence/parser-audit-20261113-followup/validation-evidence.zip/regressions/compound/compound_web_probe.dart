import 'dart:convert';

import 'legacy-doc-parser/tool/compound_web_acceptance.dart';

void main() {
  print(jsonEncode(verifyCompoundAllocationWebCases()));
}
