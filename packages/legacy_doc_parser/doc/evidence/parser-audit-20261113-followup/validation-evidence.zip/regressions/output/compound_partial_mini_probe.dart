import 'dart:convert';
import 'dart:typed_data';

import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';
import 'package:legacy_doc_parser/src/compound/cfbf_reader.dart';
import 'package:legacy_doc_parser/src/compound/cfbf_writer.dart';
import 'file:///workspace/scratch/d4b323983ed0/parser-acceptance/lib/src/bounded_cfb_reader.dart' as before;
import 'file:///workspace/scratch/d4b323983ed0/parser-acceptance/lib/src/compound/cfbf_reader.dart' as rawBefore;

void main() {
  for (final length in [1, 65, 127]) {
    final bytes = (CfbfWriter()..addStream('Small', List.generate(length, (i) => i))).build();
    final data = ByteData.sublistView(bytes);
    final directory = (data.getUint32(48, Endian.little) + 1) * 512;
    data.setUint32(directory + 120, length, Endian.little);
    Object result(Uint8List? Function() read) {
      try { return {'bytes': read()!.length}; } catch (error) { return {'error': error.toString()}; }
    }
    print(jsonEncode({
      'rootSize': length,
      'baselineRaw': result(() => rawBefore.CfbfFile.fromBytes(bytes).readPath('Small')),
      'baselineBounded': result(() => before.BoundedCfbReader(bytes).readPath('Small')),
      'candidateRaw': result(() => CfbfFile.fromBytes(bytes).readPath('Small')),
      'candidateBounded': result(() => BoundedCfbReader(bytes).readPath('Small')),
    }));
  }
}
