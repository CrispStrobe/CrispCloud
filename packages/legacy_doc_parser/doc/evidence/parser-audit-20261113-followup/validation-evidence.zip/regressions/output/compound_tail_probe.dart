import 'dart:convert';
import 'dart:typed_data';

import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';
import 'package:legacy_doc_parser/src/compound/byte_source.dart';
import 'package:legacy_doc_parser/src/compound/cfbf_reader.dart';
import 'package:legacy_doc_parser/src/compound/cfbf_writer.dart';

class CountedSource extends MemoryByteSource {
  CountedSource(super.bytes);
  int viewCalls = 0;
  int emptyViews = 0;
  @override
  Uint8List view(int offset, int length) {
    viewCalls++;
    if (length == 0) emptyViews++;
    return super.view(offset, length);
  }
}

void main() {
  const aliases = 64;
  final writer = CfbfWriter()..addStream('Large', Uint8List(1024 * 1024));
  for (var i = 0; i < aliases; i++) {
    writer.addStream('Alias$i', Uint8List(4096));
  }
  final bytes = writer.build();
  final original = CfbfFile.fromBytes(bytes);
  final first = original.entryByName('Large')!.startSector;
  final directoryChain = <int>[];
  var sector = original.header.firstDirectorySector;
  while (sector != cfbfEndOfChain) {
    directoryChain.add(sector);
    sector = original.fat[sector];
  }
  final data = ByteData.sublistView(bytes);
  for (final entry in original.entries.where((e) => e.isStream)) {
    final at = (directoryChain[entry.index ~/ 4] + 1) * 512 + entry.index % 4 * 128;
    data.setUint32(at + 116, first, Endian.little);
    data.setUint32(at + 120, 4096, Endian.little);
  }
  final source = CountedSource(bytes);
  final raw = CfbfFile.open(source);
  source.viewCalls = source.emptyViews = 0;
  var logicalBytes = 0;
  for (final entry in raw.entries.where((e) => e.isStream)) {
    logicalBytes += raw.readEntry(entry).length;
  }
  final bounded = BoundedCfbReader(bytes);
  var boundedBytes = 0;
  for (final entry in bounded.childrenOf(bounded.root)) {
    if (entry.isStream) boundedBytes += bounded.readEntry(entry).length;
  }
  print(jsonEncode({
    'sourceBytes': bytes.length,
    'streamCount': aliases + 1,
    'logicalBytes': logicalBytes,
    'rawSectorViews': source.viewCalls,
    'zeroLengthTailViews': source.emptyViews,
    'boundedAcceptedSharedTailLogicalBytes': boundedBytes,
  }));
}
