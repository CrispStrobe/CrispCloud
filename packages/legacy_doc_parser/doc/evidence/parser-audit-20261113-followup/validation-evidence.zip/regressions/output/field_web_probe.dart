import 'dart:convert';
import 'file:///workspace/scratch/d4b323983ed0/legacy-doc-parser/tool/nested_field_web_acceptance.dart';

void main() => print(jsonEncode(verifyNestedFieldWebAcceptance()));
