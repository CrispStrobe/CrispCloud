import 'dart:convert';

import '../legacy-doc-parser/tool/story_unicode_web_acceptance.dart';

void main() {
  print(jsonEncode(verifyStoryUnicodeWebAcceptance()));
}
