"""Independent read-only verification of the completed fourth-pass receipts."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path.cwd()
ACCEPTANCE = ROOT / 'build/audit-fourth/acceptance'
SCHEMA = ROOT / 'build/audit-fourth/schema'
HEAD = 'e84f4131ce1515675dc97dfa6442d0c4a8ac77cf'
issues = []
checks = {}

def check(condition, detail):
    if not condition:
        issues.append(detail)

def sha(value):
    if isinstance(value, Path):
        value = value.read_bytes()
    return hashlib.sha256(value).hexdigest()

def read(path):
    return json.loads(path.read_text())

def snapshot(directory):
    return {str(p.relative_to(directory)): sha(p)
            for p in sorted(directory.rglob('*')) if p.is_file()}

def git(*args):
    return subprocess.check_output(['git', *args])

portable = read(ACCEPTANCE / 'portable-receipt.json')
schema_receipt = read(ACCEPTANCE / 'schema-receipt.json')
gate = read(SCHEMA / 'report.json')
tracked = {}
for row in git('ls-tree', '-r', '-z', HEAD).split(b'\0'):
    if not row:
        continue
    metadata, path = row.split(b'\t', 1)
    mode, kind, oid = metadata.decode().split()
    if kind == 'blob':
        tracked[path.decode()] = oid
commit_hashes = {}
needed = set(portable['sourceBefore']) | set(gate['source']['files'])
process = subprocess.Popen(['git', 'cat-file', '--batch'], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE)
for name in sorted(needed & tracked.keys()):
    process.stdin.write((tracked[name] + '\n').encode())
    process.stdin.flush()
    _, kind, size = process.stdout.readline().decode().split()
    content = process.stdout.read(int(size))
    check(process.stdout.read(1) == b'\n', 'Git batch separator')
    check(kind == 'blob', 'Git object kind: ' + name)
    commit_hashes[name] = sha(content)
process.stdin.close()
check(process.wait() == 0, 'Git object reader failed')
portable_expected = {n for n in tracked if n.split('/')[0] in
                    {'lib', 'test', 'tool', 'example', '.github'} or n in
                    {'pubspec.yaml', 'analysis_options.yaml'}}
check(set(portable['sourceBefore']) == portable_expected, 'Portable source scope mismatch')
for name, receipt in [('portable', portable), ('schema', schema_receipt)]:
    check(receipt['passed'] is True and receipt['completed'] is True, name + ' unfinished')
    check(receipt['runtimeCommit'] == HEAD, name + ' commit mismatch')
    check(receipt['statusBefore'] == receipt['statusAfter'] == '', name + ' dirty receipt')
    check(receipt['sourceBefore'] == receipt['sourceAfter'], name + ' before/after source mismatch')
    check(receipt['sourceBefore'] == portable['sourceBefore'], name + ' source scope mismatch')
    for path, digest in receipt['sourceBefore'].items():
        check(sha(ROOT / path) == digest, name + ' current source mismatch: ' + path)
        check(commit_hashes[path] == digest, name + ' committed source mismatch: ' + path)
    for path, digest in receipt['dependencies'].items():
        check(sha(ROOT / path) == digest, name + ' dependency mismatch: ' + path)
    for command in receipt['commands']:
        check(command['exitCode'] == 0, name + ' command failed: ' + command['name'])
        check(sha(ACCEPTANCE / command['log']) == command['logSha256'],
              name + ' log mismatch: ' + command['name'])
    checks[name + 'Receipt'] = {'commands': len(receipt['commands']),
                                'sourceFiles': len(receipt['sourceBefore']),
                                'sourceMatchesCommitAndWorkingFiles': True,
                                'logsHashVerified': True,
                                'receiptSha256': sha(ACCEPTANCE / (name + '-receipt.json'))}
check(len(portable['commands']) == 6, 'Portable gate count')
check(len(schema_receipt['commands']) == 7, 'Schema/public-model gate count')
check(gate['passed'] is True and gate['gitHead'] == HEAD and not gate['gitWorktreeDirty'],
      'Inner schema status/source identity')
check(gate['source'] == gate['sourceAfter'], 'Schema source changed')
files = gate['source']['files']
check(sha(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()) ==
      gate['source']['aggregateSha256'], 'Schema aggregate digest')
untracked_source = []
for path, digest in files.items():
    check(sha(ROOT / path) == digest, 'Schema current source mismatch: ' + path)
    if path in tracked:
        check(commit_hashes[path] == digest, 'Schema committed source mismatch: ' + path)
    else:
        untracked_source.append(path)
check(set(untracked_source) == {'pubspec.lock', '.dart_tool/package_config.json'},
      'Unexpected generated schema sources')
for stage in gate['stages']:
    expected_code = 1 if stage['name'] == 'negative-controls' else 0
    check(stage['returncode'] == expected_code and stage['status'] == 'completed',
          'Schema stage status: ' + stage['name'])
    check(sha(SCHEMA / stage['log']) == stage['logSha256'], 'Schema stage log: ' + stage['name'])
checks['schemaSources'] = {'files': len(files), 'committedFiles': len(files)-len(untracked_source),
                           'separatelyHashedGeneratedDependencies': untracked_source,
                           'aggregateSha256': gate['source']['aggregateSha256'],
                           'sourceMatchesCommitAndWorkingFiles': True,
                           'stages': len(gate['stages'])}

suffixes = {'.docx', '.docm', '.dotx', '.dotm', '.xlsx', '.pptx'}
def validate_report(report_path, directory, expect_errors=False):
    report = read(report_path)
    outputs = {str(p.resolve()): sha(p) for p in directory.rglob('*')
               if p.is_file() and p.suffix.lower() in suffixes}
    actual = {}
    errors = 0
    for item in report['Reports']:
        p = Path(item['File'])
        if not p.is_absolute():
            p = ROOT / p
        key = str(p.resolve())
        check(key not in actual, 'Duplicate SDK output: ' + key)
        actual[key] = item['Sha256'].lower()
        check(not item.get('Exception'), 'SDK could not inspect: ' + key)
        check(bool(item['Errors']) == expect_errors, 'Unexpected SDK errors state: ' + key)
        for error in item['Errors']:
            check(bool(error.get('Id')), 'SDK error lacks identity: ' + key)
        errors += len(item['Errors'])
    check(actual == outputs, 'SDK output inventory/hash mismatch: ' + str(report_path))
    check(report['Files'] == len(outputs), 'SDK summary count: ' + str(report_path))
    check(report['Failures'] == (len(outputs) if expect_errors else 0),
          'SDK failure summary: ' + str(report_path))
    return {'files': len(outputs), 'errors': errors, 'exactInventoryAndHashes': True,
            'reportSha256': sha(report_path)}

for key, filename, directory, negative in [
    ('schemaValidation', 'schema-validation.json', 'corpus', False),
    ('positiveControl', 'positive-control.json', 'controls/positive', False),
    ('negativeControls', 'negative-controls.json', 'controls/negative', True)]:
    checks[key] = validate_report(SCHEMA / filename, SCHEMA / directory, negative)
    source_key = 'validation' if key == 'schemaValidation' else key
    check(checks[key]['reportSha256'] == gate[source_key]['reportSha256'], key+' report receipt hash')
    check(checks[key]['files'] == gate[source_key]['files'] and
          checks[key]['errors'] == gate[source_key]['errors'], key+' result counts')
check(checks['positiveControl']['files'] == 1 and checks['negativeControls']['files'] == 2,
      'Missing positive/negative controls')
expected_self_test = ('Open XML SDK controls passed: 8 valid Word packages, '
                     '4 invalid XML, 12 mismatched types, and exact discovery.')
check(gate['selfTestPassed'] and expected_self_test in
      (SCHEMA / 'validator-self-test.log').read_text(), 'Validator self-tests missing')
checks['validatorSelfTests'] = {'validPackages': 8, 'invalidXml': 4,
                              'mismatchedTypes': 12, 'exactDiscovery': True}

# Load only the declared inventory and package pins from the committed gate;
# all byte/hash comparison logic in this script is separate from the gate.
module = ast.parse((ROOT / 'tool/fidelity/schema.py').read_text())
constants = {}
for node in module.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and
       t.id in {'EXPECTED_CASES', 'PACKAGES'} for t in node.targets):
        exec(compile(ast.Module(body=[node], type_ignores=[]), '<inventory>', 'exec'), {}, constants)
expected_cases = constants['EXPECTED_CASES']
corpus = SCHEMA / 'corpus'
cases = gate['corpus']['cases']
manifest = read(corpus / 'manifest.json')['cases']
check(len(cases) == len(expected_cases) == 279, 'DOC-derived case count')
check({c['name'] for c in cases} == expected_cases, 'DOC-derived case inventory')
check({c['name'] for c in manifest} == expected_cases and len(manifest) == len(cases),
      'Corpus manifest case inventory')
for case in cases:
    check(sha(corpus / case['source']) == case['sourceSha256'], 'Case source: '+case['name'])
    check(sha(corpus / case['output']) == case['outputSha256'], 'Case output: '+case['name'])
check({str((corpus / c['output']).resolve()): c['outputSha256'] for c in cases} ==
      gate['corpus']['outputs'], 'Corpus output map mismatch')
first = snapshot(corpus)
check(first == snapshot(SCHEMA / 'corpus-repeat'), 'DOC-derived determinism mismatch')
check(first == gate['determinism']['sha256ByRelativePath'], 'Determinism receipt mismatch')
check(len(first) == gate['determinism']['files'] == 604, 'Determinism file count')
checks['docDerivedCorpus'] = {'cases': len(cases), 'sourceAndOutputHashesVerified': True,
                              'determinismFiles': len(first), 'twoGenerationsByteIdentical': True}

build = gate['validatorBuild']
for path, digest in build['artifacts'].items():
    check(sha(SCHEMA / 'validator' / path) == digest, 'Validator artifact: '+path)
check(sha(SCHEMA / 'compile.rsp') == build['compilerResponseSha256'], 'Compiler response file')
upstream = read(ROOT / 'tool/office-validation/upstream.json')
for path, record in upstream['files'].items():
    check(sha(ROOT / 'tool/office-validation' / path) == record['sha256'], 'Validator provenance: '+path)
for name, version, archive_sha, assembly_sha in constants['PACKAGES']:
    package = next(p for p in build['packages'] if p['id'] == name)
    check(package == {'id':name,'version':version,'nupkgSha256':archive_sha,
                       'assemblySha256':assembly_sha}, 'Package pins: '+name)
    archive = ROOT.parent / '.toolchains/nuget-cache' / f'{name.lower()}.{version}.nupkg'
    check(sha(archive) == archive_sha, 'NuGet archive: '+name)
    check(sha(SCHEMA / 'validator' / (name+'.dll')) == assembly_sha, 'Pinned assembly: '+name)
checks['validatorProvenance'] = {'mode': build['mode'], 'sdkPackage':'DocumentFormat.OpenXml 3.3.0',
                               'validationVersion':upstream['validationVersion'],
                               'sourceReceiptFiles':len(upstream['files']),
                               'pinnedPackagesVerified':len(constants['PACKAGES']),
                               'artifactHashesVerified':len(build['artifacts'])}

models = {}
for label, count in [('public-media',24), ('public-compound',17)]:
    directory = ROOT / 'build/audit-fourth' / label
    records = read(directory / 'cases.json')
    receipt = schema_receipt['publicModels'][label]
    expected = set(receipt['caseNames'])
    check(len(records) == len(expected) == count, label+' case count')
    check({r['name'] for r in records} == expected, label+' named inventory')
    check({p.stem for p in directory.iterdir() if p.suffix in suffixes} == expected,
          label+' output inventory')
    current = snapshot(directory)
    check(current == snapshot(directory.with_name(label+'-repeat')), label+' determinism')
    check(current == receipt['sha256ByRelativePath'], label+' hash receipt')
    check(len(current) == receipt['determinismFiles'], label+' determinism count')
    validation = validate_report(ACCEPTANCE / (label+'-validation.json'), directory)
    active = 0
    for record in records:
        raw = (directory / record['source']).read_bytes()
        with zipfile.ZipFile(directory / record['output']) as archive:
            relationships = [r for name in archive.namelist() if name.endswith('.rels')
                             for r in ET.fromstring(archive.read(name))]
            check(all(r.get('TargetMode') != 'External' for r in relationships),
                  label+' external relationship: '+record['name'])
            suffix = ('/'+record['kind'] if record['kind']=='vba' else '/oleObject') if label=='public-compound' else '/image'
            if suffix == '/vba': suffix = '/vbaProject'
            has_active = any(r.get('Type','').endswith(suffix) for r in relationships)
            expectation = record['expectedActiveContainer' if label=='public-compound' else 'expectedActiveImage']
            check(has_active == expectation, label+' activation mismatch: '+record['name'])
            active += int(has_active)
            matches = [name for name in archive.namelist() if archive.read(name) == raw]
            check(bool(matches), label+' raw bytes missing: '+record['name'])
            if not has_active:
                check(any(name.startswith('word/evidence/') for name in matches),
                      label+' raw inert evidence missing: '+record['name'])
    models[label] = {'inputKind':'caller-built public models', 'outputs':count,
                      'schema':validation,'determinismFiles':len(current),
                      'active':active,'inert':count-active,
                      'rawSourceBytesPreserved':True, 'externalRelationships':False}
checks['publicModels'] = models
checks['totalValidatedOutputs'] = 279+24+17

format_log = (ACCEPTANCE / 'dart-format.log').read_text()
test_log = (ACCEPTANCE / 'dart-tests.log').read_text()
python_log = (ACCEPTANCE / 'python-controls.log').read_text()
corpus_log = (ACCEPTANCE / 'corpus-integrity.log').read_text()
js_log = (ACCEPTANCE / 'javascript.log').read_text()
checks['portableCounts'] = {
    'dartTests':int(re.search(r'\+(\d+): All tests passed!',test_log).group(1)),
    'pythonTests':int(re.search(r'Ran (\d+) tests',python_log).group(1)),
    'formattedFiles':int(re.search(r'Formatted (\d+) files \(0 changed\)',format_log).group(1)),
    'retainedCorpusChecks':int(re.search(r'Verified (\d+) source hashes',corpus_log).group(1)),
    'actualCompiledJavascript':bool(re.search(r'Compiled \d+ input bytes .*JavaScript',js_log))}
js_results = {}
for line in js_log.splitlines():
    if 'JavaScript acceptance passed: ' in line:
        name, data = line.split('JavaScript acceptance passed: ',1)
        js_results[name.strip()] = json.loads(data)
check(len(js_results) == 16, 'Expected JavaScript matrix groups: '+str(len(js_results)))
checks['javascriptGroups'] = js_results

report = {'schema':'legacy-doc-parser/independent-acceptance-review', 'version':1,
          'runtimeCommit':HEAD, 'observedHead':git('rev-parse','HEAD').decode().strip(),
          'reviewMethod':'Read completed receipts, independently recompute hashes and inventories, compare Git blobs and actual generated output bytes. No test rerun.',
          'reviewerContribution':'This reviewer authored the list-label fixes; separate verification logic does not call parser or conversion code.',
          'checks':checks, 'issues':issues, 'passed':not issues,
          'limits':['No native Word or LibreOffice rendering performed.',
                    'No full CFB conformance or VBA-code-validity claim.',
                    'No hosted GitHub Actions success or package-publication claim.',
                    'Previous whole-corpus output comparison is recorded separately.']}
(ACCEPTANCE / 'independent-acceptance-review.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':not issues,'issues':issues,'portable':checks['portableCounts'],
                  'sources':len(portable['sourceBefore']),'schemaSources':len(files),
                  'docDerived':len(cases),'publicModels':{k:v['outputs'] for k,v in models.items()},
                  'totalValidatedOutputs':checks['totalValidatedOutputs'],
                  'javascriptGroups':len(js_results)},indent=2))
