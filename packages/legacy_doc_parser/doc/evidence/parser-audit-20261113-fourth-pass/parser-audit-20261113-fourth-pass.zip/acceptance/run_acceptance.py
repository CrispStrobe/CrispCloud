#!/usr/bin/env python3
"""Run this audit's clean-checkout gates and retain exact source identities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('group', choices=['portable', 'schema'])
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--toolchains', type=Path, required=True)
a = p.parse_args()
repo, tc = a.repo.resolve(), a.toolchains.resolve()
out = repo / 'build/audit-fourth/acceptance'
out.mkdir(parents=True, exist_ok=True)
os.chdir(repo)
env = dict(os.environ, PATH=f'{tc}/dart-sdk/bin:{tc}/dotnet:' + os.environ['PATH'],
           PUB_CACHE=str(tc / 'pub-cache'), TMPDIR=str(tc / 'tmp'),
           DOTNET_CLI_HOME=str(tc / 'dotnet-home'),
           DOTNET_SKIP_FIRST_TIME_EXPERIENCE='1', DOTNET_CLI_TELEMETRY_OPTOUT='1',
           CI='true')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def snapshot():
    paths = git('ls-files', '-z', 'lib', 'test', 'tool', 'example',
                'pubspec.yaml', 'analysis_options.yaml', '.github').split('\0')
    return {name: sha(repo / name) for name in paths if name}

status = git('status', '--porcelain')
if status:
    raise SystemExit('Require a clean checkout: ' + status)
before = snapshot()
receipt = {'group': a.group, 'runtimeCommit': git('rev-parse', 'HEAD'),
           'sourceBefore': before, 'statusBefore': status, 'commands': [],
           'dependencies': {name: sha(repo / name) for name in
                            ['pubspec.lock', '.dart_tool/package_config.json']}}
receipt_path = out / f'{a.group}-receipt.json'

def save():
    receipt_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')

def run(name, command):
    print('Starting ' + name, flush=True)
    start = time.monotonic()
    log_path = out / f'{name}.log'
    with log_path.open('w') as log:
        try:
            code = subprocess.run(command, cwd=repo, env=env, stdout=log,
                                  stderr=subprocess.STDOUT, timeout=1200).returncode
        except subprocess.TimeoutExpired:
            log.write('\nACCEPTANCE COMMAND TIMED OUT\n')
            code = -1
    receipt['commands'].append({'name': name, 'argv': list(map(str, command)),
                                'cwd': str(repo), 'exitCode': code,
                                'seconds': round(time.monotonic() - start, 3),
                                'log': log_path.name, 'logSha256': sha(log_path)})
    save()
    print(f'Completed {name}: exit {code}', flush=True)
    if code:
        raise RuntimeError(f'{name} failed: {log_path}')

try:
    if a.group == 'portable':
        for name, command in [
            ('dart-format', ['dart', 'format', '--output=none', '--set-exit-if-changed', 'lib', 'test', 'tool', 'example']),
            ('dart-analyze', ['dart', 'analyze', '--fatal-infos']),
            ('dart-tests', ['dart', 'test', '--reporter', 'expanded']),
            ('python-controls', ['python3', '-m', 'unittest', 'discover', '-s', 'tool/fidelity', '-p', 'test_*.py']),
            ('corpus-integrity', ['python3', 'tool/fidelity/oracle.py']),
            ('javascript', ['python3', 'tool/verify_web.py']),
        ]:
            run(name, command)
        versions = {}
        for tool, command in [('Dart', ['dart', '--version']), ('dotnet', ['dotnet', '--version']),
                              ('Node', ['node', '--version']), ('Python', ['python3', '--version'])]:
            versions[tool] = subprocess.check_output(command, env=env, text=True, stderr=subprocess.STDOUT).strip()
        (out / 'environment.json').write_text(json.dumps({'versions': versions, 'platform': platform.platform(),
             'executables': {str(path): sha(path) for path in [tc / 'dart-sdk/bin/dart', tc / 'dotnet/dotnet']},
             'nugetArchives': {path.name: sha(path) for path in sorted((tc / 'nuget-cache').glob('*.nupkg'))}}, indent=2) + '\n')
    else:
        schema_out = repo / 'build/audit-fourth/schema'
        run('schema-gate', ['python3', 'tool/fidelity/schema.py', '--out', str(schema_out),
                            '--cached-nuget', str(tc / 'nuget-cache')])
        sys.path.insert(0, str(repo / 'tool/fidelity'))
        import schema
        extra = {}
        for label, generator, expected in [
            ('public-media', 'public_metafile_fixture.dart',
             {f'{kind}-{place}-{mutation}' for kind in ('emf', 'wmf') for place in
              ('inline', 'floating', 'textbox-fill') for mutation in ('valid', 'escape', 'truncated', 'bad-size')}),
            ('public-compound', 'public_compound_fixture.dart',
             {f'{kind}-{mutation}' for kind in ('ole', 'vba') for mutation in
              ('valid', 'not-compound', 'missing-required-stream', 'storage-instead-of-stream',
               'wrong-path', 'truncated-stream')}
             | {f'ole-{mutation}' for mutation in ('linked', 'bad-version', 'bad-flags', 'bad-reserved', 'bad-moniker')}),
        ]:
            first = repo / 'build/audit-fourth' / label
            second = repo / 'build/audit-fourth' / (label + '-repeat')
            run(label + '-generate', ['dart', 'run', 'tool/fidelity/' + generator, str(first)])
            run(label + '-repeat', ['dart', 'run', 'tool/fidelity/' + generator, str(second)])
            report = out / (label + '-validation.json')
            run(label + '-validate', ['dotnet', str(schema_out / 'validator/OfficeValidation.dll'), str(first), str(report)])
            hashes = schema.tree_snapshot(first)
            if hashes != schema.tree_snapshot(second):
                raise ValueError(label + ': nondeterministic generation')
            cases = json.loads((first / 'cases.json').read_text())
            if len(cases) != len(expected) or {c['name'] for c in cases} != expected:
                raise ValueError(label + ': incomplete model inventory')
            outputs = schema.office_files(first)
            if len(outputs) != len(expected) or {Path(n).stem for n in outputs} != expected:
                raise ValueError(label + ': incomplete output inventory')
            extra[label] = {'inputKind': 'caller-built public models',
                            'caseNames': sorted(expected),
                            'validation': schema.verify_report(json.loads(report.read_text()), outputs, 0),
                            'determinismFiles': len(hashes), 'sha256ByRelativePath': hashes,
                            'nativeApplicationValidation': False}
        receipt['publicModels'] = extra
    receipt['completed'] = True
except Exception as error:
    receipt['completed'] = False
    receipt['error'] = f'{type(error).__name__}: {error}'
finally:
    receipt['sourceAfter'] = snapshot()
    receipt['sourceUnchanged'] = receipt['sourceAfter'] == before
    receipt['statusAfter'] = git('status', '--porcelain')
    receipt['passed'] = receipt.get('completed', False) and receipt['sourceUnchanged'] and not receipt['statusAfter']
    save()
print(json.dumps({'group': a.group, 'passed': receipt['passed'],
                  'runtimeCommit': receipt['runtimeCommit'], 'error': receipt.get('error')}), flush=True)
raise SystemExit(0 if receipt['passed'] else 1)
