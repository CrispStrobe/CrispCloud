import 'dart:convert';
import 'dart:io';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import '../../test/support/text_unicode_fixture.dart';

void main() {
  final directory = Directory('build/audit-fourth/text-unicode-inputs')
    ..createSync(recursive: true);
  final records = <Map<String, Object?>>[];
  for (final name in [
    ...invalidTextUnicodeCases,
    'split-physical-pieces', 'valid-field', 'unconsumed-auxiliary',
  ]) {
    final bytes = textUnicodeFixture(name);
    File('${directory.path}/$name.doc').writeAsBytesSync(bytes);
    String? text, error;
    try {
      text = extractLegacyWordText(bytes);
    } on FormatException catch (exception) {
      error = exception.message;
    }
    records.add({
      'name': name, 'input': '$name.doc',
      'expectedRejected': invalidTextUnicodeCases.contains(name),
      'actualText': text, 'actualFormatException': error,
    });
  }
  File('${directory.path}/outcomes.json').writeAsStringSync(
    '${const JsonEncoder.withIndent('  ').convert(records)}\n');
}
