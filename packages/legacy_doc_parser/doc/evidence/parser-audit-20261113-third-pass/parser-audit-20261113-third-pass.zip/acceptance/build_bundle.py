#!/usr/bin/env python3
"""Build a new immutable audit archive from the completed third-pass checks."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path('/workspace/scratch/d4b323983ed0')
repo = root / 'legacy-doc-parser'
tested = root / 'parser-acceptance-round3'
logs = root / 'audit-round3-validation'
evidence = repo / 'doc/evidence/parser-audit-20261113-third-pass'
evidence.mkdir(parents=True, exist_ok=True)
archive = evidence / 'parser-audit-20261113-third-pass.zip'
if archive.exists():
    raise SystemExit('Refusing to replace an existing evidence archive')

payloads = {}
def add(name, path):
    if name in payloads:
        raise ValueError('Duplicate archive entry: ' + name)
    payloads[name] = path.read_bytes()

for path in sorted(logs.iterdir()):
    if path.is_file():
        add('acceptance/' + path.name, path)
add('acceptance/run.py', root / 'audit_round3_acceptance.py')
add('acceptance/verify_receipts.py', root / 'verify_round3_receipts.py')
add('acceptance/build_bundle.py', Path(__file__))
add('dependencies/resolved-pubspec.lock', tested / 'pubspec.lock')
for name in ('upstream.json', 'OfficeValidation.csproj'):
    add('dependencies/' + name, tested / 'tool/office-validation' / name)

for category in ('cfb', 'models', 'metadata', 'media'):
    folder = root / ('audit-round3-' + category)
    for path in sorted(folder.iterdir()):
        if path.is_file() and path.suffix in ('.log', '.dart'):
            add('regressions/' + category + '/' + path.name, path)

schema = tested / 'build/parser-audit-round3-schema'
for path in sorted(schema.iterdir()):
    if path.is_file():
        add('schema/' + path.name, path)
for path in sorted((schema / 'controls').rglob('*')):
    if path.is_file():
        add('schema/controls/' + path.relative_to(schema / 'controls').as_posix(), path)

for name in ('nested-cached-controls.doc', 'nested-cached-controls.docx'):
    add('new-cases/nested-fields/' + name, schema / 'corpus/nested-fields' / name)
for path in sorted((schema / 'corpus/list-metadata').iterdir()):
    if path.is_file():
        add('new-cases/list-metadata/' + path.name, path)
for path in sorted((tested / 'build/parser-audit-round3-public-media').iterdir()):
    if path.is_file():
        add('public-model-media/' + path.name, path)

history = subprocess.check_output([
    'git', 'log', '--reverse', '--format=%H%x09%s',
    '7aee6425b74cfe9bf607c20e11e0a0dce8431322..b1dff952a11e7de058a924cf7da8752574d0fbc5'
], cwd=repo, text=True)
checkpoints = [{'sha': line.split('\t', 1)[0], 'message': line.split('\t', 1)[1]}
               for line in history.splitlines()]
payloads['checkpoints.json'] = (json.dumps(checkpoints, indent=2) + '\n').encode()
manifest = {'schema': 'legacy-doc-parser/audit-evidence', 'version': 1,
            'runtime_commit': 'b1dff952a11e7de058a924cf7da8752574d0fbc5',
            'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                      for name, data in sorted(payloads.items())}}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
payloads['manifest.json'] = manifest_bytes
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(payloads.items()):
        item = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
        item.create_system = 3
        item.external_attr = 0o100644 << 16
        item.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(item, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert set(bundle.namelist()) == set(payloads)
    for name, record in manifest['files'].items():
        content = bundle.read(name)
        assert len(content) == record['bytes']
        assert hashlib.sha256(content).hexdigest() == record['sha256']
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(evidence / 'manifest.json').write_bytes(manifest_bytes)
(evidence / 'SHA256SUMS').write_text(f'{digest}  {archive.name}\n')
print(json.dumps({'path': str(archive), 'bytes': archive.stat().st_size,
                  'sha256': digest, 'files': len(manifest['files']),
                  'manifest_entries_verified': True}))
