#!/usr/bin/env python3
"""Retain clean-checkout acceptance commands and source identities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument("group", choices=["portable", "schema"])
parser.add_argument("--repo", type=Path, required=True)
parser.add_argument("--out", type=Path, required=True)
args = parser.parse_args()
repo, out = args.repo.resolve(), args.out.resolve()
out.mkdir(parents=True, exist_ok=True)
work = Path("/workspace/scratch/d4b323983ed0")
environment = dict(os.environ)
environment.update({
    "PATH": f"{work}/dart-sdk/bin:{work}/dotnet:" + os.environ["PATH"],
    "PUB_CACHE": str(work / "pub-cache"),
    "TMPDIR": str(work / "tmp"),
    "DOTNET_CLI_HOME": str(work / "dotnet-home"),
    "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
    "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
    "CI": "true",
})

def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=repo, text=True)

def source_hashes():
    paths = git("ls-files", "-z", "lib", "test", "tool", "example",
                "pubspec.yaml", "analysis_options.yaml", ".github").split("\0")
    return {path: hashlib.sha256((repo / path).read_bytes()).hexdigest()
            for path in paths if path}

status = git("status", "--porcelain")
if status:
    raise SystemExit("Acceptance requires a clean checkout: " + status)
before = source_hashes()
receipt = {"group": args.group, "runtime_commit": git("rev-parse", "HEAD").strip(),
           "source_before": before, "commands": [], "status_before": status}
commands = [
    ("dart-format", ["dart", "format", "--output=none", "--set-exit-if-changed",
                     "lib", "test", "tool", "example"]),
    ("dart-analyze", ["dart", "analyze", "--fatal-infos"]),
    ("dart-tests", ["dart", "test", "--reporter", "expanded"]),
    ("python-controls", ["python3", "-m", "unittest", "discover", "-s",
                         "tool/fidelity", "-p", "test_*.py"]),
    ("corpus-integrity", ["python3", "tool/fidelity/oracle.py"]),
    ("javascript", ["python3", "tool/verify_web.py"]),
] if args.group == "portable" else [
    ("schema-gate", ["python3", "tool/fidelity/schema.py", "--out",
                     "build/parser-audit-round3-schema", "--cached-nuget",
                     str(work / "nuget-cache")]),
    ("public-media-generate", ["dart", "run", "tool/fidelity/public_metafile_fixture.dart",
                               "build/parser-audit-round3-public-media"]),
    ("public-media-repeat", ["dart", "run", "tool/fidelity/public_metafile_fixture.dart",
                             "build/parser-audit-round3-public-media-repeat"]),
    ("public-media-schema", ["dotnet", "build/parser-audit-round3-schema/validator/OfficeValidation.dll",
                             str(repo / "build/parser-audit-round3-public-media"),
                             str(out / "public-media-validation.json")]),
]
for name, command in commands:
    start = time.monotonic()
    print(f"Starting {name}", flush=True)
    with (out / f"{name}.log").open("w") as log:
        try:
            result = subprocess.run(command, cwd=repo, env=environment,
                                    stdout=log, stderr=subprocess.STDOUT,
                                    timeout=1200, check=False)
            code = result.returncode
        except subprocess.TimeoutExpired:
            log.write("\nACCEPTANCE COMMAND TIMED OUT\n")
            code = -1
    receipt["commands"].append({"name": name, "argv": command,
                                "exit_code": code,
                                "seconds": round(time.monotonic() - start, 3),
                                "log": f"{name}.log"})
    print(f"Completed {name}: exit {code}", flush=True)
    (out / f"{args.group}-receipt.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n")
receipt["artifact_checks_passed"] = True
if args.group == "schema" and all(item["exit_code"] == 0 for item in receipt["commands"]):
    try:
        sys.path.insert(0, str(repo / "tool/fidelity"))
        import schema
        first = repo / "build/parser-audit-round3-public-media"
        repeated = repo / "build/parser-audit-round3-public-media-repeat"
        initial_hashes, repeated_hashes = schema.tree_snapshot(first), schema.tree_snapshot(repeated)
        if initial_hashes != repeated_hashes:
            raise ValueError("Public metafile fixture generation was not deterministic")
        cases = json.loads((first / "cases.json").read_text())
        expected_names = {f"{kind}-{placement}-{mutation}" for kind in ("emf", "wmf")
                          for placement in ("inline", "floating", "textbox-fill")
                          for mutation in ("valid", "escape", "truncated", "bad-size")}
        if len(cases) != 24 or {case["name"] for case in cases} != expected_names:
            raise ValueError("Public metafile fixture inventory differs from the required 24 cases")
        expected = schema.office_files(first)
        if len(expected) != 24 or {Path(path).stem for path in expected} != expected_names:
            raise ValueError("Public metafile outputs are missing, duplicated, or unexpected")
        validation = schema.verify_report(json.loads((out / "public-media-validation.json").read_text()),
                                          expected, 0)
        extra_receipt = {"runtime_commit": receipt["runtime_commit"], "validation": validation,
                         "case_names": sorted(expected_names), "input_kind": "public model plus raw EMF/WMF",
                         "determinism": {"passed": True, "files": len(initial_hashes),
                                         "sha256ByRelativePath": initial_hashes},
                         "schema_only": True, "native_application_validation": False}
        (out / "public-media-receipt.json").write_text(json.dumps(extra_receipt, indent=2, sort_keys=True) + "\n")
        receipt["public_media"] = {"validation": validation, "determinism_files": len(initial_hashes)}
    except Exception as error:
        receipt["artifact_checks_passed"] = False
        receipt["artifact_check_error"] = f"{type(error).__name__}: {error}"
        print(receipt["artifact_check_error"], flush=True)
receipt["source_after"] = source_hashes()
receipt["source_unchanged"] = receipt["source_after"] == before
receipt["status_after"] = git("status", "--porcelain")
receipt["passed"] = (all(item["exit_code"] == 0 for item in receipt["commands"])
                     and receipt["source_unchanged"] and not receipt["status_after"]
                     and receipt["artifact_checks_passed"])
(out / f"{args.group}-receipt.json").write_text(
    json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(json.dumps({"group": args.group, "passed": receipt["passed"],
                  "runtime_commit": receipt["runtime_commit"]}), flush=True)
raise SystemExit(0 if receipt["passed"] else 1)
