#!/usr/bin/env python3
"""Read-only verification of third-pass audit receipts and existing outputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--receipts', type=Path, required=True)
args = parser.parse_args()
repo, receipts = args.repo.resolve(), args.receipts.resolve()
os.chdir(repo)
sys.path.insert(0, str(repo / 'tool/fidelity'))
import schema

def read(name):
    return json.loads((receipts / name).read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True)

head = git('rev-parse', 'HEAD').strip()
assert not git('status', '--porcelain')
portable = read('portable-final-receipt.json')
assert [c['name'] for c in portable['commands']] == [
    'dart-format', 'dart-analyze', 'dart-tests', 'python-controls',
    'corpus-integrity', 'javascript']
assert all(c['exit_code'] == 0 for c in portable['commands'])
assert portable['optional_check']['status'] == 'blocked and omitted'
assert not read('approval-review-note.json')['dry_run_success_claimed']
for name in ('portable-final-receipt.json', 'schema-final-receipt.json'):
    receipt = read(name)
    assert receipt['runtime_commit'] == head
    assert receipt['passed'] and receipt['source_unchanged']
    assert receipt['source_before'] == receipt['source_after']
    for relative, digest in receipt['source_after'].items():
        assert hashlib.sha256((repo / relative).read_bytes()).hexdigest() == digest

main = repo / 'build/parser-audit-round3-schema'
report = json.loads((main / 'report.json').read_text())
assert report['passed'] and report['gitHead'] == head
core = schema.verify_report(json.loads((main / 'schema-validation.json').read_text()),
                            schema.office_files(main / 'corpus'), 0)
assert core['files'] == 273 and core['errors'] == 0
media = repo / 'build/parser-audit-round3-public-media'
repeated = repo / 'build/parser-audit-round3-public-media-repeat'
hashes = schema.tree_snapshot(media)
assert hashes == schema.tree_snapshot(repeated)
extra = schema.verify_report(read('public-media-validation.json'), schema.office_files(media), 0)
assert extra['files'] == 24 and extra['errors'] == 0
assert read('public-media-receipt.json')['determinism']['sha256ByRelativePath'] == hashes
comparison = read('previous-output-comparison.json')
assert comparison['runtime_commit'] == head and comparison['passed']
assert comparison['previous_docx'] == comparison['unchanged_docx'] == 263
assert comparison['current_docx'] == 273
assert comparison['changed'] == comparison['removed'] == []
print(json.dumps({'passed': True, 'runtime_commit': head, 'source_unchanged': True,
                  'doc_derived_schema_outputs': core['files'],
                  'public_model_schema_outputs': extra['files'],
                  'previous_docx_unchanged': comparison['unchanged_docx'],
                  'publication_dry_run': 'blocked and omitted'}))
