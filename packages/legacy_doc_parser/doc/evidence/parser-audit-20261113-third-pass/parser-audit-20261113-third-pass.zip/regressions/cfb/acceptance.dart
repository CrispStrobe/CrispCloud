import 'dart:convert';

import '/workspace/scratch/d4b323983ed0/legacy-doc-parser/tool/compound_directory_web_acceptance.dart';
import '/workspace/scratch/d4b323983ed0/legacy-doc-parser/tool/compound_ownership_web_acceptance.dart';
import '/workspace/scratch/d4b323983ed0/legacy-doc-parser/tool/compound_web_acceptance.dart';

void main() {
  print(jsonEncode({
    'directories': verifyCompoundDirectoryWebCases(),
    'ownership': verifyCompoundOwnershipWebCases(),
    'allocation': verifyCompoundAllocationWebCases(),
  }));
}
