import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import '../legacy-doc-parser/test/support/list_word_fixture.dart';

void main() {
  for (final label in ['%1', '\u0000 literal %1']) {
    final doc = parseLegacyWordDocument(listWordFixture(levels: [
      listFixtureLevel(start: 7, text: label,
        placeholders: label.startsWith('\u0000') ? [1] : []),
    ]));
    print('Source label: ${label.codeUnits}; model: ${doc.numbering.single.levels.single.text}');
    print(doc.safeHtml);
  }
}
