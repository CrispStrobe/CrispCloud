import 'dart:convert';

import '../legacy-doc-parser/tool/public_field_web_acceptance.dart';

void main() {
  print(jsonEncode(verifyPublicFieldWebAcceptance()));
}
