#!/usr/bin/env python3
"""Independent OOXML controls for observed field import divergences."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

WORK = Path('/workspace/scratch/d4b323983ed0')
REPO = WORK / 'parser-acceptance'
EVIDENCE = WORK / 'audit-validation'
ROOT = EVIDENCE / 'native-field-attribution'
INPUT = ROOT / 'input'
PDF = ROOT / 'pdf'
LOGS = ROOT / 'logs'
DOTNET = WORK / 'dotnet/dotnet'
VALIDATOR = REPO / 'build/parser-audit-schema/validator/OfficeValidation.dll'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
XML = 'http://www.w3.org/XML/1998/namespace'
ET.register_namespace('w', W)
native_env = os.environ.copy()
native_env.update({
    'TMPDIR': str(WORK / 'tmp'),
    'PUB_CACHE': str(WORK / 'pub-cache'),
})
INPUT.mkdir(parents=True, exist_ok=False)
PDF.mkdir()
LOGS.mkdir()
commands = []

def run(name, args, timeout=90):
    argv = [str(arg) for arg in args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=REPO, env=native_env, text=True,
                            capture_output=True, timeout=timeout)
    (LOGS / f'{name}.stdout.log').write_text(result.stdout)
    (LOGS / f'{name}.stderr.log').write_text(result.stderr)
    commands.append({
        'name': name, 'argv': argv, 'cwd': str(REPO),
        'environment_overrides': {key: native_env[key] for key in ('TMPDIR','PUB_CACHE')},
        'started_utc': started, 'exit_code': result.returncode,
        'stdout': f'logs/{name}.stdout.log', 'stderr': f'logs/{name}.stderr.log',
    })
    return result

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def node(tag, attributes=None, text=None):
    result = ET.Element(f'{{{W}}}{tag}', {
        f'{{{W}}}{key}': value for key, value in (attributes or {}).items()
    })
    result.text = text
    return result

def run_node(element):
    result = node('r')
    result.append(element)
    return result

def text(value):
    result = node('t', text=value)
    result.set(f'{{{XML}}}space', 'preserve')
    return run_node(result)

def code(value):
    result = node('instrText', text=value)
    result.set(f'{{{XML}}}space', 'preserve')
    return run_node(result)

def field(instruction, result):
    return [
        run_node(node('fldChar', {'fldCharType':'begin','fldLock':'1','dirty':'0'})),
        *instruction,
        run_node(node('fldChar', {'fldCharType':'separate'})),
        *result,
        run_node(node('fldChar', {'fldCharType':'end'})),
    ]

def page():
    return field([code(' PAGE ')], [text('2')])

def nested(inner):
    ref = field([code(' REF Name ')], [text('pre'), *inner, text('post')])
    return field(
        [code(' IF '), *ref, code(' = "pre2post" "yes" "no" ')],
        [text('Visible')],
    )

cases = {
    'independent-nested-page': {
        'runs': nested(page()), 'expected':'AVisibleZ',
        'purpose':'Independently author the same IF > REF-result > PAGE field tree.'},
    'independent-nested-page-flattened': {
        'runs': nested([text('2')]), 'expected':'AVisibleZ',
        'purpose':'Diagnostic only: replace the innermost PAGE with its literal cached result, removing that field semantics.'},
    'independent-nested-page-absent': {
        'runs': nested([]), 'expected':'AVisibleZ',
        'purpose':'Diagnostic only: omit the inner PAGE and its cache, retaining outer cached Visible.'},
    'independent-direct-page-in-instruction': {
        'runs':field([code(' IF '), *page(), code(' = 2 "yes" "no" ')], [text('Visible')]),
        'expected':'AVisibleZ',
        'purpose':'Distinguish PAGE directly in the IF instruction from PAGE inside a nested field result.'},
    'independent-top-level-page': {
        'runs':page(), 'expected':'A2Z',
        'purpose':'Check whether this native importer retains a deliberately stale locked PAGE cache.'},
    'independent-nested-quote-in-result': {
        'runs':nested(field([code(' QUOTE "2" ')], [text('2')])),
        'expected':'AVisibleZ',
        'purpose':'Replace the innermost PAGE field with QUOTE, retaining field topology and cached text.'},
    'ordinary-empty-ref': {
        'runs':field([code(' REF Hidden ')], []), 'expected':'AZ',
        'purpose':'Independently author the same locked empty REF, with no private source flag or binary parser involved.'},
    'ordinary-empty-ref-explicit-text': {
        'runs':field([code(' REF Hidden ')], [text('')]), 'expected':'AZ',
        'purpose':'Test whether an explicit empty w:t run changes handling of a locked empty cached REF.'},
    'ordinary-cached-ref': {
        'runs':field([code(' REF Hidden ')], [text('Cached')]), 'expected':'ACachedZ',
        'purpose':'Keep the missing bookmark but provide a nonempty locked cached REF result.'},
    'ordinary-empty-ref-known-bookmark': {
        'runs':field([code(' REF Hidden ')], []), 'expected':'AZ',
        'bookmark':True,
        'purpose':'Retain an empty cache but provide an empty Hidden bookmark, isolating missing-target recalculation.'},
}

def package(path, definition):
    document = node('document')
    body = node('body')
    paragraph = node('p')
    if definition.get('bookmark'):
        paragraph.extend([
            node('bookmarkStart', {'id':'0', 'name':'Hidden'}),
            node('bookmarkEnd', {'id':'0'}),
        ])
    paragraph.extend([text('A'), *definition['runs'], text('Z')])
    body.append(paragraph)
    section = node('sectPr')
    section.append(node('pgSz', {'w':'12240', 'h':'15840'}))
    body.append(section)
    document.append(body)
    settings = node('settings')
    settings.append(node('updateFields', {'val':'false'}))
    parts = {
        '[Content_Types].xml': (
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
            '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>'
            '</Types>').encode(),
        '_rels/.rels': (
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f'<Relationship Id="rId1" Type="{R}/officeDocument" Target="word/document.xml"/>'
            '</Relationships>').encode(),
        'word/document.xml': ET.tostring(document, encoding='utf-8', xml_declaration=True),
        'word/settings.xml': ET.tostring(settings, encoding='utf-8', xml_declaration=True),
        'word/_rels/document.xml.rels': (
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f'<Relationship Id="rId1" Type="{R}/settings" Target="settings.xml"/>'
            '</Relationships>').encode(),
    }
    with ZipFile(path, 'w', compression=ZIP_DEFLATED) as z:
        for name, value in parts.items():
            entry = ZipInfo(name, date_time=(1980,1,1,0,0,0))
            entry.compress_type = ZIP_DEFLATED
            z.writestr(entry, value)
    return parts['word/document.xml']

def projection(xml):
    roots, stack = [], []
    def append(value):
        target = roots if not stack else stack[-1]['result' if stack[-1]['separated'] else 'instruction']
        target.append(value)
    for run in ET.fromstring(xml).iter(f'{{{W}}}r'):
        for item in run:
            local = item.tag.removeprefix(f'{{{W}}}')
            if local == 'fldChar':
                kind = item.get(f'{{{W}}}fldCharType')
                if kind == 'begin':
                    value = {'field':True,'lock':item.get(f'{{{W}}}fldLock'),
                             'dirty':item.get(f'{{{W}}}dirty'),'instruction':[],
                             'result':[],'separated':False}
                    append(value)
                    stack.append(value)
                elif kind == 'separate':
                    if not stack or stack[-1]['separated']:
                        raise ValueError('Unmatched field separator')
                    stack[-1]['separated'] = True
                elif kind == 'end':
                    if not stack:
                        raise ValueError('Unmatched field end')
                    stack.pop()
            elif local in ('t','instrText'):
                append({local:item.text or ''})
    if stack:
        raise ValueError('Unclosed field')
    return roots

head = run('runtime-head', ['git','rev-parse','HEAD']).stdout.strip()
status_before = run('status-before', ['git','status','--porcelain=v1']).stdout
run('soffice-version', [SOFFICE,'--version'])
run('pdftotext-version', ['/usr/bin/pdftotext','-v'])
authoring = {}
for name, definition in cases.items():
    xml = package(INPUT / f'{name}.docx', definition)
    (INPUT / f'{name}.document.xml').write_bytes(xml)
    authoring[name] = {
        'expected_normalized_text':definition['expected'],
        'purpose':definition['purpose'], 'field_tree':projection(xml),
    }
(ROOT / 'authoring.json').write_text(json.dumps(authoring, indent=2) + '\n')
source_files = list((EVIDENCE / 'native-fields-input').iterdir())
source_before = {str(path.relative_to(EVIDENCE)):sha(path) for path in source_files}
controls_before = {path.name:sha(path) for path in INPUT.iterdir()}
with ZipFile(EVIDENCE / 'native-fields-input/nested-results.docx') as z:
    nested_original = projection(z.read('word/document.xml'))
with ZipFile(EVIDENCE / 'native-fields-input/private-result.docx') as z:
    private_original = projection(z.read('word/document.xml'))
equivalence = {
    'independent_nested_matches_parser_field_tree':nested_original == authoring['independent-nested-page']['field_tree'],
    'ordinary_empty_ref_matches_private_parser_field_tree':private_original == authoring['ordinary-empty-ref']['field_tree'],
    'nested_parser_field_tree':nested_original,
    'private_parser_field_tree':private_original,
}
(ROOT / 'field-tree-equivalence.json').write_text(json.dumps(equivalence, indent=2) + '\n')
schema = run('validate-controls', [DOTNET,VALIDATOR,INPUT,ROOT/'schema-report.json'])
conversion = run('render-controls', [SOFFICE,'--headless','--convert-to','pdf','--outdir',PDF,
    *[INPUT/f'{name}.docx' for name in cases]])
results = []
for name, definition in cases.items():
    pdf, txt = PDF/f'{name}.pdf', PDF/f'{name}.txt'
    result = {
        'name':name,'purpose':definition['purpose'],
        'input_sha256':controls_before[f'{name}.docx'],
        'expected_normalized_text':definition['expected'],'pdf_created':pdf.exists(),
    }
    if pdf.exists():
        extracted = run(f'extract-{name}', ['/usr/bin/pdftotext','-enc','UTF-8',pdf,txt])
        result['extraction_exit_code'] = extracted.returncode
        result['pdf_sha256'] = sha(pdf)
        if txt.exists():
            actual = txt.read_text()
            normalized = re.sub(r'\s+', '', actual)
            result.update(actual_text=actual, actual_normalized_text=normalized,
                          matches_expected=normalized == definition['expected'])
    results.append(result)
status_after = run('status-after', ['git','status','--porcelain=v1']).stdout
source_after = {str(path.relative_to(EVIDENCE)):sha(path) for path in source_files}
controls_after = {path.name:sha(path) for path in INPUT.iterdir()}
sdk = json.loads((ROOT/'schema-report.json').read_text())
report = {
    'kind':'independent-native-field-attribution',
    'runtime_commit':head,
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'authoring':'Python ElementTree plus ZIP; independent explicit OOXML field controls, no production writer or binary parser used.',
    'scope':'Native visible-text attribution only. Diagnostic flattened/absent PAGE controls intentionally change source semantics and are not production proposals.',
    'commands':commands,
    'sources':[
        {'url':'https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.fieldchar?view=openxml-3.0.1',
         'supports':'Complex fields use start/separator/end markers and permit nested fields.'},
        {'url':'https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.fieldchar.fieldlock?view=openxml-3.0.1',
         'supports':'fldLock specifies that a field should not be recalculated.'},
        {'url':'https://learn.microsoft.com/en-us/openspecs/office_file_formats/ms-doc/28ab752b-055a-4725-8797-159bba0d125c',
         'supports':'fPrivateResult indicates result content is not intended for user display.'},
    ],
    'normalization':'Remove Unicode whitespace; raw pdftotext UTF-8 retained.',
    'validator_sha256':sha(VALIDATOR),
    'validator_schema_exit_code':schema.returncode,
    'schema_files':sdk['Files'],'schema_failures':sdk['Failures'],
    'schema_report_sha256':sha(ROOT/'schema-report.json'),
    'conversion_exit_code':conversion.returncode,
    'field_tree_equivalence':{key:value for key,value in equivalence.items() if isinstance(value,bool)},
    'original_smoke_fixtures_unchanged':source_before==source_after,
    'original_smoke_fixture_hashes_before':source_before,
    'original_smoke_fixture_hashes_after':source_after,
    'control_hashes_before':controls_before,'control_hashes_after':controls_after,
    'controls_unchanged':controls_before==controls_after,
    'repository_clean_before':status_before=='','repository_clean_after':status_after=='',
    'cases':results,
    'all_text_expectations_match':all(case.get('matches_expected') for case in results),
}
(ROOT/'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'report':str(ROOT/'report.json'),'schema_files':sdk['Files'],
    'schema_failures':sdk['Failures'],'equivalence':report['field_tree_equivalence'],
    'cases':[{key:case.get(key) for key in ('name','expected_normalized_text','actual_normalized_text','matches_expected')} for case in results],
},indent=2))
