#!/usr/bin/env python3
"""Native text smoke for converted field fixtures; never imports source DOCs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

WORK = Path('/workspace/scratch/d4b323983ed0')
REPO = WORK / 'parser-acceptance'
EVIDENCE = WORK / 'audit-validation'
INPUT = EVIDENCE / 'native-fields-input'
OUTPUT = EVIDENCE / 'native-fields-pdf'
LOGS = EVIDENCE / 'native-fields-logs'
DART = WORK / 'dart-sdk/bin/dart'
SOFFICE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
PDFTOTEXT = Path('/usr/bin/pdftotext')
EXPECTED = {
    'formula': 'A999Z',
    'nested-results': 'AVisibleZ',
    'private-result': 'AZ',
    'private-instruction-result': 'AVisibleZ',
    'unsupported-result': 'AVisibleZ',
}

native_env = os.environ.copy()
native_env.update({
    'TMPDIR': str(WORK / 'tmp'),
    'PUB_CACHE': str(WORK / 'pub-cache'),
})
OUTPUT.mkdir(exist_ok=False)
LOGS.mkdir(exist_ok=False)
commands = []

def run(name, args, timeout=90):
    argv = [str(arg) for arg in args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(
        argv, cwd=REPO, env=native_env, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout,
    )
    (LOGS / f'{name}.stdout.log').write_text(result.stdout)
    (LOGS / f'{name}.stderr.log').write_text(result.stderr)
    commands.append({
        'name': name, 'argv': argv, 'cwd': str(REPO),
        'environment_overrides': {
            key: native_env[key] for key in ('TMPDIR', 'PUB_CACHE')
        },
        'started_utc': started, 'exit_code': result.returncode,
        'stdout': f'native-fields-logs/{name}.stdout.log',
        'stderr': f'native-fields-logs/{name}.stderr.log',
    })
    return result

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

head = run('runtime-head', ['git', 'rev-parse', 'HEAD']).stdout.strip()
before = run('status-before', ['git', 'status', '--porcelain=v1']).stdout
run('dart-version', [DART, '--version'])
run('soffice-version', [SOFFICE, '--version'])
run('pdftotext-version', [PDFTOTEXT, '-v'])
generation = run(
    'generate-fields', [DART, 'run', 'tool/fidelity/nested_field_fixture.dart', INPUT],
)
if generation.returncode:
    raise RuntimeError('Fixture generation failed; consult retained logs.')
inputs_before = {path.name: digest(path) for path in sorted(INPUT.iterdir())}

# Explicit DOCX filenames prevent the source DOC fixtures from reaching Office.
conversion = run('render-converted-docx', [
    SOFFICE, '--headless', '--convert-to', 'pdf', '--outdir', OUTPUT,
    *[INPUT / f'{name}.docx' for name in EXPECTED],
])
cases = []
for name, expected in EXPECTED.items():
    pdf = OUTPUT / f'{name}.pdf'
    text = OUTPUT / f'{name}.txt'
    case = {
        'name': name,
        'input': f'native-fields-input/{name}.docx',
        'input_sha256': inputs_before[f'{name}.docx'],
        'expected_normalized_text': expected,
        'pdf_created': pdf.exists(),
    }
    if pdf.exists():
        extracted = run(f'extract-{name}', [PDFTOTEXT, '-enc', 'UTF-8', pdf, text])
        case['pdf_sha256'] = digest(pdf)
        case['text_extraction_exit_code'] = extracted.returncode
        if text.exists():
            actual = text.read_text()
            normalized = re.sub(r'\s+', '', actual)
            case.update({
                'text': f'native-fields-pdf/{name}.txt',
                'actual_text': actual,
                'actual_normalized_text': normalized,
                'matches_expected': normalized == expected,
            })
    cases.append(case)

after = run('status-after', ['git', 'status', '--porcelain=v1']).stdout
inputs_after = {path.name: digest(path) for path in sorted(INPUT.iterdir())}
report = {
    'kind': 'bounded-converted-field-native-text-smoke',
    'runtime_commit': head,
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_doc_files_imported': False,
    'normalization': 'Remove Unicode whitespace from pdftotext UTF-8 output; raw text retained.',
    'scope': 'Five converted DOCX files; visible field text only. No pagination, rendering equivalence, original DOC import, or native Microsoft Word fidelity claim.',
    'initial_setup_observation': {
        'command': [str(SOFFICE), '--version'],
        'environment': 'TMPDIR was not set for the initial probe.',
        'observed_stderr': "mktemp: failed to create directory via template ‘/tmp/codex-soffice.XXXXXXXX’: No such file or directory",
        'outcome': 'No native import ran. Repeated the version check and all actual work with the declared writable TMPDIR.',
    },
    'commands': commands,
    'conversion_exit_code': conversion.returncode,
    'repository_clean_before': before == '',
    'repository_clean_after': after == '',
    'fixture_hashes_before': inputs_before,
    'fixture_hashes_after': inputs_after,
    'fixtures_unchanged': inputs_before == inputs_after,
    'cases': cases,
    'passed': (
        head == '92486f82dd746ab14b5ccf1310f629b74f7bfa5a'
        and not before and not after and inputs_before == inputs_after
        and conversion.returncode == 0
        and all(case.get('matches_expected') for case in cases)
    ),
}
path = EVIDENCE / 'native-fields-report.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'report': str(path), 'passed': report['passed'],
    'cases': [{key: case.get(key) for key in (
        'name', 'expected_normalized_text', 'actual_normalized_text', 'matches_expected',
    )} for case in cases],
}, indent=2))
