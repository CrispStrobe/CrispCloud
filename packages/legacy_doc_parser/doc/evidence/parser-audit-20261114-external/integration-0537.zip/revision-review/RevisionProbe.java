import java.nio.file.Files;
import java.nio.file.Path;
import java.io.ByteArrayInputStream;
import org.apache.poi.hwpf.HWPFDocument;

public class RevisionProbe {
  public static void main(String[] args) throws Exception {
    try (var doc = new HWPFDocument(new ByteArrayInputStream(Files.readAllBytes(Path.of(args[0]))))) {
      var range = doc.getRange();
      for (int i=0;i<range.numParagraphs();i++) {
        var p=range.getParagraph(i);
        if (!p.text().contains("This proposal contemplates")) continue;
        System.out.printf("paragraph=%d cp=%d..%d text=%s%n",i,p.getStartOffset(),p.getEndOffset(),p.text().replace("\r","\\r"));
        for (int j=0;j<p.numCharacterRuns();j++) {
          var r=p.getCharacterRun(j);
          System.out.printf("run=%d cp=%d..%d ins=%s del=%s text=%s%n",j,r.getStartOffset(),r.getEndOffset(),r.isMarkedInserted(),r.isMarkedDeleted(),r.text().replace("\r","\\r"));
        }
      }
    }
  }
}
