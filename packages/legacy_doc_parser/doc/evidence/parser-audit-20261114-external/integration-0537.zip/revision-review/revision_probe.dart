import 'dart:io';
import 'dart:convert';
import 'package:legacy_doc_parser/legacy_doc_parser.dart';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';

Iterable<LegacyWordParagraph> paragraphs(List<LegacyWordBlock> blocks) sync* {
  for (final block in blocks) {
    if (block is LegacyWordParagraph) yield block;
    if (block is LegacyWordTable) {
      for (final row in block.rows) {
        for (final cell in row.cells) {
          yield* paragraphs(cell.blocks);
        }
      }
    }
  }
}

void main(List<String> args) {
  final bytes=File(args.single).readAsBytesSync();
  final compound=BoundedCfbReader(bytes);
  for (final name in ['WordDocument','0Table','1Table']) {
    final stream=compound.readPath(name);
    if (stream != null) File('/workspace/scratch/352c46c2574d/legacy-revision-review/$name.bin').writeAsBytesSync(stream);
  }
  final document=parseLegacyWordDocument(bytes);
  for (final p in paragraphs(document.blocks)) {
    final text=p.runs.map((r)=>r.text).join();
    if (!text.contains('This proposal contemplates')) continue;
    print(jsonEncode({
      'paragraphStartCp':p.startCp,'paragraphEndCp':p.endCp,
      'markInserted':p.mark?.inserted,'markDeleted':p.mark?.deleted,
      'runs':[for (final r in p.runs) {
        'startCp':r.startCp,'endCp':r.endCp,'inserted':r.inserted,
        'deleted':r.deleted,'text':r.text,
        'insertionAuthor':r.insertionRevision?.author,
        'deletionAuthor':r.deletionRevision?.author,
      }],
    }));
  }
}
