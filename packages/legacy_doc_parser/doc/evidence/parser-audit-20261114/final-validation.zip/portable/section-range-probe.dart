import 'package:legacy_doc_parser/legacy_doc_parser.dart';
void main() {
  final document = LegacyWordDocument(
    blocks: const [LegacyWordParagraph(startCp: 0, endCp: 2, runs: [LegacyWordRun(startCp: 0, endCp: 1, text: 'A')])],
    sections: const [LegacyWordSection(startCp: 0, endCp: 3, marginLeftTwips: -1), LegacyWordSection(startCp: 3, endCp: 4)],
    plainText: 'A', safeHtml: '',
  );
  try { final result = convertLegacyWordDocument(document); print('ACCEPTED ${result.bytes.length} bytes; sections=${result.preservedCounts["sections"]}'); }
  on FormatException catch(e) { print('REJECTED $e'); }
}
