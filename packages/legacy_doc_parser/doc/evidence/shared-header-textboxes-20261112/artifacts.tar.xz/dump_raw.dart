import 'dart:io';
import 'package:legacy_doc_parser/src/bounded_cfb_reader.dart';

void main(List<String> files) {
  for (final path in files) {
    final file = File(path);
    final cfb = BoundedCfbReader(file.readAsBytesSync());
    for (final stream in ['WordDocument', '0Table', '1Table']) {
      final body = cfb.readPath(stream);
      if (body != null) File('$path.$stream.bin').writeAsBytesSync(body);
    }
  }
}
