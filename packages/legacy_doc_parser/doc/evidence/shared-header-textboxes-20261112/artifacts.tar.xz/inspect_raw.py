import json,struct,sys
from pathlib import Path
u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
u32=lambda b,o:struct.unpack_from('<I',b,o)[0]
def record(b,o):
 h,t,n=struct.unpack_from('<HHI',b,o);return h&15,h>>4,t,b[o+8:o+8+n],o+8+n
for name in sys.argv[1:]:
 p=Path(name);w=Path(str(p)+'.WordDocument.bin').read_bytes();t=Path(str(p)+('.1Table.bin' if u16(w,10)&0x200 else '.0Table.bin')).read_bytes()
 pair=lambda i:t[u32(w,154+i*8):u32(w,154+i*8)+u32(w,158+i*8)]
 out={'file':name,'storyLengths':[u32(w,i) for i in [76,80,84,92,96,100,104]],'plcs':{}}
 for i,size in [(11,0),(41,26),(58,22),(75,6)]:
  b=pair(i)
  if not b:continue
  n=(len(b)-4)//(size+4);cp=[u32(b,j*4) for j in range(n+1)];d=b[(n+1)*4:]
  if i==41:v=[{'shape':u32(d,j*size),'box':struct.unpack_from('<iiii',d,j*size+4),'flags':u16(d,j*size+20)} for j in range(n)]
  elif i==58:v=[{'count':u32(d,j*size),'reusable':u16(d,j*size+8),'shape':u32(d,j*size+14),'raw':d[j*size:(j+1)*size].hex()} for j in range(n)]
  else:v=[d[j*size:(j+1)*size].hex() for j in range(n)]
  out['plcs'][i]={'cp':cp,'data':v}
 art=pair(50);shapes=[]
 def walk(b):
  o=0
  while o<len(b):
   v,ins,ty,d,end=record(b,o)
   if ty==0xf004:
    shape={};a=0
    while a<len(d):
     cv,ci,ct,cd,ce=record(d,a)
     if ct==0xf00a:shape.update(id=u32(cd,0),type=ci,flags=u32(cd,4))
     if ct==0xf00d:shape['clientTextbox']=u32(cd,0)
     if ct in (0xf00b,0xf121,0xf122):
      shape.setdefault('properties',{}).update({hex(u16(cd,j*6)&0x3fff):u32(cd,j*6+2) for j in range(ci)})
     a=ce
    shapes.append(shape)
   elif v==15:walk(d)
   o=end
 _,_,_,_,o=record(art,0)
 while o<len(art):
  label=art[o];v,ins,ty,d,end=record(art,o+1);walk(d);o=end
 out['shapes']=shapes
 print(json.dumps(out,indent=2))
