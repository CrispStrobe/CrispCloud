import sys, pathlib, zipfile, xml.etree.ElementTree as ET, json
sys.path.insert(0, 'tool/fidelity')
from run import office_convert, command, parser_convert
from oracle import _xml
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
V='urn:schemas-microsoft-com:vml'
P='http://schemas.openxmlformats.org/package/2006/relationships'
root=pathlib.Path('build/textbox-native-scratch').resolve()
office=pathlib.Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
dart=pathlib.Path('/home/agent/.codex/skills/remote-skills/office-recovery-0905ba96fd2d/flutter-3.47.8/bin/cache/dart-sdk/bin/dart')
font='<w:rFonts w:ascii="Liberation Serif" w:hAnsi="Liberation Serif"/><w:sz w:val="24"/>'
def paragraph(text):
 return '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:rPr>'+font+'</w:rPr></w:pPr><w:r><w:rPr>'+font+'</w:rPr><w:t>'+text+'</w:t></w:r></w:p>'
def table(content, indent=720, margin=240):
 return '<w:tbl><w:tblPr><w:tblW w:w="2880" w:type="dxa"/><w:jc w:val="left"/><w:tblInd w:w="'+str(indent)+'" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="2880"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="2880" w:type="dxa"/><w:tcMar><w:left w:w="'+str(margin)+'" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tcMar></w:tcPr>'+content+'</w:tc></w:tr></w:tbl>'
box='<w:p><w:r><w:pict><v:rect id="BoxTable" o:allowincell="f" stroked="t" strokeweight="0.75pt" fillcolor="#FFFFFF" style="position:absolute;margin-left:72pt;margin-top:72pt;width:216pt;height:108pt;mso-position-horizontal-relative:page;mso-position-vertical-relative:page"><v:textbox inset="0,0,0,0"><w:txbxContent>'+paragraph('BOX')+table(paragraph('CELL'))+paragraph('AFTER_BOX')+'</w:txbxContent></v:textbox><w10:wrap type="none"/></v:rect></w:pict></w:r></w:p>'
for header in (False,True):
 for anchored in (False, True):
  name=('header' if header else 'main')+'-'+('table' if anchored else 'paragraph')
  d=root/name;d.mkdir()
  namespaces=f'xmlns:w="{W}" xmlns:r="{R}" xmlns:v="{V}" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w10="urn:schemas-microsoft-com:office:word"'
  anchor=table(box+paragraph('ANCHOR'),0,108) if anchored else box
  section='<w:sectPr>'+('<w:headerReference w:type="default" r:id="header"/>' if header else '')+'<w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr>'
  document=f'<w:document {namespaces}><w:body>'+ (paragraph('BODY') if header else anchor)+section+'</w:body></w:document>'
  types='<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'+('<Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/>' if header else '')+'</Types>'
  parts={'word/document.xml':document,'[Content_Types].xml':types,'_rels/.rels':f'<Relationships xmlns="{P}"><Relationship Id="main" Type="{R}/officeDocument" Target="word/document.xml"/></Relationships>'}
  if header:
   parts['word/header1.xml']=f'<w:hdr {namespaces}>'+anchor+'</w:hdr>'
   parts['word/_rels/document.xml.rels']=f'<Relationships xmlns="{P}"><Relationship Id="header" Type="{R}/header" Target="header1.xml"/></Relationships>'
  source=d/'source.docx'
  with zipfile.ZipFile(source,'x',compression=zipfile.ZIP_DEFLATED) as z:
   for n,s in parts.items():z.writestr(n,s)
  binary=office_convert(office,source,d/'bridge','doc')
  native=office_convert(office,binary,d/'native','docx')
  converted=d/'converted.docx'
  try:print(name,'parse',command([dart,'tool/fidelity/convert.dart',binary,converted]))
  except Exception as e:print(name,'ERROR',repr(e));continue
  for route,path in [('source',source),('binary',binary),('native',native),('converted',converted)]:
   if path.suffix=='.docx':
    with zipfile.ZipFile(path) as z:
     for n in z.namelist():
      if not n.startswith('word/') or not n.endswith('.xml'):continue
      parsed,_=_xml(z.read(n)); boxes=list(parsed.iter('{'+W+'}txbxContent'))
      if boxes:print(name,route,[(n,[x.get('{'+W+'}w') for x in b.iter('{'+W+'}tblInd')]) for b in boxes])
   pdf=office_convert(office,path,d/('render-'+route),'pdf')
   bbox=command(['pdftotext','-bbox-layout',pdf,'-'])
   parsed=ET.fromstring(bbox)
   words={e.text:e.attrib for e in parsed.iter() if e.tag.endswith('}word') and e.text in ('BOX','CELL','AFTER_BOX')}
   print(name,route,'words',words,flush=True)
