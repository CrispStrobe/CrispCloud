# SPDX-License-Identifier: MPL-2.0
# Replays retained literal-source controls, then explicitly exercises all three
# page variants. Native DOC is the layout oracle; no parser golden is written.
from pathlib import Path
import hashlib, json, subprocess, sys, zipfile
sys.path.insert(0, 'tool/fidelity')
from run import office_convert, render, render_comparison, parser_convert, command
root=Path('build/textbox-gaps-native').resolve()
office=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice')
before=root/'before-convert'; after=root/'after-convert'
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
# Reuse the independently literal-authored header table source. Add three body
# pages and explicitly select its one source header part for every page variant.
d=root/'header-three-pages'; d.mkdir()
with zipfile.ZipFile(root/'header-paragraph/source.docx') as z:
 parts={n:z.read(n).decode() for n in z.namelist()}
body='<w:p><w:r><w:t>PAGE_ONE</w:t><w:br w:type="page"/></w:r></w:p><w:p><w:r><w:t>PAGE_TWO</w:t><w:br w:type="page"/></w:r></w:p><w:p><w:r><w:t>PAGE_THREE</w:t></w:r></w:p>'
s=parts['word/document.xml'];a=s.index('<w:body>')+len('<w:body>');b=s.index('<w:sectPr>')
s=s[:a]+body+s[b:]
s=s.replace('<w:headerReference w:type="default" r:id="header"/>','<w:headerReference w:type="default" r:id="header"/><w:headerReference w:type="first" r:id="header"/><w:headerReference w:type="even" r:id="header"/>')
s=s.replace('</w:sectPr>','<w:titlePg/></w:sectPr>');parts['word/document.xml']=s
parts['word/settings.xml']=f'<w:settings xmlns:w="{W}"><w:evenAndOddHeaders/></w:settings>'
parts['word/_rels/document.xml.rels']=parts['word/_rels/document.xml.rels'].replace('</Relationships>',f'<Relationship Id="settings" Type="{R}/settings" Target="settings.xml"/></Relationships>')
parts['[Content_Types].xml']=parts['[Content_Types].xml'].replace('</Types>','<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/></Types>')
with zipfile.ZipFile(d/'source.docx','x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,s in parts.items():z.writestr(n,s)
office_convert(office,d/'source.docx',d/'bridge','doc')
results=[]
for name in ['header-paragraph','header-table','header-three-pages']:
 d=root/name; binary=d/'bridge/source.doc'; dest=d/'after.docx'
 r=subprocess.run([before,binary,d/'before.docx'],capture_output=True,text=True)
 (d/'before.log').write_text('exitCode='+str(r.returncode)+'\n'+r.stdout+r.stderr)
 record={'id':name,'sourceSha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'beforeExitCode':r.returncode,'beforeMessage':r.stderr,'conversion':parser_convert(after,binary,dest)}
 record['binary']=render(office,binary,d/'render-binary',72,raster_storage='gzip')
 record['converted']=render(office,dest,d/'render-after',72,raster_storage='gzip')
 record['comparison']=render_comparison(record['binary'],record['converted'])
 if name == 'header-three-pages':
  assert r.returncode == 0
  assert (d/'before.docx').read_bytes() == dest.read_bytes()
 else:
  assert r.returncode!=0 and 'Invalid Word drawing-to-textbox reference' in r.stderr
 pages=3 if name=='header-three-pages' else 1
 assert len(record['binary']['pages'])==len(record['converted']['pages'])==pages
 relative=[]
 for page,(a,b) in enumerate(zip(record['binary']['pages'],record['converted']['pages'])):
  markers=[]
  for p in [a,b]:
   values={word['text']:word['box'] for word in p['words'] if word['text'] in ['BOX','CELL','AFTER_BOX']}
   assert len(values)==3,values
   origin=values['BOX'];markers.append({key:[v-origin[i%2] for i,v in enumerate(box)] for key,box in values.items()})
  relative.append(max(abs(x-y) for key in markers[0] for x,y in zip(markers[0][key],markers[1][key])))
 record['maximumStoryRelativeDriftPoints']=max(relative)
 results.append(record)
 (root/'shared-header-native-report.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,record['comparison'],'relative',record['maximumStoryRelativeDriftPoints'],flush=True)
print('renderer',command([office,'--version']).strip())
