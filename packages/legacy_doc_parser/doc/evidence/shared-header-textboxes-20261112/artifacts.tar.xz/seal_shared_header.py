# SPDX-License-Identifier: MPL-2.0
import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path.cwd();scratch=root/'build/textbox-gaps-native'
evidence=root/'doc/evidence/shared-header-textboxes-20261112';evidence.mkdir(parents=True, exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def output(args):
 r=subprocess.run(args,text=True,capture_output=True,check=True);return (r.stdout or r.stderr).strip()
dart='/home/agent/.codex/skills/remote-skills/office-recovery-0905ba96fd2d/flutter-3.47.8/bin/cache/dart-sdk/bin/dart'
office='/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
fonts=output(['fc-list','--format','%{family}|%{style}|%{file}\n']);(scratch/'fonts.txt').write_text(fonts+'\n')
fontfiles={p:sha(Path(p)) for p in sorted({line.rsplit('|',1)[-1] for line in fonts.splitlines()})}
(scratch/'font-files.json').write_text(json.dumps(fontfiles,indent=2)+'\n')
receipt={'baseCommit':output(['git','rev-parse','HEAD']),'dart':output([dart,'--version']),'executableSha256':sha(scratch/'after-convert'),'sourceFiles':{str(p.relative_to(root)):sha(p) for p in sorted((root/'lib').rglob('*.dart'))},'runtimeDiff':output(['git','diff','--','lib'])}
(scratch/'after-source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
records=json.loads((scratch/'shared-header-native-report.json').read_text())
report={'schema':'legacy-doc-parser/shared-header-textboxes','version':1,'beforeSource':json.loads((scratch/'before-source-receipt.json').read_text()),'afterSource':receipt,'environment':{'renderer':output([office,'--version']),'textExtractorVersion':output(['pdftotext','-v']),'rasterizerVersion':output(['pdftoppm','-v']),'fontInventorySha256':hashlib.sha256('\n'.join(sorted(fonts.splitlines())).encode()).hexdigest(),'fontFilesSha256':hashlib.sha256(json.dumps(fontfiles,sort_keys=True,separators=(',',':')).encode()).hexdigest()},'method':'Exact native DOC source versus corrected parser DOCX, with original failure and unchanged independent page-variant control retained. Native DOCX is not a layout oracle. No golden update.','controls':records,'focusedTests':57,'analysis':'No issues found','recoveredImportCount':2,'unchangedValidControlCount':1}
(evidence/'report.json').write_text(json.dumps(report,indent=2)+'\n')
cases=[]
for stem,case in [('shared-header-textbox-paragraph','header-paragraph'),('shared-header-textbox-table','header-table'),('header-textbox-page-variants','header-three-pages')]:
 p=root/'test/fixtures/word_native'/f'{stem}.doc';assert sha(p)==sha(scratch/case/'bridge/source.doc')
 cases.append({'file':p.name,'sha256':sha(p),'authoredSourceSha256':sha(scratch/case/'source.docx'),'artifactCase':case,'requiresSharedRecovery':case!='header-three-pages'})
(root/'test/fixtures/word_native/shared-header-textboxes.provenance.json').write_text(json.dumps({'license':'MPL-2.0','renderer':report['environment']['renderer'],'origin':'Literal authored OOXML; native DOC bridge; exact bytes retained','authoring':'doc/evidence/shared-header-textboxes-20261112/artifacts.tar.xz:probe.py and probe_shared_header.py','originalTwoControls':'doc/evidence/textbox-table-context-20261112/artifacts.tar.xz','cases':cases},indent=2)+'\n')
paths=[p for p in sorted(scratch.rglob('*')) if p.is_file() and 'profile' not in p.relative_to(scratch).parts and p.suffix in {'.py','.dart','.log','.json','.doc','.docx','.pdf','.xml','.xhtml','.txt','.gz','.bin'}]
files=[];archive=evidence/'artifacts.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in paths:
  b=p.read_bytes();name=str(p.relative_to(scratch));info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b));files.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'archive':archive.name,'sha256':sha(archive),'files':files};(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as tar:
 for item in files:assert hashlib.sha256(tar.extractfile(item['path']).read()).hexdigest()==item['sha256']
print('Sealed',len(files),'files;',archive.stat().st_size,'archive bytes')
