import sys,os,json
from pathlib import Path
sys.path.insert(0,str(Path('tool/fidelity').resolve()))
from run import render, parser_convert, office_convert
from goldens import compare_render
out=Path('build/textbox-followup').resolve()
os.environ['TMPDIR']=str(out/'tmp')
results=[]
for context in ['body','header']:
 refs={}
 for name in ['default','explicit','disabled']:
  source=out/f'{context}-{name}.doc'
  ref=render('soffice',source,out/f'source-{context}-{name}',72,raster_storage='gzip')
  refs[name]=ref
  converted=out/f'{context}-{name}-baseline.docx'
  parser_convert(out/'baseline-convert',source,converted)
  actual=render('soffice',converted,out/f'baseline-{context}-{name}',72,raster_storage='gzip')
  results.append({'context':context,'kind':name,'source':ref,'baseline':actual,'comparison':compare_render(ref,actual)})
  print(context,name,results[-1]['comparison'],flush=True)
  (out/'controls-baseline.json').write_text(json.dumps(results,indent=2)+'\n')
 print('default-v-explicit',context,compare_render(refs['default'],refs['explicit']),flush=True)
