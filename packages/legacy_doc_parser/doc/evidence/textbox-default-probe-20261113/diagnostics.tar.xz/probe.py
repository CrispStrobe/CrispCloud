import sys, os, tarfile, zipfile, json, re
from pathlib import Path
sys.path.insert(0, str(Path('tool/fidelity').resolve()))
from run import render, office_convert
from goldens import compare_render
out=Path('build/textbox-followup').resolve()
os.environ['TMPDIR']=str(out/'tmp')
source=Path('test/fixtures/word_native/word14-margin-origin.doc').resolve()
base=out/'retained-wrap-output.docx'
with tarfile.open('doc/evidence/textbox-wrap-stroke-20261112/wrap-repeat/native-artifacts.tar.xz') as t:
 base.write_bytes(t.extractfile('run/word14-margin-origin/converted.docx').read())
results={}
ref=render('soffice',source,out/'original',72,raster_storage='gzip')
results['original']=ref
for variant in ['baseline','width-only','width-outer','width-inner']:
 target=out/(variant+'.docx')
 with zipfile.ZipFile(base) as z, zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as o:
  for info in z.infolist():
   b=z.read(info.filename)
   if info.filename=='word/document.xml' and variant!='baseline':
    xml=b.decode()
    def update(m):
     tag=m.group(0)
     tag=tag[:-1]+' strokeweight="0.75pt">'
     if variant!='width-only':
      amount=-.35 if variant=='width-outer' else .35
      for key, delta in [('margin-left',amount),('margin-top',amount),('width',-2*amount),('height',-2*amount)]:
       tag=re.sub(key+r':([-0-9.]+)pt',lambda q:key+':'+format(float(q[1])+delta,'.3f')+'pt',tag)
     return tag
    xml=re.sub(r'<v:rect\b[^>]*>',update,xml)
    b=xml.encode()
   o.writestr(info,b)
 actual=render('soffice',target,out/('render-'+variant),72,raster_storage='gzip')
 results[variant]={'render':actual,'comparison':compare_render(ref,actual)}
 print(variant,results[variant]['comparison'],flush=True)
 (out/'counterfactuals.json').write_text(json.dumps(results,indent=2)+'\n')
