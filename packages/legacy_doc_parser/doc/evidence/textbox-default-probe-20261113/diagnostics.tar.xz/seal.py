import hashlib,io,json,tarfile,shutil
from pathlib import Path
base=Path('build/textbox-followup')
out=Path('doc/evidence/textbox-default-probe-20261113')
sha=lambda b:hashlib.sha256(b).hexdigest()
shutil.copyfile('test/fixtures/word_native/word14-margin-origin.doc',base/'word14-source.doc')
counter=json.loads((base/'counterfactuals.json').read_text())
native=json.loads((base/'current-baseline/report.json').read_text())
case=native['cases'][0]
summary={
 'schema':'legacy-doc-parser/textbox-default-probe','version':1,
 'decision':'No textbox stroke-default or frame-geometry runtime change accepted.',
 'runtime':{'commit':native['parserCommit'],'worktreeDirty':native['parserWorktreeDirty'],'renderer':native['renderer'],'build':native['build']},
 'source':{'path':'test/fixtures/word_native/word14-margin-origin.doc','sha256':sha((base/'word14-source.doc').read_bytes())},
 'counterfactualInput':{'kind':'retained wrap-only parser output; output-only mutations, not runtime conversions','path':'retained-wrap-output.docx','sha256':sha((base/'retained-wrap-output.docx').read_bytes()),'originalRuntime':'ab575729720f0b6f7f2316e8613e7780be950356'},
 'counterfactuals':{name:counter[name]['comparison'] for name in ['baseline','width-only','width-outer','width-inner']},
 'currentRuntime':{'initial':case['pagination'],'cycles':[{'index':r['index'],**{k:r[k] for k in ['paginationFromBinaryDoc','paginationFromPreviousImport','paginationFromFirstImport']}} for r in case['roundtripCycles']]},
 'scope':{'counterfactualRepeatsRun':False,'counterfactualSchemaClaimed':False,'word14RuntimeDefaultChanged':False,'unsupportedEffectGuardRelaxed':False,'sourceCoordinatesChanged':False,'goldensChanged':False},
 'rejectedSyntheticControls':{'count':6,'reason':'Hand-assembled parser boundary fixtures do not reproduce their native source page dimensions or text; they are not native layout acceptance controls. Their missing/explicit-width source renders agree, but the same missing native textbox behavior makes that insufficient evidence for active output.'},
 'sources':[
  'https://learn.microsoft.com/en-us/openspecs/office_file_formats/ms-odraw/fb88b56e-2c2d-41c2-a0c8-98129e913b89',
  'https://learn.microsoft.com/en-us/openspecs/office_standards/ms-oi29500/d019f23f-5977-43d8-b463-99ba8f6784eb',
  'https://github.com/LibreOffice/core/blob/9a3be2502bf7762400fd0b655b6e42714cf2bb36/sw/source/filter/ww8/ww8graf.cxx'],
}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for path in sorted(base.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(base)
 if any(part=='tmp' or part.startswith('profile') for part in rel.parts):continue
 if path.suffix not in {'.py','.txt','.json','.doc','.docx','.pdf','.xhtml','.log','.gz'}:continue
 if path.name.startswith('guard-'):continue
 files.append(path)
manifest={'schema':'legacy-doc-parser/textbox-default-artifacts','version':1,'files':[]}
with tarfile.open(out/'diagnostics.tar.xz','w:xz',preset=6) as archive:
 for path in files:
  data=path.read_bytes();name=path.relative_to(base).as_posix()
  item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644
  archive.addfile(item,io.BytesIO(data))
  manifest['files'].append({'path':name,'sizeBytes':len(data),'sha256':sha(data)})
archive=(out/'diagnostics.tar.xz').read_bytes()
manifest['archive']={'path':'diagnostics.tar.xz','sizeBytes':len(archive),'sha256':sha(archive)}
manifest['summarySha256']=sha((out/'summary.json').read_bytes())
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(files),'archiveBytes':len(archive),'sha256':sha(archive)},indent=2))
