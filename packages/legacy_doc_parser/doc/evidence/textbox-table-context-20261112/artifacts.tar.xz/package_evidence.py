from pathlib import Path
import subprocess,json,hashlib,tarfile,io,xml.etree.ElementTree as ET
root=Path.cwd(); source=root/'build/textbox-native-scratch';out=root/'doc/evidence/textbox-table-context-20261112';out.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
models=[json.loads(line) for line in (source/'binary-model.jsonl').read_text().splitlines()]
for model in models:model.pop('sourceBytesUnchanged',None)
(source/'binary-model.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in models))
report={'schema':'legacy-doc-parser/textbox-table-context-counterexample','version':1,'baselineCommit':subprocess.check_output(['git','rev-parse','fdeb82c'],text=True).strip(),'rejectedCandidateCommit':subprocess.check_output(['git','rev-parse','233a76e'],text=True).strip(),'renderer':subprocess.check_output(['/opt/codex/runtimes/codex-primary-runtime/dependencies/bin/override/soffice','--version'],text=True).strip(),'method':'Literal authored OOXML controls share textbox table XML. Compare each exact native DOC source to baseline and rejected-candidate DOCX. Marker geometry is normalized once to BOX; absolute coordinates remain retained. Native DOCX is a separate observation, never the rendering oracle.','controls':[],'headerDiagnostics':{'header-paragraph':'Invalid Word drawing-to-textbox reference.','header-table':'Word header content is not a complete paragraph.'},'syntheticBinaryNativeLimitation':'The independently assembled table-story DOC used for parser/schema controls does not retain its textbox in this native renderer. Its native DOCX has only outer/nested anchor tables; the source PDF lacks BOX/CELL/AFTER_BOX. It is not used to assert native fidelity.'}
selected=[source/'probe.py',source/'probe.log',source/'binary-model.jsonl',source/'candidate-source-receipt.json',source/'package_evidence.py']
for name in ('main-paragraph','main-table','header-paragraph','header-table'):
 d=source/name
 for p in sorted(d.rglob('*')):
  if p.is_file() and ('profile' not in p.parts) and (p.suffix in ('.doc','.docx','.pdf','.log')):selected.append(p)
 if name.startswith('header'):continue
 record={'id':name,'binaryModel':next(x for x in models if x['id']==name),'routes':{}}
 for route in ('source','binary','native','converted','before'):
  pdfs=list((d/('render-'+route)).glob('*.pdf'))
  pdf=pdfs[0];bbox=subprocess.check_output(['pdftotext','-bbox-layout',str(pdf),'-'])
  bbox_path=pdf.with_suffix('.bbox.xml');bbox_path.write_bytes(bbox);selected.append(bbox_path)
  xml=ET.fromstring(bbox)
  matches={key:[e for e in xml.iter() if e.tag.endswith('}word') and e.text==key] for key in ('BOX','CELL','AFTER_BOX')}
  if any(len(values)!=1 for values in matches.values()):raise ValueError('Missing or duplicated marker')
  words={key:{k:float(v) for k,v in values[0].attrib.items()} for key,values in matches.items()}
  record['routes'][route]={'pdfSha256':sha(pdf),'markers':words,'cellOffsetPoints':round(words['CELL']['xMin']-words['BOX']['xMin'],6)}
 binary=record['routes']['binary']['cellOffsetPoints']
 record['baselineDriftPoints']=record['routes']['before']['cellOffsetPoints']-binary
 record['candidateDriftPoints']=record['routes']['converted']['cellOffsetPoints']-binary
 record['nativeDocxDriftPoints']=record['routes']['native']['cellOffsetPoints']-binary
 report['controls'].append(record)
report['decision']='Retract table-depth reset: baseline retains both binary relative offsets; candidate and native DOCX export add 12 points only for the table anchor.'
report['candidateRejected']=all(c['baselineDriftPoints']==0 for c in report['controls']) and report['controls'][1]['candidateDriftPoints']==12
if not report['candidateRejected']:raise ValueError('Counterexample no longer reproduced')
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
entries=[]
with tarfile.open(out/'artifacts.tar.xz','w:xz',preset=6) as archive:
 def add(path,name):
  data=path.read_bytes();item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;archive.addfile(item,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 for path in sorted(set(selected)):add(path,path.relative_to(source).as_posix())
 add(root.parent/'native-before-parser/source-receipt.json','baseline-source-receipt.json')
 for base,label in [(root/'build/textbox-table-controls','synthetic'),(root/'build/textbox-table-native','synthetic-native')]:
  for path in sorted(base.rglob('*')):
   if not path.is_file() or 'profile' in path.parts or path.suffix not in ('.doc','.docx','.pdf'):continue
   if base.name=='textbox-table-controls' and path.stem!='textbox-main-default-flat-table':continue
   add(path,label+'/'+path.relative_to(base).as_posix())
manifest={'archive':'artifacts.tar.xz','sha256':sha(out/'artifacts.tar.xz'),'entries':entries}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'artifacts.tar.xz','r:xz') as archive:
 actual={p.name:hashlib.sha256(archive.extractfile(p).read()).hexdigest() for p in archive.getmembers()}
assert actual=={p['path']:p['sha256'] for p in entries}
print(json.dumps({'files':len(entries),'archiveBytes':(out/'artifacts.tar.xz').stat().st_size,'candidateRejected':True,'archiveVerified':True}))
